<template>
  <v-container > 
    <h3>Styles</h3>
  </v-container>
</template>

<style>
    /*Diseño de las tablas de las consultas*/
    .line_superior{
        width:50%;
    }
    #title{
        color:#fca311;
        text-shadow: 2px 3px 3px #ccc;
        font-family: Corbel;
        font-size: 230%;
    }
    .card_title{
        padding-bottom:0
    }
    #table_cabecera_color{
        background-color:#14213d;
        height:60px;
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
    }

    
    .btn_search{
        float:left;
    }
    .btn_folio{
        float:right;
    }
    .btn_csv{
        float:right;
        border:2px solid white;
        border-radius:20px;
        width:170px;
    }
    .btn_add{
        float:right;
        border:2px solid white;
        border-radius:20px;
        width:170px;
    }
    .btn_gped{
        float:center;
        border:2px solid white;
        border-radius:20px; 
    }
    .fieldCant{
        float:center;
        width:100px;  
    }
    .field-cantidad{
        float:center;
        width:50px;   
    }
    .select_status{
        float:right;
        width:35%;  
        border-radius:20px; 
    }
    #tabla_datos{
        background-color:#ECECEC;
        width:99.5%;
    }

    /*Diseño de panel de Módulos*/
    .design_images{
        top: -100px;
        margin-bottom: -70px;
        max-width:180px;
    }
    #design_card{
        border-radius:25px;
    }
    /* Diseño de menu lateral */
     #menu_lateral{
        background-color:#fca311;
        height:130%; background-color:#fca311;
    }
    #letras_menu_superior{
        color:#14213d;
        font-size:16px;
        position: relative;
       font-weight: bold;
        
    }

    
    #iconos_menu_superior{
        color:#000;
        font-size:25px;
    }
     /* Menu de registro*/
    #btn_guardar_formulario{
        background-color:#fca311;
        color:#fff;
        border-radius: 70px;
        
        
     }

     #btn_borrar_formulario{
        background-color:#DC7633 ;
        color:#fff;
        border-radius: 70px;
        
        
     }

     #btn_cancelar_formulario{
        background-color:#C0392B;
        color:#fff;
        border-radius: 70px;
        
        
     }
     #btn_agrega_otro_formulario{
        background-color:#E65100;
        color:#fff;
        border-radius: 70px;
        
        
     }
     #btn_actualizar_formulario{
        background-color:#D4AC0D;
        color:#fff;
        border-radius: 70px;
        
        
     }
      #btn_inic{
        background-color:#14213d;
        float:right;
        border:2px solid white;
        border-radius:20px;
        color:#fff;
    }
   

     #title_cabecera{
        color:#000000;
        font-family: Corbel;
        font-size: 90%;
        
    }
     #title_editar{
        color:#F7F9F9 ;
        font-family: Corbel;
        font-size:110%;
        
    }


    #table_cabecera_color_formulario{
        background-color:#14213d;
        height:60px;
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
    }

    #cabecera_color_azul{
        background-color:#14213d;
    }
    #cabecera_color_amarilla{
        background-color:#D4AC0D;
    }
      
   #title_formulario{
        background-color:#AEB6BF;
        height:40px;
        border-radius: 12px;
        
    }
  

   #tabla_datos_dos{
        background-color:#f5f5f5;
        width:200%;
         
       
    }
    #table_cabecera_color_camb_pass{
        background-color:#14213d;
        height:60px;
        border-radius: 12px;
    }
</style>