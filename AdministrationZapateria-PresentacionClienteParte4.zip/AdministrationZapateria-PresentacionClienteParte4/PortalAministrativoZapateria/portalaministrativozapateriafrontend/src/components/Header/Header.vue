<template>
    <div>
        <!--<v-btn depressed to="/">INICIO</v-btn>
        <v-btn depressed to="/Proveedores">PROVEEDORES</v-btn>-->
        
      
    <!--
    <v-chip
      class="ma-2"
      color="indigo"
      text-color="white"
      
    >
      <v-avatar right>
        <v-icon>mdi-account-circle</v-icon>
      </v-avatar>
      Mike
    </v-chip>-->

    </div>
</template>