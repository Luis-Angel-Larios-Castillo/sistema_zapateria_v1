<template>
  <v-card
    class="mx-auto"
    height="685"
    width="310"
  >
    <v-navigation-drawer
      absolute
      dark
      color="#9E9E9E"
      width="200%"
      permanent
    >
    <br>
    <br>
    <br>
    <v-btn text to="/">INICIO</v-btn>
    <br> 
    <br>
   <v-btn text to="/Proveedores">PROVEEDORES</v-btn>
   <br>
   <v-btn   rounded  text to="/RegistroProveedores">REGISTRAR</v-btn>
     <br>
     <br>
   <v-btn text to="/Empleados">Empleados</v-btn>
   <br>
   <v-btn   rounded  text to="/Usuarios">REGISTRAR</v-btn>
     <br>
     <br>
       <v-btn text to="/Clientes">Clientes</v-btn>
   <br>
   
   <v-btn   rounded  text to="/Usuario">REGISTRAR</v-btn>
     <br>
     <br>
     <v-btn text to="/ClientesNoAfi">Clientes No Afiliados</v-btn>
   <br>
   <v-btn   rounded  text to="/RegistroClientesNoAfi">REGISTRAR</v-btn>
     <br>
   
        
    </v-navigation-drawer>
  </v-card>
</template>
