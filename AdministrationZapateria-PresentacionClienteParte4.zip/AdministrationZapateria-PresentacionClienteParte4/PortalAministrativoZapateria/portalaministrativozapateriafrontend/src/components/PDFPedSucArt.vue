Autor: Miguel Angel Zamora Carmona
Descripción: En el presente archivo se muestra el formulario del PDF para el ticket de pedido.
<template>
  <div>   
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
        <v-btn icon color="blue" @click="generatePDF" v-bind="attrs" v-on="on">
            <v-icon>mdi-cloud-print-outline</v-icon>
        </v-btn>
        </template>
        <span>Imprimir</span>
    </v-tooltip> 
  </div>
</template>
<script> 
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
const axios = require('axios') 
const moment = require('moment')
export default {
    props: [
      'id', 
    ],
    
  data() {
    return {
      cabecera: [],
      heading: "",
      fecha: "", 
      prov: '',
      suc: '',
      arr: [ ]
    };
  },
  created() {  
    
    
  }, 
  methods: { 
    generatePDF() {  
      axios.get('http://127.0.0.1:8000/pedsuc/cab/' + this.id + '/')
      .then(resCab => {
        this.heading = resCab.data.zpedsuc_nombre
        this.fecha = moment(resCab.data.zpedsuc_fech_creat).locale('MX').format('DD-MM-YYYY') 
        this.prov = 'Proveedor: ' + resCab.data.zpedpro_proveedor_nombre
        this.suc = 'Sucursal: ' + resCab.data.zpedsuc_sucursal
        axios.get('http://127.0.0.1:8000/pedsuc/item/?search=' + resCab.data.zpedsuc_id_ped_sucur)
        .then(res => {
          this.arr = res.data
          const columns = [
              { title: "#", dataKey: "zpedsuca_cant_ped" },
              { title: "Articulo", dataKey: "zpedsuca_model" }, 
              { title: "Color", dataKey: "zpedsuca_color" },
              { title: "Talla", dataKey: "zpedsuca_talla" }, 
          ]; 
          const doc = new jsPDF({
              orientation: "portrait",
              unit: "in",
              format: "letter",
          }); 
          let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
          doc.setFont(undefined, 'bold').setFontSize(40).text(this.heading, pageWidth / 2, 1.0, {align: 'center'}); 
          
          doc.setFont(undefined, 'bold').setFontSize(40).text(this.fecha, pageWidth / 2, 1.8, {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(40).text(this.prov, pageWidth / 2, 2.6, {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(40).text(this.suc, pageWidth / 2, 3.4, {align: 'center'}); 
          
          doc.setDrawColor(0);
          doc.setFillColor(255, 255, 255); 
          //Sección de Nombre de Pedido
          doc.setLineWidth(0.05).roundedRect(2.5, 3.7,    5,      2,    .3, .3, "FD");
          doc.setFont(undefined, 'bold').setFontSize(40).text("Firma:", 0.7, 4.8);  
          doc.autoTable({
              showHead: 'firstPage',
              styles: { fontSize: 35, halign: 'center' },
              columns,
              theme: 'plain',
              body: this.arr,
              margin: { left: 0.5, top: 6.4 }
          }); 
          doc.autoPrint();
          doc.output('dataurlnewwindow');



        })
      }) 
        
        
        

        //doc.save(`${this.heading}.pdf`);
    },
  },
};
</script>