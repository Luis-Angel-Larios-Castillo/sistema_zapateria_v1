Autor: Ely
Modifico: Miguel Angel Zamora Carmona
Descripción: Este archivo consta del Footer
<template>
  <v-container>
    Zapatería Deny's - {{year}}
  </v-container>
</template>
<script>
const moment = require('moment')
export default {
  data() {
    return {
      year: moment().format("YYYY")
    }
  },
}
</script>

