Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un botón para imprimir el corte de turno 
<template>
<div>
    <v-btn color='blue' text class="white--text" @click='generatePDF'>Imprimir</v-btn>
</div>
</template>
<script>
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable"
export default {    
  props:[
      'corteData'
  ],
  data() {
  return {
    heading: "",
    total: '',
    items: []
  };
  },
  created() {
      this.items = this.corteData.movimientos,
      this.total = 'Total: $'+ this.corteData.total,
      this.heading =  'Reporte de ventas de '+ this.corteData.fecha 
      this.empleado =  'Empleado: '+ this.corteData.empleado
  },
  methods: {
    generatePDF() {
      this.items = this.corteData.movimientos,
      this.total = 'Total: $'+ this.corteData.total,
      this.heading =  'Reporte de ventas de '+ this.corteData.fecha 
      this.empleado =  'Empleado: '+ this.corteData.empleado
      const columns = [
        { title: "Titulo", dataKey: "zca_nombre" },
        { title: "Hora", dataKey: "zca_hora" },
        { title: "Tipo de transacción", dataKey: "zca_tipo" },
        { title: "Subtotal", dataKey: "zca_total" }
      ];
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "in",
        format: "letter"
      });
      doc.setFontSize(16).text(this.heading, 0.5, 1.0);
      doc.setFontSize(14).text(this.total, 0.5, 1.4);
      doc.setFontSize(14).text(this.empleado, 0.5, 1.7);
      doc.setLineWidth(0.05).line(0.5, 1.8, 8.0, 1.8);
      doc.autoTable({
        columns,
        theme: 'plain',
        body: this.items,
        margin: { left: 0.5, top: 1.9 }
      });
      doc
        .save(`${this.heading + ' - ' + this.corteData.empleado}.pdf`);
    }
    }
    
}
</script>