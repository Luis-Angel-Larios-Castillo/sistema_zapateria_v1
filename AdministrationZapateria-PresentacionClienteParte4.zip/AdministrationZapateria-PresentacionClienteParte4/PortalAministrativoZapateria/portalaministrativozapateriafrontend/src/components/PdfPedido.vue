Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el formulario del PDF para el ticket de pedido.
<template>
  <div>
    <v-btn color="blue" text class="white--text" @click="generatePDF">
      Imprimir
    </v-btn>
 
  </div>
</template>
<script>

import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
const axios = require('axios') 
export default {
  props: ["pedidoData"],
    
  data() {
    return {
      heading: "",
      total: "",
      items: [],
      nombre: ""
    };
  },
  created() {
    this.getName()
  },
  updated() {
    this.getName()
  },
  methods: {
    getName(){
      axios.get('http://127.0.0.1:8000/usuario/getusuario/'+this.pedidoData.cabecera.zped_id_usuario+'/')
      .then(res =>{ 
        if(res.data.is_superuser==false){
            if(res.data.is_staff==false){
              axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.pedidoData.cabecera.zped_id_usuario)
              .then(respuesta=>{
                this.nombre = 'Cliente: ' + respuesta.data[0].zc_nombre + ' ' + respuesta.data[0].zc_apell_pat + ' ' + respuesta.data[0].zc_apell_mat
                
              })
            }
            else{
              axios.get('http://127.0.0.1:8000/empleado/?search='+this.pedidoData.cabecera.zped_id_usuario)
              .then(respuesta=>{
                this.nombre = 'Trabajador: ' + respuesta.data[0].zdem_nombre + ' ' + respuesta.data[0].zdem_apell_pat + ' ' + respuesta.data[0].zdem_apell_mat
                
              })
          }
        }
        else{ 
          this.nombre = 'Administrador: ' + this.pedidoData.cabecera.zdus_correo 
        }
      })
    },
    generatePDF() {
      (this.total = "Total: $" + this.pedidoData.cabecera.zipe_total),
      (this.heading =
        "Pedio: " +
        this.pedidoData.cabecera.zped_nombre +
        " - Estatus: " +
        this.pedidoData.cabecera.zped_status +
        " - Fecha del pedido: " +
        this.pedidoData.cabecera.zped_fecha 
      );
      (this.items = this.pedidoData.items)
          
      
      const columns = [
        { title: "#", dataKey: "zipe_cant" },
        { title: "Articulo", dataKey: "zipe_art_nom" },
        { title: "Estatus", dataKey: "zipe_status" },
        { title: "Color", dataKey: "zipe_color" },
        { title: "Talla", dataKey: "zipe_talla" },
        { title: "SubTotal", dataKey: "zipe_sub_tot" },
      ];
     
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "in",
        format: "letter",
      });
    doc.setFontSize(16).text(this.heading, 0.5, 1.0);
      doc.setFontSize(14).text(this.total, 0.5, 1.4);
      doc.setFontSize(14).text(this.nombre, 0.5, 1.7);
      doc.setLineWidth(0.05).line(0.5, 1.8, 8.0, 1.8);
      doc.autoTable({
        columns,
        theme: 'plain',
        body: this.items,
        margin: { left: 0.5, top: 1.9 }
      });

      doc.save(`${this.heading}.pdf`);
    },
  },
};
</script>