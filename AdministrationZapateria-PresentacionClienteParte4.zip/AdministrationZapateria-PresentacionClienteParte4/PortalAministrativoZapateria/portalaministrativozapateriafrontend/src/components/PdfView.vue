Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un botón para imprimir el corte general
<template>
  <div>
    <v-btn color="blue" text class="white--text" @click="generatePDF">
      Imprimir
    </v-btn>
  </div>
</template>
<script>
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
export default {
  props: ["corteData"],
  data() {
    return {
      heading: "",
      total: "",
      items: [],
    };
  },
  methods: {
    generatePDF() {
      (this.items = this.corteData.corteItems),
        (this.total = "Total: $" + this.corteData.totalCorte),
        (this.heading =
          "Reporte de ventas de " +
          this.corteData.fInicio +
          " al " +
          this.corteData.fFin);
      const columns = [
        { title: "Fecha", dataKey: "zca_fecha" },
        { title: "Hora", dataKey: "zca_hora" },
        { title: "Tipo de transacción", dataKey: "zca_tipo" },
        { title: "Empleado", dataKey: "zca_empleado" },
        { title: "Total", dataKey: "zca_total" },
      ];
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "in",
        format: "letter",
      });
      doc.setFontSize(16).text(this.heading, 0.5, 1.0);
      doc.setFontSize(14).text(this.total, 0.5, 1.4);
      doc.setLineWidth(0.01).line(0.5, 1.5, 8.0, 1.5);
      doc.autoTable({
        columns,
        theme: "plain",
        body: this.items,
        margin: { left: 0.5, top: 1.55 },
      });
      doc.save(`${this.heading}.pdf`);
    },
  },
};
</script>