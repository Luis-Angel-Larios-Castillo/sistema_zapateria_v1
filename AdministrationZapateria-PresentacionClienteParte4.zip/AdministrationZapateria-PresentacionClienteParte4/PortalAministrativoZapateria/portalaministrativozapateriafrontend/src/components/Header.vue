Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo consta del Header 
<template>
<div>
    <div>
      <v-row>
        <v-col class="col-8">
          <div style="float:right;">
          <v-btn :to="'/'" text id="letras_menu_superior">
         INICIO
        </v-btn>

          <v-menu offset-y  v-for="dpto in dptos" :key="dpto.zde_id_dep" open-on-hover>
            <template v-slot:activator="{ on, attrs }">
              <v-btn  text v-bind="attrs" v-on="on" :to="'/departamento/'+ dpto.zde_id_dep" id="letras_menu_superior">
                {{dpto.zde_nombre}}
              </v-btn>
            </template>
            
            <v-list style="background:#14213d; opacity: 0.9; width:500px;color:#fff; scroll:none;">
              
                <v-row>
                  <v-col>
                    <strong>CALZADO</strong>
                  </v-col>
                  <v-col>
                    <strong>ROPA</strong>
                  </v-col>
                  <v-col>
                    <strong>ACCESORIOS</strong>
                  </v-col>
                </v-row>
               

              <v-row style="margin-top:-30px;">
                  <v-col>
                    <v-list-item v-for="subdpto in subdptos" :key="subdpto.zsude_id_subdep" v-if="subdpto.zsude_id_dep == dpto.zde_id_dep && subdpto.zsude_categoria == 'Calzado'">
                      <v-btn :to="'/departamento/'+ subdpto.zsude_id_subdep"  text dark>
                        {{subdpto.zsude_nombre}}
                      </v-btn>
                    </v-list-item>
                  </v-col>
                  <v-col>
                    <v-list-item v-for="subdpto in subdptos" :key="subdpto.zsude_id_subdep" v-if="subdpto.zsude_id_dep == dpto.zde_id_dep && subdpto.zsude_categoria == 'Ropa'">
                      <v-btn :to="'/departamento/'+ subdpto.zsude_id_subdep"  text dark>
                        {{subdpto.zsude_nombre}}
                      </v-btn>
                    </v-list-item>
                  </v-col>
                  <v-col>
                    <v-list-item v-for="subdpto in subdptos" :key="subdpto.zsude_id_subdep" v-if="subdpto.zsude_id_dep == dpto.zde_id_dep && subdpto.zsude_categoria == 'Accesorios'">
                      <v-btn :to="'/departamento/'+ subdpto.zsude_id_subdep"  text dark>
                        {{subdpto.zsude_nombre}}
                      </v-btn>
                    </v-list-item>
                  </v-col>
                  
                </v-row>
              
              <br>
            </v-list>
          </v-menu>
          </div>
        </v-col>
          <v-col v-if="logeado" class="col-1"> 
          <!--<v-col v-if="ocultar">-->
          <!--<v-tooltip bottom v-if="logeado">-->
             <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
              <v-badge bottom :content="numItems" :value="numItems" color="black"  overlap  >
                <v-btn icon to="/carrito/" v-bind="attrs" v-on="on">
                  <v-icon  id="iconos_menu_superior" >mdi-shopping-outline</v-icon>
                </v-btn>
              </v-badge>
            </template>
            <span>Mis Pedidos</span>
          </v-tooltip>
        </v-col>
         <v-col v-if="logeado"> 
            <v-menu transition="fab-transition">
                  <template v-slot:activator="{ on, attrs }"  style="background:red;">
                    <v-btn icon raised rounded v-bind="attrs" v-on="on">
                      <v-avatar
                      class="white--text"
                       color="primary"
                        size="30"
                      >
                        {{ava}}
                      </v-avatar>
                    </v-btn>
                     
                  </template>
                  <v-list  style="background:#14213d; opacity: 0.9;">
                     <v-list-item >
                      <v-list-item-title> 
                        <v-btn to="/perfil/" v-if="logeado">
                          <v-icon >mdi-account</v-icon> Ver Perfil
                        </v-btn>  
                      </v-list-item-title>
                    </v-list-item>
                    <v-list-item >
                      <v-list-item-title> 
                        <v-btn @click="logout ()" text v-if="logeado" dark style="color:white;">
                          Cerrar sesión
                        </v-btn> 
                      </v-list-item-title>
                    </v-list-item>
                   
                  </v-list>
              </v-menu>
               <span style="color:#14213d; margin-left:10px;  text-align: center; font-weight: bold;">{{nombremepl}}</span>  
          </v-col>
          <v-col v-if="!logeado">
              <v-btn to="/login/" id="btn_inic">Ingreso</v-btn>
             
               <v-btn to="/Usuario"  id="btn_inic" >Registro</v-btn>
          </v-col> 
          <v-col class="col-1" v-if="logeado && isStaffUser == true">
            <v-menu transition="slide-y-transition">
                  <template v-slot:activator="{ on, attrs }">
                    <v-btn
                      icon
                      raised
                      rounded
                      color="#14213d"
                      v-bind="attrs"
                      v-on="on"
                    >
                      <v-icon >mdi-menu</v-icon>
                    </v-btn>
                  </template>
                  
                  <v-list  style="background:#14213d; opacity: 0.9;">
                    <v-list-item >
                      <v-list-item-title> 
                        <v-btn :to="'/articulos/'" v-if="isStaffUser == true" text dark  width="100%">
                          <v-icon style="margin-right:10px;">mdi-bag-personal</v-icon>  Almacén
                        </v-btn>
                      </v-list-item-title>
                    </v-list-item>
                    <hr width="80%">
                    <v-list-item align="left">
                      <v-list-item-title> 
                        <v-btn :to="'/listcaja/'" v-if="isStaffUser == true" text dark width="100%">
                           <v-icon style="margin-right:10px;">mdi-clipboard-text-multiple-outline</v-icon> Movimientos    
                        </v-btn>
                      </v-list-item-title>
                    </v-list-item>
                  </v-list>
          </v-menu>
          </v-col>
        </v-row>
  </div>
</div>
</template>
<script>
const axios = require('axios')  
export default { 
  created() {
     this.findemplado()

    axios.get("http://127.0.0.1:8000/departamentos/dep/")
      .then(res=> this.dptos = res.data)
    axios.get("http://127.0.0.1:8000/departamentos/subdep/")
      .then(res=> this.subdptos = res.data)
    if(localStorage.token){
      axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then(res => {
          this.logeado= true
          if(localStorage.type){
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/')
              .then(res=>{
                axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
                  .then(res=> {
                    //this.consultarItems()
                      if(res.data.is_staff == true){
                          this.isStaffUser = true
                      }else{
                          this.isStaffUser = false
                      }
                  })
              })
          }  
          })
          .catch(error => { localStorage.token ='', this.logeado= false })
          this.isStaffUser = localStorage.type
      }
  },
  data() {
    return {
      token: localStorage.token,
      logeado: false,
      isStaffUser: false,
      numItems: 0,
      dptos: [],
      subdptos: [],
      ocultar: true,
      nombremepl:"",
      dataiduser:[],
      ava:""
    
    }
  },
  methods: {

   

    findemplado(){
      if(localStorage.token != ''){
        axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/')
        .then(res=> { 
          
          if(localStorage.type){
          this.dataiduser = res.data.user
        
        axios.get('http://127.0.0.1:8000/empleado/?search='+this.dataiduser)
        .then(res=> { 

          if(res.data.length == 0){

               axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.dataiduser)
              .then(res=> { 
                   this.nombremepl = res.data[0].zc_nombre              
                    this.ava = this.nombremepl.substr(0,1) 
                
              })

            
          }else{
              this.nombremepl = res.data[0].zdem_nombre              
            this.ava = this.nombremepl.substr(0,1) 
          }
       
      
          })
           }
        else{}
        }).catch(error => { localStorage.token = '' })}
        else{}
    },



    buscarSubdptos(id){
      let arr
      axios.get("http://127.0.0.1:8000/departamentos/subdep/?search=" + id)
        .then(res=> {console.log(res.data), arr = res.data})
      return arr
    },
    comprobarToken(){
      axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then(res => { 
          console.log(res)
          this.logeado= true
          if(localStorage.type){
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/')
              .then(res=>{
                axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
                  .then(res=> {
                      if(res.data.is_staff == true){
                          this.isStaffUser = true
                      }else{
                          this.isStaffUser = false
                      }
                  })
              })
          }  
        })
          .catch(error => { localStorage.token = '', this.logeado = false })
    },
    /*Funcion inutilizada por modificaciones en el modulo pedidos 
    consultarItems(){ 
      axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then((res) => {
            this.idUser = res.data.user
              axios.get('http://127.0.0.1:8000/pedido/pcuactiv/?search='+res.data.user)
                .then((res) => {
                    if(res.data.length == 0){ 
                        axios.post('http://127.0.0.1:8000/pedido/pedcab/',{
                            "zped_status": "Activo",
                            "zped_fecha":  new Date().toISOString().slice(0,10),
                            "zipe_total": 0,
                            "zped_id_usuario": this.idUser
                        }).then(res=> window.location.reload())
                      }
                    this.pedidoActivo = res.data[0],
                    axios.get('http://127.0.0.1:8000/pedido/itembpc/?search='+res.data[0].zped_id_pedcab)
                        .then(res=> {
                                this.numItems = res.data.length
                        })
                    })
        }) 
    },
    */
    logout(){
        axios.delete('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then((res)=> {
          this.logeado = false, 
          localStorage.type = false, 
          this.isStaffUser = false,
          localStorage.token = '',
          this.$router.replace({name: 'Login'})
          })
        .catch((error)=>{this.logeado = false, localStorage.token = '', localStorage.type = false })
    }
  }, 
  watch:{
    $route (to, from){
        if(localStorage.token){
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
            .then(res => {
              this.logeado= true
              if(localStorage.type){
                axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/')
                  .then(res=>{
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
                      .then(res=> {
                        //this.consultarItems()
                          if(res.data.is_staff == true){
                              this.isStaffUser = true
                          }else{
                              this.isStaffUser = false
                          }
                      })
                  })
              }  
              })
            .catch(error => { localStorage.token ='', this.logeado= false })
            this.isStaffUser = localStorage.type
        }
    }
}  
}
</script>