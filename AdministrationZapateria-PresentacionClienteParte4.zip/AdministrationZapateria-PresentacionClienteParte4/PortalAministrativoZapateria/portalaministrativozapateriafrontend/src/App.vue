<template>
  <center>
  <v-app>
   <!-- <v-app-bar app color="Primary" >-->
      <!--<app-header style="z-index: 135"/>-->
   <!-- </v-app-bar>-->
    <v-main>
      <router-view/>  
    </v-main>
   <!-- <v-footer  dark>
      <app-footer/>
    </v-footer>-->
  </v-app>
  </center>
</template>

<script>
const axios = require('axios')
window.onload = function Ejemplo(){ 
  let usuario = {
    zdus_correo: 'zapateria@denys.com',
    password: 'Hola@1234',
    password_confirmation: 'Hola@1234'
  }
  let empleado = {
    "zdem_id_usuario": '',
    "zdem_nombre": 'Administrador',
    "zdem_apell_pat": 'Sucursal',
    "zdem_apell_mat": 'Matriz',
    "zdem_num_tel": '241-000-00-00',
    "zdem_num_cel": '241-000-00-00',
    "zdem_id_sucursal": '',
    "zdem_fech_nacim": '2021-08-31',
    "zdem_dir_pais": 'México',
    "zdem_correo": usuario.zdus_correo,
    "zdem_dir_estado": 'Tlaxcala',
    "zdem_dir_municipio": 'Tlaxcala',
    "zdem_dir_colonia": 'Colonia Tlaxcala Centro',
    "zdem_dir_cod_postal": '90000',
    "zdem_dir_calle_1": 'Calle 01',
    "zdem_dir_calle_2": 'Calle 02',
    "zdem_dir_num_int": 'Num 01',
    "zdem_dir_num_ext": 'Num 01',
  }
  let sucursal = {
    "zdsu_nombre": 'Matriz',
    "zdsu_dir_calle_1": 'Calle 01',
    "zdsu_dir_calle_2": 'Calle 02',
    "zdsu_dir_colonia": 'Colonia Tlaxcala Centro',
    "zdsu_dir_municipio": 'Tlaxcala',
    "zdsu_dir_estado": 'Tlaxcala',
    "zdsu_dir_pais": 'México',
    "zdsu_dir_cod_postal": '90000',
    "zdsu_dir_num_ext": 'Num 01',
    "zdsu_dir_num_int": 'Num 02',
    "zdsu_num_tel": '241-000-00-00',
    "zdsu_estat_sucur": true,
    "zdsu_folio_surcur": "FOL" + " - "+ 'TLX' +" - "+ Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1)),
  }
  
  let existUser = false
  axios.get('http://127.0.0.1:8000/usuario/getusuario/')
    .then(res => {
      res.data.forEach(user => { 
        if(user.zdus_correo.toLowerCase() == usuario.zdus_correo.toLowerCase()){
          existUser = true
        }
      }); 
      if(existUser == false){ 
        axios.post('http://127.0.0.1:8000/sucursal/', sucursal) 
        .then(resSuc => {
          axios.post('http://127.0.0.1:8000/usuario/signupadmin/', usuario) 
          .then(resUs => {
            empleado.zdem_id_usuario = resUs.data.zdus_id_usuario
            empleado.zdem_id_sucursal = resSuc.data.zdsu_id_sucursal
            axios.post('http://127.0.0.1:8000/empleado/', empleado)
          })
        })
        
      }
    })
} 
//import Footer from './components/Footer/Footer';
//import Header from './components/Header';
import Navigation from './components/Menu/Navigation'; 
export default {
  //name: 'Header', 
  name: 'Footer',
  name: 'Navigation',
  components: {
    //"app-header": Header,
    //"app-footer": Footer,
    "app-navigation": Navigation,

 },
 

  
  
};
 </script>
 