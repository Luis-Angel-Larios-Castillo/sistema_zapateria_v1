import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Proveedores from '../views/Proveedores/Proveedores.vue'
import RegistroProveedores from '../views/Proveedores/RegistroProveedores.vue'
import Actualizar from '../views/Proveedores/EditarProveedor.vue'
import Empleados from '../views/Empleados/Empleados.vue'
import RegistroEmpleados from '../views/Empleados/RegistroEmpleados.vue'
import ActualizarEmpleados from '../views/Empleados/EditarEmpleado.vue'
import Usuarios from '../views/moduloUsuarios/Logind.vue'
import Usuario from '../views/moduloUsuarios/LoginCliente.vue'
import Login from '../views/moduloUsuarios/Login.vue'
import Clientes from '../views/ClientesAfiliados/Clientes.vue'
import RegistroClientes from '../views/ClientesAfiliados/RegistroClientes.vue'
import ActualizarCliente from '../views/ClientesAfiliados/EditarCliente.vue'
import cargacsv from '../views/moduloArticulos/cargacsv/cargacsv.vue'
import Devoluciones from '../views/moduloCaja/devoluciones/Devoluciones.vue'
import ProveedorHist from '../views/Proveedores/ProveedoresHistorico.vue' 
const axios = require('axios')

Vue.use(VueRouter)

const routes = [  
  {
    path: '/clientesnoafi', 
    name: 'ClientesNoAfi',
    component: () => import(/* webpackChunkName: "about" */ '../views/ClientesNoAfiliados/ClientesNoAfi.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/DetailPedCatProveedor/:id',
    name: 'DetailPedCatProveedor',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedCaProv/partials/_DetailPedidoCaProv.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/ListPedCatalogoPro',
    name: 'ListPedCatalogoPro',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedCaProv/ListPedCatalogoPro.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/DetailPedCatSucursal/:id',
    name: 'DetailPedCatSucursal',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedCaSuc/partials/_DetailPedCatSucursal.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/ListPedCatSucursal',
    name: 'ListPedCatSucursal',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedCaSuc/ListPedCatalogoSuc.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/DetailPedidoPro/:id',
    name: 'DetailPedidoPro',
    component: () => import('../views/moduloPedProveedor/partials/_DetailPedidoPro.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/ListPedProveedor',
    name: 'ListPedProveedor',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedProveedor/ListPedProveedor.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/PedSucursal/:id',
    name: 'PedSucursal',
    component: () => import('../views/moduloPedSucursal/partials/_DetailPedidoSuc.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/ListPedSucursal',
    name: 'ListPedSucursal',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedSucursal/ListPedSucursal.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/cGroup',
    name: 'cGroup',
    component: () => import('../views/moduloPermissions/partials/cGroup.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/uGroup/:id',
    name: 'uGroup',
    component: () => import('../views/moduloPermissions/partials/uGroup.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/ListGroups',
    name: 'ListGroups',
    component: () => import('../views/moduloPermissions/ListGroups.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/listUserPermissions',
    name: 'ListUsuariosPermissions',
    component: () => import('../views/moduloPermissions/ListUsuariosPermissions.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/uUserPermissions/:id',
    name: 'uUserPermissions',
    component: () => import('../views/moduloPermissions/partials/uUserPermissions.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_superuser == false ){ 
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/perfil',
    name: 'Perfil',
    component: () => import( '../views/moduloUsuarios/Profile.vue' ),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .then(res=> { return next() })
        .catch(err => {return next({name: 'Home'})}) 
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {

    path: '/departamento/:id',
    name: 'Dpto',
    component: () => import(/* webpackChunkName: "about" */ '../views/Home/Dpto')
  },
  {
    path: '/cargacsv',
    name: 'cargacsv',
    component: cargacsv,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/Devoluciones',
    name: 'Devoluciones',
    component: Devoluciones,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }

  },
  
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/articulos',
    name: 'Articulos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloArticulos/Articulos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/articulosglobales',
    name: 'ArticulosGlobales',
    component: () => import('../views/moduloArticulosGlobales/ArticulosGlobales'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/carticuloglobal',
    name: 'cArticuloGlobal',
    component: () => import('../views/moduloArticulosGlobales/partials/cArticuloGlobal'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/uarticuloglobal/:id',
    name: 'uArticuloGlobal',
    component: () => import('../views/moduloArticulosGlobales/uArticuloGlobal'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },


  {
    path: '/traspaso',
    name: 'Traspaso',
    component: () => import('../views/moduloTraspaso/Traspaso'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/ctraspaso',
    name: 'cTraspaso',
    component: () => import('../views/moduloTraspaso/partials/cTraspaso'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/utraspaso/:id',
    name: 'uTraspaso',
    component: () => import('../views/moduloTraspaso/uTraspaso'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },


  {
    path: '/vales',
    name: 'Vale',
    component: () => import('../views/moduloVales/Vales'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/cvales',
    name: 'cVales',
    component: () => import('../views/moduloVales/partials/cVales'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/uvales/:id',
    name: 'uvales',
    component: () => import('../views/moduloVales/uVales'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/sucursal',
    name: 'Sucursal',
    component: () => import('../views/moduloSucursales/Sucursal'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/cSucursal',
    name: 'cSucursal',
    component: () => import('../views/moduloSucursales/partials/cSucursal'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/usucursal/:id',
    name: 'usucursal',
    component: () => import('../views/moduloSucursales/uSucursal'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
 
  /*--------------------------Módulo de Slider-Autor:Mario Alonso------------------------------------------------*/
  /*Consulta de registros del Slaider*/
  {
    path: '/slider',
    name: 'Slider',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloSlider/Slider'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  /*Vista de acceso al formulario de registros del slider*/
  {
    path: '/cSlider',
    name: 'cSlider',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloSlider/partials/cSlider'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*Vista de acceso al formulario de edición de registros del slider*/
  {
    path: '/uslider/:id',
    name: 'uslider',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloSlider/uSlider'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  /*--------------------------Módulo de Clientes Afiliados Historico-Autor:Mario Alonso---------------------------*/
  /*Consulta de registros de clientes afiliados y que han pasado al formato historico*/
  {
    path: '/clientesHistorico',
    name: 'ClientesHistorico',
    component: () => import(/* webpackChunkName: "about" */ '../views/ClientesAfiliados/partials/ClientesAfiliadosHistorico'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  /*--------------------------Módulo de Clientes Afiliados-Autor:Elisa Huerta Coautor:Mario Alonso----------------------
  path: '/Clientes',
  name: 'Clientes',
  component: Clientes*/

  /*Vista a la consulta de registros de clientes afiliados*/
  {
    path: '/Clientes',
    name: 'Clientes',
    component: () => import(/* webpackChunkName: "about" */ '../views/ClientesAfiliados/Clientes'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*Vista de acceso al formulario de edición de registros de clientes afiliados
    path: '/acliente/:id',
    name: 'ActualizarCliente',
    component: ActualizarCliente
  */
  {
    path: '/acliente/:id',
    name: 'ActualizarCliente',
    component: () => import(/* webpackChunkName: "about" */ '../views/ClientesAfiliados/EditarCliente'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
  
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  /*--------------------------Módulo de Inventario-Autor:Mario Alonso-------------------------------------------- */
  /*Consulta de General de Articulos*/
  {
    path: '/inventario',
    name: 'Inventario',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloInventario/Inventario'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*--------------------------Módulo de Inventario-Autor:Mario Alonso---------------------------*/
  /*Consulta de Articulos por Sucursal*/
  {
    path: '/invSuc/:id',
    name: 'invSuc',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloInventario/partials/invSuc'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*------------------------------------------------------------------------------------------ */
  {
    path: '/carticulos',
    name: 'cArticulo',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloArticulos/partials/cArticulo'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/cDepartamento',
    name: 'cDepartamento',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/partials/cDepartamento'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },   
  
  {
    path: '/cCatalogo',
    name: 'cCatalogo',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/partials/cCatalogo'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  }, 
  {
    path: '/cSubDepartamento',
    name: 'cSubDepartamento',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/partials/cSubDepartamento'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },  
  {
    path: '/dep/',
    name: 'Departamentos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/Departamentos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/deparhistorico/',
    name: 'DptoHistorico',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/DepartHistorico'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    },
  },
  {
    path: '/subdeparthistorico/',
    name: 'SubDepartHistorico',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/SubDepartHistorico'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    },
  },
  {
    path: '/udep/:id',
    name: 'uDepartamentos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/uDepartamentos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/subdep/',
    name: 'SubDepartamentos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/SubDepartamentos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/empleadosHist',
    name: 'EmpleadosHist',
    component: () => import(/* webpackChunkName: "about" */ '../views/Empleados/EmpleadosHist'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/usubdep/:id',
    name: 'uSubDepartamentos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloDepartamentos/uSubDepartamentos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/catalogos',
    name: 'Catalogos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/Catalogos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    },
  },
  {
    path: '/catalogoshistorico',
    name: 'CatalogosHistorico',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/CatalogosHistorico'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    },
  },
  /*--------------------------Módulo de Inventario Catalogos-Autor:Mario Alonso-------------------------------------------- */
  /*Consulta de General de Catalogos*/
  {
    path: '/InventarioCatalogos',
    name: 'InventarioCatalogos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/Inventario'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*--------------------------Módulo de Inventario Catalogos-Autor:Mario Alonso---------------------------*/
  /*Consulta de Catalogos por Sucursal*/
  {
    path: '/invCat/:id',
    name: 'invCat',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/partials/invCat'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){
                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*------------------------------------------------------------------------------------------ */
  {
    path: '/Proveedores',
    name: 'Proveedores',
    component: Proveedores,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/proveedorhist',
    name: 'ProveedorHist',
    component: ProveedorHist,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/RegistroProveedores',
    name: 'RegistroProveedores',
    component: RegistroProveedores,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  
  {
    path: '/aproveedor/:id',
    name: 'Actualizar',
    component: Actualizar,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },

  {
    path: '/Empleados',
    name: 'Empleados',
    component: Empleados,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/RegistroEmpleados/:id',
    name: 'RegistroEmpleados',
    component: RegistroEmpleados,
    props:true,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/aempleado/:id',
    name: 'ActualizarEmpleados',
    component: ActualizarEmpleados,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/' + userToken + '/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + res.data.user  + '/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  
  {
    path: '/Usuarios/',
    name: 'Usuarios',
    component: Usuarios,
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }

  },

  {
    path: '/Usuario/',
    name: 'Usuario',
    component: Usuario,

  },

  {
    path: '/Login/',
    name: 'Login',
    component: Login,

  },
  {
    path: '/RegistroClientes/:id',
    name: 'RegistroClientes',
    component: RegistroClientes,
    props:true
  },
  /*
  {
    path: '/ClientesNoAfi',
    name: 'ClientesNoAfi',
    component: ClientesNoAfi

  },

  {
    path: '/RegistroClientesNoAfi/',
    name: 'RegistroClientesNoAfi',
    component: RegistroClientesNoAfi,
  
  },
  {
    path: '/aclientes/:id',
    name: 'ActualizarClienteNoAfi',
    component: ActualizarClienteNoAfi
  },
  */
  {

    path: '/corte',
    name: 'Corte',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/Corte'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/listcaja',
    name: 'ListCaja',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/List'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/mostrador',
    name: 'Mostrador',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/Mostrador'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/generarpedido/:id',
    name: 'GenerarPedido',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/GenerarPedido.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/pedidocatalogo/:id',
    name: 'PedidoCatalogo',
    component: () => import('../views/moduloCaja/partials/moduloPedidoCatalogo/PedidoCatalogo.vue'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/listventas',
    name: 'ListVentas',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/Ventas'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/movcaja/',
    name: 'MovimientoCaja',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/MovimientoCaja'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  {
    path: '/graficos/',
    name: 'Graficos',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/Graficos'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  /*--------------------------Módulo de Venta - Clientes Afiliados-Autor:Mario Alonso----------------------
  /*Vista a la consulta de clientes afiliados y pedidos realizados por el cliente seleccionado*/
  {
    path: '/ventasClientesAfi/',
    name: 'VentasClientesAfi',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/ventaClientesAfi'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
  //---------------------------------------------------------------------------------------------------------
  {
    path: '/mostrador/:id',
    name: 'MostradorDetail',
    component: () => import(/* webpackChunkName: "about" */ '../views/moduloCaja/Trans'),
    beforeEnter: (to, from, next) => {
      if(localStorage.token){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .catch(err => {return next({name: 'Home'})})
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
                if( res.data.is_staff == false ){

                  return next({name: 'Home'})
                }else{ return next() }
            })
        })
      }else{ return next({name: 'Home'}) }
    }
  },
{
  path: '/uarticulo/:id',
  name: 'uArticulo',
  component: () => import(/* webpackChunkName: "about" */ '../views/moduloArticulos/uArticulo'),
  beforeEnter: (to, from, next) => {
    if(localStorage.token){
      const userToken = localStorage.token
      axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
      .catch(err => {return next({name: 'Home'})})
      .then((res) => { 
          axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
          .then(res=> {
              if( res.data.is_staff == false ){

                return next({name: 'Home'})
              }else{ return next() }
          })
      })
    }else{ return next({name: 'Home'}) }
  }
}
,
{
  path: '/ucatalogo/:id',
  name: 'uCatalogo',
  component: () => import(/* webpackChunkName: "about" */ '../views/moduloCatalogos/uCatalogo'),
  beforeEnter: (to, from, next) => {
    if(localStorage.token){
      const userToken = localStorage.token
      axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
      .catch(err => {return next({name: 'Home'})})
      .then((res) => { 
          axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
          .then(res=> {
              if( res.data.is_staff == false ){

                return next({name: 'Home'})
              }else{ return next() }
          })
      })
    }else{ return next({name: 'Home'}) }
  }
},
{
  path: '/carrito',
  name: 'CarritoPedido',
  component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedido/CartPedido')
},
{
  path: '/detailarti/:id',
  name: 'DetailArticulo',
  component: () => import(/* webpackChunkName: "about" */ '../views/Home/_Detail')
},
{
  path: '/pedidos',
  name: 'Pedidos',
  component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedido/Admin/AdCart'),
  beforeEnter: (to, from, next) => {
    if(localStorage.token){
      const userToken = localStorage.token
      axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
      .catch(err => {return next({name: 'Home'})})
      .then((res) => { 
          axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
          .then(res=> {
              if( res.data.is_staff == false ){

                return next({name: 'Home'})
              }else{ return next() }
          })
      })
    }else{ return next({name: 'Home'}) }
  }
},
{
  path: '/epedido/:id',
  name: 'EditarPedido',
  component: () => import(/* webpackChunkName: "about" */ '../views/moduloPedido/Admin/partials/_EditCart')
},


]




const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
