<template>
  <v-container>  
    <h3>About</h3>  
  </v-container>
</template>    
<script> 
export default {
  data() {
    return { 

    };
  },
  created() {  

  },
  methods: {
    
  }
}
</script>