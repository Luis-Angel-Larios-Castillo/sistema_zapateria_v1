<!--Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz para seleccionar un módulo-->
<template>
    <v-container fluid >
        <app-header style="z-index: 135"/> 
        <div class="col-10">
        <div align="center" justify="space-around">
            
          <hr class="line_superior">
          <h1 id="title">Seleccionar movimiento:</h1>
        </div><br><br><br><br>
        <v-row class="justify-center">
            <v-col cols="md-4 xs-12" v-for="item in items" :key="item.nombre">
                <v-hover v-slot="{ hover }">
                    <v-card :to="item.url" :class="{ 'on-hover': hover }" :elevation="hover ? 20 : 5" id="design_card">
                        <v-card-text class="justify-center" align="center">
                            <v-img :src="item.icon" class="design_images"/>
                            <br>
                            <h1 :class="item.color+'--text'">{{item.nombre}}</h1>
                        </v-card-text>
                        <br><br>
                    </v-card>
                </v-hover>
                <br><br><br>
            </v-col>
        </v-row>  
        </div>      
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import styles from '../../../public/Styles'
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        },
    data() {
        return {
            items:[
                /*
                {
                    nombre: 'Mostrador',
                    icon: require('@/assets/vendedor.png'),
                    url: '/mostrador/',
                    color:'black'
                },
                */ 
                {
                    nombre: 'Corte y cierre de caja',
                    icon: require('@/assets/caja-registradora.png'),
                    url: '/corte/',
                    color:'black'
                },
                {
                    nombre: 'Movimientos de caja',
                    icon: require('@/assets/cash-flow.png'),
                    url: '/movcaja/',
                    color:'black'
                },
                {
                    nombre: 'Historial de ventas',
                    icon: require('@/assets/cuenta.png'),
                    url: '/listventas/',
                    color:'black'
                },
                {
                    nombre: 'Devoluciones',
                    icon: require('@/assets/facil.png'),
                    url: '/devoluciones/',
                    color:'black'
                },
                {
                    nombre: 'Gráficos',
                    icon: require('@/assets/grafico-de-barras.png'),
                    url: '/graficos/',
                    color:'black'
                },
                {
                    nombre: 'Venta Clientes',
                    icon: require('@/assets/VentasClienteAfi.jpg'),
                    url: '/ventasClientesAfi/',
                    color:'black'
                },
            ],      
        }
    },
}
</script>
<style lang="sass" scoped>
.v-card.on-hover.theme--dark
  background-color: rgba(#FFF, 0.8)
  >.v-card__text
    color: #000
</style>