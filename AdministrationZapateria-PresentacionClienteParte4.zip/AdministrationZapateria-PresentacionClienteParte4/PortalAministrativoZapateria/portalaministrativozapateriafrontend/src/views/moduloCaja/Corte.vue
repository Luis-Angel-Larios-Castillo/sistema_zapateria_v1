Autor: Miguel Angel Zamora Carmona
Descripción: En este archivo se tienen las funciones necesarias para generar reportes. 
<template>
    <v-container>  
      <app-header style="z-index: 135"/>  
      <br>

      <v-row justify="space-around">
        <v-spacer></v-spacer>
          <CorteMensual v-if="isAdmin == true"/>
          <CorteTurno/>
          <Reporte v-if="isAdmin == true"/>
      </v-row>    
      <br>
      <div v-if="corte.corteExist">
        <div class="hr-sect"><h2>Corte</h2></div>
        <v-row>
          <v-spacer/>
          <h2>Zapatería Deny´s</h2>
          <v-spacer/>
          <v-text-field v-model="corte.fInicio" label="Fecha inicial"  prepend-icon="mdi-calendar" readonly disabled/>
          <v-text-field v-model="corte.fFin" label="Fecha final"  prepend-icon="mdi-calendar" readonly disabled/>
          <v-spacer/>
        </v-row> 
        <h3>Total: ${{corte.totalCorte}}</h3>
        <PDF :corteData="corte"/>
      </div>
        
        <div class="hr-sect"><h2>Transacciones</h2></div>
        <v-card>
                <v-card-title>
                <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar"
                    single-line
                    hide-details
                ></v-text-field>
                </v-card-title>
                <v-data-table 
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen transacciones registradas." :headers="headers" :search="search" :items="items" 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                >
                    <template v-slot:item.zca_tipo="{ item }"  >
                      <p v-if="item.zca_tipo == 'Retiro'" class="red--text">{{item.zca_tipo}}</p>
                      <p v-if="item.zca_tipo == 'Venta'" class="green--text">{{item.zca_tipo}}</p>
                      <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">{{item.zca_tipo}}</p>
                      <p v-if="item.zca_tipo == 'Servicio'" class="orange--text">{{item.zca_tipo}}</p>
                    </template>
                    <template v-slot:item.zca_total="{ item }"  >
                      <p v-if="item.zca_tipo == 'Retiro'" class="red--text">${{item.zca_total}}</p>
                      <p v-if="item.zca_tipo == 'Venta'" class="green--text">${{item.zca_total}}</p>
                      <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">${{item.zca_total}}</p>
                      <p v-if="item.zca_tipo == 'Servicio'" class="orange--text">${{item.zca_total}}</p>
                    </template>
                </v-data-table>
            </v-card>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import PdfCorteTurno from "../../components/PdfCorteTurno"
import CorteMensual from './partials/_CorteMensual'
import CorteTurno from './partials/_CorteTurno'
import Reporte from './partials/_Reporte'
const axios = require('axios')
const moment = require('moment')
  export default {
    name: 'Header', 
    components: {
       "app-header": Header,
      PdfCorteTurno, 
      CorteMensual,
      CorteTurno,
      Reporte
    },
    methods: {
      
      getItems(){
        let userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .then((res) => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
            .then(res=> {
              this.isAdmin = res.data.is_superuser
              if(this.isAdmin == true){
                axios.get('http://127.0.0.1:8000/caja/list/')
                .then(r => this.items = r.data)
              }else{
                axios.get('http://127.0.0.1:8000/caja/listmovuser/?search=' + res.data.zdus_id_usuario)
                .then(r => this.items = r.data)
              }
              
            })
        })
      },
    },
    created() {
      this.getItems()
    },
    data () {
      return {
        isAdmin: false,
        search: '',
        corte: {
          corteExist: false,
          totalCorte: 0,
          fInicio: '',
          fFin: '',
          corteItems:[]
        },
        headers: [
            {
                text: 'Transacción',
                align: 'start',
                value: 'zca_nombre',
            },
            
            { text: 'Empleado', value: 'zca_empleado' },
            { text: 'Fecha', value: 'zca_fecha' },
            { text: 'Hora', value: 'zca_hora' },
            { text: 'Tipo', value: 'zca_tipo' },
            //{ text: 'Cliente', value: 'cliente' },
            { text: 'Total final', value: 'zca_total' },
        ],
        items: [],       
      }
    },
  }
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>