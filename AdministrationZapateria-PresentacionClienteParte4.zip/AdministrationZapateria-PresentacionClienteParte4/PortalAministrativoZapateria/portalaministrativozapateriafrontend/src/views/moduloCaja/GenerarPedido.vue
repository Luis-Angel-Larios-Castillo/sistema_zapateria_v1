<template>   
    <v-container fluid>
        <h2>Nuevo pedido</h2>     
        <v-row class="justify-center">  
            <v-col cols="md-7 xs-12">
                <v-tabs v-model="tab"  centered  icons-and-text>
                <v-tabs-slider/> 
                <v-tab href="#tab-1"> Articulos </v-tab> 
                <v-tab href="#tab-2" v-if="noShowVales == false"> Vales </v-tab>  
                </v-tabs>
                <v-tabs-items v-model="tab">
                    <v-tab-item value="tab-1"> 
                        <v-card>
                            <v-card-title class="card_title">
                                <div class="col-12" id="table_cabecera_color">
                                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                </div>
                            </v-card-title> 
                            <v-card-text>
                            <v-data-table  :headers="headersArticulos" :items="articulos" 
                                :items-per-page="5"
                                :search="search"
                                :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                                no-data-text="No se ha realizado una búsqueda."
                                :header-props="{ sortByText: 'Ordenar por' }">
                                <template v-slot:item.zaa_cantidad="{ item }">
                                    <v-chip :color="getColor(item.zaa_cantidad)" class="white--text"> 
                                        {{ item.zaa_cantidad }} pzas.
                                    </v-chip>
                                </template>
                                <template v-slot:item.zaa_id_articulo="{ item }"> 
                                    <AddArticuloPedido :noShowStock="noShowStock" :cab="cabecera" :artilce="item"/>
                                </template>
                            </v-data-table>
                            </v-card-text>
                        </v-card>
                    </v-tab-item>
                    <v-tab-item value="tab-2">               
                        <v-card> 
                            <v-card-title class="card_title">
                                <div class="col-12" id="table_cabecera_color">
                                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                </div>
                            </v-card-title> 
                            <v-card-text>
                            <v-data-table  :headers="headersVales" :items="vales" 
                                :items-per-page="5"
                                :search="search"
                                :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                                no-data-text="No se ha realizado una búsqueda."
                                :header-props="{ sortByText: 'Ordenar por' }"> 
                                <template v-slot:item.zdv_estat_vale="{ item }" >  
                                    <p style=" margin-top:15px;" v-if="item.zdv_estat_vale == false" class="red--text">
                                        No cobrado aún
                                    </p>
                                </template>
                                <template v-slot:item.zdv_fech_crea="{ item }">  
                                    {{fecha(item.zdv_fech_crea)}}
                                    {{getFechaAplicacion(item)}} 
                                </template>
                                <template v-slot:item.zdv_importe="{ item }">  
                                    ${{item.zdv_importe}}
                                </template> 
                                <template v-slot:item.zdv_id_vale="{ item }">  
                                    <v-btn icon v-if="getFechaAplicacion(item) <= 3" color="success" @click="asignarVale(item)" >
                                        <v-icon>mdi-plus</v-icon>
                                    </v-btn> 
                                    <AutorizaVale v-else :idEmp="cabecera.zped_id_empleado" :vale="item" :cabPed="$route.params.id"/> 
                                </template>
                            </v-data-table>
                            </v-card-text>
                        </v-card>
                    </v-tab-item>
                </v-tabs-items>
                
            </v-col>
            <v-col cols="md-5 xs-12"> 
                <v-tabs v-model="tabArtVal"  centered  icons-and-text>
                <v-tabs-slider/> 
                <v-tab href="#tabArtVal-1"> Pedido </v-tab> 
                <v-tab href="#tabArtVal-2" v-if="noShowVales == false"> Vales aplicados </v-tab>  
                </v-tabs>
                <v-tabs-items v-model="tabArtVal">
                    <v-tab-item value="tabArtVal-1"> 
                        <PedidoDetail :vale="valeSuma" :noShowVales="noShowVales" :cab="cabecera" :cliente="clienteNombre" :empleado="empleadoNombre" />
                    </v-tab-item>
                    <v-tab-item value="tabArtVal-2"> 
                        <v-data-table  :headers="headersValesAplicado" :items="valesAplicados" 
                            :items-per-page="5" 
                            :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen vales aplicados." 
                            :header-props="{ sortByText: 'Ordenar por' }">  
                            <template v-slot:item.zdv_importe="{ item }"> 
                                 {{item.zdv_importe}}
                            </template>
                        </v-data-table>
                    </v-tab-item>
                </v-tabs-items>
                 
            </v-col>
        </v-row>     
    </v-container>     
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import AddArticuloPedido from './partials/_AddArticuloPedido.vue'
import PedidoDetail from './partials/_PedidoDetail.vue'
import AutorizaVale from './partials/_AutorizarVale.vue'
export default {
    components:{
        AddArticuloPedido,
        PedidoDetail,
        AutorizaVale
    },
    data() {
        return { 
            idUser:'',
            empleadoResult:[],
            noShowVales: false, 
            noShowStock: false,
            valeSuma: 0,
            tabArtVal: null,
            tab: null,
            empleadoNombre: '',
            clienteNombre: '',
            search: '',
            cabecera: [], 
            selecciono: false, 
            headersArticulos: [
                {text: 'Articulo', align: 'start', filterable: true, value: 'zaa_nombre_arti'},
                {text: 'Modelo', value: 'zaa_modelo' },
                {text: 'Clave', value: 'zaa_clave' },
                {text: 'Marca', value: 'zaa_marca' },
                {text: 'Catalogo', value: 'zaa_catalogo'},
                {text: 'Cantidad', value: 'zaa_cantidad', sortable: false},
                {text: 'Acciones', value: 'zaa_id_articulo', sortable: false }, 
            ],
            articulos: [],
            items: [],
            headersVales: [
                {
                    text: 'Vale',
                    align: 'start',
                    filterable: true,
                    value: 'zdv_folio_vale',
                },  
                { text: 'Estatus', value: 'zdv_estat_vale' },
                { text: 'Fecha', value: 'zdv_fech_crea' },
                { text: 'Importe', value: 'zdv_importe' }, 
                { text: 'Acciones', value: 'zdv_id_vale', sortable: false }, 
            ],
            vales: [],
            headersValesAplicado: [
                {
                    text: 'Vale',
                    align: 'start',
                    filterable: true,
                    value: 'zdv_folio_vale',
                },  
                { text: 'fecha de creación', value: 'zdv_fech_crea' },
                { text: 'Fecha de cobro', value: 'zdv_fecha_cobro' },
                { text: 'Importe', value: 'zdv_importe' },  
            ],
            valesAplicados: [],
            admin:[],
        }
    }, 
    created() {
        this.getCabecera() 
        this.getValesAplicados()
        this.findEmpleado()
    },  
    methods: {   
        getFechaAplicacion(dataVale){ 
            let a = moment(moment(dataVale.zdv_fech_crea).format('YYYY-MM-DD'))
            let b = moment(moment().format('YYYY-MM-DD'))
            let diffMonths = b.diff(a, 'months') 
            return diffMonths
        },
        asignarVale(dataVale){  
            dataVale.zdv_estat_vale = true 
            dataVale.zdv_id_pedcab = this.$route.params.id
            dataVale.zdv_id_user_qcobra_vale = this.cabecera.zped_id_empleado
            dataVale.zdv_fecha_cobro = moment().format('YYYY-MM-DD')
            //dataVale.zdv_id_user_autori = 'Autorizado por'
            axios.put('http://127.0.0.1:8000/vale/' + dataVale.zdv_id_vale + '/', dataVale )
                .then(res => window.location.reload())
        },
        getValesAplicados(){
            axios.get('http://127.0.0.1:8000/vale/?search=' + this.$route.params.id )
                .then(res => {
                    this.valesAplicados = res.data
                        res.data.forEach(vale => {
                            this.valeSuma += vale.zdv_importe
                        });
                    })
        },
        getClienteID(cabe){  
            axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + cabe.zped_id_usuario )
                .then(res => this.getVales(res.data[0]) ) 
        },
        fecha(fechaEnBruto){
            return moment(fechaEnBruto).format('YYYY-MM-DD')
        },
        getVales(idCliente){  
            console.log()  
            if(idCliente != null){
                let arrVales = []  
                //axios.get('http://127.0.0.1:8000/vale/?search=' + idCliente.zc_id_cliente)
                axios.get('http://127.0.0.1:8000/vale/?search=' + idCliente.zc_id_usuario)
                    .then(res => {  
                        res.data.forEach(vale => {
                            if(vale.zdv_estat_vale == false){
                                arrVales.push(vale) 
                            }
                        });
                    })
                this.vales = arrVales 
            }
             
        },
        
        getUsuariosData(cab){
            axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + cab.zped_id_usuario )
            .then(res => {
                this.clienteNombre = res.data
                //console.log(res.data.length)
                if(res.data.length == 0){
                    //console.log("Es 0")
                    axios.get('http://127.0.0.1:8000/clientes/?search=' + cab.zped_id_usuario)
                    .then(clienteNombre => {
                        this.clienteNombre = clienteNombre.data
                        this.noShowVales = true
                        this.noShowStock = true
                        })
                }else{
                    //console.log("Es mayor a 0")
                }
            })
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + cab.zped_id_empleado + '/' )
            .then(res =>{
                if(res.data.is_superuser == true){
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zped_id_empleado )
                    .then( resEmpl => this.empleadoNombre = resEmpl.data[0].nombre ) 
                    //this.empleadoNombre = res.data.zdus_correo
                }else{
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zped_id_empleado )
                    .then( resEmpl => this.empleadoNombre = resEmpl.data[0].nombre ) 
                }
            })
        },
        getCabecera(){
            axios.get('http://127.0.0.1:8000/pedido/pedcab/' + this.$route.params.id + '/' ) 
                .then(res => {
                    this.cabecera = res.data
                    this.getUsuariosData(res.data)
                    this.getClienteID(res.data)
                }) 
        },
        getColor (zaa_cantidad) {
            if (zaa_cantidad < 2) return 'red accent-3'
            else if (zaa_cantidad < 5) return 'orange accent-3'
            else return 'green accent-4'
        },
        findEmpleado(){
            let config = {
                headers: {
                    Authorization: "Token " + localStorage.token,
                }
            }
            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user

                axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+ this.idUser)
                .then(res=>{this.admin=res.data[0]
                
                if(this.admin.is_superuser==false){
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
                    .then(res => { this.empleadoResult = res.data[0]
                        axios.get('http://127.0.0.1:8000/articulo/admin/?search=' + this.empleadoResult.zdem_id_sucursal,config)
                        .then(res => this.articulos = res.data)
                    })
                }else{
                    axios.get('http://127.0.0.1:8000/articulo/admin/')
                        .then(res => this.articulos = res.data)
                }
                })
            })
        },
    },
}
</script>