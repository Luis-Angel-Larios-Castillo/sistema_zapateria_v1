Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran los gráficos del trimestre, semestre, mes y anual   
<template>
    <v-container fluid>
         <app-header style="z-index: 135"/> 
        <h2>Gráficos</h2>
            <v-card>
                <v-tabs v-model="tab"  centered  icons-and-text>
                <v-tabs-slider/> 
                <v-tab href="#tab-1"> general </v-tab> 
                <v-tab href="#tab-2"> trimestral </v-tab> 
                <v-tab href="#tab-3"> semestral </v-tab> 
                <v-tab href="#tab-4"> mensual </v-tab>
                <v-tab href="#tab-5"> anual </v-tab>
                </v-tabs>
                <v-tabs-items v-model="tab">
                    <v-tab-item value="tab-1">  
                        <RepoteGanancias :reporteData="{datosReporteGanancias,fechasReporteGanancias}"/> 
                    </v-tab-item>
                    <v-tab-item value="tab-2">
                        <ReporteGT :reporteData="{infoTrimestre, datoTrimestre, triSelect}"/> 
                    </v-tab-item>
                    <v-tab-item value="tab-3" >
                        <ReporteGS :reporteData="{infoSemestre, datoSemestre, semestreSelect}"/> 
                    </v-tab-item>
                    <v-tab-item value="tab-4" >
                        <ReporteGM :reporteData="{infoMensual, datoMensual, mesSelect}"/> 
                    </v-tab-item>
                    <v-tab-item value="tab-5" >
                        <ReporteGA :reporteData="{infoAnual, datoAnual, year}"/> 
                    </v-tab-item>
                </v-tabs-items>
            </v-card>
    </v-container>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import Header from '../../components/Header';
import ReporteGT from "./partials/_ReporteGT";
import ReporteGS from "./partials/_ReporteGS";
import ReporteGM from "./partials/_ReporteGM";
import ReporteGA from "./partials/_ReporteGA";
import RepoteGanancias from "./partials/_RepoteGanancias";
export default {
    name: 'Header', 
    components: {"app-header": Header, ReporteGT, ReporteGS, ReporteGM, ReporteGA, RepoteGanancias },
    data() {
        return {
            datosReporteGanancias: [],
            fechasReporteGanancias: [],
            tab: null,
            fecha: moment().format('YYYY-MM'),
            year: moment().format('YYYY'),
           
            trimestres: [
                { mes01: '01', mes02: '02', mes03: '03' },
                { mes01: '04', mes02: '05', mes03: '06' },
                { mes01: '07', mes02: '08', mes03: '09' },
                { mes01: '10', mes02: '11', mes03: '12' }
            ],
            triSelect: {
                year: moment().format('YYYY'),
                name: '',
                dates: [],
            },
            infoTrimestre: [],
            datoTrimestre: {
                salidas: 0,
                entradas: 0,
                total: 0
            },
            semestres: [
                { mes01: '01', mes02: '02', mes03: '03', mes04: '04', mes05: '05', mes06: '06' },
                { mes01: '07', mes02: '08', mes03: '09', mes04: '10', mes05: '11', mes06: '12' }
            ],
            semestreSelect: {
                year: moment().format('YYYY'),
                name: '',
                dates: [],
            },
            infoSemestre: [],
            datoSemestre: {
                salidas: 0,
                entradas: 0,
                total: 0
            },
            mesSelect: {
                year: moment().format('YYYY'),
                name: moment( this.fecha ).locale('es').format('MMMM'),
                dates: moment( this.fecha ).locale('es').format('YYYY-MM'), 
            },
            infoMensual: [],
            datoMensual: {
                salidas: 0,
                entradas: 0,
                total: 0
            },
            infoAnual: [],
            datoAnual: {
                salidas: 0,
                entradas: 0,
                total: 0
            },

        }
    },
    created() {
        //let datos = this.consultarGananciasAnuales()
        //let fechasGan = this.getFechas() 
        this.fechasReporteGanancias = this.getFechas()
        this.datosReporteGanancias = this.consultarGananciasAnuales()
        this.getTrimestre()
        this.getSemestre()
        this.reporteMensual()
        this.reporteAnual()
    },
    methods: {
        reporteAnual(){
            let arr = []
            axios.get('http://127.0.0.1:8000/caja/cabasc/')
                .then(res => {
                    res.data.forEach(element => {
                        if ( this.year == moment(element.zca_fecha).format('YYYY')  ) {
                            arr.push(element)
                        }
                    });
                    let ventas = 0
                    let retiros = 0
                    arr.forEach(element => {
                        if (element.zca_tipo  == 'Venta' || element.zca_tipo == 'Depósito') {
                            ventas = ventas + element.zca_total
                        } else {
                            retiros = retiros + element.zca_total
                        }
                    });
                    this.datoAnual.salidas = retiros
                    this.datoAnual.entradas = ventas
                    this.datoAnual.total = (ventas -retiros)
                    this.infoAnual = arr
                })
        },
        getSemestre(){
            let mesActual =moment( this.fecha ).format('MM')
            this.semestres.forEach(element => {
                if(mesActual == element.mes01 || mesActual == element.mes02 || mesActual == element.mes03 || mesActual == element.mes04 || mesActual == element.mes05 || mesActual == element.mes06){
                    this.semestreSelect.name = 
                        moment(element.mes01).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes02).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes03).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes04).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes05).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes06).locale('es').format('MMMM') 
                        this.semestreSelect.dates.push(
                            moment(this.semestreSelect.year + '-' + element.mes01).format('YYYY-MM'),
                            moment(this.semestreSelect.year + '-' + element.mes02).format('YYYY-MM'),
                            moment(this.semestreSelect.year + '-' + element.mes03).format('YYYY-MM'),
                            moment(this.semestreSelect.year + '-' + element.mes04).format('YYYY-MM'),
                            moment(this.semestreSelect.year + '-' + element.mes05).format('YYYY-MM'),
                            moment(this.semestreSelect.year + '-' + element.mes06).format('YYYY-MM'),
                        )
                }
            });
            this.reporteSemestral(this.semestreSelect)
        },
        getTrimestre(){
            let mesActual =moment( this.fecha ).format('MM')
            this.trimestres.forEach(element => {
                if(mesActual == element.mes01 || mesActual == element.mes02 || mesActual == element.mes03 ){
                    this.triSelect.name = 
                        moment(element.mes01).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes02).locale('es').format('MMMM') 
                        + ' - ' + 
                        moment(element.mes03).locale('es').format('MMMM') 
                        this.triSelect.dates.push(
                            moment(this.triSelect.year + '-' + element.mes01).format('YYYY-MM'),
                            moment(this.triSelect.year + '-' + element.mes02).format('YYYY-MM'),
                            moment(this.triSelect.year + '-' + element.mes03).format('YYYY-MM'),
                        )
                }
            });
            this.reporteTrimestral(this.triSelect)
        },
        reporteMensual(){
            let arr = []
            axios.get('http://127.0.0.1:8000/caja/cabasc/')
                .then(res => {
                    res.data.forEach(element => {
                        if ( this.mesSelect.dates == moment(element.zca_fecha).format('YYYY-MM')  ) {
                            arr.push(element)
                        }
                    });
                    let ventas = 0
                    let retiros = 0
                    arr.forEach(element => {
                        if (element.zca_tipo  == 'Venta' || element.zca_tipo == 'Depósito') {
                            ventas = ventas + element.zca_total
                        } else {
                            retiros = retiros + element.zca_total
                        }
                    });
                    this.datoMensual.salidas = retiros
                    this.datoMensual.entradas = ventas
                    this.datoMensual.total = (ventas -retiros)
                    this.infoMensual = arr
                })
        },
        reporteTrimestral(e){
            let arr = []
            axios.get('http://127.0.0.1:8000/caja/cabasc/')
                .then(res => {
                    res.data.forEach(element => {
                        if ( e.dates.includes( moment(element.zca_fecha).format('YYYY-MM') ) ) {
                            arr.push(element)
                        }
                    });
                    let ventas = 0
                    let retiros = 0
                    arr.forEach(element => {
                        if (element.zca_tipo  == 'Venta' || element.zca_tipo == 'Depósito') {
                            ventas = ventas + element.zca_total
                        } else {
                            retiros = retiros + element.zca_total
                        }
                    });
                    this.datoTrimestre.salidas = retiros
                    this.datoTrimestre.entradas = ventas
                    this.datoTrimestre.total = (ventas -retiros)
                    this.infoTrimestre = arr
                })
        },
        reporteSemestral(e){
            let arr = []
            axios.get('http://127.0.0.1:8000/caja/cabasc/')
                .then(res => {
                    res.data.forEach(element => {
                        if ( e.dates.includes( moment(element.zca_fecha).format('YYYY-MM') ) ) {
                            arr.push(element)
                        }
                    });
                    let ventas = 0
                    let retiros = 0
                    arr.forEach(element => {
                        if (element.zca_tipo  == 'Venta' || element.zca_tipo == 'Depósito') {
                            ventas = ventas + element.zca_total
                        } else {
                            retiros = retiros + element.zca_total
                        }
                    });
                    this.datoSemestre.salidas = retiros
                    this.datoSemestre.entradas = ventas
                    this.datoSemestre.total = (ventas -retiros)
                    this.infoSemestre = arr
                })
        },
        getFechas(){
            let fechas = []
            let mesActual = moment().format('M')
            let year = moment().format('YYYY')
            for (let i = 1; i <= mesActual ; i++) {
                fechas.push(moment(year + '-' + i).locale('es').format('MMMM - YYYY'))                
            }
            return fechas
        },
        consultarGananciasAnuales(){
            let fechas = this.getFechas()
            let datos = []
            axios.get('http://127.0.0.1:8000/caja/cabasc/')
                .then(res =>{ 

                    fechas.forEach(fecha => { 
                        let total = 0
                        res.data.forEach(item => { 
                            if(moment(item.zca_fecha).locale('es').format('MMMM - YYYY') == fecha){
                                if (item.zca_tipo  == 'Venta' || item.zca_tipo == 'Depósito') {
                                    total = total + item.zca_total
                                } else {
                                    total = total - item.zca_total
                                }
                            } 
                        });
                        datos.push(total)

                    });
                    
                })
                return datos
        }
    },
}
</script>