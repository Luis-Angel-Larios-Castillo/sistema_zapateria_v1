<template>
    <v-container fluid>
         <app-header style="z-index: 135"/> 
         <br>
        <v-card>
            <v-tabs v-model="tab" centered icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1"> Clientes Afiliados </v-tab> 
                <v-tab href="#tab-2"> Clientes No Afiliados </v-tab> 
            </v-tabs>
            <v-tabs-items v-model="tab">
                <v-tab-item value="tab-1">
                    <ventaClienteAfi/> 
                </v-tab-item>
                <v-tab-item value="tab-2">
                    <ventaClienteNoAfi/> 
                </v-tab-item>
            </v-tabs-items>
        </v-card>
    </v-container>
</template>

<script>
    import Header from '../../components/Header';
    import ventaClienteAfi from './partials/_ventaClientesAfi.vue'
    import ventaClienteNoAfi from './partials/_ventaClientesNoAfi.vue'
    
    const axios = require('axios')
    export default {
        name: 'Header', 
        components:{
            "app-header": Header,
            ventaClienteAfi,
            ventaClienteNoAfi,
        },
        data() {
            return {
                tab: null,
            }
        },
    }
</script>