Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz para de ventas del día 
<template>
    <v-container fluid justify-end>
        <div class="hr-sect"><h2>Mostrador</h2></div> 
        <v-card>
            <v-card-actions class="justify-end">
                <v-btn color="success" text @click="crearCab">Agregar venta</v-btn>
            </v-card-actions>
            <v-card-text>
                <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar"
                    single-line
                    hide-details
                    clearable
                ></v-text-field>
                <v-data-table 
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen transacciones registradas." 
                    :headers="headers" 
                    :search="search" 
                    :items="items" 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                >
                    <template v-slot:item.zca_tipo="{ item }">
                      <p v-if="item.zca_tipo == 'Retiro'" class="red--text">{{item.zca_tipo}}</p>
                      <p v-if="item.zca_tipo == 'Venta'" class="green--text">{{item.zca_tipo}}</p>
                      <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">{{item.zca_tipo}}</p>
                    </template>
                    <template v-slot:item.zca_total="{ item }">
                      <p v-if="item.zca_tipo == 'Retiro'" class="red--text">${{item.zca_total}}</p>
                      <p v-if="item.zca_tipo == 'Venta'" class="green--text">${{item.zca_total}}</p>
                      <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">${{item.zca_total}}</p>
                    </template>
                </v-data-table>
            </v-card-text>
        </v-card>
    </v-container>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
export default {
    data() {
        return { 
            search: '',
            headers: [
                {
                    text: 'Transacción',
                    align: 'start',
                    value: 'zca_nombre',
                },
                 
                { text: 'Empleado', value: 'zca_empleado' },
                { text: 'Fecha', value: 'zca_fecha' },
                { text: 'Hora', value: 'zca_hora' },
                { text: 'Tipo', value: 'zca_tipo' },
                //{ text: 'Cliente', value: 'cliente' },
                { text: 'Total final', value: 'zca_total' },
            ],
            items: [],
            empleado: null,
            hora: moment(new Date()).format('H:mm '),
            venta: 'VENTA-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
            retiro: 'RETIRO-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
        }
    },
    created() {
        this.getUser()
        window.document.title = 'Mostrador'
    },
    methods: {
        getItems(){
            axios.get('http://127.0.0.1:8000/caja/listventasusuario/?search=' + this.empleado.zdus_id_usuario)
                .then(res => {
                    let arr = []
                    let fecha = new Date().toISOString().substr(0, 10)
                    for (let i = 0; i < res.data.length; i++) {
                        if (res.data[i].zca_fecha == fecha) {
                            arr.push(res.data[i])
                        }
                    }
                    this.items = arr
                    })
        },
        getUser(){
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                .then(res => {
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data.user +'/' )
                        .then(r => {
                            this.empleado = r.data
                            this.getItems()
                        } )
                })
        },
        crearCab(){
            axios.post('http://127.0.0.1:8000/caja/cabecera/', {
                zca_nombre: this.venta,
                zca_tipo: 'Venta',
                zca_fecha: new Date().toISOString().slice(0,10),
                zca_hora: this.hora,
                zca_total: 0,
                zca_id_usuario: this.empleado.zdus_id_usuario
            })
                .then(res =>{
                    this.$router.replace({
                        path: '/mostrador/' + res.data.zca_id_pedcab 
                    })
                })
            
        },
        retiroCaja(){
            console.log('Retiro: ' + this.retiro)

        }
    },
}
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>