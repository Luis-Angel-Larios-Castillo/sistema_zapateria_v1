<template>
    <div  class="col-12" style="padding-top:0"> 
        <v-card :elevation="0"> 
            <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    </div>
                </v-card-title> 
                <v-card-text>
                    <v-data-table
                    id="tabla_datos"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen devoluciónes registrados."
                    :headers="headers"
                    :search="search"
                    :items="items"
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                        }"
                    :header-props="{ sortByText: 'Ordenar por' }"> 
                    <template v-slot:item.cliente="{ item }">
                        <strong>{{item.cliente}}</strong>
                    </template> 
                    <template v-slot:item.folio="{ item }">
                        <strong>{{item.folio}}</strong>
                    </template> 
                    <template v-slot:item.precio="{ item }">
                        <strong>$</strong>{{item.precio}}
                    </template> 
                    </v-data-table>  
                </v-card-text>
            
        </v-card>
    </div>
</template>
<script>
const axios = require("axios");
export default { 
    data() {
        return {
            search: '',
            headers: [
                {
                text: 'Cliente',
                align: 'start',
                sortable: false,
                value: 'cliente',
                },
                { text: 'Folio', value: 'folio' },
                { text: 'Fecha', value: 'fecha' },
                { text: 'Pedido', value: 'pedido' },
                { text: 'Articulo', value: 'articulo' }, 
                { text: 'Monto', value: 'precio' },                 
            ],
            items: [],
        }
    },
    created() {
        this.getItems()
    },
    methods: {
        getItems(){
            axios.get('http://127.0.0.1:8000/pedido/Itembyuser/')
            .then(resItems => {
                axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(resUser => {  
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + resUser.data[0].user)
                    .then(resEmp => { 
                        axios.get('http://127.0.0.1:8000/usuario/getusuario/' + resUser.data[0].user + '/')
                        .then(resGetData=> { 
                        if (resGetData.data.is_superuser == true){ 
                            
                            resItems.data.forEach(item => { 
                                
                                if(item.zipe_status == 'Devolución'){
                                    axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + item.zipe_id_cliente )    
                                    .then(resCliA => {
                                        console.log(resCliA.data[0])
                                        if(resCliA.data.length != 0){ 
                                            this.items.push({
                                                cliente: resCliA.data[0].nombre,
                                                folio: resCliA.data[0].zc_folio_client,
                                                pedido: item.zipe_pedido_nombre,
                                                precio: item.zipe_sub_tot,
                                                fecha: item.zipe_pedido_fecha,
                                                articulo: item.zipe_art_nombre
                                            });
                                        }else{
                                            axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + item.zipe_id_cliente )
                                            .then(resCliNA =>{
                                                console.log(resCliNA.data[0])
                                                this.items.push({
                                                    cliente: resCliNA.data[0].nombre,
                                                    pedido: item.zipe_pedido_nombre,
                                                    folio: resCliNA.data[0].zc_folio_client,
                                                    precio: item.zipe_sub_tot,
                                                    fecha: item.zipe_pedido_fecha,
                                                    articulo: item.zipe_art_nombre
                                                })
                                            });
                                        }
                                        
                                    }) 
                                }  
                                        
                            });
                        } else{
                            resItems.data.forEach(item => { 
                                if(resEmp.data[0].zdem_id_sucursal == item.zipe_sucursal){
                                    if(item.zipe_status == 'Devolución'){
                                        axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + item.zipe_id_cliente )    
                                        .then(resCliA => {
                                            if(resCliA.data.length != 0){ 
                                                this.items.push({
                                                    cliente: resCliA.data[0].nombre,
                                                    pedido: item.zipe_pedido_nombre,
                                                    precio: item.zipe_sub_tot,
                                                    fecha: item.zipe_pedido_fecha,
                                                    articulo: item.zipe_art_nombre
                                                });
                                            }else{
                                                axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + item.zipe_id_cliente )
                                                .then(resCliNA =>{
                                                    this.items.push({
                                                        cliente: resCliNA.data[0].nombre,
                                                        pedido: item.zipe_pedido_nombre,
                                                        precio: item.zipe_sub_tot,
                                                        fecha: item.zipe_pedido_fecha,
                                                        articulo: item.zipe_art_nombre
                                                    })
                                                    
                                                })
                                            }
                                            
                                        }) 
                                    }
                                }        
                            });
                            
                        }
                        })  
                    })
                })  
            })
        }
    },
}
</script>