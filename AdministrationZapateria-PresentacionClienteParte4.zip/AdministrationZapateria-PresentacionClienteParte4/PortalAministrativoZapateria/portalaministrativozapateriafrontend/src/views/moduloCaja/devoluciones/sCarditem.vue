Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo cuenta con un Card que contiene los datos del articulo para hacer un intercambio
<template >
    <div>
    <v-hover>
        <v-card>
            <v-row>
                <v-col cols="6"> 
                    <v-img v-if="CardData.item.zaa_cantidad >= 1" dark class=" imgColor white--text align-end"  height="200px">
                        <v-card-title>{{CardData.item.zaa_nombre_arti}}</v-card-title>
                    </v-img>
                    <v-img  v-if="CardData.item.zaa_cantidad == 0" dark class=" imgColor white--text align-end"  height="200px">
                        <h2  class="text-center">Agotado</h2>
                        <v-card-title>{{CardData.item.zaa_nombre_arti}}</v-card-title>
                    </v-img>
                </v-col>
                <v-col cols="6">
                    <v-card-text class=" black--text">

                        <div v-show="false">
                        pagado : {{CardData.intercambioData.zipe_id_pedido_cab.zped_pagado}}
                        <br>                      

                        <div v-if="CardData.intercambioData.zipe_id_pedido_cab.zped_pagado >= mulpli">
                           cal cab : {{calreem = CardData.intercambioData.zipe_id_pedido_cab.zped_pagado - mulpli}}
                        </div>
                        <div v-else>
                            calreem : {{calreem = 0}}
                        </div>
                        <div>
                        </div>
                         </div>

                        <p class="text-center"><strong>Catalogo: </strong>{{CardData.item.zaa_cata_name}}</p>
                        <p class="text-center"><strong>Depto: </strong>{{CardData.item.zaa_dpto_etiqueta}}</p>
                        <p class="text-center"><strong>Temporada: </strong>{{CardData.item.zaa__temporada}}</p>
                        <p class="headline"><strong>Costo: $</strong>{{CardData.item.zaa_prec_cont}}</p>
                         <p class="headline"><strong>Total: $</strong> {{mulpli = (cantidad) * (CardData.item.zaa_prec_cont)}}</p>
                    </v-card-text>  
                    <v-card-actions v-if="CardData.item.zaa_cantidad != 0">
                        <v-form ref="form" v-model="valid" lazy-validation m>
                            <v-row>
                                <v-col cols="6">
                                    <v-select v-model="colorSel" :items="colores" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']"  label="Color" required/>
                                </v-col>
                                <v-col cols="6">
                                    <v-select v-model="sizeSel" :items="sizes" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un talla']"  label="Talla" required/>
                                </v-col>
                            </v-row>
                            <v-row align="center">
                                <v-col cols="2"/>
                                <v-col cols="4" >
                                    <v-select v-model="cantidad" :items="cantidad02" :rules="[v => !!v || 'Debe seleccionar una cantidad']"  label="Cantidad" required/>
                                </v-col>
                                <v-col cols="4" >
                                    <v-btn text  color="primary" :disabled="!valid" @click="validate()">
                                        Seleccionar  
                                    </v-btn>
                                </v-col>
                                <v-col cols="2"/>
                            </v-row>
                        </v-form>
                    </v-card-actions>
                </v-col>
            </v-row>
        </v-card>
    </v-hover>
    <v-dialog v-model="dialogcaja" width="300"  persistent>
            <v-card><v-card-title>
                <!--{{this.folio_vale}}-->
            </v-card-title>
            <v-card-text>
                <v-form ref="form" v-model="validcaja" lazy-validation>
                    <v-text-field label="Numero de Caja" outlined type="text" v-model="n_caja" maxlength="5" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" :rules="n_cajaRules" required></v-text-field>
                </v-form>
                
                <v-btn :disabled="!validcaja"   text color="primary" v-on:click="generatePDF()">
                    Imprimir Vale
                </v-btn>
            </v-card-text>
        </v-card>
    </v-dialog>
     <v-snackbar
        v-model="msjalerta"
        >
        Se realizará un vale por el monto de ${{cantvale}}
        <template v-slot:action="{ attrs }">
            <v-btn
            color="pink"
            text
            v-bind="attrs"
            @click="snackbar = false"
            >
            Close
            </v-btn>
        </template>
        </v-snackbar>
    </div>
</template>
<script>
const axios = require('axios')
import jsPDF from "jspdf"; 
export default {
    props:[
        'CardData',
    ],
    data () {
        return {
            num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
            calreem:0,
            mulpli:0,
            valid: true,
            validcaja: true,
            dialog: false,
            dialogcaja: false,
            colores: [],
            colorSel: '',
            sizes: [],
            sizeSel: '',
            cantidad: 1,
            cantidad02: [],
            idUser:'',
            name: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1)),
            elementG: [],
            cab: [],
            itemPed: [],
            cantRules: [
                v => !!v || 'Cantidad inválida.',
                v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                v => (v && v < this.cantidad+1) || 'No se puede seleccionar esta cantidad +',
            ],
            valeMonto:0,
            anticipo:0,
            calcmulti:0,
            cantvale:0,
            valorcuenta:0,
            //Datos para el vale
            busqvalest:0,
            msjalerta:false,
            imgData: require('@/assets/logoSneaker.jpg'),
             n_caja: '',
            n_cajaRules: [
              v => !!v || 'El numero de caja es obligatorio',
              v => (v && v.length >= 0) || 'No se puede registrar numero de caja',
            ],
            
        }
    },
    created() {
        this.colores = this.CardData.item.zaa_color
        this.sizes = this.CardData.item.zaa_talla
        let cant = []
        for (let i = 1; i <= this.CardData.item.zaa_cantidad; i++) {               
            cant.push(i)
        }
        this.cantidad02 = cant
        axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then(res => this.idUser = res.data.user)
    },
    methods: {


        validate(){

           
            this.calcmulti = (this.cantidad) * (this.CardData.item.zaa_prec_cont)

            if(this.CardData.intercambioData.zipe_sub_tot > this.calcmulti){
                this.cantvale = (this.CardData.intercambioData.zipe_sub_tot - this.calcmulti)
                this.valorcuenta = this.calcmulti
                
                //alert('se creara un vale por la cantidad'+ this.cantvale)
                this.msjalerta = true
                this.dialogcaja = true

                 axios.get('http://127.0.0.1:8000/vale/')
                .then(res => {this.busqvalest = res.data.length
                
                let fecha_vale =  new Date().toISOString().slice(0,10)

                this.element = { 
                    "zdv_folio_vale": 'Vale-'+fecha_vale + '-'+this.num_random+'-'+ (this.busqvalest + 1),
                    "zdv_id_user_autori": 'No autorizado aún',
                    "zdv_id_user_qcobra_vale": 'No cobrado aún',
                    "zdv_fecha_cobro": null,
                    "zdv_importe": this.cantvale,
                    "zdv_id_sucursal": this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_sucursal,
                    "zdv_id_item_ped":this.CardData.intercambioData.zipe_id_item_ped,
                    "zdv_estat_vale": false,
                    "zdv_id_cliente": this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_usuario, 
                    "zdv_id_empleado": this.idUser 
                }  

                axios.post("http://127.0.0.1:8000/vale/", this.element)
                        .then (resVale => {
                            
                            
                          // this.generatePDF(this.element)
                        
                        
                        } ) 
                
                
                })

            }
            else{
                  //alert('NO se creara un vale')
                  this.valorcuenta = this.CardData.intercambioData.zipe_sub_tot
            }


            let artOriginal = []
            let idItemOriginal = this.CardData.intercambioData.zipe_id_item_ped 
            let URLArtOriginal = 'http://127.0.0.1:8000/articulo/client/' + this.CardData.intercambioData.zipe_id_arti.zaa_id_articulo + '/'
            let URLItemPedOri = 'http://127.0.0.1:8000/pedido/itemped/' + this.CardData.intercambioData.zipe_id_item_ped + '/'
             
            artOriginal = {
                zaa_cantidad: this.CardData.intercambioData.zipe_id_arti.zaa_cantidad + this.CardData.intercambioData.zipe_cant,
                zaa_color: this.CardData.intercambioData.zipe_id_arti.zaa_color,
                zaa_existen: this.CardData.intercambioData.zipe_id_arti.zaa_existen,
                zaa_id_sucursal: this.CardData.intercambioData.zipe_id_arti.zaa_id_sucursal,
                zaa_talla: this.CardData.intercambioData.zipe_id_arti.zaa_talla,
                zaa_id_arti_global: this.CardData.item.zaa_id_arti_global
            }
            
            if (this.$refs.form.validate()){





                axios.post('http://127.0.0.1:8000/pedido/pedcab/', {
                zped_status: 'Espera',
                zped_fecha: new Date().toISOString().slice(0,10),
                zipe_total: this.cantidad * this.CardData.item.zaa_prec_cont,
                zped_id_usuario: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_usuario,
                zped_nombre: 'PED-DEV-'+ this.name +'-'+ new Date().toISOString().slice(5,10),
                zped_id_empleado: this.idUser,
                zped_id_sucursal: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_sucursal,
                zped_is_afi: this.CardData.intercambioData.zipe_id_pedido_cab.zped_is_afi,
                zped_pagado:  this.valorcuenta,
                })
                .then(res => {
                    axios.post('http://127.0.0.1:8000/pedido/itemped/', {
                        zipe_status: 'Espera',
                        zipe_cant: this.cantidad,
                        zipe_color: this.colorSel,
                        zipe_devo: this.CardData.intercambioData.zipe_devo + 1,
                        zipe_id_arti: this.CardData.item.zaa_id_articulo,
                        zipe_id_pedido_cab: res.data.zped_id_pedcab,
                        zipe_sub_tot: this.cantidad * this.CardData.item.zaa_prec_cont,
                        zipe_talla: this.sizeSel,
                        zica_tipo_articulo: 'Preferido',
                    },
                    
                    axios.put('http://127.0.0.1:8000/pedido/pedcab/'+ this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_pedcab + '/', {
                    zped_status: this.CardData.intercambioData.zipe_id_pedido_cab.zped_status,
                    zped_fecha: this.CardData.intercambioData.zipe_id_pedido_cab.zped_fecha,
                    zipe_total: this.CardData.intercambioData.zipe_id_pedido_cab.zipe_total,
                    zped_id_usuario: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_usuario,
                    zped_nombre: this.CardData.intercambioData.zipe_id_pedido_cab.zped_nombre,
                    zped_id_empleado: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_empleado,
                    zped_id_sucursal: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_sucursal,
                    zped_is_afi: this.CardData.intercambioData.zipe_id_pedido_cab.zped_is_afi,
                    zped_pagado: this.anticipo
                    })
                        
                    
                    )

                    
                    
                    .then(newres => {
                        axios.post('http://127.0.0.1:8000/pedido/iteminter/', {
                            zpd_id_item_ori: idItemOriginal,
                            zpd_id_item_nue: newres.data.zipe_id_item_ped
                        })
                        .then(tabaux => {
                            axios.put(URLArtOriginal, artOriginal)
                            .then(artiori => {
                                axios.put(URLItemPedOri, {
                                    zipe_status: 'Devolución',
                                    zipe_cant: this.CardData.intercambioData.zipe_cant,
                                    zipe_color: this.CardData.intercambioData.zipe_color,
                                    zipe_devo: this.CardData.intercambioData.zipe_devo,
                                    zipe_id_arti: this.CardData.intercambioData.zipe_id_arti.zaa_id_articulo,
                                    zipe_id_pedido_cab: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_pedcab,
                                    zipe_sub_tot: this.CardData.intercambioData.zipe_sub_tot,
                                    zipe_talla: this.CardData.intercambioData.zipe_talla
                                })
                                .then(itemori => {
                                    if(this.dialogcaja == true){

                                    }
                                    else{
                                    window.location.reload()
                                    }
                                })
                            })
                        })
                    })
                })
            }
        },


        generatePDF() {
            
            this.total_pares = " " + this.CardData.intercambioData.zipe_cant + " pzas.";
            this.import = "$" + this.cantvale;
            this.fechaCreateVale = this.fecha_vale =  new Date().toISOString().slice(0,10)
            this.folio_vale = "Vale-" + this.fechaCreateVale + "-"+this.num_random+"-"+ (this.busqvalest + 1)
            var imgLogo = this.imgData
            
            var doc = new jsPDF({
                orientation: "portrait",
                unit: "in",
                format: "letter",
            }); 

            let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth(); 
            doc.setFont(undefined, 'bold').setFontSize(40).text("Zapatería Deny´s", pageWidth / 2, 1.0, {align: 'center'}); 
            doc.setFont(undefined, 'bold').setFontSize(35).text("CALZADO POR CATALOGO", pageWidth / 2, 2.0, {align: 'center'}); 
            doc.setLineWidth(0.05).line(0.5, 2.2, 8, 2.2); 
            doc.setFont(undefined, 'bold').setFontSize(30).text("VALE No.", pageWidth / 2, 2.8, {align: 'center'});
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
                                        //     x    y   longitud altura
            doc.setLineWidth(0.05).roundedRect(1.25, 3,    6,      0.75,    .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(this.element.zdv_folio_vale, pageWidth / 2, 3.5,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("FECHA: " + this.fechaCreateVale, pageWidth / 2, 4.2,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("CAJA: " + this.n_caja, pageWidth / 2, 4.8,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("PARES: " + this.total_pares, pageWidth / 2, 5.4,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("FOLIO PEDIDO", pageWidth / 2, 6,  {align: 'center'});
            
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
            doc.setLineWidth(0.05).roundedRect(1.75, 6.2,    5,      0.75,    .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(this.CardData.intercambioData.zipe_id_pedido_cab.zped_nombre, pageWidth / 2, 6.7,  {align: 'center'});

            doc.setFont(undefined, 'bold').setFontSize(30).text('IMPORTE: ' + this.import, 0.5, 7.5 );
            doc.setFont("courier", "bolditalic").text("VALIDO EN SU SIGUIENTE COMPRA", 0.25, 8); 
            doc.setFont("times", "normal").setFontSize(40).text("Firma:", 0.25, 9.6);
            doc.setLineWidth(0.05).line(1.8, 9.6, 8, 9.6);  
            doc.setFillColor(0, 0, 0);
            doc.setLineWidth(0.05).line(1.8, 9.6, 8, 9.6);  
            doc.autoPrint();
            doc.output('dataurlnewwindow');

            window.location.reload()
            
        },


    },
  }
</script>