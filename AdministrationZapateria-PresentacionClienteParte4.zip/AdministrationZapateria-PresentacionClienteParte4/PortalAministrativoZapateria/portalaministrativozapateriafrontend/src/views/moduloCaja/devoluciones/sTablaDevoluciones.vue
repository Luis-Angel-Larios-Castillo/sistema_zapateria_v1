<template>
  <div>
    <br />
    <v-row>
      <v-col>
        <v-card>
          <v-card-title class="card_title">
            <div class="col-12" id="table_cabecera_color">
              <v-text-field
                v-model="search"
                class="btn_search"
                dark
                dense
                rounded
                solo-inverted
                append-icon="mdi-magnify"
                label="Buscar"
                single-line
                hide-details
              />
            </div>
          </v-card-title>
          <v-card-text>
            <v-data-table
              no-results-text="No hay resultados."
              :items-per-page="5"
              no-data-text="No se tienen transacciones registradas."
              :headers="headersPedidos"
              :search="search"
              :items="findPedidos"
              :footer-props="{
                showFirstLastPage: true,
                itemsPerPageText: 'Elementos por página ',
              }"
            >
              <template v-slot:item.zped_id_pedcab="{ item }">
                <v-btn
                  icon
                  @click="getdetallesPedidos(item.zped_id_pedcab)"
                  justify-center
                >
                  <v-icon color="green">mdi-eye-outline</v-icon>
                </v-btn>
                <!--<v-btn
                  outlined
                  color="red"
                  @click="aceptar(item.zped_id_pedcab)"
                >
                  Borrar
                </v-btn>-->
              </template>
            </v-data-table>
          </v-card-text>
        </v-card>
      </v-col>
      <v-col>
        <v-card>
          <v-card height="100%" v-if="select == ''" color="grey lighten-1">
            <v-container fill-height justify-center>
              <h3>No se ha seleccionado ninguna transacción.</h3>
            </v-container>
          </v-card>

          <v-card height="100%" v-else>
            <v-card-title class="justify-center">
              <div>
                <h3>Articulos del pedido</h3>
              </div>
            </v-card-title>
            <v-card-subtitle class="subtitle-2 text-center black--text">
            </v-card-subtitle>
            <v-card-text class="justify-center">
              <h3 class="black--text">{{ detallespedselect.zipe_art_nom }}</h3>
              <v-text-field
                v-model="search2"
                append-icon="mdi-magnify"
                label="Buscar"
                single-line
                hide-details
              />
              <v-data-table
                no-results-text="No hay resultados."
                :items-per-page="5"
                no-data-text="No se tienen transacciones registradas."
                :headers="headersPedidosselect"
                :search="search2"
                :items="detallespedselect"
                :footer-props="{
                  showFirstLastPage: true,
                  itemsPerPageText: 'Elementos por página ',
                }"
              >
                <template v-slot:item.zipe_id_item_ped="{ item }">
                  <v-row align="center">
                    <v-col v-show="false">
                      <Vale :element="item" />
                    </v-col>
                    <v-col>
                      <SIntercambio :intercambioData="item" />
                    </v-col>
                  </v-row>
                </template>
              </v-data-table>
            </v-card-text>
          </v-card>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>
<script>
import Vale from "./pdfValeDevoluciones";
import SIntercambio from "./sIntercambio";
const axios = require("axios");
export default {
  components: {
    Vale,
    SIntercambio,
  },
  data() {
    return {
      findPedidos: [],
      search: "",
      search2: "",
      select: "",
      detallespedselect: [],
      headersPedidos: [
        { text: "Pedido", filterable: true, value: "zped_nombre" },
        { text: "Estatus", value: "zped_status" },
        { text: "Fecha", value: "zped_fecha" },
        {
          text: "Detalles",
          value: "zped_id_pedcab",
          sortable: false,
          align: "center",
        },
      ],
      headersPedidosselect: [
        { text: "Articulo", filterable: true, value: "zipe_art_nom" },
        {
          text: "Color",
          value: "zipe_color",
          sortable: false,
          align: "center",
        },
        { text: "Cantidad", value: "zipe_cant", align: "center" },
        {
          text: "Total",
          value: "zipe_sub_tot",
          sortable: false,
          align: "center",
        },
        {
          text: "Estatus",
          value: "zipe_status",
          sortable: false,
          align: "center",
        },
        {
          text: "Intercambiar",
          value: "zipe_id_item_ped",
          sortable: false,
          align: "center",
        },
      ],
      idUser:[],
      empleadoResult:[],
    };
  },

  created() {
    this.getPedidos();
  },

  methods: {
    aceptar(id) {
      let URL = "http://127.0.0.1:8000/pedido/pedcab/" + id;
      axios.delete(URL).then((response) => {
        this.dialog = false;
        window.location.reload();
      });
    },

    getPedidos() {

       const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            
            axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
            .then(res => { this.empleadoResult = res.data[0]
      axios
        .get("http://127.0.0.1:8000/pedido/pedcab/?search="+this.empleadoResult.zdem_id_sucursal)
        .then((res) => (this.findPedidos = res.data));

         })
                 })
    },

    getdetallesPedidos(id) {
      axios
        .get("http://127.0.0.1:8000/pedido/itembpc/?search=" + id)
        .then((res) => (this.detallespedselect = res.data));

      return (this.select = 1);
    },
  },
};
</script>