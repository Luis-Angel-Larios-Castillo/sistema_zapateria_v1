<template>
    <div>
        <v-btn text  color="teal" v-if="intercambioData.zipe_status == 'Entregado'" dark @click.stop="dialog = true" :disabled="intercambioData.zica_tipo_articulo == 'Opcional'">
            <v-icon>mdi-cached</v-icon>

        </v-btn>

       <v-tooltip bottom v-else >
      <template v-slot:activator="{ on, attrs }" >
        <v-btn text  color="secondary" v-bind="attrs"
          v-on="on">
            <v-icon>mdi-cached</v-icon>
        </v-btn>
         </template>
      <span>No se puede intercambiar este articulo por que no ha sido entregado</span>
    </v-tooltip>

        <v-dialog v-model="dialog" max-width="800">
            <v-card>
                <v-card-title>
                    <h3>Intercambiar: {{intercambioData.zipe_id_arti.zaa_nombre_arti}} - Fecha: {{intercambioData.zipe_fecha}}</h3> 
                </v-card-title>
                <v-card-text v-if="intercambioData.zipe_devo <= 3 && diasdiff <= 10">
                    <v-data-iterator :items="items" no-data-text="No hay resultados." no-results-text="No hay resultados." :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" :sort-by="sortBy.toLowerCase()" :sort-desc="sortDesc" hide-default-footer>
                    <template v-slot:header>
                        <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
                    </template>
                    <!-- Items inicio -->
                    <template v-slot:default="props"> 
                      <div v-for="item in props.items" :key="item.zaa_id_articulo">
                          <CardItem :CardData="{item, intercambioData}"/> <br><br>
                      </div>
                    </template>
                    <!--Items fin -->
                    <!-- Paginación inicio -->
                    <template v-slot:footer>
                      <v-row class="mt-2" align="center" justify="center" >
                        <span class="grey--text">Elementos por página</span>
                        <v-menu offset-y>
                          <template v-slot:activator="{ on, attrs }">
                            <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                              {{ itemsPerPage }}
                              <v-icon>mdi-chevron-down</v-icon>
                            </v-btn>
                          </template>
                          <v-list>
                            <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                              <v-list-item-title>{{ number }}</v-list-item-title>
                            </v-list-item>
                          </v-list>
                        </v-menu>
                        <v-spacer></v-spacer>
                        <span class="mr-4 grey--text">
                          Página {{ page }} de {{ numberOfPages }}
                        </span>
                          <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
                          <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
                        <!-- Paginación fin -->
                      </v-row>
                    </template>
                  </v-data-iterator>
                </v-card-text>  
                <v-card-text v-else>
                  <v-alert border="bottom" colored-border type="warning" elevation="2" >
                    No se puede hacer el intercambio porque ya se realizaron mas de 3 devoluciones o se excedió la fecha limite para realizar la devolución. 
                  </v-alert>
                </v-card-text>              
            </v-card>
        </v-dialog>    
    </div>
</template>
<script>
import CardItem from './sCarditem'
const axios = require('axios')
const moment = require('moment')
export default {
    components:{
        CardItem
    },
    props:[
        'intercambioData'
    ],
    data() {
        return {
            dialog: false,       
            items: [],
            diasdiff: 0,
            itemsPerPageArray: [ 5, 10, 15],
            search: '',
            filter: {},
            sortDesc: false,
            page: 1,
            itemsPerPage: 5,
            sortBy: 'zaa_nombre_arti',
            keys: [
            'zaa_color',
            'zaa_marca',
            'zaa_clave',
            'zaa_talla',
            'zaa_cantidad',
            'zaa_prec_cont',
            'zaa_modelo' 
            ],     
            idUser:[],
            empleadoResult:[],
        }
    },
    computed: {
      numberOfPages () {
        return Math.ceil(this.items.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Name')
      },
    },
    created() {

      const userToken = localStorage.token
      axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
      .then(res => {this.idUser = res.data.user      
          axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
          .then(res => { this.empleadoResult = res.data[0]
          axios.get('http://127.0.0.1:8000/articulo/client/?search=' + this.empleadoResult.zdem_id_sucursal)
            .then(res => {this.items = res.data 
               })
            })

        }) 



      let f01 = moment(new Date())
      let f02 = moment(this.intercambioData.zipe_fecha)
      let dias = f01.diff(f02, 'days')
      this.diasdiff = dias
    },
     methods: {
      nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
      },
      formerPage () {
        if (this.page - 1 >= 1) this.page -= 1
      },
      updateItemsPerPage (number) {
        this.itemsPerPage = number
      },
    },
}
</script>