/*
        ♣ Autor: Luis Angel Larios Castillo.
        ♣ Descripción:  Complemento de dialog para vista de articulos devueltos
 */
<template>
  <v-row justify="center">
    <v-dialog
      v-model="dialog"
      scrollable
      max-width="400px"
    >
      <template v-slot:activator="{ on, attrs }">
        <v-btn
            color="#000"
            text
          v-bind="attrs"
          v-on="on"
           @click="find(element.zpd_id_item_ori.zipe_id_arti.zaa_id_articulo)"
        >
         {{element.articuloorig}}
        </v-btn>
      </template>
      <v-card>
        <v-card-title>{{findarticulo.zaa_nombre_arti}}</v-card-title>
        <v-divider></v-divider>
        <v-card-text style="height: 400px; color:#000; font-size:16px;">
           <v-alert dense text type="info"><strong>ID de devolución :</strong> <h5>{{element.zpd_id_pedid_devol}}</h5></v-alert>
                       
           <v-simple-table dense>
            <template v-slot:default>
              <tbody>
                <tr>
                  <th class="text-left">
                   Clave
                  </th>
                  <td>{{findarticulo.zaa_clave}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                    Codigo de barras
                  </th>
                  <td>{{findarticulo.zaa_codigo_bar}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                   Categoria
                  </th>
                  <td>{{findarticulo.zaa_categoria}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                    Modelo
                  </th>
                   <td>{{findarticulo.zaa_modelo}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                   Cantidad devuelta
                  </th>
                   <td>{{element.zpd_id_item_ori.zipe_cant}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                    Sub total
                  </th>
                   <td>${{element.zpd_id_item_ori.zipe_sub_tot}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                   Marca 
                  </th>
                   <td>{{findarticulo.zaa_marca}}</td>
                </tr>
                 <tr>
                  <th class="text-left">
                   Color 
                  </th>
                   <td>{{element.zpd_id_item_ori.zipe_color}}</td>
                </tr>
                <tr>
                  <th class="text-left">
                   Talla 
                  </th>
                   <td>{{element.zpd_id_item_ori.zipe_talla}}</td>
                </tr>
                </tbody>
            </template>
          </v-simple-table>


          
           
           
        </v-card-text>
        <v-divider></v-divider>
        <v-card-actions>
          <v-btn
            color="blue darken-1"
            text
            @click="dialog = false"
          >
            Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script>
const axios = require('axios')
  export default {
       props:[
        'element'
    ],
    data () {
      return {
        findarticulo:[],
        dialog: false,
      }
    },
    created(){
     
    },
    
    methods: {
      find(id) {
        let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
        axios.get('http://127.0.0.1:8000/articulo/admin/' + id+'/',config)
        .then(res => {this.findarticulo = res.data
       
        });
    },
    }
  }
</script>