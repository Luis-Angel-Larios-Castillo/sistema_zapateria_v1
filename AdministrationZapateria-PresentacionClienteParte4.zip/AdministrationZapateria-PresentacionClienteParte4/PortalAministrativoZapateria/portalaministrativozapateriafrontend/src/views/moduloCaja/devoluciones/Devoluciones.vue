/*
        ♣ Autor: Luis Angel Larios Castillo.
        ♣ Apoyo: Miguel Angel Zamora Carmona.
        ♣ Descripción:  Este modulo se centra en realizar la busqueda y comparativa de
                        productos devueltos depues de que se realiza el algun pedido.
 */

<template>
  <v-container fluid>
     <app-header style="z-index: 135"/> 
     <br>
    <v-card>
      <v-tabs background-color="#14213d" dark>
        <v-tab>Devolución de pedidos</v-tab>
        <v-tab>Intercambio de articulos</v-tab>
        <v-tab>Devoluciones</v-tab>
        <v-tab-item> <sTablaDevoluciones /> </v-tab-item>
        <v-tab-item>
          <v-row>
            <v-col>
              <div class="grey darken-4">
                <h2 class="white--text">Artículos devueltos</h2>
              </div>
              <v-responsive class="overflow-y-auto" max-height="450">
                <v-responsive class="text-center">
                  <v-data-iterator
                    :items="pedi"
                    no-data-text="No hay resultados."
                    no-results-text="No hay resultados."
                    :items-per-page.sync="itemsPerPage"
                    :page.sync="page"
                    :search="search"
                    :sort-by="sortBy.toLowerCase()"
                    :sort-desc="sortDesc"
                    hide-default-footer
                  >
                  
                    <template v-slot:header>
                       <v-tabs>
        <v-tab @click="select_buscador = 1">Estatus</v-tab>
        <v-tab @click="select_buscador = 2">Buscador</v-tab>
         </v-tabs>
                      <v-col v-show="select_buscador == 2">
                      <v-text-field
                        v-model="search"
                        clearable
                        flat
                        solo-inverted
                        hide-details
                        prepend-inner-icon="mdi-magnify"
                        label="Buscar..."
                        
                      />
                      </v-col>
                      <v-col v-show="select_buscador == 1">
                        <v-select v-model="statusped" v-on:change="find()" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar un Estatus']"  label="Estatus" required/>
                      </v-col>
                    </template>

                
                    <!-- Items inicio -->
                    <template v-slot:default="props">
                      <v-row>
                       
                        <v-col
                          v-for="d in props.items"
                          :key="d.zpd_id_pedid_devol"
                          cols="12"
                        >
                          <v-hover v-slot="{ hover }">
                            <v-card
                              class="mx-auto cardcolor"
                              max-width="400"
                              outlined
                              :elevation="hover ? 16 : 2"
                              :class="{ 'on-hover': hover }"
                            >
                              <v-list-item three-line> 
                                <v-list-item-content> 
                                  <div class="text-overline mb-4">
                                     {{d.claveorig}}<br>
                                    Precio: ${{
                                      d.zpd_id_item_ori.zipe_sub_tot
                                    }}
                                  </div>
                                 
                                  <sArtPed :element="d" />
                                  
                                  <v-list-item-subtitle
                                    >
                                    
                                    <v-chip
                                      :color="
                                        conditionColor(
                                          d.zpd_id_item_ori.zipe_status
                                        )
                                      "
                                      class="white--text"
                                    >
                                      {{ d.zpd_id_item_ori.zipe_status }}
                                    </v-chip>
                                    </v-list-item-subtitle
                                  >
                                </v-list-item-content>
                              </v-list-item>
                              <v-card-actions>
                                <v-btn
                                  @click="select = d.zpd_id_pedid_devol"
                                  outlined
                                  depressed
                                  color="deep-purple accent-4"
                                  rounded
                                >
                                  Detalles de cambio
                                </v-btn>
                              </v-card-actions>
                            </v-card>
                          </v-hover>
                        </v-col>
                      </v-row>
                      <div></div>
                    </template>
                    <!-- Items fin -->
                  </v-data-iterator>
                </v-responsive>
              </v-responsive>
            </v-col>
            <v-col cols="md-8 xs-12">
              <v-card height="100%" v-if="select == ''" color="#ECECEC">
                <v-container fill-height justify-center>
                  <h3>No se ha seleccionado ningún artículo</h3>
                </v-container>
              </v-card>

              <div
                v-for="prin in findarticulos"
                v-bind:key="prin.zpd_id_pedid_devol"
              >
                <div v-if="select == prin.zpd_id_pedid_devol">
                  <v-card height="100%">
                    <v-alert dense color="#000" dark>
                      <h2 class="white--text">Este artículo se cambio por</h2>
                    </v-alert>
                    <v-card-text class="">
                      <div align="left">
                        <v-card class="mx-auto" max-width="800" outlined>
                          <v-list-item three-line>
                            <v-list-item-avatar tile size="190" color="grey">
                              <v-img class="imgColor align-center"/>
                            </v-list-item-avatar>
                            <v-list-item-content>
                              <div class="text-overline mb-4">
                                <v-chip class="white--text" color="#000">
                                  SKU:
                                </v-chip>
                                <v-chip class="ma-2" label>
                                  <!--<h3>{{prin.zpd_id_item_nue.zipe_id_arti.zaa_id_articulo}}</h3>-->
                                  <h3>
                                    {{
                                      prin.clavenew
                                    }}
                                  </h3>
                                </v-chip>
                               
                                <br />
                                <v-chip class="white--text" color="#000">
                                  Artículo:
                                </v-chip>
                                <v-chip class="ma-2" label>
                                  <h3>
                                    {{
                                      prin.articulonew
                                    }}
                                  </h3>
                                </v-chip>
                                <br />
                                <v-chip class="white--text" color="#000">
                                  Precio:
                                </v-chip>
                                <v-chip class="ma-2" label>
                                  <h3>
                                    $ {{ prin.zpd_id_item_nue.zipe_sub_tot }}
                                  </h3>
                                </v-chip>
                              </div>
                              <br />
                              <div class="text-center">
                                <sArtPedNew :elementnew="prin" />
                              </div>
                            </v-list-item-content>
                          </v-list-item>
                        </v-card>
                        <br />
                        <v-card>
                          <v-tabs background-color="#000" dark>
                            <!--<v-tab>Transacción</v-tab>-->
                            <v-tab>Datos del cliente</v-tab>
                            <v-tab>Detalles de cambio</v-tab>
                            <!--<v-tab-item>
                              <v-simple-table>
                                <template v-slot:default>
                                  <thead>
                                    <tr>
                                      <th class="text-center">
                                        Articulo devuelto
                                      </th>
                                      <th class="text-center">
                                        Articulo Nuevo
                                      </th>
                                      <th class="text-center">Transacción</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td class="text-center">
                                        $
                                        {{ prin.zpd_id_item_ori.zipe_sub_tot }}
                                      </td>
                                      <td class="text-center">
                                        $
                                        {{ prin.zpd_id_item_nue.zipe_sub_tot }}
                                      </td>
                                      <td class="text-center">
                                        {{
                                          calcular(
                                            prin.zpd_id_item_ori.zipe_sub_tot,
                                            prin.zpd_id_item_nue.zipe_sub_tot
                                          )
                                        }}
                                      </td>
                                    </tr>
                                    <tr>
                                      <td hidden>
                                        <div hidden>
                                          {{
                                            comprobardebo(
                                              prin.zpd_id_pedid_devol
                                            )
                                          }}
                                        </div>
                                        <v-btn
                                          rounded
                                          color="primary"
                                          dark
                                          small
                                          v-show="false"
                                          v-if="comrprobacionboo == false"
                                          @click="
                                            guardar(
                                              prin.zpd_id_item_ori.zipe_sub_tot,
                                              prin.zpd_id_item_nue.zipe_sub_tot,
                                              prin.zpd_id_pedid_devol
                                            )
                                          "
                                        >
                                          Guardar
                                        </v-btn>
                                        <v-alert dense text type="info" v-else v-show="false"
                                          >Este articulo ya se registro como
                                          devuelto</v-alert
                                        >
                                         
                                      </td>
      
                                       <td v-show="mensaje_reem == 'Reembolso'" colspan="3"> <pdfreem :element="prin" :cantreem="valor_reem"/></td>
                                    </tr>
                                  </tbody>
                                </template>
                              </v-simple-table>
                            </v-tab-item>-->
                            <v-tab-item>
                              <v-simple-table>
                                <template v-slot:default>
                                  <thead>
                                    <tr>
                                      <td class="text-left">Folio :</td>
                                      <td class="text-left">
                                        {{
                                         foliclie
                                        }}
                                      </td>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td class="text-left">Nombre :</td>
                                      <td class="text-left">
                                        {{
                                          getName(
                                            prin.zpd_id_item_ori
                                              .zipe_id_pedido_cab
                                              .zped_id_usuario
                                          )
                                        }}
                                        {{ nomclie }}
                                      </td>
                                    </tr>
                                  </tbody>
                                </template>
                              </v-simple-table>
                            </v-tab-item>
                            <v-tab-item>
                              <v-simple-table>
                                <template v-slot:default>
                                  <thead>
                                    <tr>
                                      <th>Tipo de pedido</th>
                                      <th>Nombre de pedido</th>
                                      <th>Fecha de pedido</th>
                                      <th>Estatus</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Pedido Original</td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_ori
                                            .zipe_id_pedido_cab.zped_nombre
                                        }}
                                      </td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_ori
                                            .zipe_id_pedido_cab.zped_fecha
                                        }}
                                      </td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_ori
                                            .zipe_id_pedido_cab.zped_status
                                        }}
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Pedido Nuevo</td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_nue
                                            .zipe_id_pedido_cab.zped_nombre
                                        }}
                                      </td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_nue
                                            .zipe_id_pedido_cab.zped_fecha
                                        }}
                                      </td>
                                      <td>
                                        {{
                                          prin.zpd_id_item_nue
                                            .zipe_id_pedido_cab.zped_status
                                        }}
                                      </td>
                                    </tr>
                                  </tbody>
                                </template>
                              </v-simple-table>
                            </v-tab-item>
                          </v-tabs>
                        </v-card>
                      </div>
                    </v-card-text>
                  </v-card>
                </div>
                <div v-else></div>
              </div>
            </v-col>
          </v-row>
        </v-tab-item>
        <v-tab-item> <ListDevoluciones/> </v-tab-item>
      </v-tabs>
    </v-card>
  </v-container>
</template>
<script>
import Header from '../../../components/Header';
const axios = require("axios");
import sArtPed from "./sArtPed";
import ListDevoluciones from './ListDevoluciones.vue';
import sArtPedNew from "./sArtPedNew";
import sTablaDevoluciones from './sTablaDevoluciones';
import pdfreem from './pdfValereembolso';
const moment = require("moment");
export default {
  name: 'Header', 
  components: {
    "app-header": Header,
    sArtPed,
    sArtPedNew,
    sTablaDevoluciones,
    pdfreem,
    ListDevoluciones,
  },
  data() {
    return {
      select: "",
      tab: null,
      dialog: false,
      id: "",
      element: Object,
      elementnew: Object,
      envinfo: {},
      fecha: new Date().toISOString().substr(0, 10),
      empleado: null,
      alerta: null,
      nombre: "",
      foli_client:"",
      itemsPerPageArray: [9, 18, 27],
      search: "",
      filter: {},
      sortDesc: false,
      page: 1,
      itemsPerPage: 999999,
      sortBy: "zpd_id_pedid_devol",
      keys: [
        //'zpd_id_item_ori.zipe_sub_tot',
        "articuloorig",
        "claveorig",
        "user_correo",
        "precio_orig",
      ],
      findarticulos: [],
      comrprobacionboo: Boolean,
      alertcond: 0,
      mensaje_reem:'',
      valor_reem:0,
      statusItems: [
                'Devolución', 
                'Entregado',
               
            ],
      statusped: 'Devolución',
      pedi: [],
      select_buscador:1,
      idUser:[],
      empleadoResult:[],
       datos:[],
         nomclie:[],
         datosclinoafi:[],
         foliclie:[],
    };
  },
  created() {
    this.find();
    this.getUser();
  },
  computed: {
    numberOfPages() {
      return Math.ceil(this.findarticulos.length / this.itemsPerPage);
    },
    filteredKeys() {
      return this.keys.filter((key) => key !== "Name");
    },
  },

  methods: {
    getName(id_user_client) {
        axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+ id_user_client)
                .then(res =>{ this.datos = res.data           
                if(res.data.length  > 0){
                    this.nomclie = this.datos[0].nombre
                    this.foliclie = this.datos[0].zc_folio_client

                    //console.log(this.datos[0].nombre)
                }
                else{
                    axios.get('http://127.0.0.1:8000/clientes/'+id_user_client+'/')
                    .then(res =>{ this.datosclinoafi = res.data 
                        this.nomclie = this.datosclinoafi.nombre
                         this.foliclie = this.datosclinoafi.zc_folio_client
                    
                    })          
                }
                
                })       
    },

    conditionColor(estatus) {
      if (estatus == "Devolución") return "red accent-3";
      else if (estatus == "Proceso") return "orange accent-3";
      else return "green accent-4";
    },
    find() {
      this.pedi = []

       const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            
            axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
            .then(res => { this.empleadoResult = res.data[0]

      axios
        .get("http://127.0.0.1:8000/pedido/intercambiadmin/")
        .then((res) => {this.findarticulos = res.data
        
        res.data.forEach(element => { 
                        if(element.zpd_id_item_ori.zipe_status ==  this.statusped && element.zpd_id_item_ori.zipe_id_pedido_cab.zped_id_sucursal == this.empleadoResult.zdem_id_sucursal){
                            this.pedi.push(element)
                        }
                    }); 
        
        
        });
            })
                 })
    },
    getUser() {
      axios
        .get("http://127.0.0.1:8000/usuario/token/" + localStorage.token + "/")
        .then((res) => {
          axios
            .get(
              "http://127.0.0.1:8000/usuario/getusuario/" + res.data.user + "/"
            )
            .then((r) => (this.empleado = r.data));
        });
    },
    calcular(p_orig, p_new) {
      let total = 0;
      let est_total = "";
      let respuesta = "";
      if (p_orig > p_new) {
        total = p_orig - p_new;
        est_total = "Reembolso de $ ";
        this.mensaje_reem='Reembolso';
        this.valor_reem=total;
      } else if (p_new > p_orig) {
        total = p_orig - p_new;
        total = Math.abs(total);
        est_total = "Adeuda $ ";
       this.mensaje_reem='Adeuda';
      } else {
        total = 0;
        this.mensaje_reem='Adeuda';
        est_total = "Adeuda $ ";
      }
      respuesta = est_total + total;
      return respuesta;
    },
    guardar(p_orig, p_new, id_ped) {
      let total = 0;
      let est_trans = "";
      let est_tipomin = "";
      let concepto = "";
      if (p_orig > p_new) {
        total = p_orig - p_new;
        concepto = "Reembolso por intercambio de articulo: ";
        est_trans = "RETIRO";
        est_tipomin = "Retiro";
      } else if (p_new > p_orig) {
        total = p_orig - p_new;
        total = Math.abs(total);
        concepto = "Deposito por intercambio de articulo: ";
        est_trans = "DEPOSITO";
        est_tipomin = "Depósito";
      } else {
        total = 0;
        est_trans = "RETIRO";
        est_tipomin = "Retiro";
        concepto = "Reembolso por intercambio de articulo: ";
      }
      this.envinfo = {
        zca_nombre:
          est_trans +
          "-" +
          new Date().toISOString().slice(2, 10) +
          "-" +
          moment(new Date()).format("H:mm "),
        zca_tipo: est_tipomin,
        zca_concepto: concepto + id_ped,
        zca_fecha: this.fecha,
        zca_hora: moment(new Date()).format("H:mm "),
        zca_total: total,
        zca_id_usuario: this.empleado.zdus_id_usuario,
      };
      axios.post("http://127.0.0.1:8000/caja/cabecera/", this.envinfo);
      this.alertcond = 1;
      window.location.reload();
    },
    nextPage() {
      if (this.page + 1 <= this.numberOfPages) this.page += 1;
    },
    formerPage() {
      if (this.page - 1 >= 1) this.page -= 1;
    },
    updateItemsPerPage(number) {
      this.itemsPerPage = number;
    },
    comprobardebo(id_debo) {
      axios
        .get("http://127.0.0.1:8000/caja/cabconcepto/?search=" + id_debo)
        .then((res) => {
          if (res.data.length != 0) {
            this.comrprobacionboo = true;
          } else {
            this.comrprobacionboo = false;
          }
        });
    },
  },
};
</script>
<style scoped>
</style>