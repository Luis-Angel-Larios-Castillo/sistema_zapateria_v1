<template>
  <v-container>
    <v-dialog v-model="dialog" width="300">
      <template v-slot:activator="{ on, attrs }">
        <v-btn v-bind="attrs" v-on="on" icon :disabled="element.zica_tipo_articulo == 'Opcional'">
          <v-icon color="orange">mdi-inbox-full-outline</v-icon>
        </v-btn>
      </template>

      <v-card>
        <v-card-title>
          {{ element.nomped_nomarti }}
          {{findnomclien(element.zipe_id_pedido_cab.zped_id_usuario)}}
        </v-card-title>

        <v-card-text>
          <v-form ref="form" v-model="valid" lazy-validation>
            <v-text-field
              label="Numero de Caja"
              outlined
              type="number"
              v-model="n_caja"
              :rules="n_cajaRules"
            ></v-text-field>
          </v-form>

          <v-btn color="red" text @click="dialog = false"> Cancelar </v-btn>
          <v-btn :disabled="!valid" @click="guardarvale()" text color="primary">
            generar
          </v-btn>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template> 
<script>
import jsPDF from "jspdf";
let fecha_vale = new Date().toISOString().slice(0, 10);
const axios = require("axios");
const moment = require("moment");
export default {
  props: ["element"],
  data() {
    return {
      //guardar vale
      busqvalest: [],
      num_random:
        Math.floor(Math.random() * (10 - 1 + 1)) +
        "" +
        Math.floor(Math.random() * (10 - 1 + 1)) +
        "" +
        Math.floor(Math.random() * (10 - 1 + 1)),
      empleado: [],
      vale_folio: "",
      busqnomcli: [],
      //generar pdf
      fec_crea_valida: null,
      total: "",
      ocultar: false,
      total_pares: "",
      dialog: false,
      valid: true,
      n_caja: "",
      n_cajaRules: [
        (v) => !!v || "El campo es obligatorio",
        (v) => (v && v >= 0) || "No se puede registrar este valor",
      ],
    };
  },
  created() {
    this.findvalest();
    
  },
  methods: {
    findvalest() {
      axios
        .get("http://127.0.0.1:8000/vale/")
        .then((res) => (this.busqvalest = res.data));
    },

    guardarvale() {
      axios
        .post("http://127.0.0.1:8000/vale/", {
          zdv_folio_vale:
            "Vale-" +
            fecha_vale +
            "-" +
            this.num_random +
            "-" +
            (this.busqvalest.length + 1),
          zdv_id_user_autori: "No autorizado aún",
          zdv_id_user_qcobra_vale: "No cobrado aún",
          zdv_fecha_cobro: null,
          zdv_importe: this.element.zipe_sub_tot,
          zdv_id_sucursal: this.element.zipe_id_arti.zaa_id_sucursal,
          zdv_id_item_ped: this.element.zipe_id_item_ped,
          zdv_id_cliente: this.element.zipe_id_pedido_cab.zped_id_usuario,
          zdv_estat_vale: false,
          zdv_id_empleado: this.element.zipe_id_pedido_cab.zped_id_empleado,
          zdv_tipo_vale: "Devolución",
        })
        .then((res) => {
          (this.vale_folio = res.data.zdv_folio_vale),
            (this.fec_crea_valida = moment(res.data.zdv_fech_crea)
              .locale("MX")
              .format("DD-MM-YYYY"));
            
          this.generatePDF();
        })
        .catch((error) => console.log(error));
    },

    findnomclien(id) {
      axios
        .get(
          "http://127.0.0.1:8000/cliente/clientes/?search=" + id
        )
        .then((res) => (this.busqnomcli = res.data[0]));
    },

    generatePDF() {
      this.total = "$" + this.element.zipe_sub_tot;
      this.total_pares = " " + this.element.zipe_cant;
      var doc = new jsPDF();

      // Contorno
      doc.setDrawColor(0);
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(55, 20, 100, 170, 3, 3, "FD");

      // Contorno FOLIO VALE 1
      doc.setDrawColor(0);
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(70, 67, 70, 10, 3, 3, "FD");

      // Contorno FOLIO VALE 2
      doc.setDrawColor(0);
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(70, 117, 70, 10, 3, 3, "FD");

      // Titulos 1
      doc.setFontSize(22);
      doc.setFont("times", "normal");
      doc.text("Zapateria Dennys", 105, 35, null, null, "center");
      // Titulos 2
      doc.setFontSize(15);
      doc.setFont("times", "normal");
      doc.text("CALZADO POR CATALOGO", 105, 45, null, null, "center");
      // Linea Horizontal 1
      doc.line(78, 50, 130, 50);

      // Campos de vale estaticos
      doc.setFontSize(13);
      doc.setFont("times", "normal");
      doc.text("VALE No. :", 103, 65, null, null, "center");
      doc.text("FECHA :", 72, 85, null, null, "center");
      doc.text("CAJA :", 120, 85, null, null, "center");
      doc.text("CLIENTE :", 74, 95, null, null, "center");
      doc.text("PARES :", 72, 105, null, null, "center");
      doc.text("FOLIO PEDIDO :", 105, 115, null, null, "center");
      doc.text("IMPORTE :", 72, 135, null, null, "center");
      // Campo de alerta y firma
      doc.setFont("courier", "bolditalic");
      doc.text(
        "VALIDO EN SU SIGUIENTE COMPRA!",
        105,
        150,
        null,
        null,
        "center"
      );
      doc.setFont("times", "normal");
      doc.text("FIRMA :", 72, 170, null, null, "center");
      // Linea Horizontal 2
      doc.line(85, 170, 145, 170);

      //DATOS DINAMICOS
      doc.setFont("times", "bold");
      doc.text(this.vale_folio, 105, 74, null, null, "center"); //id vale1
      doc.text(this.fec_crea_valida, 93, 85, null, null, "center"); //fecha
      doc.text(this.n_caja, 133, 85, null, null, "center"); // caja

      doc.text(this.busqnomcli.nombre, 115, 95, null, null, "center"); //folio cliente

      doc.text(this.total_pares, 88, 105, null, null, "center"); //pares
      doc.text(
        this.element.zipe_id_pedido_cab.zped_nombre,
        105,
        124,
        null,
        null,
        "center"
      ); //id vale2
      doc.text(this.total, 92, 135, null, null, "center"); //importe

      doc.save(`${this.vale_folio}.pdf`);
    },
  },
};
</script> 