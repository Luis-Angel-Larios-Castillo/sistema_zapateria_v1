Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz con un listado de retiros y depósitos y el formulario para crear uno nuevo  
<template>
    <v-container fluid>
        <app-header style="z-index: 135"/> 
        <div class="hr-sect"><h2>Movimientos de caja</h2></div>
        <v-row>
            <v-col cols="md-6 xs-12">
                <v-card height="100%">
                    <v-card-title  dark class="grey darken-4">
                        <h3 class="white--text">Nuevo movimiento</h3>
                    </v-card-title>
                    <v-card-text>
                        <v-text-field v-model="search" append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                        <v-data-table 
                            no-results-text="No hay resultados."
                            :items-per-page="5"
                            no-data-text="No se tienen transacciones registradas." :headers="headers" :search="search" :items="items" 
                            :footer-props="{
                                showFirstLastPage: true,
                                itemsPerPageText: 'Elementos por página ',
                            }"
                        >
                            <template v-slot:item.zca_tipo="{ item }"  >
                            <p v-if="item.zca_tipo == 'Retiro'" class="red--text">{{item.zca_tipo}}</p>
                            <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">{{item.zca_tipo}}</p>
                            <p v-if="item.zca_tipo == 'Servicio'" class="orange--text">{{item.zca_tipo}}</p>
                            </template>
                            <template v-slot:item.zca_total="{ item }">
                            <p v-if="item.zca_tipo == 'Retiro'" class="red--text">${{item.zca_total}}</p>
                            <p v-if="item.zca_tipo == 'Depósito'" class="blue--text">${{item.zca_total}}</p>
                            <p v-if="item.zca_tipo == 'Servicio'" class="orange--text">${{item.zca_total}}</p>
                            </template>
                            <template v-slot:item.zca_id_pedcab="{ item }"  >
                                <v-btn icon @click="select = item.zca_id_pedcab" justify-center> 
                                    <v-icon color="green">mdi-eye-outline</v-icon>
                                </v-btn>
                            </template>
                        </v-data-table>
                    </v-card-text>
                </v-card>
            </v-col>
            <v-col cols="md-3 xs-12">
                <v-card height="100%" v-if="select == ''" color="grey lighten-1">
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado ninguna transacción.</h3>
                    </v-container>
                </v-card>

                <v-card height="100%" v-else>
                    <v-card-title class="justify-center">
                        <div>
                            <h3 >Zapatería Deny´s</h3>
                        </div>
                    </v-card-title>
                    <v-card-subtitle class="subtitle-2 text-center black--text">
                    </v-card-subtitle>
                    <v-card-text class="justify-center">
                        {{detail()}}
                        <h3 class="black--text">{{itemsDetail.zca_nombre}}</h3>
                        <h4 class="black--text">Fecha:{{itemsDetail.zca_fecha}}</h4>
                        <h4 class="black--text">Hora: {{itemsDetail.zca_hora}}</h4>
                        <h4 class="black--text">Tipo: {{itemsDetail.zca_tipo}}</h4>
                        <h4 class="black--text">Total: ${{itemsDetail.zca_total}}</h4>
                        <p class="black--text">Concepto: {{itemsDetail.zca_concepto}}</p>
                        
                    </v-card-text>
                </v-card>
                </v-col>
                <v-col cols="md-3 xs-12">
                <v-card >
                    <v-card-title  dark class="grey darken-4">
                        <h3 class="white--text">Nuevo movimiento</h3>
                    </v-card-title>
                    <v-card-actions class="justify-center" align="center">
                        <v-btn color="red" @click="movType = 'Retiro', reset()" text>Retiro</v-btn>
                        <v-btn color="blue" @click="movType = 'Depósito', reset()" text>Deposito</v-btn>
                        <v-btn color="orange" @click="movType = 'Servicio'" text>Servicios</v-btn>
                    </v-card-actions>
                    <v-card-text>
                        <v-form ref="form" v-model="valid" lazy-validation m>
                            
                            <v-row>
                                
                               
                                <v-col>
                                    <v-text-field v-model="movType" class="black--text" required disabled/>
                                </v-col>
                                <v-col>
                                    <v-text-field v-model="monto" label="Monto" :rules="montoRules" required type="number" min="1"/>
                                </v-col>
                            </v-row>
                            <v-row v-if="movType == 'Servicio'">
                                <v-col>
                                   <v-select
                                    :items="['Agua Potable', 'Luz Electrica', 'Internet', 'Otro']"
                                    label="Seleccione el Servicio"
                                    v-model="p_serv"
                                    :rules="[v => !!v || 'Debe seleccionar una servicio']"
                                ></v-select>
                                </v-col>
                            </v-row>
                            <v-row v-else>
                                <v-col>
                                    <v-textarea  auto-grow label="Concepto" v-model="concepto" :rules="conceptoRules" rows="2" row-height="20"/>
                                </v-col>
                            </v-row>
                            
                            <v-row v-if="p_serv=='Agua Potable' && movType == 'Servicio' || p_serv=='Luz Electrica' && movType == 'Servicio' || p_serv=='Internet' && movType == 'Servicio' ">
                                <v-col>
                                   <v-text-field v-model="periodo_serv" class="black--text" label="Periodo" required :rules="perido_serv" maxlength="60"/>
                                </v-col>
                            </v-row>

                            <v-row v-if="p_serv=='Otro' && movType == 'Servicio'">
                                <v-col>
                                   <v-text-field v-model="p_serv2" class="black--text" label="Tipo de servicio" required :rules="otroserv" maxlength="60"/>
                                </v-col>
                            </v-row>
                            <v-btn :disabled="!valid" color="success" class="mr-4" @click="validate" text>
                                Guardar
                            </v-btn>
                        </v-form>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container> 
</template>
<script>
import Header from '../../components/Header';
const axios = require('axios')
const moment = require('moment')
export default {
    name: 'Header',
     components:{
        "app-header": Header,
        },
    data() {
        return {
            p_serv:'',
            p_serv2:'',
            periodo_serv:'',
            select: '',
            search: '',
            empleado: null,
            movType: 'Retiro',
            valid: true,
            element: Object,
            fecha: new Date().toISOString().substr(0, 10),
            monto: 1,
            montoRules: [ 
                v => !!v || 'Monto inválida.', 
                v => (v && v > 0) || 'No se puede seleccionar este monto.'
            ],
            concepto: '',
            conceptoRules: [ 
                v => !!v || 'Concepto inválido.', 
                v => (v && v.length <= 250) || 'Concepto demaciado largo.'
            ],
            
            otroserv: [ 
                v => !!v || 'Tipo de servicio inválido.', 
                v => (v && v.length >= 3) || 'Tipo de servicio demaciado corto.',
                v => (v && v.length <= 60) || 'Tipo de servicio demaciado largo.'
            ],
            perido_serv:
            [ 
                v => !!v || 'Tipo de periodo inválido.', 
                v => (v && v.length >= 3) || 'Tipo de periodo demaciado corto.',
                v => (v && v.length <= 60) || 'Tipo de periodo demaciado largo.'
            ],
            headers: [
                {
                    text: 'Transacción',
                    align: 'start',
                    value: 'zca_nombre',
                },
                
                //{ text: 'Empleado', value: 'zca_empleado' },
                { text: 'Fecha', value: 'zca_fecha' },
                //{ text: 'Hora', value: 'zca_hora' },
                { text: 'Tipo', value: 'zca_tipo' },
                //{ text: 'Cliente', value: 'cliente' },
                { text: 'Monto', value: 'zca_total' },
                { text: 'Seleccionar', value: 'zca_id_pedcab', sortable: false },
            ],
            items:[],
            itemsDetail: Object
        }
    },
    created() {
        this.getUser()
        this.getItems()
        window.document.title = 'Movimientos de caja'
    },
    methods: {
        detail(){
            axios.get('http://127.0.0.1:8000/caja/listmov/' + this.select)
                .then(res => this.itemsDetail = res.data)
        },
        getItems(){
            axios.get('http://127.0.0.1:8000/caja/listmov/')
                .then(res => this.items = res.data)
        },
        getUser(){
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                .then(res => {
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data.user +'/' )
                        .then(r => this.empleado = r.data )
                })
        },
        validate () {
            if (this.movType == 'Retiro') {
                if (this.$refs.form.validate()){
                    this.element = {
                        zca_nombre: 'RETIRO-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
                        zca_tipo: this.movType,
                        zca_concepto: this.concepto,
                        zca_fecha: this.fecha,
                        zca_hora: moment(new Date()).format('H:mm '),
                        zca_total: this.monto,
                        zca_id_usuario: this.empleado.zdus_id_usuario
                    }
                    this.guardar()
                } 
            }
            else if (this.movType == 'Servicio') {
                if(this.p_serv=="Otro"){

                    if (this.$refs.form.validate()){
                    this.element = {
                        zca_nombre: 'PAGO DE SERVICIO : ' + this.p_serv2,
                        zca_tipo: this.movType,
                        zca_concepto: 'Pago de servicio de '+ this.p_serv2,
                        zca_fecha: this.fecha,
                        zca_hora: moment(new Date()).format('H:mm '),
                        zca_total: this.monto,
                        zca_id_usuario: this.empleado.zdus_id_usuario
                    }
                    this.guardar()
                } 
                }

                else {

                    if (this.$refs.form.validate()){
                    this.element = {
                        zca_nombre: 'PAGO DE SERVICIO : ' + this.p_serv,
                        zca_tipo: this.movType,
                        zca_concepto: 'Pago de servicio de '+ this.p_serv +' , ' + 'Periodo : '+ this.periodo_serv,
                        zca_fecha: this.fecha,
                        zca_hora: moment(new Date()).format('H:mm '),
                        zca_total: this.monto,
                        zca_id_usuario: this.empleado.zdus_id_usuario
                    }
                    this.guardar()
                } 
                }

            }
            else{
                if (this.$refs.form.validate()){
                    this.element = {
                        zca_nombre: 'DEPOSITO-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
                        zca_tipo: this.movType,
                        zca_concepto: this.concepto,
                        zca_fecha: this.fecha,
                        zca_hora: moment(new Date()).format('H:mm '),
                        zca_total: this.monto,
                        zca_id_usuario: this.empleado.zdus_id_usuario
                    }
                    this.guardar()
                } 
            }   
        },  
        guardar(){
            axios.post('http://127.0.0.1:8000/caja/cabecera/', this.element)
                .then(res => window.location.reload())
        },
         reset () {
            this.p_serv=null
            this.concepto=null
      },
    },
}
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>