Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz para realizar una venta y cuenta con los componentes _TransDetail y _AddArticle
<template>
    <v-container fluid>   
        <div class="hr-sect"><h2>{{cabecera.zca_nombre}}</h2></div>        
        <v-row>
        <v-col cols="md-8 xs-12" >
            <v-card>
                <v-card-title primary-title>
                    <v-spacer/>
                    <v-text-field v-model="search" label="Buscar..." clearable/>
                    <v-btn  icon @click="buscar">
                        <v-icon >mdi-magnify</v-icon>
                    </v-btn>
                    <v-spacer/>
                </v-card-title>
                <v-card-text>
                    <v-data-table  :headers="headers" :items="items" 
                        :items-per-page="5"
                        :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                        no-data-text="No se ha realizado una búsqueda."
                        :header-props="{ sortByText: 'Ordenar por' }">
                        <template v-slot:item.zaa_cantidad="{ item }"  >
                            <v-chip :color="getColor(item.zaa_cantidad)" dark > 
                                {{ item.zaa_cantidad }}
                            </v-chip>
                        </template>
                        <template v-slot:item.zaa_id_articulo="{ item }"  >
                            <AddArticle :cab="cabecera" :artilce="item"/>
                        </template>
                    </v-data-table>
                </v-card-text>
            </v-card>
        </v-col>
        <v-col cols="md-4 xs-12" >
            <TransDetail :cab="cabecera"/>
        </v-col>
        </v-row>
        
        
    </v-container>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
import TransDetail from './partials/_TransDetail'
import AddArticle from './partials/_AddArticle'
export default {
    components:{
        AddArticle,
        TransDetail
    },
    created() {
        this.getCab()

    },
    data() {
        return {
            
            cabecera: Object,
            search: '',
            headers: [
                {
                    text: 'Articulo',
                    align: 'start',
                    filterable: true,
                    value: 'zaa_nombre_arti',
                },          
                { text: 'Cantidad', value: 'zaa_cantidad' },
                { text: 'Modelo', value: 'zaa_modelo' },
                { text: 'Código de Barras', value: 'zaa_codigo_bar' },
                { text: 'Marca', value: 'zaa_marca' },
                { text: 'Precio', value: 'zaa_prec_cont' },
                { text: 'Acciones', value: 'zaa_id_articulo', sortable: false },
            ],
            items: []
        }
    },
    methods: {
        getCab(){
            axios.get('http://127.0.0.1:8000/caja/list/' +this.$route.params.id )
                .then(res => this.cabecera = res.data)
                .catch(err => console.log(err))
                this.buscar()
        },
        buscar(){
            axios.get('http://127.0.0.1:8000/articulo/artcaja/?search=' + this.search)
                .then(res => this.items = res.data)
        },
        getColor (zaa_cantidad) {
            if (zaa_cantidad < 2) return 'red accent-3'
            else if (zaa_cantidad < 5) return 'orange accent-3'
            else return 'green accent-4'
        },
    },
}
</script>