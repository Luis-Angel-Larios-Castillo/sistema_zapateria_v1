<template>
    <v-container fluid>
        <v-alert color="dark" dark dense>
            <strong>Articulos - Opcionales</strong>
        </v-alert>
        <div v-show="false">{{this.findPedido.zped_id_pedcab}}</div>
        <v-row>
            <v-card-text>
                <v-simple-table dense fixed-header height="150">
                    <template v-slot:default>
                        <thead>
                            <tr>
                                <th>Artículos</th>
                                <th>Color</th>
                                <th>Talla</th>
                                <th>Total</th>
                                <th class="text-center">Estatus</th>
                                <th class="text-center">Tipo</th>
                                <th>Detalles</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="item in findArticles" :key="item.zped_id_pedcab" height="50">  
                                <td>{{item.zipe_categoria}} {{item.zipe_marca}}</td>
                                <td>{{item.zipe_color}}</td>
                                <td>{{item.zipe_talla}}</td>
                                <td class="text-center">{{item.zipe_sub_tot}}</td>
                                
                                <td v-if="item.zipe_status == 'Sin Existencia'" class="red--text text-center">Sin Existencia</td>
                                <td v-else class="green--text text-center">En Existencia</td>
                                
                                <td class="green--text text-center" v-if="item.zica_tipo_articulo == 'Preferido'">{{item.zica_tipo_articulo}}</td>
                                <td class="blue--text text-center" v-else>{{item.zica_tipo_articulo}}</td>
                                
                                <td>
                                    <v-row class="align-center">
                                        <DetalleArti :findArticles="item" style="margin-top:15px; margin-left:20px;"/>
                                    </v-row>
                                </td>
                            </tr>
                        </tbody>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-row>
    </v-container>
</template>

<script>
    import DetalleArti from './_detalleArticulo'
    const axios = require('axios')
    
    export default {
        props:[
            'findPedido'
        ],
        components:{
            DetalleArti,
        },
        data() {
            return {
                findArticles:[],
            }
        },
        
        created() {
            this.getArticles()
        },
        updated() {
            this.getArticles()
        },

        methods: {
            getArticles(){
                axios.get('http://127.0.0.1:8000/pedido/itempedopc/?search=' + this.findPedido.zped_id_pedcab)
                .then(res => this.findArticles = res.data)
            },
        },
    }
</script>