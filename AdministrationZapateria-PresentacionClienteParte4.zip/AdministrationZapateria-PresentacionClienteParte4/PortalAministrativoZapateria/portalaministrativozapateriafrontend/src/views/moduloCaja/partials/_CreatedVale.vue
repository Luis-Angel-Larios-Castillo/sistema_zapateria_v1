<template>
    <div>
        <v-dialog  max-width="625">
        <template v-slot:activator="{ on, attrs }"> 
            <v-btn icon v-bind="attrs" v-on="on">
                <v-icon color="red">mdi-cancel</v-icon>
            </v-btn>
        </template> 
        <v-card> 
            <v-toolbar dark>
                <h3>CANCELAR PEDIDO</h3>
            </v-toolbar>   
            
            {{getCliente(cab)}}   
            {{getEmpleado(cab)}}  
            <v-card-text class="black--text">  
                <br> 
                <v-alert dense type="info" outlined v-if="puedeCancelar == false">
                    No se puede cancelar el producto ya que el total del pedido será menor al anticipo.
                    
                </v-alert>
                <v-alert dense type="info" outlined v-if="(cab.zped_pagado+cab.zped_vale) == 0">
                    No se puede genera un vale ya que no se tiene registrado un anticipo.
                    
                </v-alert>
                <h3>Anticipo: ${{cab.zped_pagado+cab.zped_vale}}</h3>
                <h3>Importe del producto: ${{item.zipe_sub_tot}}</h3>  
                <h3>Total del pedido: ${{cab.zipe_total}}</h3>
            </v-card-text>  
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn v-show="false" v-if="noShowCretedVale == true">Generar vale</v-btn>
                <v-btn outlined @click.stop="dialog = true" :disabled="(cab.zped_pagado+cab.zped_vale) == 0 " color="success" v-else>Generar vale</v-btn>

                <v-btn outlined @click="cancelarProducto()" :disabled="puedeCancelar == false" color="success" v-if="noShowCretedVale == true">Cancelar producto</v-btn>
                <v-btn outlined @click="cancelarProducto()" :disabled="puedeCancelar == false" color="success" v-else>Solo cancelar producto</v-btn>
            </v-card-actions>
        </v-card>
        </v-dialog>
        
        <v-dialog v-model="dialog" width="300">
            <v-card><v-card-title>
                <!--{{this.folio_vale}}-->
            </v-card-title>
            <v-card-text>
                <v-form ref="form" v-model="valid" lazy-validation>
                    <v-text-field label="Numero de Caja" outlined type="text" v-model="n_caja" maxlength="5" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" :rules="n_cajaRules" required></v-text-field>
                </v-form>
                
                <v-btn color="red" text @click="dialog = false">
                    Cancelar
                </v-btn>
                <v-btn :disabled="!valid"   text color="primary" v-on:click="generarVale()">
                    Generar
                </v-btn>
            </v-card-text>
        </v-card>
    </v-dialog>
</div>
</template>
<script>
import jsPDF from "jspdf"; 
let fecha_vale =  new Date().toISOString().slice(0,10)
const axios = require('axios')
export default {
    props:[ 
        'cab',
        'item',
        'noShowCretedVale',
    ],
    data () {
        return {
            num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
            busqvalest:0,
            total:0,
            dif: 0, 
            importe: 0,
            empleado: [],
            cliente: [],
            puedeCancelar: true,
            restante: 0,
            vale: [],
            folio_vale:'',
            dialog: false,
            valid: true,
            n_caja: '',
            n_cajaRules: [
              v => !!v || 'El numero de caja es obligatorio',
              v => (v && v.length >= 0) || 'No se puede registrar numero de caja',
            ],
            imgData: require('@/assets/logoSneaker.jpg'),
        }
    }, 
    methods: { 
        findvalest(){
            axios.get('http://127.0.0.1:8000/vale/')
            .then(res => this.busqvalest = res.data.length)
            this.dif = (this.cab.zipe_total - this.item.zipe_sub_tot )
        },
        getCliente(cabe){ 
            if((cabe.zipe_total - this.item.zipe_sub_tot) < (cabe.zped_pagado+cabe.zped_vale)){ 
                this.puedeCancelar = false
            }
            axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + cabe.zped_id_usuario )
                .then(res =>  this.cliente = res.data[0] ) 
                this.findvalest()
        },
        getEmpleado(cabe){
            axios.get('http://127.0.0.1:8000/empleado/?search=' + cabe.zped_id_empleado )
                .then(res => this.empleado = res.data[0] )
        }, 
        generarVale(){   
            
            //let idCliente = this.cliente.zc_id_cliente
            let idCliente = this.cliente.zc_id_usuario
            let idEmpleado = this.empleado.zdem_id_usuario
            let idSucursal = this.empleado.zdem_id_sucursal
            let valeMonto = 0 
            let pedidoTotal = (this.cab.zipe_total - this.item.zipe_sub_tot)
            if(pedidoTotal == 0){
                this.cab.zped_status = 'Finalizado';
            }
            if (this.cab.zped_pagado == this.item.zipe_sub_tot) { 
                console.log('Monto del item es = a lp pagado')
                valeMonto = this.cab.zped_pagado;
                console.log('Nuevo total: ' + pedidoTotal) 
                this.cab.zped_pagado = 0;
                console.log(valeMonto);
            } else {
                if(this.cab.zped_pagado > this.item.zipe_sub_tot){
                    console.log('Pagado mayor al item')
                    valeMonto = this.item.zipe_sub_tot; 
                    this.cab.zped_pagado -= this.item.zipe_sub_tot; 
                    console.log('Monto del vale: ' + valeMonto)
                    console.log('Nuevo total: ' + pedidoTotal)
                    console.log('Pagado menos monto: ' + this.cab.zped_pagado)
                }else{ 
                    let sumaValePagado = (this.cab.zped_pagado+this.cab.zped_vale); 
                    console.log('Suma: ' + sumaValePagado)
                    console.log(this.item.zipe_sub_tot) 
                    if(sumaValePagado <= this.item.zipe_sub_tot){
                        valeMonto = sumaValePagado; 
                        this.cab.zped_vale = 0
                        this.cab.zped_pagado = 0 
                    }else {
                        if(sumaValePagado > this.item.zipe_sub_tot){
                            valeMonto = this.item.zipe_sub_tot; 
                            this.cab.zped_vale = 0
                            this.cab.zped_pagado = (sumaValePagado-this.item.zipe_sub_tot)
                        }
                    } 
                } 
            }    
            this.element = { 
                "zdv_folio_vale": 'Vale-'+fecha_vale + '-'+this.num_random+'-'+ (this.busqvalest + 1),
                "zdv_id_user_autori": 'No autorizado aún',
                "zdv_id_user_qcobra_vale": 'No cobrado aún',
                "zdv_fecha_cobro": null,
                "zdv_importe": valeMonto,
                "zdv_id_sucursal": idSucursal,
                "zdv_id_item_ped":this.item.zipe_id_item_ped,
                "zdv_estat_vale": false,
                "zdv_id_cliente": idCliente, 
                "zdv_id_empleado": idEmpleado 
            }    
            this.generatePDF(this.element) 
            this.item.zipe_status = 'Cancelado'    
            this.cab.zipe_total = pedidoTotal  
            axios.put('http://127.0.0.1:8000/pedido/itemped/' + this.item.zipe_id_item_ped + '/', this.item)
                .then(resItem => { 
                    axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab)
                    .then(resCab => {
                        axios.post("http://127.0.0.1:8000/vale/", this.element)
                        .then (resVale => window.location.reload() ) 
                    })
                })  
        },
        cancelarProducto(){   
            let pedidoTotal = (this.cab.zipe_total - this.item.zipe_sub_tot)
            if(pedidoTotal == 0){
                this.cab.zped_status = 'Finalizado'
            }
            this.cab.zipe_total = pedidoTotal 
            this.item.zipe_status = 'Cancelado'
            axios.put('http://127.0.0.1:8000/pedido/itemped/' + this.item.zipe_id_item_ped + '/', this.item)
                .then(resItem => { 
                    axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab)
                    .then(resCab => {
                        window.location.reload()  
                    })
                })
        },
        generatePDF(DataVale) {
            console.log(DataVale.zdv_importe)
            this.total_pares = " " + this.item.zipe_cant + " pzas.";
            this.import = "$" + (this.cab.zped_pagado + this.cab.zped_vale);
            this.fechaCreateVale = this.fecha_vale =  new Date().toISOString().slice(0,10)
            this.folio_vale = "Vale-" + this.fechaCreateVale + "-"+this.num_random+"-"+ (this.busqvalest + 1)
            var imgLogo = this.imgData
            
            var doc = new jsPDF({
                orientation: "portrait",
                unit: "in",
                format: "letter",
            }); 

            let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth(); 
            doc.setFont(undefined, 'bold').setFontSize(40).text("Zapatería Deny´s", pageWidth / 2, 1.0, {align: 'center'}); 
            doc.setFont(undefined, 'bold').setFontSize(35).text("CALZADO POR CATALOGO", pageWidth / 2, 2.0, {align: 'center'}); 
            doc.setLineWidth(0.05).line(0.5, 2.2, 8, 2.2); 
            doc.setFont(undefined, 'bold').setFontSize(30).text("VALE No.", pageWidth / 2, 2.8, {align: 'center'});
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
                                        //     x    y   longitud altura
            doc.setLineWidth(0.05).roundedRect(1.25, 3,    6,      0.75,    .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(DataVale.zdv_folio_vale, pageWidth / 2, 3.5,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("FECHA: " + this.fechaCreateVale, pageWidth / 2, 4.2,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("CAJA: " + this.n_caja, pageWidth / 2, 4.8,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("PARES: " + this.total_pares, pageWidth / 2, 5.4,  {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text("FOLIO PEDIDO", pageWidth / 2, 6,  {align: 'center'});
            
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
            doc.setLineWidth(0.05).roundedRect(1.75, 6.2,    5,      0.75,    .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(this.cab.zped_nombre, pageWidth / 2, 6.7,  {align: 'center'});

            doc.setFont(undefined, 'bold').setFontSize(30).text('IMPORTE: $' + DataVale.zdv_importe, 0.5, 7.5 );
            doc.setFont("courier", "bolditalic").text("VALIDO EN SU SIGUIENTE COMPRA", 0.25, 8); 
            doc.setFont("times", "normal").setFontSize(40).text("Firma:", 0.25, 9.6);
            doc.setLineWidth(0.05).line(1.8, 9.6, 8, 9.6);  
            doc.setFillColor(0, 0, 0);
            doc.setLineWidth(0.05).line(1.8, 9.6, 8, 9.6);  
            doc.autoPrint();
            doc.output('dataurlnewwindow');
            /*  

            doc.text("IMPORTE:", 15, 210);
            doc.text(this.import, 70, 210);

            doc.setFont("courier", "bolditalic");
            doc.text("VALIDO EN SU SIGUIENTE COMPRA!", 105, 235, null, null, "center");
            doc.setFont("times", "normal");

            doc.text("FIRMA:", 35, 270, null, null, "center");
            doc.line(55, 270, 200, 270);

            doc.autoPrint();
            doc.output('dataurlnewwindow');
            */

            /*
            var doc = new jsPDF()
            
            // Contorno
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
            doc.roundedRect(55, 20, 100, 170, 3, 3, "FD");
            
            // Contorno FOLIO VALE 1
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
            doc.roundedRect(70, 67, 70, 10, 3, 3, "FD");
            
            // Contorno FOLIO VALE 2
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
            doc.roundedRect(70, 117, 70, 10, 3, 3, "FD");
            
            // Titulos 1
            doc.setFontSize(22);
            doc.setFont("times", "normal");
            doc.text("Zapateria Dennys", 105, 35, null, null, "center");
            // Titulos 2
            doc.setFontSize(15);
            doc.setFont("times", "normal");
            doc.text("CALZADO POR CATALOGO", 105, 45, null, null, "center");
            // Linea Horizontal 1
            doc.line(78, 50, 130, 50); 
            
            // Campos de vale estaticos
            doc.setFontSize(13);
            doc.setFont("times", "normal");
            doc.text("VALE No.", 105, 65, null, null, "center");
            doc.text("FECHA:", 72, 85, null, null, "center");
            doc.text("CAJA:", 120, 85, null, null, "center");
            doc.text("CLIENTE:", 74, 95, null, null, "center");
            doc.text("PARES:", 72, 105, null, null, "center");
            doc.text("FOLIO PEDIDO", 105, 115, null, null, "center");
            doc.text("IMPORTE:", 75, 135, null, null, "center");
            // Campo de alerta y firma
            doc.setFont("courier", "bolditalic");
            doc.text("VALIDO EN SU SIGUIENTE COMPRA!", 105, 150, null, null, "center");
            doc.setFont("times", "normal");
            doc.text("FIRMA:", 73, 170, null, null, "center");
            // Linea Horizontal 2
            doc.line(85, 170, 145, 170);
            
            //DATOS DINAMICOS
            doc.setFont("times", "bold");
            doc.text(this.folio_vale, 105, 74, null, null, "center");//folio vale
            doc.text(this.fechaCreateVale, 92, 85, null, null, "center"); //fecha creación
            doc.text(this.n_caja, 130, 85, null, null, "center"); // caja
            doc.text(this.cliente.nombre, 112, 95, null, null, "center"); //nombre cliente
            doc.text(this.total_pares, 88, 105, null, null, "center"); //pares - cantidad articulos
            doc.text(this.cab.zped_nombre, 105, 124, null, null, "center");//nombre pedido
            doc.text(this.import, 92, 135, null, null, "center");//importe
            
            doc.save(`${this.folio_vale}.pdf`);
            */
        },
    },
}
</script>