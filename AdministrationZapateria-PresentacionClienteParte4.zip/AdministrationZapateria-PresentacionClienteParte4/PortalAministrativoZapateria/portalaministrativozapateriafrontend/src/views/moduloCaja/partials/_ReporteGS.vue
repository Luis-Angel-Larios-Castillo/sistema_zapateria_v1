Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra la información de transacciones del semestre actual
<template>
    <v-card>
        <v-card-title primary-title>
            Informe del semestre: {{reporteData.semestreSelect.name}}
        </v-card-title>
        <v-card-text>
            <v-row class="justify-center">
                <v-col cols="md-4 xs-12">
                    <v-card>
                        <v-simple-table >
                            <template v-slot:default>
                            <thead>
                                <tr>
                                    <th class="text-left black--text">Concepto</th>
                                    <th class="text-left black--text">Monto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr >
                                    <td>Entradas de efectivo</td>
                                    <td>${{ reporteData.datoSemestre.entradas }}</td>
                                </tr>
                                <tr >
                                    <td>Salidas de efectivo</td>
                                    <td>${{ reporteData.datoSemestre.salidas }}</td>
                                </tr>
                                <tr >
                                <td>Ganancias </td>
                                    <td v-if="reporteData.datoSemestre.total < 0 ">-${{ -reporteData.datoSemestre.total }}</td>
                                    <td v-else>${{ reporteData.datoSemestre.total }}</td>
                                </tr>
                            </tbody>
                            </template>
                        </v-simple-table>
                    </v-card>
                </v-col>
                <v-col cols="md-8 xs-12">
                    <apexchart width="500"  :options="options" :series="series"/>
                </v-col>
            </v-row>
        </v-card-text>
    </v-card>
</template>
<script>
import Vue from 'vue';
import VueApexCharts from 'vue-apexcharts'
Vue.use(VueApexCharts)
Vue.component('apexchart', VueApexCharts)
export default {
    props:[
        'reporteData'
    ],
    data() {
        return {
            options: {
                chart: {
                    id: 'ReporteSemestral',
                    type: 'bar'
                },
                xaxis: {
                    categories: ['Ingresos', 'Salidas', 'Ganancias']
                },                
                plotOptions: {
                    bar: {
                        barHeight: '100%',
                        distributed: true,
                        horizontal: false,
                        dataLabels: {
                        position: 'bottom'
                        },
                    }
                },
                colors: ['#00CD00', '#FF1919', '#3299FF']
            },
                series: [{
                    name: 'Balance semestral',
                    data: [this.reporteData.datoSemestre.entradas, this.reporteData.datoSemestre.salidas, this.reporteData.datoSemestre.total]
                }]
            }
    },
}
</script>