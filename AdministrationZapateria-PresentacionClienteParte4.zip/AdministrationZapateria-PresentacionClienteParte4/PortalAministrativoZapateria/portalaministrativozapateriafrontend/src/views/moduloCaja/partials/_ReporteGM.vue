Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra la información de transacciones del mes 
<template>
    <v-card>
        <v-card-title primary-title>
            Informe del mes {{reporteData.mesSelect.name}}
        </v-card-title>
        <v-card-text>
            <v-row class="justify-center">
                <v-col cols="md-4 xs-12">
                    <v-card>
                        <v-simple-table >
                            <template v-slot:default>
                            <thead>
                                <tr>
                                    <th class="text-left black--text">Concepto</th>
                                    <th class="text-left black--text">Monto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr >
                                    <td>Entradas de efectivo</td>
                                    <td>${{ reporteData.datoMensual.entradas }}</td>
                                </tr>
                                <tr >
                                    <td>Salidas de efectivo</td>
                                    <td>${{ reporteData.datoMensual.salidas }}</td>
                                </tr>
                                <tr >
                                <td>Ganancias </td>
                                    <td v-if="reporteData.datoMensual.total < 0 ">-${{ -reporteData.datoMensual.total }}</td>
                                    <td v-else>${{ reporteData.datoMensual.total }}</td>
                                </tr>
                            </tbody>
                            </template>
                        </v-simple-table>
                    </v-card>
                </v-col>
                <v-col cols="md-8 xs-12">
                    <apexchart width="500"  :options="options" :series="series"/>
                </v-col>
            </v-row>
        </v-card-text>
    </v-card>
</template>
<script>
import Vue from 'vue';
import VueApexCharts from 'vue-apexcharts'
Vue.use(VueApexCharts)
Vue.component('apexchart', VueApexCharts)
export default {
    props:[
        'reporteData'
    ],
    data() {
        return {
            options: {
                chart: {
                    id: 'ReporteMensual',
                    type: 'bar'
                },
                xaxis: {
                    categories: ['Ingresos', 'Salidas', 'Ganancias']
                },                
                plotOptions: {
                    bar: {
                        barHeight: '100%',
                        distributed: true,
                        horizontal: false,
                        dataLabels: {
                        position: 'bottom'
                        },
                    }
                },
                colors: ['#00CD00', '#FF1919', '#3299FF']
            },
                series: [{
                    name: 'Balance mensual',
                    data: [this.reporteData.datoMensual.entradas, this.reporteData.datoMensual.salidas, this.reporteData.datoMensual.total]
                }]
            }
    },
}
</script>