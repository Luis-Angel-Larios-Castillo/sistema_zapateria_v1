<template>
  <v-container>
    <v-overlay :value="overlay">
        <v-progress-circular :size="70" :width="7" indeterminate/>    
    </v-overlay>
    <v-row style="margin-top:-35px;">
      <div v-show="false">{{this.restante = parseInt(this.findPedido.zipe_total) - (parseInt(this.findPedido.zped_pagado) + parseInt(this.efectivo))}}</div>
      
      <div v-show="false" v-if="findPedido.zipe_total == 0">{{this.pagado = 0}}</div>
      <div v-show="false" v-else>{{this.pagado = parseInt(this.findPedido.zped_pagado) + parseInt(this.efectivo)}}</div>
      <v-col>
        <v-alert dense text color="green" v-if="findPedido.zped_pagado == findPedido.zipe_total" type="info">
          <strong>CUENTA PAGADA</strong>
        </v-alert>
        <v-text-field v-model="efectivo" v-else label="Efectivo:" required :counter="5" oninput="this.value=this.value.replace(/[^0-9.]/g,'');" placeholder="Ejem. 1500" maxlength="5"></v-text-field>
      </v-col>
    </v-row>
    <v-tooltip bottom>
      <template v-slot:activator="{ on, attrs }">
        <v-btn @click="generatePDF" v-bind="attrs" v-on="on" color="warning" rounded class="mr-4" outlined v-on:click="updateCab">
          Generar Ticket
          <v-icon>mdi-file-document</v-icon>
        </v-btn>
      </template>
      <span>Generar Ticket</span>
    </v-tooltip>
    <v-row>
      <v-col>
        {{findEmpleado(Usuario)}}
          <!--<p v-if="ocultar">{{empleado.nombre}}
          {{empleado.zdsu_suc_direccionCalle}}
          {{empleado.zdsu_suc_direccionMuni}}</p>-->
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        {{findCliente(findPedido.zped_id_usuario)}}
          <!--<p v-if="ocultar">{{cliente.nombre}}</p>-->
      </v-col>
    </v-row>
  </v-container>
</template> 

<script>
  import moment from 'moment'
  import jsPDF from "jspdf"; 
  const axios = require('axios')
  
  export default {
    created() {
      this.findUsuario()
    },
    
    data() {
      return {
        efectivo:'0',
        Usuario: '',
        empleado: '',
        cliente:[],
        administrador:'',
        overlay: false,
        imgData: require('@/assets/logoSneaker.jpg'),
      }
    },

    props:[
      'findPedido'
    ], 

    watch: {
      overlay (val) {
        val && setTimeout(() => {
          this.overlay = false
        }, 2000)
      },
    },
    
    methods: {
      generatePDF() {
        this.import_anti = "$" + this.findPedido.zped_pagado;
        this.rest = "$" + this.restante;
        this.tot = "$" + this.findPedido.zipe_total;
        var imgLogo = this.imgData

        var doc = new jsPDF({
            orientation: "portrait",
            unit: "in",
            format: "letter",
        });

        let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth(); 
        doc.setFont(undefined, 'bold').setFontSize(40).text("Zapatería Deny´s", pageWidth / 2, 1.0, {align: 'center'}); 
        doc.setFont(undefined, 'bold').setFontSize(35).text("CALZADO POR CATALOGO", pageWidth / 2, 1.7, {align: 'center'}); 
        doc.setLineWidth(0.05).line(0.5, 1.8, 8, 1.8); 
        doc.setFont(undefined, 'bold').setFontSize(30).text("Folio de pedido", pageWidth / 2, 2.4, {align: 'center'});
        doc.setDrawColor(0);
        doc.setFillColor(255, 255, 255);
        //Sección de Nombre de Pedido
        doc.setLineWidth(0.05).roundedRect(1.25, 2.6,    6,      0.75,    .3, .3, "FD");
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.findPedido.zped_nombre, pageWidth / 2, 3.1,  {align: 'center'});
        //Sección de Fecha
        doc.setFont(undefined, 'bold').setFontSize(30).text("Fecha: "+ this.findPedido.zped_fecha, pageWidth / 2, 3.8,  {align: 'center'});
        //Sección de Cliente 
        doc.setFont(undefined, 'bold').setFontSize(30).text("Cliente: ", pageWidth / 2, 4.4,  {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.cliente.nombre, pageWidth / 2, 5,  {align: 'center'}); 
        //Sección Folio de Cliente
        doc.setFont(undefined, 'bold').setFontSize(30).text("Folio de cliente", pageWidth / 2, 5.6,  {align: 'center'}); 
        doc.setDrawColor(0);
        doc.setFillColor(255, 255, 255); 
        //Sección de Folio de cliente
        doc.setLineWidth(0.05).roundedRect(1.25, 5.8,    6,      0.75,    .3, .3, "FD");
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.cliente.zc_folio_client, pageWidth / 2, 6.3,  {align: 'center'});
        //Sección Atendido por
        doc.setFont(undefined, 'bold').setFontSize(30).text("Atendido por", pageWidth / 2, 6.9,  {align: 'center'});
        if(this.admin.is_superuser==false){
          doc.setFont(undefined, 'bold').setFontSize(30).text(this.empleado.nombre, pageWidth / 2, 7.4,  {align: 'center'});  
        }else{
          doc.setFont(undefined, 'bold').setFontSize(30).text(this.administrador.nombre, pageWidth /2, 7.4,  {align: 'center'});  
        }
        //Sección de importes
        doc.line(0.5, 7.5, 8, 7.5); // horizontal line

        if(this.findPedido.zipe_total == 0){
          doc.setFont(undefined, 'bold').setFontSize(30).text("Importe Acumulado: $0", pageWidth /2, 8.1,  {align: 'center'});
          doc.setFont(undefined, 'bold').setFontSize(30).text("Efectivo: $0", pageWidth /2, 8.7,  {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(30).text("Restante: $0", pageWidth /2, 9.3,  {align: 'center'});  
          doc.setFont(undefined, 'bold').setFontSize(30).text("TOTAL DE COMPRA: $0", pageWidth /2, 9.9,  {align: 'center'});
        }else{
          doc.setFont(undefined, 'bold').setFontSize(30).text("Importe Acumulado: " + this.import_anti, pageWidth /2, 8.1,  {align: 'center'});
          doc.setFont(undefined, 'bold').setFontSize(30).text("Efectivo: $" + this.efectivo, pageWidth /2, 8.7,  {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(30).text("Restante: " + this.rest, pageWidth /2, 9.3,  {align: 'center'});  
          doc.setFont(undefined, 'bold').setFontSize(30).text("TOTAL DE COMPRA: " + this.tot, pageWidth /2, 9.9,  {align: 'center'});
        }
        
        doc.autoPrint();
        doc.output('dataurlnewwindow');
      },
      
      findUsuario(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .then(res => this.Usuario = res.data.user)
      },

      findEmpleado(id_usuario){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+id_usuario)
        .then(res=>{this.admin=res.data[0]
          if(this.admin.is_superuser==false){
            axios.get('http://127.0.0.1:8000/empleado/?search='+ id_usuario)
            .then(res => this.empleado = res.data[0])
          }else{
            axios.get('http://127.0.0.1:8000/empleado/?search='+ id_usuario)
            .then(res => this.administrador = res.data[0])
          }
        })
        this.$emit("getDataPagado", this.pagado)
      },
      findCliente(id_cliente){
        axios.get('http://127.0.0.1:8000/clientes/?search='+id_cliente)
        .then(res => this.cliente = res.data[0])
      },

      updateCab(){
        axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/',{
          "zped_id_usuario": this.findPedido.zped_id_usuario,
          "zped_nombre": this.findPedido.zped_nombre,
          "zped_status": this.findPedido.zped_status,
          "zped_pagado": this.pagado,
          "zped_fecha": this.findPedido.zped_fecha,
          "zped_vale": this.findPedido.zped_vale,
          "zipe_total": this.findPedido.zipe_total,
          "zped_is_afi": this.findPedido.zped_is_afi,
          "zped_id_empleado": this.findPedido.zped_id_empleado,
          "zped_id_sucursal": this.findPedido.zped_id_sucursal,
        })
        .then(resCab =>{
          this.$emit('pedido', resCab.data)
        })
        this.overlay = true
        this.newVenta()
      },
      newVenta(){
        if(this.efectivo > 0){
          let venta = {
            zca_nombre: 'VENTA-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
            zca_tipo: 'Venta',
            zca_concepto: this.findPedido.zped_nombre,
            zca_fecha: moment().locale('MX').format('YYYY-MM-DD'),
            zca_hora: moment(new Date()).format('H:mm '),
            zca_total: this.efectivo,
            zca_id_usuario: this.findPedido.zped_id_empleado
          }
          axios.post('http://127.0.0.1:8000/caja/cabecera/', venta)
          this.overlay = true
        }else{
          this.overlay = true
        }
      }
    },
  }
</script>