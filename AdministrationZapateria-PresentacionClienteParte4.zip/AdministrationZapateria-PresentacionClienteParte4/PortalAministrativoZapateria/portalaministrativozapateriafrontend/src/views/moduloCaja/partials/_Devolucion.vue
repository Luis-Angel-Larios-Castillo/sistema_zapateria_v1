<template>
    <v-row justify="center">
        <v-tooltip bottom >
            <template v-slot:activator="{ on, attrs }">
            <v-btn icon color="red" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
                <v-icon>mdi-clipboard-arrow-down-outline</v-icon>
            </v-btn>
            </template>
            <span>Devolución</span>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="600">
        <v-card>
            <v-toolbar color="#14213d">
                <h2 class="white--text">Devolución del articulo: {{articulo.zipe_nombre}}</h2>
            </v-toolbar> 

            <v-card-text class="black--text subtitle-1">   
                <br>
                Se hará la devolución del articulo: <strong>{{articulo.zipe_nombre}}</strong> y se creara un vale con un valor de: <strong>${{articulo.zipe_sub_tot}}.</strong>
            </v-card-text> 
            <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="red darken-1" text @click="dialog = false">
                Cancelar 
            </v-btn>
            <v-btn color="green darken-1" text @click="generarVale()" >
                Aceptar 
            </v-btn>
            </v-card-actions>
        </v-card>
        </v-dialog>
    </v-row>
</template>
<script>
import jsPDF from "jspdf"; 
import moment from 'moment'
const axios = require('axios')
let fecha_vale =  new Date().toISOString().slice(0,10)

export default {
    props:[
        'articulo' 
    ],
    data () {
      return {      
        num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1)),
        dialog: false, 
    }
    },
    created() { 
    }, 
    methods:{ 
        generarVale(){  
            axios.get('http://127.0.0.1:8000/vale/')
            .then(res => { 
                axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token)
                .then(resUser => {  
                    this.element = { 
                        "zdv_folio_vale": 'VALE-'+fecha_vale + '-'+this.num_random+'-'+ (res.data.length + 1),
                        "zdv_id_user_autori": 'No autorizado aún',
                        "zdv_id_user_qcobra_vale": 'No cobrado aún',
                        "zdv_fecha_cobro": null,
                        "zdv_importe": this.articulo.zipe_sub_tot,
                        "zdv_id_sucursal": this.articulo.zipe_sucursal,
                        "zdv_id_item_ped": this.articulo.zipe_id_item_ped,
                        "zdv_estat_vale": false,
                        "zdv_id_cliente": this.articulo.zipe_id_cliente, 
                        "zdv_id_empleado": resUser.data[0].user 
                    }    
                    this.generatePDF(this.element) 
                    this.articulo.zipe_status = 'Devolución'  
                    //axios.get('http://127.0.0.1:8000/pedido/itemped/' + this.articulo.zipe_id_item_ped + '/')
                    axios.put('http://127.0.0.1:8000/pedido/itemped/' + this.articulo.zipe_id_item_ped + '/', this.articulo)
                    .then(resItem => { 
                        axios.post("http://127.0.0.1:8000/vale/", this.element)
                        //axios.get("http://127.0.0.1:8000/vale/")
                            .then (resVale => {
                                this.$emit('articuloN', this.articulo)
                            }) 
                    }) 
                }) 
            })
        },
        generatePDF(DataVale) {
            var doc = new jsPDF({
                orientation: "portrait",
                unit: "in",
                format: "letter",
            }); 
            let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth(); 
            doc.setFont(undefined, 'bold').setFontSize(40).text("Zapatería Deny´s", pageWidth / 2, 1.0, {align: 'center'}); 
            doc.setFont(undefined, 'bold').setFontSize(35).text("CALZADO POR CATALOGO", pageWidth / 2, 1.7, {align: 'center'}); 
            doc.setLineWidth(0.05).line(0.5, 1.8, 8, 1.8); 
            doc.setFont(undefined, 'bold').setFontSize(30).text("VALE No.", pageWidth / 2, 2.3, {align: 'center'});
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
                                        //     x    y   longitud altura
            doc.setLineWidth(0.05).roundedRect(1.25, 2.5,    6,      0.75,    .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(DataVale.zdv_folio_vale, pageWidth / 2, 3, {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text('Fecha: ' + fecha_vale, pageWidth / 2, 3.8, {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text('Pares: ' + this.articulo.zipe_cant + 'pzas.', pageWidth / 2, 4.4, {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text('FOLIO PEDIDO', pageWidth / 2, 5, {align: 'center'});
            doc.setDrawColor(0);
            doc.setFillColor(255, 255, 255);
                                        //     x    y   longitud altura
            doc.setLineWidth(0.05).roundedRect(1.75, 5.2, 5, 0.75, .3, .3, "FD");
            doc.setFont(undefined, 'bold').setFontSize(30).text(this.articulo.zipe_pedido_nombre, pageWidth / 2, 5.7, {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(30).text('IMPORTE: $' + DataVale.zdv_importe, pageWidth / 2, 6.5, {align: 'center'});
            doc.setFont(undefined, 'bold').setFontSize(25).text("VALIDO EN SU SIGUIENTE COMPRA", pageWidth / 2, 7.1, {align: 'center'});
            doc.setFont("times", "normal").setFontSize(40).text("Firma: ", 0.4, 9);
            doc.setLineWidth(0.05).line(1.95, 9, 8, 9);  

            doc.autoPrint();
            doc.output('dataurlnewwindow'); 
        }
    },
  }
</script>