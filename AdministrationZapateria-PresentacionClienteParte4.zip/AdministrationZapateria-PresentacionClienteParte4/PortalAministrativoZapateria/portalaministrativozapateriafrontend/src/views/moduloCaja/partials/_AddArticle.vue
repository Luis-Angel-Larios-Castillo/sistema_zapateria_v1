Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) que muestra la información para agregar un articulo a la venta.
<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="red" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
            <v-icon >mdi-plus</v-icon>
          </v-btn>
        </template>
        <span>Agregar</span>
    </v-tooltip>
    <v-dialog
      v-model="dialog"
      max-width="500"
    >
      <v-card>
        <v-card-title class="blue--text">
          Agregar articulo: {{artilce.zaa_nombre_arti}}
        </v-card-title>

        <v-card-text>
          <v-form ref="form" v-model="valid" lazy-validation m>
          <v-row> 
            <v-spacer/>
            <v-text-field 
                v-model="cantidad" 
                label="Seleccionar cantidad" 
                v-on:change="cambiarCantidad(artilce)" 
                type="number"
                min="1"
                :rules="[   v => !!v || 'Cantidad inválida.', 
                    v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                    v => (v && v < artilce.zaa_cantidad+1) || 'No se puede seleccionar esta cantidad' ]"  
            />
            <v-spacer/>
            <v-text-field 
              v-on:change="cambiarCantidad(artilce)"
              v-model="des" 
              label="Descuento por articulo"
              type="number"
              min="0"
            />
            <v-spacer/>
          </v-row>
          </v-form>
            <h3 class="black--text">$ {{total}}</h3>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="green darken-1" text @click="dialog = false">
            Cancelar 
          </v-btn>
          <v-btn color="green darken-1" text @click="aceptar()" :disabled="!valid">
            Aceptar 
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'artilce',
        'cab'
    ],
    data () {
      return {     
        element: Object,   
        valid: true,
        cantidad: 1,
        dialog: false,
        total: 0,
        des: 0
    }
    },
    created() {
        this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
    },
    updated() {
        this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
    },
    methods:{
      create(){
        axios.post('http://127.0.0.1:8000/caja/item/',this.element)
          .then(res =>{
            this.dialog = false
            window.location.reload()
          })
      },
      aceptar(){
        this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
        if (this.$refs.form.validate()){
        this.element = {
          zica_cant: this.cantidad,
          zica_sub_tot: this.artilce.zaa_prec_cont * this.cantidad,
          zica_tot: this.total,
          zica_des: this.cantidad * this.des,
          zica_id_caja_cab: this.cab.zca_id_pedcab,
          zica_id_arti: this.artilce.zaa_id_articulo
        }
        this.create()
        }            
        
      },
      cambiarCantidad: function (event) {
          
          if(event.zaa_cantidad >= this.cantidad){
              if(this.cantidad <= 0){
                  this.cantidad = 1
                  this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
              }else{
                  this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
              }
          }else{
              this.cantidad = 1
              this.total = this.artilce.zaa_prec_cont * this.cantidad - this.cantidad * this.des
          }
          
      },
    },
  }
</script>