<template>
    <v-container fluid>
        <v-alert color="dark" dark dense>
            <strong>Articulos - Preferidos</strong>
        </v-alert>
        <div v-show="false">{{this.findPedido.zped_id_pedcab}}</div>
        <v-row>
            <v-card-text>
                <v-simple-table dense fixed-header height="200">
                    <template v-slot:default>
                        <thead>
                            <tr>
                                <th></th>
                                <th>Estatus</th>
                                <th>#</th>
                                <th>Articulos</th>
                                <th>Color</th>
                                <th>Talla</th>
                                <th>Total</th>
                                <th class="text-center">Estatus</th>
                                <th>Intercambiar</th>
                                <th>Detalles</th>
                            </tr>
                        </thead>
                        <tbody v-for="item in findArticles" :key="item.zipe_id_item_ped" height="50">
                            <tr>
                                <td v-if="item.zipe_status == 'Entregado'"><v-icon color="blue">mdi-checkbox-marked-circle</v-icon></td>
                                <td v-else-if="item.zipe_status == 'Sin Existencia'"><v-icon color="red">mdi-close-circle</v-icon></td>
                                <td v-else-if="item.zipe_status == 'Pendiente'"><v-icon color="warning">mdi-close-circle</v-icon></td>
                                <td v-else-if="item.zipe_status == 'Cancelado'"><v-icon color="red">mdi-close-octagon</v-icon></td>
                                <td v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'"><v-icon color="red">mdi-account-arrow-left</v-icon></td>
                                <td v-else><v-checkbox v-model="selectArti" :value="item.zipe_id_item_ped" style="margin-right:-50px;" @click="updateitem(item)"/></td>
                                <td>
                                    <v-tooltip bottom v-if="item.zipe_status == 'Cancelado'">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-icon color="red" v-bind="attrs" v-on="on">
                                                mdi-cancel
                                            </v-icon>
                                        </template>
                                        <span>Cancelado</span>
                                    </v-tooltip>
                                    
                                    <v-tooltip bottom v-else-if="item.zipe_status == 'Entregado'">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-icon color="blue" v-bind="attrs" v-on="on">
                                                mdi-alert-circle-check-outline
                                            </v-icon>
                                        </template>
                                        <span>Entregado</span>
                                    </v-tooltip>

                                    <v-tooltip bottom v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-icon color="red" v-bind="attrs" v-on="on">
                                                mdi-alert-remove-outline
                                            </v-icon>
                                        </template>
                                        <span>Devuelto</span>
                                    </v-tooltip>

                                    <v-tooltip bottom v-else>
                                        <template v-slot:activator="{ on, attrs }"> 
                                            <v-icon color="warning" v-bind="attrs" v-on="on" >
                                                mdi-alert-circle-outline
                                            </v-icon>
                                        </template>
                                        <span>Pendiente</span>
                                    </v-tooltip>
                                </td>
                                <td>{{item.zipe_cant}}</td>
                                <td>{{item.zipe_nombre}}</td>
                                <td>{{item.zipe_color}}</td>
                                <td>{{item.zipe_talla}}</td>
                                <td>{{item.zipe_sub_tot}}</td>
                                
                                <td v-if="item.zipe_status == 'Sin Existencia'" class="red--text text-center">Sin Existencia</td>
                                <td v-else-if="item.zipe_status == 'Entregado'" class="blue--text text-center">Entregado</td>
                                <td v-else-if="item.zipe_status == 'Cancelado'" class="red--text text-center">Cancelado</td>
                                <td v-else-if="item.zipe_status == 'Pendiente'" class="red--text text-center">Pendiente</td>
                                <td v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'" class="red--text text-center">Devuelto</td>
                                <td v-else class="green--text text-center">En Existencia</td>
                                
                                <td v-if="item.zipe_status == 'Sin Existencia' || item.zipe_status == 'Sin existencia' || item.zipe_status == 'Cancelado'"><SelectArtiOption :findPedido="findPedido" :findArticle="item"/></td>
                                <td v-else-if="item.zipe_status == 'Entregado'"><v-icon color="blue" style="margin-left:20px;">mdi-account-check</v-icon></td>
                                <!--<td v-else-if="item.zipe_status == 'Cancelado'"><v-icon color="red" style="margin-left:20px;">mdi-close-octagon</v-icon></td>-->
                                <td v-else-if="item.zipe_status == 'Pendiente'"><v-icon color="warning" style="margin-left:20px;">mdi-alert-circle-outline</v-icon></td>
                                <td v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'"><v-icon color="red" style="margin-left:20px;">mdi-account-arrow-left</v-icon></td>
                                <td v-else><v-icon color="green" style="margin-left:20px;">mdi-check-all</v-icon></td>
                                
                                <td>
                                    <v-row class="justify-center align-center">
                                        <DetalleArti :findArticles="item" style="margin-top:15px;"/>
                                        <!--<CreatedVale :cab="findPedido" v-if="item.zipe_status != 'Entregado' && item.zipe_status !='Pendiente' && item.zipe_status !='Cancelado' && item.zipe_status !='Devolucion' && item.zipe_status !='Devolución'" :item="item"/>-->
                                        <CreatedVale :cab="findPedido" v-if="item.zipe_status != 'Entregado' && item.zipe_status !='Cancelado' && item.zipe_status !='Devolución'" :item="item"/>
                                        <Devolucion :articulo="item" @articuloN="item = $event" v-if="item.zipe_status == 'Entregado'"/> 
                                    </v-row>
                                </td>
                            </tr>
                            <!--<div v-show="false">{{rowTotal(Pedido.zipe_total)}}
                                <br>{{totalFinal}}
                            </div>-->
                        </tbody>
                    </template>
                </v-simple-table>
            </v-card-text>
        </v-row>
        <v-snackbar v-model="snackbar">
            <h3>No se puede entregar ya que no se ha pagado.</h3> 
            <template v-slot:action="{ attrs }">
                <v-btn color="pink" text v-bind="attrs" @click="snackbar = false" >
                Cerrar
                </v-btn>
            </template>
        </v-snackbar>
    </v-container>
</template> 
<script>
    import Devolucion from './_Devolucion.vue'
    import SelectArtiOption from './_SelectArtiOption.vue'
    import DetalleArti from './_detalleArticulo'
    import CreatedVale from './_CreatedVale.vue'
    const axios = require('axios')  
    export default {
        props:[
            'findPedido'
        ],
        components:{
            SelectArtiOption,
            DetalleArti,
            Devolucion,
            CreatedVale,
        },
        data() {
            return {
                selectArti: [],
                totalFinal:0,
                findArticles:[],
                Pedido:Object,
                findArticles2:[],
                articuloGlobal:[],
                snackbar: false,
                itemsPedido:[],
                itemsStock:[],
                nuevoStock:0,
                updacStock:[],
            }
        },
        updated() {
            this.getArticles()
            this.getPedido()
        },
        methods: {
            getArticles(){
                axios.get('http://127.0.0.1:8000/pedido/itempedpre/?search=' + this.findPedido.zped_id_pedcab)
                .then(res => this.findArticles = res.data)
            },
            getPedido(){
                axios.get('http://127.0.0.1:8000/pedido/pedcab/' + this.findPedido.zped_id_pedcab)
                .then(res =>  this.Pedido = res.data)
            },
            rowTotal(totalCab) {
                this.totalFinal = (totalCab) - (this.selectArti.reduce((sum,cur) => sum+cur , 0))
                //this.updateCab()
                this.$emit("getData", this.totalFinal);
                return this.totalFinal
            }, 
            updateitem(m){ 
                let enCaja = (this.findPedido.zped_pagado+this.findPedido.zped_vale) 
                if(enCaja >= m.zipe_sub_tot){ 
                    if(this.findPedido.zped_pagado >= m.zipe_sub_tot){ 
                        this.findPedido.zped_pagado -= m.zipe_sub_tot 
                        this.findPedido.zipe_total -= m.zipe_sub_tot  
                        if(this.findPedido.zipe_total === 0){
                            this.findPedido.zped_status = 'Finalizado'
                        }
                        axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/', this.findPedido)
                        .then(resCPed =>{
                            this.$emit('pedido', resCPed.data)
                        }) 
                    }else{ 
                        let diff = (m.zipe_sub_tot - this.findPedido.zped_pagado) 
                        this.findPedido.zped_pagado = 0
                        this.findPedido.zipe_total -= m.zipe_sub_tot
                        this.findPedido.zped_vale -= diff
                        if(this.findPedido.zipe_total === 0){
                            this.findPedido.zped_status = 'Finalizado'
                        } 
                        axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/', this.findPedido)
                        .then(resCPed =>{
                            this.$emit('pedido', resCPed.data)
                        })
                    }   
                    const URL = 'http://127.0.0.1:8000/pedido/itempedpre/'+m.zipe_id_item_ped+'/'
                    m.zipe_status = 'Entregado'
                    m.zipe_entregado = true  
                    axios.put(URL, m) 
                    let config = {
                        headers: {
                            Authorization: "Token " + localStorage.token,
                        }
                    }
                    axios.get('http://127.0.0.1:8000/articulo/admin/' + m.zipe_id_arti + '/', config)
                    .then(resArt => { 
                        this.nuevoStock = (resArt.data.zaa_cantidad - m.zipe_cant)  
                        axios.put('http://127.0.0.1:8000/articulo/admin/' + m.zipe_id_arti +'/',{
                            "zaa_cantidad": this.nuevoStock,
                            "zaa_color": resArt.data.zaa_color,
                            "zaa_id_arti_global": resArt.data.zaa_id_arti_global,
                            "zaa_id_sucursal": resArt.data.zaa_id_sucursal,
                            "zaa_talla": resArt.data.zaa_talla,
                        }, config) 
                    }) 
                } else { 
                    this.snackbar = true
                    m.zipe_entregado = false 
                }
                
            },
        },
    }
</script>