<template>
    <v-row justify="center">
        <v-tooltip bottom >
            <template v-slot:activator="{ on, attrs }">
                <!--<v-btn icon color="green" dark @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="artilce.zaa_cantidad <=0">-->
                <v-btn icon color="green" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
                    <v-icon >mdi-plus</v-icon>
                </v-btn>
            </template>
            <span>Agregar</span>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="550">
            <v-card>
                <v-toolbar dark>
                    <h3>Agregar articulo: {{artilce.zaa_nombre_arti}}</h3>
                </v-toolbar><br>
                <v-card-text>
                    <v-form ref="form" v-model="valid" lazy-validation m>
                        <v-row>
                            <v-col cols="6" v-if="noShowStock == false">
                                <v-select v-model="tipo" :items="tipos"  :rules="[v => !!v || 'Debe seleccionar un tipo']"  label="Tipo de Articulo" required/>
                            </v-col>
                            <v-col cols="6" v-else>
                                <v-text-field v-model="tipo" readonly label="Tipo de Articulo"></v-text-field>
                            </v-col>

                            <v-col cols="6">
                                <v-select v-model="color" :items="artilce.zaa_color" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']"  label="Color" required/>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col cols="6">
                                <v-select :items="artilce.zaa_talla" v-model="size" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un talla']"  label="Talla" required/>
                            </v-col>
                            <!--{{noShowStock}}-->
                            <div v-if="noShowStock == false" style="width:50%;">
                                <v-col v-if="tipo=='Opcional'">
                                    <v-text-field
                                        readonly
                                        v-model="cantidad"
                                        label="Seleccionar cantidad" 
                                        v-on:change="cambiarCantidad()"
                                        type="number"
                                        v-show="false"
                                        :value="cantidad"
                                    />
                                    <v-alert dense text color="red">
                                        <strong>No se puede seleccionar una cantidad</strong>
                                    </v-alert>
                                </v-col>
                                <v-col v-else>
                                    <v-text-field
                                        v-model="cantidad" 
                                        label="Seleccionar cantidad" 
                                        v-on:change="cambiarCantidad()" 
                                        type="number"
                                        min="1"
                                        :rules="[   v => !!v || 'Cantidad inválida.', 
                                        v => (v && v > 0) || 'No se puede seleccionar esta cantidad.']"
                                    />
                                </v-col>
                            </div>
                            <div v-else style="width:50%;">
                                <v-col v-if="tipo=='Opcional'">
                                    <v-text-field
                                        readonly
                                        v-model="cantidad"
                                        label="Seleccionar cantidad" 
                                        v-on:change="cambiarCantidad()"
                                        type="number"
                                        v-show="false"
                                        :value="cantidad"
                                    />
                                    <v-alert dense text color="red">
                                        <strong>No se puede seleccionar una cantidad</strong>
                                    </v-alert>
                                </v-col>
                                <v-col v-else>
                                    <v-text-field
                                        v-model="cantidad" 
                                        label="Seleccionar cantidad" 
                                        v-on:change="cambiarCantidad()" 
                                        type="number"
                                        min="1"
                                        :rules="[   v => !!v || 'Cantidad inválida.', 
                                            v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                                            v => (v && v < artilce.zaa_cantidad+1) || 'No se puede seleccionar esta cantidad' ]"
                                    />
                                </v-col>
                            </div>
                        </v-row>
                        <v-row>
                            <v-col v-if="noShowStock == false">
                                    <p v-if="cantidad == 0">
                                        <v-alert dense text color="blu">
                                            <strong>Estatus de entrega</strong>
                                        </v-alert>
                                    </p>
                                    <p v-else-if="cantidad > artilce.zaa_cantidad">
                                        <v-alert dense text color="warning" type="info">
                                            <strong>{{tstock}} Artículos deben ser solicitados al proveedor</strong>
                                        </v-alert>
                                    </p>
                                    <p v-else>
                                        <v-alert dense text color="green" type="success">
                                            <strong>{{cantidad}} Artículos estan listos para ser entregados</strong>
                                        </v-alert>
                                    </p>
                            </v-col>
                            <v-col v-else>
                                    <p v-if="cantidad == 0">
                                        <v-alert dense text color="blu">
                                            <strong>Estatus de entrega</strong>
                                        </v-alert>
                                    </p>
                                    <p v-else-if="cantidad > artilce.zaa_cantidad">
                                        <v-alert dense text color="warning" type="info">
                                            <strong>No se puede seleccionar esta cantidad de artículos</strong>
                                        </v-alert>
                                    </p>
                                    <p v-else>
                                        <v-alert dense text color="green" type="success">
                                            <strong>{{cantidad}} Artículos estan listos para ser entregados</strong>
                                        </v-alert>
                                    </p>
                            </v-col>
                        </v-row>
                        {{calcular(cantidad, artilce.zaa_cantidad)}}
                        <div v-show="false">{{tstock = totalStock}}</div>
                        <v-row>
                            <v-col cols="6">
                                <v-switch v-model="pMayoreo" v-on:change="cambiarCantidad()" color="purple" label="Mayorista" style="margin-left:50px;"/>
                            </v-col>
                            <v-col cols="6">
                                <v-alert dense text color="red" type="info" v-if="artilce.zaa_oferta <= 0" style="margin-left:-40px; margin-top:10px">
                                    <strong>Sin oferta de descuento</strong>
                                </v-alert>
                                <v-switch v-model="pDescuento" v-on:change="cambiarCantidad()" v-else color="purple" label="Aplicar descuento"/> 
                            </v-col>
                        </v-row>
                    </v-form><br>
                    <div v-if="noShowStock == false">
                        <div v-if="cantidad > artilce.zaa_cantidad">
                            <h3 class="black--text">$ {{totalArtiStock + totalSumaStock - descuentoStock - descuentoRestStock}}</h3>
                        </div>
                        <div v-else>
                            <h3 class="black--text">$ {{total - descuentoStock - descuentoRestStock}}</h3>
                        </div>
                        <div v-show="true">
                            <h3 class="black--text" v-show="false">$ {{totalArtiStock}}</h3>
                            <h3 class="black--text" v-show="false">$ {{totalSumaStock}}</h3>
                        </div>
                    </div>
                    <div v-else>
                        <div v-if="cantidad > artilce.zaa_cantidad">
                            <h3 class="black--text">$ 0</h3>
                        </div>
                        <div v-else>
                            <h3 class="black--text">$ {{total - descuentoStock - descuentoRestStock}}</h3>
                        </div>
                    </div>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="green darken-1" text @click="dialog = false">
                        Cancelar
                    </v-btn>
                    <v-btn color="green darken-1" text @click="aceptar()" :disabled="!valid">
                        Aceptar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-row>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'artilce',
        'cab',
        'noShowStock',
    ],
    data () {
        return {
            pMayoreo: false,
            pDescuento: false,
            element: [],
            elementStock: [],
            valid: true,
            cantidad: 1,
            dialog: false,
            totalArtiStock:0,
            total:0,
            totalSumaStock:0,
            color: '',
            size: '',
            des: 0,
            tipo: 'Preferido',
            tipos:['Preferido', 'Opcional'],
            cantidad:0,
            tstock:0,
            decimal:0,
            descuento: 0,
            totalArti:0,

            totalArtiDesc:0,
            totalSumaDesc:0,
            descuentoStock:0,
            descuentoRestStock:0

        }
    },
    created() {
        this.cambiarCantidad()
    },
    methods:{
        calcular(cantidad, stock) {
            let totalStock = 0;
            
            if (cantidad >= stock) {
                this.totalStock = cantidad - stock;

            } else if (stock > cantidad) {
                totalStock = cantidad - stock;
                this.totalStock = Math.abs(totalStock);
            } else {
            
            }
        },

        createElement(){
            axios.post('http://127.0.0.1:8000/pedido/itemped/',this.elementUnit)
            .then(res =>{
                this.dialog = false
                window.location.reload()
            })
        },

        create(){
            axios.post('http://127.0.0.1:8000/pedido/itemped/',this.element)
            .then(res =>{
                this.dialog = false
                window.location.reload()
            })
        },
        createStock(){
            axios.post('http://127.0.0.1:8000/pedido/itemped/',this.elementStock)
            .then(res =>{
                this.dialog = false
                window.location.reload()
            })
        },
        aceptar(){
            if (this.$refs.form.validate()){
                if(this.cantidad > this.artilce.zaa_cantidad){
                    if(this.artilce.zaa_cantidad == 0){
                        this.elementStock = {
                            "zipe_cant": this.totalStock,
                            "zipe_devo": 0, 
                            "zipe_sub_tot": this.totalSumaStock - this.descuentoRestStock,
                            "zipe_status": "Pendiente",
                            "zipe_color": this.color,
                            "zipe_talla": this.size,
                            "zipe_id_pedido_cab": this.cab.zped_id_pedcab,
                            "zipe_id_arti": this.artilce.zaa_id_articulo,
                            "zica_tipo_articulo":this.tipo,
                        }
                        this.createStock()
                    }else{
                        this.element = {
                            "zipe_cant": this.artilce.zaa_cantidad,
                            "zipe_devo": 0, 
                            "zipe_sub_tot": this.totalArtiStock - this.descuentoStock,
                            "zipe_status": "Listo para entregar",
                            "zipe_color": this.color,
                            "zipe_talla": this.size,
                            "zipe_id_pedido_cab": this.cab.zped_id_pedcab,
                            "zipe_id_arti": this.artilce.zaa_id_articulo,
                            "zica_tipo_articulo":this.tipo,
                        },
                        this.elementStock = {
                            "zipe_cant": this.totalStock,
                            "zipe_devo": 0, 
                            "zipe_sub_tot": this.totalSumaStock - this.descuentoRestStock,
                            "zipe_status": "Pendiente",
                            "zipe_color": this.color,
                            "zipe_talla": this.size,
                            "zipe_id_pedido_cab": this.cab.zped_id_pedcab,
                            "zipe_id_arti": this.artilce.zaa_id_articulo,
                            "zica_tipo_articulo":this.tipo,
                        }
                        this.create()
                        this.createStock()
                    }
                }else if(this.cantidad <= this.artilce.zaa_cantidad) {
                    this.elementUnit = {
                        "zipe_cant": this.cantidad,
                        "zipe_devo": 0, 
                        "zipe_sub_tot": this.total - this.descuentoStock,
                        "zipe_status": "Listo para entregar",
                        "zipe_color": this.color,
                        "zipe_talla": this.size,
                        "zipe_id_pedido_cab": this.cab.zped_id_pedcab,
                        "zipe_id_arti": this.artilce.zaa_id_articulo,
                        "zica_tipo_articulo":this.tipo,
                    }
                this.createElement()
                }
            }
        },
        cambiarCantidad: function () {
            if(this.cantidad > this.artilce.zaa_cantidad){
                if (this.pMayoreo == true) {
                    this.totalArtiStock = this.artilce.zaa_prect_mayo * this.artilce.zaa_cantidad
                    this.totalSumaStock = this.tstock * this.artilce.zaa_prect_mayo
                    this.total = 0
                    if (this.pDescuento == true) {
                        this.decimal = this.artilce.zaa_oferta / 100
                        this.descuentoStock = this.totalArtiStock * this.decimal
                        this.descuentoRestStock = this.totalSumaStock * this.decimal
                    }else{
                        this.totalArtiStock = this.artilce.zaa_prect_mayo * this.artilce.zaa_cantidad
                        this.totalSumaStock = this.tstock * this.artilce.zaa_prect_mayo
                        this.total = 0
                        this.descuentoStock = 0
                        this.descuentoRestStock = 0
                    }
                }else{
                    this.totalArtiStock = this.artilce.zaa_prect_menud * this.artilce.zaa_cantidad
                    this.totalSumaStock = this.tstock * this.artilce.zaa_prect_menud
                    this.total = 0
                    if (this.pDescuento == true) {
                        this.decimal = this.artilce.zaa_oferta / 100
                        this.descuentoStock = this.totalArtiStock * this.decimal
                        this.descuentoRestStock = this.totalSumaStock * this.decimal
                    }else{
                        this.totalArtiStock = this.artilce.zaa_prect_menud * this.artilce.zaa_cantidad
                        this.totalSumaStock = this.tstock * this.artilce.zaa_prect_menud
                        this.total = 0
                        this.descuentoStock = 0
                        this.descuentoRestStock = 0
                    }
                }
            }else{
                if (this.pMayoreo == true) {
                    this.total = this.artilce.zaa_prect_mayo * this.cantidad
                    this.totalArtiStock = 0
                    this.totalSumaStock = 0
                    if (this.pDescuento == true) {
                        this.decimal = this.artilce.zaa_oferta / 100
                        this.descuentoStock = this.total * this.decimal
                        this.descuentoRestStock = 0
                    }else{
                        this.total = this.artilce.zaa_prect_mayo * this.cantidad
                        this.totalArtiStock = 0
                        this.totalSumaStock = 0
                        this.descuentoStock = 0
                        this.descuentoRestStock = 0
                    }
                }else{
                    this.total = this.artilce.zaa_prect_menud * this.cantidad
                    this.totalArtiStock = 0
                    this.totalSumaStock = 0
                    if (this.pDescuento == true) {
                        this.decimal = this.artilce.zaa_oferta / 100
                        this.descuentoStock = this.total * this.decimal
                        this.descuentoRestStock = 0
                    }else{
                        this.total = this.artilce.zaa_prect_menud * this.cantidad
                        this.totalArtiStock = 0
                        this.totalSumaStock = 0
                        this.descuentoStock = 0
                        this.descuentoRestStock = 0
                    }
                }
            }
        },
    },
}
</script>