<!--Autor: Mario Alonso
Descripción: Este archivo despliega un Dialog (modal) que permite registrar un nuevo cliente no afiliado-->
<template>
  <v-row justify="center">
    <v-btn dark text class="btn_csv" @click.stop="dialog = true" style="margin-top:-25px;">Agregar Cliente</v-btn> 
        <v-dialog v-model="dialog" max-width="550">
      <v-card>
        <v-toolbar dark>
          <h3>Agregar Cliente</h3> 
          <v-spacer/>
          <v-col v-show="name">
            <v-chip class="btn_folio" color="white" outlined>
              <strong>FOLIO: {{folio(name)}}{{folios(apep)}}-{{fech(fec)}}  </strong>    
            </v-chip>
          </v-col>
        </v-toolbar><br>
        <v-card-text>
          <v-form ref="form" v-model="valid" lazy-validation m>
            <v-alert color="dark" dark dense icon="mdi-account-check">
                <strong>Datos Personales</strong>
              </v-alert>
            <v-row> 
              <v-col>
              <v-text-field v-model="name" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"></v-text-field>
            </v-col>
            </v-row> 
            <v-row> 
              <v-col>
              <v-text-field v-model="apep" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
          </v-col>
          </v-row>
          <v-row>
            <v-col> 
                  <v-text-field v-model="apem" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
          </v-col>
          </v-row>
          <br>
          <v-alert color="dark" dark dense icon="mdi-card-account-phone">
                <strong>Información de Contacto</strong>
              </v-alert>

          <v-row>
                <v-col>
                  <v-text-field v-model="telDom" v-mask="'###-###-##-##'" max="13" :rules="telDomRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono Domiciliar:" required counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos"></v-text-field>
                </v-col>
                <v-col>
                  <v-text-field v-model="telCel" v-mask="'###-###-##-##'" max="13" :rules="telCelRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Número de Celular:" required counter placeholder="Ejem. 245-875-35-20" title="Sólo se permiten datos númericos"></v-text-field>
                </v-col>
              </v-row>

              <v-row>
                <v-col>
                  <v-textarea
                    v-model="direccion"
                    class="mx-2"
                    label="Dirección"
                    rows="1"
                    placeholder="C. Los Pinos 15 - Obregon 90500 Apizaco, Tlaxcala"
                    :rules="direccionRules"
                    :counter="100"
                    maxlength="100"
                  ></v-textarea>
                </v-col>
              </v-row>
              <!--{{idCliente}}-->

          </v-form>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
           <v-btn :disabled="!valid" x-large color="success" class="mr-4" @click="validate" text rounded>
             Guardar 
             <v-icon right dark>
               mdi-cloud-upload
              </v-icon>
            </v-btn>
            <v-btn color="orange" x-large class="mr-4" @click="reset" text rounded>
                    Borrar todo
                    <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                </v-btn>
                
                <v-btn color="red" x-large text @click="dialog = false" rounded>
            Cancelar 
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
let fecha_fol =  moment().locale('MX').format('YYMMDDSS')
export default {

    data () {
      return {  
        clienteNoAfi:[],
        valid: true,
        dialog: false,
        idCliente:'',
        
        //Sección de datos personales
        name:'',
        nameRules: [
          v => !!v || 'Se requiere ingresar un Nombre.',
          v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
          v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
          v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        ],
        apep:'',
        apepRules: [
          v => !!v || 'Se requiere ingresar un Apellido Paterno.',
          v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
          v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.',
          v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
        ],
        apem:'',
        apemRules: [
          v => !!v || 'Se requiere ingresar un Apellido Materno.',
          v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
          v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.',
          v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',    
        ],
        //Sección de datos de contacto
        telDom: '',
        telDomRules: [
          v => !!v || 'Se requiere ingresar un Número de Teléfono Domiciliar.',
          v => (v && v.length == 13) || 'El campo "Teléfono Domiciliar" debe tener al menos 10 caracteres.',
        ],
        telCel: '',
        telCelRules: [
          v => !!v || 'Se requiere ingresar un Número de Celular.',
          v => (v && v.length == 13) || 'El campo "Número de Celular" debe tener al menos 10 caracteres.',
        ],
        direccion:'',
        direccionRules:[
          v => !!v || 'Se requiere ingresar una Dirección.',
          v => (v && v.length >= 5) || 'El campo "Dirección" debe tener al menos 5 caracteres.',
          v => (v && v.length <= 100) || 'El campo "Dirección Paterno" no debe tener más de 100 caracteres.',
          v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Dirección" debe ser mayúscula',
        ],
        search: '',
        pedidoName: "PED-" + moment().locale('MX').format('YYMMDDSS'),//.format('YYYY MM DD'),
        empleadoId: '',
        sucursalId: '',
        fec:'',
      }
    },
    created() { 
        this.getEmpleado()
    },
    methods: {
      validate(){
        if (this.$refs.form.validate()){
          this.cliente = {
            zc_nombre:this.name,
            zc_apell_pat:this.apep,
            zc_apell_mat:this.apem,
            zc_num_telefono:this.telDom,
            zc_num_cell:this.telCel,
            zc_direccion:this.direccion,
            zc_existen: true,
            zc_folio_client:  this.name.slice(0,3).toUpperCase() + this.apep.slice(0,3).toUpperCase() +"-"+ moment().locale('MX').format('YYMMDDSS'),
          },
          this.submitClient()
        }
      },
      submitClient(){
        axios.post('http://127.0.0.1:8000/clientes/',this.cliente)
        .then (res => {
          this.idCliente = res.data.zc_id_cliente
          //console.log(res.data.zc_id_cliente)
          axios.post('http://127.0.0.1:8000/pedido/pedcab/', {
            "zped_nombre": this.pedidoName,
            "zped_status": "Pendiente",
            "zped_fecha": moment().locale('MX').format('YYYY-MM-DD'),
            "zipe_total": 0,
            "zped_id_usuario": res.data.zc_id_cliente,
            "zped_id_empleado": this.empleadoId,
            "zped_id_sucursal": this.sucursalId
          })
          .then( res => { this.$router.replace({ path: '/generarpedido/' + res.data.zped_id_pedcab }) } )
        })
      },
      getEmpleado(){
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => { 
                    this.empleadoId = res.data[0].user
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + res.data[0].user)
                      .then(resEmp => this.sucursalId = resEmp.data[0].zdem_id_sucursal)
                })
                .catch(error => console.log(error)); 
        }, 
      reset(){
        this.$refs.form.reset()

      },
      folio(nom){
        let obtfolio=""
        obtfolio=   nom.slice(0,3).toUpperCase();
        return obtfolio
      },
       folios(nam){
        let obfolio=""
        obfolio=   nam.slice(0,3).toUpperCase();
        return obfolio
      },
      fech(fec){
        let obtfech= fecha_fol
        return obtfech
    
      },
    }
  }
</script>