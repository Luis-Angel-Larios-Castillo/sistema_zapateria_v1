Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra la información de las ganancias hasta el año actual
<template>
    <v-container fluid> 
        <h2>Reporte de ganancias</h2>
        <apexchart width="800"  :options="options" :series="series"/>
    </v-container>
</template>
<script>
import Vue from 'vue';
import VueApexCharts from 'vue-apexcharts'
Vue.use(VueApexCharts)
Vue.component('apexchart', VueApexCharts)
export default {
    props:[
        'reporteData'
    ],
    created() {
    },
    data() {
        return {
            options: {
                chart: {
                    id: 'ReporteGanancias',
                    type: 'line',
                },
                xaxis: {
                    categories: this.reporteData.fechasReporteGanancias
                },
            },
            series: [{
                    name: 'Total mensual',
                    data: this.reporteData.datosReporteGanancias
                }],
                
        }
    },
}
</script>