Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) que muestra la interfaz para seleccionar cliente
<template>
    <v-row justify="center"> 
        <v-btn dark text class="btn_csv" @click.stop="dialog = true">Agregar Pedido</v-btn> 
        <v-dialog v-model="dialog" max-width="550">
        <v-card>
            <v-toolbar dark>
                <h3>Seleccionar Cliente </h3>
                <v-spacer></v-spacer>
                <AddClienteNoAfi style="margin-top:15px;" />
            </v-toolbar> 
            <v-card>
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    </div>
                </v-card-title>  
                <v-card-text>
                    <v-data-table  :headers="headersClientes" :items="clientes" 
                        :items-per-page="5"
                        :search="search"
                        no-results-text="No hay resultados."
                        :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                        no-data-text="No se tienen cliente registrados."
                        :header-props="{ sortByText: 'Ordenar por' }">
                        <template v-slot:item.nombre="{ item }">
                            <sCliente :elements="item"/>
                        </template>
                        <template v-slot:item.zc_id_cliente="{ item }">
                            <v-tooltip bottom>
                                <template v-slot:activator="{ on, attrs }">
                                    <!-- Se manda con el click a la funcion la informacion del cliente  -->
                                    <v-icon  color="green" @click="sCliente(item)" v-bind="attrs" v-on="on">
                                       mdi-shoe-sneaker
                                    </v-icon>
                                </template>
                                <span>Seleccionar</span>
                            </v-tooltip>   
                        </template>
                    </v-data-table>
                </v-card-text>
            </v-card>
        </v-card>
        </v-dialog>
    </v-row>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
import AddClienteNoAfi from './_AddClienteNoAfi.vue'
import sCliente from './_DetalleClienteNoAfi.vue'
export default {
    components:{
        AddClienteNoAfi,
        sCliente,
    }, 
    data() {
        return {
            dialog: false,
            headersClientes: [
                {
                    text: 'Nombre',
                    align: 'start',
                    filterable: true,
                    value: 'nombre',
                },  
                { text: 'Acciones', value: 'zc_id_cliente', sortable: false, align:'center' },
            ], 
            clientes: [], 
            search: '',
            pedidoName: "PED-" + moment().locale('MX').format('YYMMDDSS'),//.format('YYYY MM DD'),
            empleadoId: '',
            sucursalId: ''
        }
    },
    created() { 
        //Cuado se carga el componente se obtiene la informacion del empleado 
        this.getEmpleado()
        this.getClientes()
    }, 
    methods: {
        //Funcion para crear la cabecera de un pedido espera una objeto con la informacion del usuario 
        sCliente(Obj){ 
            let cab = {
                "zped_nombre": this.pedidoName,
                "zped_status": "Pendiente",
                "zped_fecha": moment().locale('MX').format('YYYY-MM-DD'),
                "zipe_total": 0,
                "zped_id_usuario": Obj.zc_id_cliente,
                "zped_id_empleado": this.empleadoId,
                "zped_id_sucursal": this.sucursalId
            }
            axios.post('http://127.0.0.1:8000/pedido/pedcab/', cab)
                .then( res => { this.$router.replace({ path: '/generarpedido/' + res.data.zped_id_pedcab }) } ) 
        },
        //Funcion para buscar empleado 
        getEmpleado(){
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => { 
                    this.empleadoId = res.data[0].user
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + res.data[0].user)
                    .then(resEmp => this.sucursalId = resEmp.data[0].zdem_id_sucursal)
                })
                .catch(error => console.log(error)); 
        }, 
        getClientes(){
            axios.get('http://127.0.0.1:8000/clientes/')
                .then(res => this.clientes = res.data)
        }, 
    },
}
</script> 