<!--Autor: Mario Alonso
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un articulo del pedido-->

<template>
  <div>
    <v-dialog  max-width="500">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <v-btn icon v-bind="attrs" v-on="on">
            <v-icon color="blue">mdi-shoe-sneaker</v-icon>
          </v-btn>
        </p>
      </template>
      
      <v-card>
        <v-card-title class="headline"></v-card-title>
        <v-alert dense type="success">
          Producto: <strong>{{detailArti.zaa_nombre_arti}}</strong>
        </v-alert>
        
        <v-card-text>
          <v-simple-table dense>
            <template v-slot:default>
              <tbody>
                <tr>
                  <td><strong>Clave:</strong></td>
                  <td>{{detailArti.zaa_clave}}</td>
                </tr>
                
                <tr>
                  <td><strong>Categoría:</strong></td>
                  <td>{{detailArti.zaa_categoria}}</td>
                </tr>
                
                <tr>
                  <td><strong>Catálogo:</strong></td>
                  <td>{{detailArti.zaa_catalogo}}</td>
                </tr>
                
                <tr>
                  <td><strong>Departamento: </strong>{{detailArti.zaa_dpto_name}}</td>
                  <td><strong>SubDepartamento: </strong>{{detailArti.zaa_subdpto_name}}</td>
                </tr>
                
                <tr>
                  <td><strong>Marca:</strong></td>
                  <td>{{detailArti.zaa_marca}}</td>
                </tr>
                
                <tr>
                  <td><strong>Modelo:</strong></td>
                  <td>{{detailArti.zaa_modelo}}</td>
                </tr>
              </tbody>
            </template>
          </v-simple-table> 
        
        </v-card-text>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
  const axios = require('axios')
  
  export default {
    props:[
      'findArticles'
    ],
    
    created() {
      this.getDetailArti()
    },
    data () {
      return {
        detailArti: '',
      }
    },
    methods:{
      getDetailArti(){
         let config = {
                headers: {
                    Authorization: "Token " + localStorage.token,
                }
            }
        axios.get('http://127.0.0.1:8000/articulo/admin/' + this.findArticles.zipe_id_arti +'/', config)
        //axios.get('http://127.0.0.1:8000/articulo/client/' + this.findArticles.zipe_id_arti +'/')
        .then(res => this.detailArti = res.data)
      },
    },
  }
</script>