<template>
    <v-container fluid>
        <div class="hr-sect"><h2>Venta - Clientes Afiliados</h2></div>
        <v-row>
            <v-col cols="col-5 xs-12">
                <v-card height="100%">
                    <v-card-title  dark class="grey darken-4">
                        <h3 class="white--text">Clientes Afiliados</h3>
                        <v-spacer></v-spacer>
                        <SelectCliente />
                    </v-card-title>
                    <v-card-text><br>
                        <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/>
                        <v-data-table
                            :headers="headersClientes" 
                            :items="findClientes"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen cliente registrados."
                            :search="search" :footer-props="{
                                showFirstLastPage: true,
                            itemsPerPageText: 'Elementos',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                            <template v-slot:item.nombre="{ item }">
                                <sCliente :elements="item"/>
                            </template>
                            <template v-slot:item.zc_tipo_cliente="{ item }">
                                <v-tooltip bottom v-if="item.zc_tipo_cliente == true">
                                    <template v-slot:activator="{ on, attrs }">
                                        <p class="green--text" align="left" style="margin-top:15px;"><strong>Mayorista</strong></p>
                                    </template>
                                </v-tooltip>
                                <v-tooltip bottom v-if="item.zc_tipo_cliente == false">
                                    <template v-slot:activator="{ on, attrs }">
                                        <p class="red--text" align="left" style="margin-top:20px"><strong>Minorista</strong></p>
                                    </template>
                                </v-tooltip>
                            </template>
                            <template v-slot:item.zc_id_usuario="{ item }">
                                <v-tooltip bottom v-if="item.zc_tipo_cliente == true">
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-icon color="green" @click="nombre = item.nombre, select = item.zc_id_usuario, selectPed = '', getPedidos(), getPedidosCat()" justify-center>
                                            mdi-eye
                                        </v-icon>
                                    </template>
                                </v-tooltip>
                                <v-tooltip bottom v-if="item.zc_tipo_cliente == false">
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-icon color="green" @click="nombre = item.nombre, select = item.zc_id_usuario, selectPed = '', getPedidos(), getPedidosCat()" justify-center>
                                            mdi-eye
                                        </v-icon>
                                    </template>
                                </v-tooltip>
                            </template>
                        </v-data-table>
                    </v-card-text>
                </v-card>
            </v-col>
            <!--Ventana de consulta de pedidos por cliente-->
            <v-col cols="col-2 xs-12">
                <v-card height="100%" v-if="select == ''" color="grey lighten-1">
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado un cliente.</h3>
                    </v-container>
                </v-card>
                <v-card height="100%" v-else>
                    
                    <v-alert color="dark" dark dense>
                        <strong>Pedidos de {{nombre}}</strong>
                    </v-alert>

                    <v-tabs>
                            <v-tab>Articulos</v-tab>
                            <v-tab>Catálogos</v-tab>
                            
                        <v-tab-item>
                    <v-card-text>
                        <v-text-field v-model="searchPed" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
                        <v-data-table
                            :headers="headersPedidos"
                            :items="findPedidos"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen pedidos registrados."
                            :search="searchPed" :footer-props="{
                                showFirstLastPage: true,
                                itemsPerPageText: 'Elementos',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                        <template v-slot:item.zped_nombre="{ item }">
                            <v-tooltip bottom v-if="item.zped_status == 'Finalizado'">
                                <template v-slot:activator="{ on, attrs }">
                                    <strong class="green--text" v-bind="attrs" v-on="on">
                                        {{item.zped_nombre}}
                                    </strong> 
                                </template>
                                <span>Pedido finalizado</span>
                            </v-tooltip> 
                            <strong v-else>
                                {{item.zped_nombre}}
                            </strong> 
                            
                        </template>
                        <template v-slot:item.zped_fech_creat="{ item }">
                            {{fecha(item.zped_fech_creat)}}
                        </template>
                            <template v-slot:item.zped_id_pedcab="{ item }">
                                <v-btn icon @click="selectPed = item.zped_id_pedcab, getPedido(), cardvar = 1" justify-center style="margin-left: 20px; margin-top: -10px;">
                                    <v-icon color="green">mdi-eye</v-icon>
                                </v-btn>
                            </template>
                        </v-data-table>
                    </v-card-text>
                    </v-tab-item>
                    <v-tab-item>
                         <v-card-text>
                        <v-text-field v-model="searchPedCat" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
                        <v-data-table
                            :headers="headersPedidosCat"
                            :items="findPedidosCat"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen pedidos registrados."
                            :search="searchPedCat" :footer-props="{
                                showFirstLastPage: true,
                                itemsPerPageText: 'Elementos',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                        <template v-slot:item.zpdcat_nombre="{ item }">
                            <v-tooltip bottom v-if="item.zpdcat_status == 'Finalizado'">
                                <template v-slot:activator="{ on, attrs }">
                                    <strong class="green--text" v-bind="attrs" v-on="on">
                                        {{item.zpdcat_nombre}}
                                    </strong> 
                                </template>
                                <span>Pedido finalizado</span>
                            </v-tooltip> 
                            <strong v-else>
                                {{item.zpdcat_nombre}}
                            </strong>
                        </template>

                        <template v-slot:item.zpdcat_fech_creat="{ item }">
                            {{fecha(item.zpdcat_fech_creat)}}
                        </template>
                            <template v-slot:item.zpdcat_id_pedcabcat="{ item }">
                                <v-btn icon @click="selectPedCat = item.zpdcat_id_pedcabcat, getPedidoCat(), cardvar = 2" justify-center style="margin-left: 20px; margin-top: -10px;">
                                    <v-icon color="blue">mdi-eye</v-icon>
                                </v-btn>
                            </template>
                        </v-data-table>
                    </v-card-text>
                    </v-tab-item>
                    </v-tabs>
                </v-card>
            </v-col>
            <!--Ventana de consulta por pedido seleccionado-->
            <v-col cols="md-4 xs-12">
                <v-card height="100%" v-if="selectPed == '' && selectPedCat == ''" color="grey lighten-1">
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado un pedido.</h3>
                    </v-container>
                </v-card>
                <v-card height="100%" v-else-if="cardvar == 1">
                    <v-card-title class="justify-center">
                        <div>
                            <h3>Zapatería Deny´s</h3>
                        </div>
                    </v-card-title>
                    <v-tabs v-model="tab" centered icons-and-text>
                        <v-tabs-slider/>
                        <v-tab href="#tab-1"> Articulos Preferidos </v-tab> 
                        <v-tab href="#tab-2"> Articulos Opcionales </v-tab>
                    </v-tabs>
                    <v-tabs-items v-model="tab">
                        <v-tab-item value="tab-1">
                            <ArtiPreferidos :findPedido="findPedido" @pedido="findPedido = $event"/> 
                        </v-tab-item>
                        <v-tab-item value="tab-2">
                            <ArtiOpcionales :findPedido="findPedido"/>
                        </v-tab-item>
                    </v-tabs-items>
                    <v-row>
                        <v-card-text>
                            <v-alert color="dark" dark dense>
                                <strong>Pedido</strong>
                            </v-alert>
                            <v-simple-table dense>
                                <template v-slot:default>
                                    <tbody>
                                        <tr>
                                            <td><strong>Cliente:</strong></td>
                                            <td>{{nombre}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Pedido:</strong></td>
                                            <td>{{findPedido.zped_nombre}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Fecha:</strong></td>
                                            <td>{{findPedido.zped_fecha}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Pagado:</strong></td>
                                            <td>${{findPedido.zped_pagado}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Vales:</strong></td> 
                                            <td>$ {{findPedido.zped_vale}}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Total Compra:</strong></td>
                                            <td>${{findPedido.zipe_total}}</td>
                                            <!--<td>${{msg}}</td>-->
                                        </tr>
                                        <tr>
                                            <td><strong>Restante:</strong></td>
                                            <td>${{findPedido.restante}}</td>
                                            <!--<td>${{msg - (totalVales + totalPagado)}}</td>-->
                                            <!--<td>${{findPedido.zipe_total - (totalVales + totalPagado)}}</td>-->
                                            <!--<td>$ {{findPedido.zipe_total-(findPedido.zped_pagado+findPedido.zped_vale)}}</td>-->
                                        </tr>
                                    </tbody>
                                </template>
                            </v-simple-table><br>
                            <v-alert color="dark" dark dense>
                                <strong>Forma de Pago</strong>
                            </v-alert>
                            <v-row>
                                <v-col cols="4">
                                    <UseValesCliente :findPedido="findPedido" @getDataVales="getDataVales"/>
                                </v-col>
                                <v-col cols="8">
                                    <Tarjeta :findPedido="findPedido"  @pedido="findPedido = $event"/>
                                </v-col>
                            </v-row>
                        </v-card-text>
                    </v-row>
                </v-card>
                 <v-card v-else-if="cardvar == 2">
                     <v-card-text>
                         <SelectPedCat :findPedidoCat="findPedidoCat" :pedcabcatdata="pedcabcatdata"/>                       
                     </v-card-text>
                  </v-card>
               
            </v-col>
        </v-row>
    </v-container>
</template> 

<script>
    import SelectCliente from './_SelectCliente.vue'
    import sCliente from './_DetalleClienteAfi.vue'
    import ArtiPreferidos from './_ArtiPreferidos.vue'
    import ArtiOpcionales from './_ArtiOpcionales.vue'
    import UseValesCliente from './_ValeCliente.vue'
    import Tarjeta from './_PDFVentaClienteAfi'
    import SelectPedCat from './moduloPedidoCatalogo/_SelectPedCat.vue'
    const axios = require('axios')
    const moment = require('moment')
    
    export default {
        components:{
            nombre: '',
            sCliente,
            SelectCliente,
            ArtiPreferidos,
            ArtiOpcionales,
            UseValesCliente,
            Tarjeta,
            SelectPedCat,
        },
        data() {
            return {
                cardvar:1,
                tab: null,
                //Función para almacenar los datos de los clientes y el botón que envia el id del usuario
                headersClientes: [
                    { text: 'Nombre', filterable: true, value: 'nombre',},
                    { text: 'Folio', value: 'zc_folio_client' },
                    { text: 'Tipo de cliente', value: 'zc_tipo_cliente' },
                    { text: 'Acciones', value: 'zc_id_usuario', sortable: false, align:'center'},
                ],
                search: '',
                keys: [
                    'nombre',
                    'zc_nombre',
                    'zc_apell_pat',
                    'zc_apell_mat',
                    'zc_folio_client',
                ],
                findClientes:[],
                select:'',
                
                //Función para almacenar los datos de los pedidos de un cliente y el botón que envia el id del pedido especifico
                headersPedidos: [
                    {text: 'Pedido', filterable: true, value: 'zped_nombre',},
                    { text: 'Fecha', value: 'zped_fech_creat' }, 
                    { text: 'Detalles', value: 'zped_id_pedcab', sortable: false, align:'center'},
                ],
                searchPed: '',
                keys: [
                    'zped_nombre',
                    'zped_fecha',
                ],
                findPedidos:[],
                selectPed:'', 
                
                //Función para almacenar los datos de un pedido en especifico
                findPedido:Object,
                msg:0,

                //DATA DE PEDIDOS CATALOGOS
                headersPedidosCat: [
                    {text: 'Pedido', filterable: true, value: 'zpdcat_nombre',},
                    { text: 'Fecha', value: 'zpdcat_fech_creat' }, 
                    { text: 'Detalles', value: 'zpdcat_id_pedcabcat', sortable: false, align:'center'},
                ],
                searchPedCat: '',
                findPedidosCat:[],
                selectPedCat:'',
                findPedidoCat:[],
                pedcabcatdata:[],
                totalVales:0,
                totalPagado:0
            }
        },
        created(){
            this.getClientes()
        }, 
        methods: {
            getData(data){
                this.msg = data;
            },
            getDataVales(dataVales){
                this.totalVales=dataVales;
            },
            getDataPagado(dataPagado){
                this.totalPagado=dataPagado;
            },
            getClientes(){
                axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resUser =>{
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + resUser.data[0].user)
                    .then(resEmp =>{ 
                        axios.get('http://127.0.0.1:8000/cliente/clientes/')
                        .then(resClie =>{
                            resClie.data.forEach(cliente => {
                                if(cliente.zc_id_sucursal == resEmp.data[0].zdem_id_sucursal){
                                    this.findClientes.push(cliente)
                                }
                            }); 
                        })
                    })
                }) 
            },
            getPedidos(){
                axios.get('http://127.0.0.1:8000/pedido/pedcab/?search=' + this.select)
                .then(res => this.findPedidos = res.data)
            },
            getPedidosCat(){ 
                axios.get('http://127.0.0.1:8000/pedido/pedcabcat/?search=' + this.select)
                .then(res => {this.findPedidosCat = res.data})
            },
            getPedido(){
                axios.get('http://127.0.0.1:8000/pedido/pedcab/' + this.selectPed)
                .then(res =>  this.findPedido = res.data)
            },
            getPedidoCat(){
                axios.get('http://127.0.0.1:8000/pedido/itempedcat/?search=' + this.selectPedCat)
                .then(res => { this.findPedidoCat = res.data
                
                
                axios.get('http://127.0.0.1:8000/pedido/pedcabcat/' + this.selectPedCat +'/')
                .then(res => {this.pedcabcatdata = res.data})
                
                })
            },
            fecha(date){
                return moment(date).locale('MX').format('DD-MM-YYYY LT')
            },
        },
    }
</script>