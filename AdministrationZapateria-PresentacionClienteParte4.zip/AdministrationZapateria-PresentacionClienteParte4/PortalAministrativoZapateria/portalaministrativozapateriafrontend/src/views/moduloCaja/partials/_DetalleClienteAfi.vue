<!--Autor: Mario Alonso
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro de un cliente afiliado-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="500">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text" style="margin-bottom:2px; margin-left:-10px;">
          <strong>{{elements.nombre}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline"></v-card-title>
        <v-card-text>
          <v-alert dense text color="blue">
            Cliente <strong>{{elements.nombre}}</strong>
          </v-alert>
          <div class="black--text">
            <v-alert color="grey lighten-4" dense align="center">
              <h3>DATOS DE CONTÁCTO</h3>
            </v-alert>
            <div align="center">
              <p><strong>Folio </strong><br>{{elements.zc_folio_client}}</p>
              <p><strong>Teléfono:</strong> {{elements.zc_num_telefono}} ---- <strong>Celular: </strong>{{elements.zc_num_cell}}</p>
              <p><strong>Correo Electrónico </strong><br>{{elements.zc_correo}}</p>
              <p><strong>Fecha de Nacimiento </strong><br>{{elements.zc_fech_nacim}}</p>
              <v-alert color="grey lighten-4" dense align="center">
                <h3>DATOS DE DIRECCIÓN</h3>
              </v-alert>
              <v-row align="center">
                <v-col align="center">
                  <p class="mb-0">{{elements.zc_dir_municipio}} {{elements.zc_dir_estado}}, {{elements.zc_dir_pais}}</p>
                  <p style="font-size:13px;"><strong>Lugar de recidencia</strong></p><p class="mb-0">{{elements.zc_dir_municipio}}</p>
                  <p style="font-size:13px;"><strong>Ciudad</strong></p>
                </v-col>
              </v-row>
            </div>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
  export default {
    props:['elements'],
  }
</script>