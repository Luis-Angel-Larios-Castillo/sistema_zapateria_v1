Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) que muestra la información para validar Vale
<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="blue" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
            <v-icon >mdi-card-account-details-outline</v-icon>
          </v-btn>
        </template>
        <span>Agregar</span>
    </v-tooltip>
    <v-dialog v-model="dialog" max-width="500">
      <v-card>
        <v-toolbar dark>
          <h3>Autorizar vale</h3>
        </v-toolbar>
        <v-card-text> 
          <v-form ref="form" v-model="valid" lazy-validation m>
            <v-text-field v-model="correo"  :rules="correoRules" label="Correo" required/>
            <v-text-field v-model="pass"  
              :rules="passRules"
              :append-icon="show ? 'mdi-eye' : 'mdi-eye-off'"
              prepend-icon="mdi-lock"
              label="Contraseña"
              :type="show ? 'text' : 'password'"
              @click:append="show = !show"
              required/>
            <br><br>
            <v-row align="center" justify="space-around"> 
                <v-btn :disabled="!valid" color="success" class="mr-4" @click="validar" outlined>
                    Validar 
                    <v-icon right dark>
                        mdi-cloud-upload
                    </v-icon>
                </v-btn> 
                <v-btn @click="dialog = false" outlined color="red">
                  Cancelar
                </v-btn> 
            </v-row>
          </v-form>
        </v-card-text>   
      </v-card>
    </v-dialog>
    <v-snackbar  :color="color" v-model="snackbar">{{text}}</v-snackbar>
  </v-row>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
export default {
    props:[
        'vale',
        'cabPed',
        'idEmp'
    ],
    data () {
      return {  
        color: '', 
        text: '',
        conalert: 0,
        canAuthorize: false,
        element: [],
        snackbar: false,
        show: false,
        valid: true, 
        dialog: false,   
        correo: 'diana@gmail.com',
        correoRules: [
          v => !!v || 'El correo es obligatorio',
          v => /.+@.+\..+/.test(v) || 'El correo tine que ser valido',
        ],
        pass: 'Hola@1234',
        passRules: [
          v => !!v || 'La contraseña es obligatorio.',    
          v => /(?=.*[A-Z])/.test(v) || 'Debe tener una mayúscula.', 
          v => /(?=.*\d)/.test(v) || 'Debe tener al menos un número.', 
          v => /([!@$%])/.test(v) || 'Debe tener un carácter especial "!@$%"',       
        ],
      }
    }, 
    methods:{
      guardar(id){
        this.snackbar = false
        this.vale.zdv_estat_vale = true
        this.vale.zdv_id_user_autori = id
        this.vale.zdv_id_pedcab = this.cabPed
        this.vale.zdv_id_user_qcobra_vale = this.idEmp
        this.vale.zdv_fecha_cobro = moment().format('YYYY-MM-DD') 
        axios.put('http://127.0.0.1:8000/vale/' + this.vale.zdv_id_vale + '/', this.vale )
          .then(res => window.location.reload())
      },
      validar(){
        if (this.$refs.form.validate()){
          this.element = {
            zdus_correo: this.correo,
            password: this.pass
          }
        this.validarCredenciales()
        } 
      },
      async validarCredenciales(){ 
        await axios.post('http://127.0.0.1:8000/usuario/compuser/', this.element)
          .then(res => {  
            if (res.data.user.is_superuser == true) { 
              this.canAuthorize = true  
              this.guardar(res.data.user.zdus_id_usuario)
            } else {
              res.data.user.groups.forEach(Group => {
                Group.permissions.forEach(Permission => { 
                  axios.get('http://127.0.0.1:8000/usuario/permissions/' + Permission + '/' )
                    .then(resPer=> {  
                      if (resPer.data.codename){ 
                        this.canAuthorize = true 
                        this.guardar(res.data.user.zdus_id_usuario)
                      }
                    })
                });
              }); 
            }  
            if(this.canAuthorize == false){
              this.snackbar= true
              this.text = 'No puede autorizar'
              this.color = 'orange' 
            }
          }) 
          .catch(res => {
            this.snackbar= true
            this.text = 'Las credenciales son invalidas'
            this.color = 'orange' 
          }) 
          
      }  
    },

  }
</script>