<template>
    <v-container fluid>
        <div class="hr-sect"><h2>Venta - Clientes No Afiliados</h2></div>
        <v-row>
            <v-col cols="md-5 xs-12">
                <v-card height="100%">
                    <v-card-title  dark class="grey darken-4">
                        <h3 class="white--text">Clientes No Afiliados</h3>
                        <v-spacer></v-spacer>
                        <SelectClienteNoAfi />
                        <AddClienteNoAfi />
                    </v-card-title>
                    
                    <v-card-text><br>
                        <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/>
                        <v-data-table    
                            :headers="headersClientes" 
                            :items="findClientes"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen cliente registrados."
                            :search="search" :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                            <template v-slot:item.nombre="{ item }">
                                <sCliente :elements="item"/>
                            </template>

                            <template v-slot:item.zc_id_cliente="{ item }">
                                <v-icon color="green" @click="nombre = item.nombre, select = item.zc_id_cliente, selectPed = '', getPedidos()" justify-center>
                                    mdi-eye
                                </v-icon>
                            </template>
                        </v-data-table>  
                    </v-card-text>
                </v-card>
            </v-col> 
            <!--Ventana de consulta de pedidos por cliente-->
            <v-col cols="md-3 xs-12">
                <v-card height="100%" v-if="select == ''" color="grey lighten-1">
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado un cliente.</h3>
                    </v-container>
                </v-card> 
                <v-card height="100%" v-else>
                    <v-card-title class="justify-center">
                        <div>
                            <h3>Zapatería Deny´s</h3>
                        </div>
                    </v-card-title> 
                    <v-alert color="dark" dark dense>
                        <strong>Pedidos de {{nombre}}</strong>
                    </v-alert>
                    
                    <v-card-text>
                        <v-text-field v-model="searchPed" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
                        <v-data-table    
                            :headers="headersPedidos" 
                            :items="findPedidos"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen pedidos registrados."
                            :search="searchPed" :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                        <template v-slot:item.zped_nombre="{ item }">
                            <v-tooltip bottom v-if="item.zped_status == 'Finalizado'">
                                <template v-slot:activator="{ on, attrs }">
                                    <strong class="green--text" v-bind="attrs" v-on="on">
                                        {{item.zped_nombre}}
                                    </strong> 
                                </template>
                                <span>Pedido finalizado</span>
                            </v-tooltip> 
                            <strong v-else>
                                {{item.zped_nombre}}
                            </strong>
                        </template>
                        <template v-slot:item.zped_fech_creat="{ item }">
                            {{fecha(item.zped_fech_creat)}}
                        </template>
                            <template v-slot:item.zped_id_pedcab="{ item }"  > 
                                <v-btn icon @click="selectPed = item.zped_id_pedcab, getArticles(), getPedido()" justify-center style="margin-left: 20px; margin-top: -10px;">
                                    <v-icon color="green">mdi-eye</v-icon>
                                </v-btn>
                            </template>
                        </v-data-table> 
                    </v-card-text>
                </v-card>
            </v-col>
            
            <!--Ventana de consulta por pedido seleccionado-->
            <v-col cols="md-4 xs-12">
                <v-card height="100%" v-if="selectPed == ''" color="grey lighten-1">
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado un pedido.</h3>
                    </v-container>
                </v-card>
                
                <v-card height="100%" v-else>
                    <v-card-title class="justify-center">
                        <div>
                            <h3>Zapatería Deny´s</h3>
                        </div>
                    </v-card-title>
                    
                    <v-alert color="dark" dark dense>
                        <strong>Articulos</strong>
                    </v-alert> 
                    <v-row> 
                        <v-card-text>
                            <v-simple-table dense fixed-header height="150">
                                <template v-slot:default>
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Estatus</th>
                                            <th>#</th>
                                            <th>Articulos</th>
                                            <th>Color</th>
                                            <th>Talla</th>
                                            <th>Total</th>
                                            <th class="text-center">Estatus</th>
                                            <th>Detalles</th>
                                        </tr>
                                    </thead>
                                    <tbody v-for="item in findArticles" :key="item.zipe_id_item_ped" height="50"> 
                                        <tr>
                                            <td v-if="item.zipe_status == 'Entregado'"><v-icon color="blue">mdi-checkbox-marked-circle</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Sin Existencia'"><v-icon color="red">mdi-close-circle</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Cancelado'"><v-icon color="red">mdi-close-octagon</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'"><v-icon color="red">mdi-account-arrow-left</v-icon></td>
                                            <td v-else><v-checkbox v-model="selectArti" :value="item.zipe_id_item_ped" style="margin-right:-50px;" @click="updateitem(item)"/></td>
                                            <td> 
                                                <v-tooltip bottom v-if="item.zipe_status == 'Cancelado'">
                                                    <template v-slot:activator="{ on, attrs }"> 
                                                        <v-icon color="red" v-bind="attrs" v-on="on" >
                                                            mdi-cancel
                                                        </v-icon> 
                                                    </template>
                                                    <span>Cancelado</span>
                                                </v-tooltip>
                                                <v-tooltip bottom v-else-if="item.zipe_status == 'Entregado'">
                                                    <template v-slot:activator="{ on, attrs }">
                                                        <v-icon color="blue" v-bind="attrs" v-on="on">
                                                            mdi-alert-circle-check-outline
                                                        </v-icon>
                                                    </template>
                                                    <span>Entregado</span>
                                                </v-tooltip>
                                                <v-tooltip bottom v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'">
                                                    <template v-slot:activator="{ on, attrs }">
                                                        <v-icon color="red" v-bind="attrs" v-on="on">
                                                            mdi-alert-remove-outline
                                                        </v-icon>
                                                    </template>
                                                    <span>Devuelto</span>
                                                </v-tooltip>
                                                <v-tooltip bottom v-else>
                                                    <template v-slot:activator="{ on, attrs }"> 
                                                        <v-icon color="warning" v-bind="attrs" v-on="on" >
                                                            mdi-alert-circle-outline
                                                        </v-icon>
                                                    </template>
                                                    <span>Listo para entregar</span>
                                                </v-tooltip> 
                                            </td>
                                            <td>{{item.zipe_cant}}</td>
                                            <td>{{item.zipe_nombre}}</td>
                                            <td>{{item.zipe_color}}</td>
                                            <td>{{item.zipe_talla}}</td> 
                                            <td>{{item.zipe_sub_tot}}</td>
                                            <td v-if="item.zipe_status == 'Pendiente'" class="red--text text-center">Sin Entregar <v-icon color="red">mdi-close-octagon</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Cancelado'" class="red--text text-center">Cancelado <v-icon color="red">mdi-close-octagon</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Devolución' || item.zipe_status == 'Devolucion'" class="red--text text-center">Devuelto <v-icon color="red">mdi-account-arrow-left</v-icon></td>
                                            <td v-else-if="item.zipe_status == 'Listo para entregar'" class="green--text text-center">Listo para entregar <v-icon color="green">mdi-check-all</v-icon></td>
                                            <td v-else class="blue--text text-center">Entregado <v-icon color="blue">mdi-account-check</v-icon></td>
                                            <td>
                                                <v-row class="justify-center align-center">
                                                    <DetalleArti :findArticles="item" style=" margin-top:15px;"/>    
                                                    <!--<CreatedVale :cab="findPedido" v-if="item.zipe_status != 'Entregado' && item.zipe_status !='Pendiente'  && item.zipe_status !='Cancelado' && item.zipe_status !='Devolucion' && item.zipe_status !='Devolución'" :item="item" :noShowCretedVale="noShowCretedVale"/>-->
                                                    <CreatedVale :cab="findPedido" v-if="item.zipe_status != 'Entregado' && item.zipe_status !='Cancelado'" :item="item" :noShowCretedVale="noShowCretedVale"/>
                                                </v-row> 
                                            </td> 
                                        </tr>
                                    </tbody>
                                </template>
                            </v-simple-table>  
                        </v-card-text> 
                        <v-card-text>
                            <v-alert color="dark" dark dense>
                            <strong>Pedido</strong>
                        </v-alert>  
                        <v-simple-table dense>
                            <template v-slot:default>
                                <tbody>
                                    <tr>
                                        <td><strong>Cliente:</strong></td>
                                        <td>{{nombre}}</td>
                                    </tr> 
                                    <tr>
                                        <td><strong>Pedido:</strong></td>
                                        <td>{{findPedido.zped_nombre}}</td>
                                    </tr> 
                                    <tr>
                                        <td><strong>Fecha:</strong></td>
                                        <td>{{findPedido.zped_fecha}}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Pagado:</strong></td>
                                        <td>${{findPedido.zped_pagado}}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Total Compra:</strong></td>
                                        <td>${{findPedido.zipe_total}}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Restante:</strong></td>
                                        <td>${{findPedido.restante}}</td>
                                    </tr>
                                </tbody>
                            </template>
                        </v-simple-table><br>
                        <v-alert color="dark" dark dense>
                            <strong>Forma de Pago</strong>
                        </v-alert>
                        <Tarjeta :findPedido="findPedido" @pedido="findPedido = $event"/><br>  
                        </v-card-text> 
                    </v-row>
                </v-card>
                
            </v-col>
        </v-row>
        <v-snackbar v-model="snackbar">
            <h3>¡No se puede entregar el articulo ya que no se ha pagado!</h3> 
            <template v-slot:action="{ attrs }">
                <v-btn color="pink" text v-bind="attrs" @click="snackbar = false" >
                Cerrar
                </v-btn>
            </template>
        </v-snackbar>
    </v-container>
</template> 
<script> 
    import SelectClienteNoAfi from './_SelectClienteNoAfi.vue'
    import sCliente from './_DetalleClienteNoAfi.vue'
    import Tarjeta from './_PDFVentaClienteNoAfi'
    import DetalleArti from './_detalleArticulo'
    import CreatedVale from './_CreatedVale.vue'
    import AddClienteNoAfi from './_AddClienteNoAfi.vue'
    const axios = require('axios')
    const moment = require('moment')

    export default {
        components:{
            nombre: '',
            sCliente,
            Tarjeta,
            DetalleArti,
            SelectClienteNoAfi,
            CreatedVale,
            AddClienteNoAfi,
        }, 
        data() {
            return {
                noShowCretedVale: false,
                selectArti: [],
                //Función para almacenar los datos de los clientes y el botón que envia el id del usuario
                headersClientes: [
                    { text: 'Nombre', filterable: true, value: 'nombre',},
                    { text: 'Folio', value: 'zc_folio_client' }, 
                    { text: 'Acciones', value: 'zc_id_cliente', sortable: false, align:'center'},
                ],
                search: '',
                keys: [
                    'nombre',
                    'zc_nombre',
                    'zc_apell_pat',
                    'zc_apell_mat',
                    'zc_folio_client',
                ],
                findClientes:[],
                select:'', 
                //Función para almacenar los datos de los pedidos de un cliente y el botón que envia el id del pedido especifico
                headersPedidos: [
                    {text: 'Pedido', filterable: true, value: 'zped_nombre',},
                    { text: 'Fecha', value: 'zped_fech_creat' }, 
                    { text: 'Detalles', value: 'zped_id_pedcab', sortable: false, align:'center'},
                ],
                searchPed: '',
                keys: [
                    'zped_nombre',
                    'zped_fecha',
                ],
                findPedidos:[],
                selectPed:'', 
                //Función para almacenar los datos de un pedido en especifico y la función que almacena los datos de los articulos asociados a un pedido
                findPedido:Object,
                findArticles:[], 

                snackbar: false,
            }
        },
        
        created(){
            this.getClientes()
        },
        
        methods: {
            getClientes(){
                axios.get('http://127.0.0.1:8000/clientes/')
                .then(res => this.findClientes = res.data)
            },
            getPedidos(){
                axios.get('http://127.0.0.1:8000/pedido/pedcab/?search=' + this.select)
                .then(res => this.findPedidos = res.data)
            },
            getPedido(){
                axios.get('http://127.0.0.1:8000/pedido/pedcab/' + this.selectPed)
                .then(res =>  this.findPedido = res.data )
            },
            getArticles(){
                axios.get('http://127.0.0.1:8000/pedido/itemped/?search=' + this.selectPed)
                .then(res => {this.findArticles = res.data
                this.noShowCretedVale = true
                })
            },
            updateitem(m){
                let enCaja = (this.findPedido.zped_pagado)
                
                if(enCaja >= m.zipe_sub_tot){ 
                    if(this.findPedido.zped_pagado >= m.zipe_sub_tot){ 
                        this.findPedido.zped_pagado -= m.zipe_sub_tot 
                        this.findPedido.zipe_total -= m.zipe_sub_tot  
                        if(this.findPedido.zipe_total === 0){
                            this.findPedido.zped_status = 'Finalizado'
                        }
                        axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/', this.findPedido)
                    }
                    
                    const URL = 'http://127.0.0.1:8000/pedido/itempedpre/'+m.zipe_id_item_ped+'/'
                    m.zipe_status = 'Entregado'
                    m.zipe_entregado = true  
                    axios.put(URL, m) 
                    
                    let config = {
                        headers: {
                            Authorization: "Token " + localStorage.token,
                        }
                    }
                    axios.get('http://127.0.0.1:8000/articulo/admin/' + m.zipe_id_arti + '/', config)
                    .then(resArt => { 
                        this.nuevoStock = (resArt.data.zaa_cantidad - m.zipe_cant)  
                        axios.put('http://127.0.0.1:8000/articulo/admin/' + m.zipe_id_arti +'/',{
                            "zaa_cantidad": this.nuevoStock,
                            "zaa_color": resArt.data.zaa_color,
                            "zaa_id_arti_global": resArt.data.zaa_id_arti_global,
                            "zaa_id_sucursal": resArt.data.zaa_id_sucursal,
                            "zaa_talla": resArt.data.zaa_talla,
                        }, config)
                    })
                } else { 
                    this.snackbar = true
                    m.zipe_entregado = false
                }
            },
            fecha(date){
                return moment(date).locale('MX').format('DD-MM-YYYY LT')
            },
        },
    }
</script>