Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) para generar el PDF de un reporte o corte general.
<template>
  <div>
    <!-- Dialog-->
    <v-dialog v-model="dialog" persistent max-width="600px">
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="info" dark v-bind="attrs" v-on="on" text> Reporte </v-btn>
      </template>
      <v-card>
        <v-toolbar flat align="center" justify="space-around" dark>
          <v-toolbar-title>Reporte</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-btn @click="(dialog = false), (reporte = false)" text>
            Cerrar
          </v-btn>
        </v-toolbar>
        <v-card-title justify="center">
          <h5>Seleccionar fecha inicial y final:</h5>
        </v-card-title>
        <br />
        <v-card-text>
          <v-row>
            <v-menu
              ref="menu01"
              v-model="menu01"
              :close-on-content-click="false"
              :return-value.sync="fechaInicial"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="fechaInicial"
                  label="Fecha inicial"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                />
              </template>
              <v-date-picker
                v-model="fechaInicial"
                no-title
                locale="es-mx"
                scrollable
              >
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="menu01 = false">
                  Cancelar
                </v-btn>
                <v-btn
                  text
                  color="primary"
                  @click="$refs.menu01.save(fechaInicial)"
                  >Guardar</v-btn
                >
              </v-date-picker>
            </v-menu>
            <v-menu
              ref="menu02"
              v-model="menu02"
              :close-on-content-click="false"
              :return-value.sync="fechaFinal"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="fechaFinal"
                  label="Fecha final"
                  prepend-icon="mdi-calendar"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                />
              </template>
              <v-date-picker
                v-model="fechaFinal"
                no-title
                locale="es-mx"
                scrollable
              >
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="menu02 = false">
                  Cancelar
                </v-btn>
                <v-btn
                  text
                  color="primary"
                  @click="$refs.menu02.save(fechaFinal)"
                  >Guardar</v-btn
                >
              </v-date-picker>
            </v-menu>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn @click="filtrar()" color="green" text>filtrar</v-btn>
          <PDF v-if="corte.corteExist == true" :corteData="corte" />
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- Fin del Dialog-->
  </div>
</template>
<script>
const axios = require("axios");
const moment = require("moment");
import PDF from "../../../components/PdfView";
export default {
  components: {
    PDF,
  },
  data() {
    return {
      dialog: false,
      menu01: false,
      menu02: false,
      fechaInicial: new Date().toISOString().substr(0, 10),
      fechaFinal: new Date().toISOString().substr(0, 10),
      corte: {
        corteExist: false,
        totalCorte: 0,
        fInicio: "",
        fFin: "",
        corteItems: [],
      },
    };
  },
  methods: {
    filtrar() {
      this.corte.totalCorte = 0;
      axios.get("http://127.0.0.1:8000/caja/list/").then((res) => {
        let arr = [];
        let fIn = moment(this.fechaInicial)
          .subtract(1, "days")
          .format("YYYY-MM-DD");
        let fFinal = moment(this.fechaFinal)
          .add(1, "days")
          .format("YYYY-MM-DD");
        for (let i = 0; i < res.data.length; i++) {
          if (
            moment(res.data[i].zca_fecha).isBetween(moment(fIn), moment(fFinal))
          ) {
            if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
              arr.push(res.data[i]);
              this.corte.totalCorte += res.data[i].zca_total;
            } else {
              arr.push(res.data[i]);
              this.corte.totalCorte -= res.data[i].zca_total;
            }
          }
        }
        for (let i = 0; i < res.data.length; i++) {
          if (
            moment(res.data[i].zca_fecha).isBetween(moment(fIn), moment(fFinal))
          ) {
            if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
              res.data[i].zca_total = "$" + res.data[i].zca_total;
            } else {
              res.data[i].zca_total = "-$" + res.data[i].zca_total;
            }
          }
        }
        this.items = arr;
        (this.corte.fInicio = moment(this.fechaInicial)
          .locale("es")
          .format("LL")),
          (this.corte.fFin = moment(this.fechaFinal).locale("es").format("LL")),
          (this.corte.corteItems = arr);
        this.corte.corteExist = true;
      });
    },
  },
};
</script>