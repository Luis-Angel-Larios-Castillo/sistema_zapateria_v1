Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) para generar el PDF de un corte de turno.
<template>
    <div>
      <!-- Dialog-->
      <v-dialog v-model="dialog" persistent max-width="600px">
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="info" dark v-bind="attrs" v-on="on" text>
          Corte de turno
        </v-btn>
      </template>
      <v-card >
        <v-toolbar flat align="center" justify="space-around"  dark>
            <v-toolbar-title>Corte de turno</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn @click="dialog = false , reporte = false" text >
                Cerrar
            </v-btn>
          </v-toolbar>
          <v-card-title primary-title class="black--text">
            <div>
              <h3>Zapatería Deny´s</h3>
              <div>
                Fecha: {{corteTurno.fecha}}
              </div>
            </div>
          </v-card-title>
          <v-card-text >
              <v-container class="black--text">
                <h3>Empleado: {{corteTurno.empleado}}</h3>
                <h3>Total: ${{corteTurno.total}}</h3>
              </v-container>

          </v-card-text>
        <v-card-actions class="justify-center">
          <v-spacer></v-spacer>
          <PDF :corteData="corteTurno"/>
        </v-card-actions>
      </v-card>
    </v-dialog>
      <!-- Fin del Dialog-->
    </div>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
import PDF from "../../../components/PdfCorteTurno"
export default {
    components: {
      PDF,
    },
    data() {
       return {
        dialog: false,
        corteTurno:{
          corteExist: false,
          empleado: '',
          fecha: moment(this.fechaInicial).locale('es').format('LL'),
          movimientos: [],
          total: 0
        },

       }
    },
    created() {
      this.getItemsByUser()
    },
    methods: {
      getItemsByUser(){
        this.corteTurno.total = 0
        axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
            .then(res => {
                axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data.user +'/' )
                    .then(emp => {
                        this.corteTurno.empleado = emp.data.zdus_correo
                        axios.get('http://127.0.0.1:8000/caja/listmovuser/?search=' + emp.data.zdus_id_usuario)
                          .then(res => {
                            let arr = []
                            let suma
                            let fecha = new Date().toISOString().substr(0, 10)
                            for (let i = 0; i < res.data.length; i++) {
                                if (res.data[i].zca_fecha == fecha) {
                                    if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
                                      arr.push(res.data[i])
                                      this.corteTurno.total += res.data[i].zca_total
                                    }else{
                                      arr.push(res.data[i])
                                      this.corteTurno.total -= res.data[i].zca_total
                                    }
                                }
                            }
                            for (let i = 0; i < res.data.length; i++) {
                                if (res.data[i].zca_fecha == fecha) {
                                    if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
                                        res.data[i].zca_total = '$' + res.data[i].zca_total
                                    }else{
                                        res.data[i].zca_total = '-$' + res.data[i].zca_total
                                    }
                                }
                            }
                            this.items = arr
                            this.corteTurno.movimientos = arr
                            this.corteTurno.corteExist = true
                            })

                    } )
            })

        
      }
    },  
}
</script>