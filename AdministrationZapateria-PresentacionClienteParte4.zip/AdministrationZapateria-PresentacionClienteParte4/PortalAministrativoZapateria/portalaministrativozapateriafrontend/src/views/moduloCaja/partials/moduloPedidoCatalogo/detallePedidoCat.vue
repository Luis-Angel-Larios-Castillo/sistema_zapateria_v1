<template>
  <v-card>
    <v-card-text>
      <div v-show="false">{{ cab.zpdcat_id_pedcabcat }}</div>
      <v-responsive class="overflow-y-auto" max-height="200">
        <v-responsive height="vh" class="text-center pa-2">
          <v-lazy
            v-model="isActive"
            :options="{
              threshold: 0.5,
            }"
            min-height="200"
            transition="fade-transition"
          >
            <v-simple-table>
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">Nombre</th>
                    <th class="text-left">Tipo de precio</th>
                    <th class="text-left">Cantidad</th>
                    <th class="text-left">Total</th>

                    <th class="text-center">
                      <v-icon>mdi-delete-outline</v-icon>
                    </th>
                  </tr>
                </thead>

                <tbody>
                  <tr v-for="item in items" :key="item.zipcat_id_itemped_cat">
                    <td>{{ item.nombre_cat }}</td>
                    <td>{{ item.zipcat_tipo_precio }}</td>
                    <td>{{ item.zipcat_cant }}</td>
                    <td>${{ item.zipcat_sub_tot }}</td>
                    <td>
                      <v-btn icon color="error" @click="eliminar(item)">
                        <v-icon>mdi-delete-outline</v-icon>
                      </v-btn>
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </v-lazy>
        </v-responsive>
      </v-responsive>
    </v-card-text>
    <v-card-text class="black--text">
      <v-divider />
      <br />
      <v-row>
          <v-col>
            <v-text-field
                v-model="cant_pago"
                label="Anticipo"
                v-on:change="calutotal()"
                prefix="$"
                oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                required
                maxlength="6"
            />
          </v-col>
          <v-col>
            <h2 class="">Total: ${{ total }}</h2>
            <h2 v-if="restant == 'El anticipo es superior al total'">
                Su cambio es: ${{ cambio }}
            </h2>
            <h2 v-else>Restante: ${{ restant }}</h2>
          </v-col>
      </v-row>
     
    </v-card-text>
    <v-card-actions>
   
<v-btn
      color="error"
        elevation="2"
        outlined
        class="col-5"
        rounded
      @click.stop="dialog = true"
      v-if="totalitems >= 1"
    >
     Cancelar
    </v-btn>

      <v-btn color="error"
        elevation="2"
        outlined
        class="col-5"
        rounded
        v-else
       @click="cancelar()">Cancelar</v-btn>
       <v-spacer/>
      
      <v-btn color="primary" elevation="2" outlined class="col-5" rounded v-if="totalitems <= 0" @click.stop="dialogSave = true">Guardar</v-btn>
      <v-btn color="primary" elevation="2" outlined class="col-5" rounded @click="guardar()" v-else>Guardar</v-btn>


    </v-card-actions>
    <v-dialog
      v-model="dialog"
      max-width="290"
    >
      <v-card>
        <v-card-title class="text-h5">
          No se puede cancelar este pedido!
        </v-card-title>
        <v-divider></v-divider>
       
        <v-card-text>
           <br>
       <v-alert
       class="col-12"
      dense
      outlined
      type="error"
    >
      Por que tiene catalogos agreagos
    </v-alert>
        </v-card-text>
<v-divider></v-divider>
        <v-card-actions>
          

          <v-spacer></v-spacer>

          <v-btn
            color="primary"
            text
            @click="dialog = false"
          >
            Aceptar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogSave" max-width="410">
      <v-card>
        <v-card-title class="text-h5"></v-card-title>
        <v-alert dense text color="warning" type="info">
          <strong>No se puede guardar este pedido</strong>
        </v-alert>
        <v-divider></v-divider>
        <v-card-text><br>
          <v-alert class="col-12" dense outlined type="error">No se encuentra con catálogos relacionados</v-alert>
        </v-card-text>
        <v-divider></v-divider>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="dialogSave = false">
            Aceptar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

  </v-card>
  
</template>
<script>
import moment from 'moment'
const axios = require("axios");
export default {
  props: ["cab", "cliente"],
  data() {
    return {
      dialogSave:false,
      dialog: false,
      isActive: false,
      total: 0,
      cant_pago: 0,
      items: [],
      restant: null,
      cambio: null,
      search: "",
      headersitemCatalog: [
        { text: "Tipo de precio", value: "zipcat_tipo_precio" },
        { text: "Cantidad", value: "zipcat_cant" },
        { text: "Total", value: "zipcat_sub_tot", sortable: false },
      ],
      itemcatalogo:[],
      updacatalogos:[],
      buscatalogo:[],
      totalitems:0
    };
  },
  created() {
    this.findItems();
  },
  updated() {
    this.findItems();
  },
  methods: {
    eliminar(itemPed) {
      axios
        .delete(
          "http://127.0.0.1:8000/pedido/itempedcat/" +
            itemPed.zipcat_id_itemped_cat +
            "/"
        )
        .then((res) =>{ 
           window.location.reload()
          
         });
    },

       /*findcatalogos(itemPed){
            axios.get('http://127.0.0.1:8000/pedido/itempedcat/'+itemPed.zipcat_id_itemped_cat+'/')
                .then(res => {this.itemcatalogo = res.data
                 axios.get('http://127.0.0.1:8000/catalogo/catalogos/activos/'+itemPed.zipcat_id_catalogo+'/')
                  .then(res => {this.buscatalogo = res.data
                   this.buscatalogo.zac_cantidad = (this.buscatalogo.zac_cantidad)+(this.itemcatalogo.zipcat_cant)
                 axios.put('http://127.0.0.1:8000/catalogo/catalogos/activos/'+itemPed.zipcat_id_catalogo+'/',this.buscatalogo)
                 .then(res =>{ this.updacatalogos = res.data
                       this.eliminar(itemPed)
                    })

                  })

                
                })
        },*/ 



    findItems() {
      axios
        .get(
          "http://127.0.0.1:8000/pedido/itempedcat/?search=" +
            this.cab.zpdcat_id_pedcabcat
        )
        .then((res) => {
          this.items = res.data;
          this.totalitems = res.data.length
          let total = 0;
          this.items = res.data;
          res.data.forEach((element) => {
            total += element.zipcat_sub_tot;
          });
          this.total = total;
        });
    },
    calutotal() {
      if (this.total > this.cant_pago) {
        this.restant = this.total - this.cant_pago;
      } else {
        this.cambio = this.cant_pago - this.total;
        this.restant = "El anticipo es superior al total";
      }
    },
    guardar() {
      this.cab.zpdcat_total = this.total;
      this.cab.zpdcat_pagado = this.cant_pago;
      axios
        .put(
          "http://127.0.0.1:8000/pedido/pedcabcat/" +
            this.cab.zpdcat_id_pedcabcat +
            "/",
          this.cab
        )
        .then((res) => {
          

          // Condicion para si se registra un anticipo se cree un registro paralos graficos
                    if(res.data.cant_pago != 0){
                        let transaccion = {
                            zca_nombre: 'VENTA-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
                            zca_tipo: 'Venta',
                            zca_concepto: res.data.zpdcat_nombre,
                            zca_fecha: moment().locale('MX').format('YYYY-MM-DD'),
                            zca_hora: moment(new Date()).format('H:mm '),
                            zca_total: this.cant_pago,
                            
                            zca_id_usuario: res.data.zpdcat_id_empleado
                        } 
                        axios.post('http://127.0.0.1:8000/caja/cabecera/', transaccion)
                        .then(resCaja => {
                            this.$router.replace({ path: '/ventasClientesAfi/' }) 
                        })
                    } else {
                        this.$router.replace({ path: '/ventasClientesAfi/' }) 
                    }


       });
    },
    cancelar() {
      axios
        .get(
          "http://127.0.0.1:8000/pedido/itempedcat/?search=" +
            this.cab.zpdcat_id_pedcabcat
        )
        .then((resItems) => {
          resItems.data.forEach((item) => {
            
            axios.delete(
              "http://127.0.0.1:8000/pedido/itempedcat/" +
                item.zipcat_id_itemped_cat +
                "/"
            );
          });
          axios
            .delete(
              "http://127.0.0.1:8000/pedido/pedcabcat/" +
                this.cab.zpdcat_id_pedcabcat +
                "/"
            )
            .then((res) => {
              this.$router.replace({ path: "/ventasClientesAfi/" });
            });
        });
    },
  },
};
</script>