Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra la información de transacciones a lo largo del año actual 
<template>
    <v-card>
        <v-card-title primary-title>
            Informe anual {{reporteData.year}}
        </v-card-title>
        <v-card-text>
            <v-row class="justify-center">
                <v-col cols="md-4 xs-12">
                    <v-card>
                        <v-simple-table >
                            <template v-slot:default>
                            <thead>
                                <tr>
                                    <th class="text-left black--text">Concepto</th>
                                    <th class="text-left black--text">Monto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr >
                                    <td>Entradas de efectivo</td>
                                    <td>${{ reporteData.datoAnual.entradas }}</td>
                                </tr>
                                <tr >
                                    <td>Salidas de efectivo</td>
                                    <td>${{ reporteData.datoAnual.salidas }}</td>
                                </tr>
                                <tr >
                                <td>Ganancias </td>
                                    <td v-if="reporteData.datoAnual.total < 0 ">-${{ -reporteData.datoAnual.total }}</td>
                                    <td v-else>${{ reporteData.datoAnual.total }}</td>
                                </tr>
                            </tbody>
                            </template>
                        </v-simple-table>
                    </v-card>
                </v-col>
                <v-col cols="md-8 xs-12">
                    <apexchart width="500"  :options="options" :series="series"/>
                </v-col>
            </v-row>
        </v-card-text>
    </v-card>
</template>
<script>
import Vue from 'vue';
import VueApexCharts from 'vue-apexcharts'
Vue.use(VueApexCharts)
Vue.component('apexchart', VueApexCharts)
export default {
    props:[
        'reporteData'
    ],
    data() {
        return {
            options: {
                chart: {
                    id: 'ReporteAnual',
                    type: 'bar'
                },
                xaxis: {
                    categories: ['Ingresos', 'Salidas', 'Ganancias']
                },
                plotOptions: {
                    bar: {
                        barHeight: '100%',
                        distributed: true,
                        horizontal: false,
                        dataLabels: {
                        position: 'bottom'
                        },
                    }
                },
                colors: ['#00CD00', '#FF1919', '#3299FF'],
            },
            series: [{
                    name: 'Balance anual',
                    data: [this.reporteData.datoAnual.entradas, this.reporteData.datoAnual.salidas, this.reporteData.datoAnual.total]
                }],
                
        }
    },
}
</script>