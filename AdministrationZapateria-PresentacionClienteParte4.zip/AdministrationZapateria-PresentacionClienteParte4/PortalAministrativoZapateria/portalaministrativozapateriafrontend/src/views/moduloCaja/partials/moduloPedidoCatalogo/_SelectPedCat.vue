<template>
  <div>
    <h2>DETALLES DE PEDIDO</h2>
    {{pedcabcatdata.zpdcat_nombre}}
    <br/>
    {{pedcabcatdata.zpdcat_fecha}}
    <br/>
    
    <p class="blue--text mb-0">{{ pedcabcatdata.zpdcat_status }}</p>
    <v-responsive class="overflow-y-auto" max-height="200">
      <v-responsive height="vh" class="text-center pa-2">
        <v-lazy
          v-model="isActive"
          :options="{
            threshold: 0.5,
          }"
          min-height="200"
          transition="fade-transition"
        >
          <v-simple-table>
            <thead>
              <tr>
                <th>
                  <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon color="blue" v-bind="attrs" v-on="on" style="margin-left:10px;">
                        mdi-truck-check-outline
                      </v-icon>
                    </template>
                    <span>Estatus de entrega</span>
                  </v-tooltip>
                </th>
                <th class="text-center">Nombre</th>
                <th>Cantidad</th>
                <th>Total</th>
                <th class="text-center">Estatus</th>
              </tr>
            </thead>
            <tbody
              v-for="itempedcat in findPedidoCat"
              :key="itempedcat.zipcat_id_itemped_cat"
            >
              <tr>
                <td v-if="itempedcat.zipcat_estatus_cat != 'Listo para entregar'">
                  <v-tooltip bottom v-if="itempedcat.zipcat_estatus_cat == 'Cancelado'">
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon color="red" v-bind="attrs" v-on="on">
                        mdi-cancel
                      </v-icon>
                    </template>
                    <span>Cancelado</span>
                  </v-tooltip>
                  
                  <v-tooltip bottom v-else-if="itempedcat.zipcat_estatus_cat == 'Entregado'">
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon color="blue" v-bind="attrs" v-on="on">
                        mdi-checkbox-marked-circle
                      </v-icon>
                    </template>
                    <span>Entregado</span>
                  </v-tooltip>
                  
                  <v-tooltip bottom v-else>
                    <template v-slot:activator="{ on, attrs }"> 
                      <v-icon color="warning" v-bind="attrs" v-on="on" >
                        mdi-alert-circle-outline
                      </v-icon>
                    </template>
                    <span>Pendiente</span>
                  </v-tooltip>
                </td>
                <td v-else><v-checkbox v-model="selectCatalog" :value="itempedcat.zipcat_id_itemped_cat" @click="updateitem(itempedcat)" style="margin-left:10px;"/></td>
                
                <td>{{ itempedcat.nombre_cat }}</td>
                <td>{{ itempedcat.zipcat_cant }}</td>
                <td>${{ itempedcat.zipcat_sub_tot }}</td>
                
                <td v-if="itempedcat.zipcat_estatus_cat == 'Entregado'" class="blue--text text-center">Entregado</td>
                <td v-else-if="itempedcat.zipcat_estatus_cat == 'Cancelado'" class="red--text text-center">Cancelado</td>
                <td v-else-if="itempedcat.zipcat_estatus_cat == 'Pendiente'" class="warning--text text-center">Pendiente</td>
                <td v-else class="green--text text-center">Listo para entregar</td>
              </tr>
            </tbody>
          </v-simple-table>
        </v-lazy>
      </v-responsive>
    </v-responsive>
    
    <div class="hr-sect"><h2>PEDIDO</h2></div>
    <v-simple-table>
      <tbody>
        <tr>
          <th class="text-center">Costo total de pedido</th>
          <td class="text-left">${{pedcabcatdata.zpdcat_total }}</td>
        </tr>
        <tr>
          <th class="text-center">Anticipo</th>
          <td>${{pedcabcatdata.zpdcat_pagado}}</td>
        </tr>
        <tr>
          <th class="text-center">Resta</th>
          <td>${{pedcabcatdata.restante}}</td>
        </tr>
        <tr>
          <th class="text-center">Abonar</th>
          <td v-if="pedcabcatdata.zpdcat_pagado == pedcabcatdata.zpdcat_total"><v-text-field style="margin-right:20px;" v-model="abono" label="Cantidad" type="number" prefix="$" disabled/></td>
          <td v-else><v-text-field v-model="abono" label="Cantidad" type="number" prefix="$"/></td>
        </tr><br>
      </tbody>
      <v-row>
        <v-col>
          <Tarjeta :pedcabcatdata="pedcabcatdata" @pedido="pedcabcatdata = $event" :abono="abono" style="width:220%"/>
        </v-col>
      </v-row>
    </v-simple-table>
    
    <v-snackbar v-model="snackbar">
      <h3>¡No se puede entregar el catálogo ya que no se ha pagado!</h3> 
      <template v-slot:action="{ attrs }">
        <v-btn color="pink" text v-bind="attrs" @click="snackbar = false" >
          Cerrar
        </v-btn>
      </template>
    </v-snackbar>
  </div>
</template>

<script>

  const axios = require("axios");
  import Tarjeta from './_PDFVentaCatalogo'
  
  export default {
    components: {
      Tarjeta
    },
    
    props:[
      "findPedidoCat",
      "pedcabcatdata"
    ],
    
    data() {
      return {
        snackbar: false,
        isActive: false,
        selectCatalog: [],
        abono: 0,
      };
    },
    
    methods: {
      updateitem(m){
        let enCaja = (this.pedcabcatdata.zpdcat_pagado)
        
        if(enCaja >= m.zipcat_sub_tot){ 
          if(this.pedcabcatdata.zpdcat_pagado >= m.zipcat_sub_tot){ 
            this.pedcabcatdata.zpdcat_pagado -= m.zipcat_sub_tot 
            this.pedcabcatdata.zpdcat_total -= m.zipcat_sub_tot  
            
            if(this.pedcabcatdata.zpdcat_total === 0){
              this.pedcabcatdata.zpdcat_status = 'Finalizado'
            }
            
            axios.put('http://127.0.0.1:8000/pedido/pedcabcat/'+this.pedcabcatdata.zpdcat_id_pedcabcat + '/', this.pedcabcatdata)
          }
          
          const URL = 'http://127.0.0.1:8000/pedido/itempedcat/'+m.zipcat_id_itemped_cat+'/'
          m.zipcat_estatus_cat = 'Entregado'
          axios.put(URL, m)
          
          let config = {
            headers: {
              Authorization: "Token " + localStorage.token,
            }
          }
          
          axios.get('http://127.0.0.1:8000/catalogo/' + m.zipcat_id_catalogo + '/', config)
          .then(resArt => {
            this.nuevoStock = (resArt.data.zac_cantidad - m.zipcat_cant)
            
            axios.put('http://127.0.0.1:8000/catalogo/' + m.zipcat_id_catalogo +'/',{
              "zca_id_catalogo": resArt.data.zca_id_catalogo,
              "zca_nombre_ca": resArt.data.zca_nombre_ca,
              "zca_id_proveedores": resArt.data.zca_id_proveedores,
              "zca_year": resArt.data.zca_year,
              "zca_temporada": resArt.data.zca_temporada,
              "zca_cod_barras": resArt.data.zca_cod_barras,
              "zca_prec_prev": resArt.data.zca_prec_prev,
              "zca_prec_regul": resArt.data.zca_prec_regul,
              "zac_prec_comp": resArt.data.zac_prec_comp,
              "zac_existen": resArt.data.zac_existen,
              "zac_apart": resArt.data.zac_apart,
              "zac_cantidad": this.nuevoStock,
              "zac_tipo_paquete": resArt.data.zac_tipo_paquete,
              "zac_sucursal": resArt.data.zac_sucursal,
              "zac_fech_delet": resArt.data.zac_fech_delet,
              "zac_is_deleted": resArt.data.zac_is_deleted,
              "zac_usua_delet": resArt.data.zac_usua_delet,
            }, config) 
          })
        }else{
          this.snackbar = true
        }
      },
    },
  };
</script>