<template>
    <v-row justify="center">
        <v-tooltip bottom >
            <template v-slot:activator="{ on, attrs }">
                <v-btn icon color="green" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
                    <v-icon >mdi-plus</v-icon>
                </v-btn>
            </template>
            <span>Agregar</span>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="550">
            <v-card>
                <v-toolbar dark>
                    <h3>Agregar catálogo: {{element.zca_nombre_ca}}</h3>
                </v-toolbar><br>
                <v-card-text>
                    <v-form ref="form" v-model="valid" lazy-validation m>
                        <v-row>
                            <v-col cols="6">
                                <v-select
                                    v-model="tprecioselect"
                                    :items="tipo_precio"
                                    v-on:change="caluprecio()" 
                                    :rules="[v => !!v || 'Debe seleccionar un tipo de precio']"
                                    label="Tipo de precio a aplicar"
                                    required
                                />
                            </v-col>
                            <v-col cols="6">
                                <v-text-field
                                    v-model="cantidad"
                                    label="Seleccionar cantidad" 
                                    v-on:change="caluprecio()" 
                                    type="number"
                                    required
                                    min="1"
                                    :rules="[   v => !!v || 'Cantidad inválida.', 
                                        v => (v && v > 0) || 'No se puede seleccionar esta cantidad.']"
                                />
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col>
                                <p v-if="cantidad == 0">
                                    <v-alert dense text color="blu">
                                        <strong>Estatus de entrega</strong>
                                    </v-alert>
                                </p>
                                <p v-else-if="cantidad > element.zac_cantidad">
                                    <v-alert dense text color="warning" type="info">
                                        <strong>{{tstock}} Catálogos deben ser solicitados al proveedor</strong>
                                    </v-alert>
                                </p>
                                <p v-else>
                                    <v-alert dense text color="green" type="success">
                                        <strong>{{cantidad}} Catálogos estan listos para ser entregados</strong>
                                    </v-alert>
                                </p>
                            </v-col>
                        </v-row>
                        {{calcular(cantidad, element.zac_cantidad)}}
                        <div v-show="false">{{tstock = totalStock}}</div>
                    </v-form>
                    <br><hr><br>
                    <div v-if="cantidad > element.zac_cantidad">
                        <h3 class="black--text">Total Compra: $ {{totalArtiStock + totalSumaStock}}</h3>
                    </div>
                    <div v-else>
                        <h3 class="black--text">Total Compra: $ {{total}}</h3>
                    </div>

                    <div v-show="false">
                        <h3 class="black--text" v-show="false">TotalArtoStock $ {{totalArtiStock}}</h3>
                        <h3 class="black--text" v-show="false">TotalSumaStock $ {{totalSumaStock}}</h3>
                    </div>

                </v-card-text>
                
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="red darken-1" text @click="dialog = false">
                        Cancelar
                    </v-btn>
                    <v-btn color="green darken-1" text @click="create()" :disabled="!valid">
                        Aceptar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-row>
</template>

<script>
    const axios = require('axios')
    export default {
        
        props:[
            'element',
            'cab'
        ],
        
        data () {
            return {          
                valid: true,
                dialog: false,
                total: 0,           
                tipo_precio:['Preventa', 'Regular','Compra'],
                tprecioselect:'',
                cantidad:0,
                validt_pre:0,
                catalogo:[],
                updacatalogos:[],
                tstock:0,
                totalArtiStock:0,
                totalSumaStock:0,
            }
        },
        
        methods:{
            caluprecio(){
                if(this.cantidad > this.element.zac_cantidad){
                    if(this.tprecioselect=='Preventa'){
                        this.validt_pre = 1
                        this.totalArtiStock = this.element.zca_prec_prev * this.element.zac_cantidad
                        this.totalSumaStock = this.tstock * this.element.zca_prec_prev
                    }
                    else if(this.tprecioselect=='Regular'){
                        this.validt_pre = 1
                        this.totalArtiStock = this.element.zca_prec_regul * this.element.zac_cantidad
                        this.totalSumaStock = this.tstock * this.element.zca_prec_regul
                    }
                    else{
                        this.validt_pre = 1
                        this.totalArtiStock = this.element.zac_prec_comp * this.element.zac_cantidad
                        this.totalSumaStock = this.tstock * this.element.zac_prec_comp
                    }
                }else{
                    if(this.tprecioselect=='Preventa'){
                        this.totalArtiStock = 0
                        this.totalSumaStock = 0
                        this.validt_pre = 1
                        this.total= this.element.zca_prec_prev * this.cantidad
                    }
                    else if(this.tprecioselect=='Regular'){
                        this.totalArtiStock = 0
                        this.totalSumaStock = 0
                        this.validt_pre = 1
                        this.total= this.element.zca_prec_regul * this.cantidad
                    }
                    else{
                        this.totalArtiStock = 0
                        this.totalSumaStock = 0
                        this.validt_pre = 1
                        this.total= this.element.zac_prec_comp * this.cantidad
                    }
                }
            },
            
            calcular(cantidad, stock) {
                let totalStock = 0;
                if (cantidad >= stock) {
                    this.totalStock = cantidad - stock;
                } else if (stock > cantidad) {
                    totalStock = cantidad - stock;
                    this.totalStock = Math.abs(totalStock);
                } else {

                }
            },

            createElement(){
                axios.post('http://127.0.0.1:8000/pedido/itempedcat/',this.elementUnit)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            createCat(){
                axios.post('http://127.0.0.1:8000/pedido/itempedcat/',this.elemento)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            createStock(){
                axios.post('http://127.0.0.1:8000/pedido/itempedcat/',this.elementStock)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            
            create(){
                if(this.cantidad > this.element.zac_cantidad){
                    if(this.element.zac_cantidad == 0){
                        this.elementStock = {
                            "zipcat_tipo_precio": this.tprecioselect,
                            "zipcat_cant": this.totalStock,
                            "zipcat_sub_tot": this.totalSumaStock,
                            "zipcat_estatus_cat": "Pendiente",
                            "zipcat_id_catalogo": this.element.zca_id_catalogo,
                            "zipcat_id_pedcabcat": this.cab.zpdcat_id_pedcabcat,
                        }
                        this.createStock()
                    }else{
                        this.elemento = {
                            "zipcat_tipo_precio": this.tprecioselect,
                            "zipcat_cant": this.element.zac_cantidad,
                            "zipcat_sub_tot": this.totalArtiStock,
                            "zipcat_estatus_cat": "Listo para entregar",
                            "zipcat_id_catalogo": this.element.zca_id_catalogo,
                            "zipcat_id_pedcabcat": this.cab.zpdcat_id_pedcabcat,
                        },
                        this.elementStock = {
                            "zipcat_tipo_precio": this.tprecioselect,
                            "zipcat_cant": this.totalStock,
                            "zipcat_sub_tot": this.totalSumaStock,
                            "zipcat_estatus_cat": "Pendiente",
                            "zipcat_id_catalogo": this.element.zca_id_catalogo,
                            "zipcat_id_pedcabcat": this.cab.zpdcat_id_pedcabcat,
                        }
                        this.createCat()
                        this.createStock()
                    }
                }else if(this.cantidad <= this.element.zac_cantidad){
                    this.elementUnit = {
                        "zipcat_tipo_precio": this.tprecioselect,
                        "zipcat_cant": this.cantidad,
                        "zipcat_sub_tot": this.total,
                        "zipcat_estatus_cat": "Listo para entregar",
                        "zipcat_id_catalogo": this.element.zca_id_catalogo,
                        "zipcat_id_pedcabcat": this.cab.zpdcat_id_pedcabcat,
                    }
                    this.createElement()
                }
            },
        },
    }
</script>