<template>   
    <v-container fluid>
         <br>
        <v-row>  
            <v-col cols="md-7 xs-12">
                        <v-card>
                            <br>
                            <h1>PEDIDO DE CATÁLOGOS</h1>   
                            <v-card-title class="card_title">
                                <div class="col-12" id="table_cabecera_color">
                                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                </div>
                            </v-card-title> 
                            <v-card-text>
                            <v-data-table  :headers="headersCatalog" :items="catalogos" 
                                :items-per-page="5"
                                :search="search"
                                :footer-props="{ showFirstLastPage: true, itemsPerPageText: 'Elementos por página ', }"
                                no-data-text="No se ha realizado una búsqueda."
                                :header-props="{ sortByText: 'Ordenar por' }">

                                <template v-slot:item.zac_cantidad="{ item }">
                                    <v-chip :color="getColor(item.zac_cantidad)" class="white--text"> 
                                        {{ item.zac_cantidad }} pzas.
                                    </v-chip>
                                </template>
                               
                                <template v-slot:item.zca_id_catalogo="{ item }">
                                    <v-row align="center">

                                        <v-col>
                                        <Addpedcat :element="item" :cab="cabecera"/>
                                        </v-col>
                                        
                                    </v-row>
                                </template>
                            </v-data-table>
                            </v-card-text>
                        </v-card>
                
            </v-col>
           <v-col>
                 <v-card>
                    <v-card-title class="card_title justify-center">
                        <h2>Detalles de pedido</h2>
                    </v-card-title>
                    <br>
                    <v-row>
                    <v-col>{{cabecera.zpdcat_nombre}}</v-col>
                    <v-col> {{cabecera.zpdcat_fecha}}</v-col>
                    </v-row>          
                    {{datoscliuser.nombre}}
                    <br>
                    <p class="blue--text">{{cabecera.zpdcat_status}}</p>
                     <Detallepedido :cab="cabecera" :cliente="datoscliuser"/>
                </v-card>
           </v-col>
            
        </v-row>     
    </v-container>     
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import Addpedcat from './add_PedCat'
import Detallepedido from './detallePedidoCat.vue'

export default {
    components:{
        Addpedcat,
        Detallepedido
    },
    data() {
        return { 
            search: '',
            cabecera: [], 
            selecciono: false, 
            datoscliuser:[],
            headersCatalog: [
                {
                    text: 'Nombre',
                    align: 'start',
                    filterable: true,
                    value: 'zca_nombre_ca',
                },  
                { text: 'Temporada', value: 'zca_temporada' },
                { text: 'Cantidad', value: 'zac_cantidad' },
                { text: 'Acciones', value: 'zca_id_catalogo', sortable: false }, 
            ],
            catalogos: [],
           
           
        }
    }, 
    created() {
        this.getCabecera() 
        this.findcatalogos()
    },  
    methods: {   
        
        getCabecera(){
            axios.get('http://127.0.0.1:8000/pedido/pedcabcat/' + this.$route.params.id + '/' ) 
                .then(res => {this.cabecera = res.data
                

                 axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.cabecera.zpdcat_id_usuario)
                .then(res => this.datoscliuser = res.data[0])

                }) 
        },
        findcatalogos(){
            let config = {
                headers: {
                    Authorization: "Token " + localStorage.token,
                }
            }
            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user

                axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+ this.idUser)
                .then(res=>{this.admin=res.data[0]
                
                if(this.admin.is_superuser==false){
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
                    .then(res => { this.empleadoResult = res.data[0]
                        axios.get('http://127.0.0.1:8000/catalogo/catalogos/activos/?search=' + this.empleadoResult.zdem_id_sucursal,config)
                        .then(res => this.catalogos = res.data)
                    })
                }else{
                    axios.get('http://127.0.0.1:8000/catalogo/catalogos/activos/')
                        .then(res => this.catalogos = res.data)
                }
                })
            })
        },
        getColor (zac_cantidad) {
            if (zac_cantidad < 2) return 'red accent-3'
            else if (zac_cantidad < 5) return 'orange accent-3'
            else return 'green accent-4'
        },
        
       
    },
}
</script>