<template>
    <v-row justify="center">
        <v-tooltip bottom >
            <template v-slot:activator="{ on, attrs }">
                <v-btn icon color="blue" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
                    <v-icon >mdi-plus-circle</v-icon>
                </v-btn>
            </template>
            <span>Agregar</span>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="650">
            <v-card>
                <v-toolbar dark>
                    <!--{{findArticle.zipe_id_item_ped}}-->
                    <h3>Agregar artículo:</h3>
                </v-toolbar>
                <div v-show="false">
                    <v-alert dense text color="red">
                        <strong>Artículo a Cambiar<br></strong>
                    </v-alert>
                    {{this.ArticleOld.zipe_id_item_ped}}<br>
                    {{this.ArticleOld.zipe_cant}}<br>
                    {{this.ArticleOld.zipe_devo}}<br>
                    {{this.ArticleOld.zipe_sub_tot}}<br>
                    {{this.ArticleOld.zipe_color}}<br>
                    {{this.ArticleOld.zipe_talla}}<br>
                    {{this.ArticleOld.zipe_id_pedido_cab}}<br>
                    {{this.ArticleOld.zipe_id_arti}}
                </div>
                <v-container>
                    <v-alert dense text color="green">
                        <strong>Detalles del Artículo<br></strong>
                    </v-alert>
                    <v-simple-table dense>
                        <template v-slot:default>
                            <tbody>
                                <tr>
                                    <td><strong>Nombre:</strong></td>
                                    <td>{{ArticleClient.zaa_nombre_arti}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Clave:</strong></td>
                                    <td>{{ArticleClient.zaa_clave}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Categoría:</strong></td>
                                    <td>{{ArticleClient.zaa_categoria}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Catálogo:</strong></td>
                                    <td>{{ArticleClient.zaa_catalogo}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Departamento: </strong>{{ArticleClient.zaa_dpto_name}}</td>
                                    <td><strong>SubDepartamento: </strong>{{ArticleClient.zaa_subdpto_name}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Marca:</strong></td>
                                    <td>{{ArticleClient.zaa_marca}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Modelo:</strong></td>
                                    <td>{{ArticleClient.zaa_modelo}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Precio al Contado:</strong></td>
                                    <td>${{ArticleClient.zaa_prec_cont}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Precio Mayoreo:</strong></td>
                                    <td>${{ArticleClient.zaa_prect_mayo}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Precio Menudeo:</strong></td>
                                    <td>${{ArticleClient.zaa_prect_menud}}</td>
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>
                </v-container><br>
                <v-container>
                    <v-alert dense text color="blue">
                        <strong>Detalles de Compra</strong>
                    </v-alert>
                </v-container>
                <v-card-text>
                    <v-form ref="form" v-model="valid" lazy-validation m>
                        <v-row>
                            <v-col>
                                <v-text-field
                                    v-model="cantidad" 
                                    label="Seleccionar cantidad" 
                                    v-on:change="cambiarCantidad()" 
                                    type="number"
                                    min="1"
                                    :rules="[   v => !!v || 'Cantidad inválida.', 
                                        v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                                        v => (v && v < ArticleClient.zaa_cantidad+1) || 'No se puede seleccionar esta cantidad' ]"
                                    />
                            </v-col>
                            <v-col>
                                <v-select v-model="findArticle.zipe_color" :items="ArticleClient.zaa_color" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un Color']"  label="Color" required/>
                            </v-col>
                            <v-col>
                                <v-select v-model="findArticle.zipe_talla" :items="ArticleClient.zaa_talla" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar una Talla']"  label="Talla" required/>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col>
                                <v-switch v-model="pMayoreo" v-on:change="cambiarCantidad()" color="purple" label="Mayorista" style="margin-left:30%;"/> 
                            </v-col>
                            <v-col cols="6">
                                <v-alert dense text color="red" type="info" v-if="ArticleClient.zaa_oferta <= 0" style="margin-left:-40px; margin-top:10px">
                                    <strong>Sin oferta de descuento</strong>
                                </v-alert>
                                <v-switch v-model="pDescuento" v-on:change="cambiarCantidad()" v-else color="purple" label="Aplicar descuento" style="margin-left:10px;"/> 
                            </v-col>
                        </v-row>
                        <v-col>
                            <v-text-field v-model="tipo" v-if="ocultar" v-show="false" :rules="[v => !!v || 'Debe seleccionar un tipo']"  label="Tipo de Articulo" required readonly/>
                        </v-col>
                    </v-form>
                    <v-simple-table dense>
                        <tbody>
                            <tr v-if="cantidad == 0 || cantidad > ArticleClient.zaa_cantidad">
                                <td><h3 class="black--text" style="margin-left:20px;">Total del Nuevo Artículo: $0</h3></td>
                                <td><h3 class="black--text" style="margin-left:-12%;">Total de Pedido: ${{findPedido.zipe_total}}</h3></td>
                            </tr>
                            <tr v-else>
                                <td><h3 class="black--text" style="margin-left:20px;">Total del Nuevo Artículo: ${{this.totalNewCompra = total - descuentoStock}}</h3></td>
                                
                                <td v-if="this.ArticleOld.zipe_status == 'Cancelado'"><h3 class="black--text" style="margin-left:-20%;">Total de Pedido: ${{this.totalFinal = this.totalNewCompra + this.findPedido.zipe_total}}</h3></td>
                                <td v-else><h3 class="black--text" style="margin-left:-20%;">Total de Pedido: ${{this.totalFinal = this.totalNewCompra - this.ArticleOld.zipe_sub_tot + this.findPedido.zipe_total}}</h3></td>
                            </tr>
                        </tbody>
                    </v-simple-table>
                    <!--
                        <br>{{findArticle.zipe_id_item_ped}}
                        <br>{{findArticle.zipe_cant}}
                        <br>{{findArticle.zipe_devo}}
                        <br>{{findArticle.zipe_sub_tot}}
                        <br>{{findArticle.zipe_status}}
                        <br>{{findArticle.zipe_color}}
                        <br>{{findArticle.zipe_talla}}
                        <br>{{findArticle.zica_tipo_articulo}}
                        <br>{{findArticle.zipe_id_arti}}
                        <br>{{findArticle.zipe_id_pedido_cab}}<br><br>
                        <hr>
                        
                        {{ArticleClient.zaa_color}}
                        {{findPedido.zped_id_pedcab}}
                        <br>{{findPedido.zped_id_usuario}}
                        <br>{{findPedido.zped_nombre}}
                        <br>{{findPedido.zped_status}}
                        <br>{{findPedido.zped_pagado}}
                        <br>{{findPedido.zped_fecha}}
                        <br>{{findPedido.zped_vale}}
                        <br>{{findPedido.zipe_total}}
                        <br>{{findPedido.zped_id_empleado}}
                    <br>-->
                </v-card-text><br>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn outlined color="red" @click="dialog = false">
                        Cancelar
                        <v-icon right dark>mdi-close-circle</v-icon>
                    </v-btn>
                    <v-btn outlined color="success" @click="aceptar()" :disabled="!valid">
                        Aceptar
                        <v-icon right dark>mdi-check-all</v-icon>
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-row>
</template>

<script>
    const axios = require('axios')
    export default {
        props:[
            'article',
            'findPedido',
            'ArticleOld',
        ],
        
        data () {
            return {
                valid: true,
                dialog: false,
                tipo: 'Preferido',
                ocultar: false,
                pMayoreo: false,
                pDescuento: false,
                total: 0,
                totalFinal:0,
                
                findArticle:[],
                ArticleClient:Object,

                cantidad:0,
                decimal:0,
                descuentoStock:0,
                totalNewCompra:0,
            }
        },
        
        created() {
            this.getArticle()
            this.getArticleClient()
            this.cambiarCantidad()
        },
        
        methods:{
            getArticle(){
                axios.get('http://127.0.0.1:8000/pedido/itemped/' + this.article.zipe_id_item_ped + '/')
                .then(res => this.findArticle = res.data)
            },
            getArticleClient(){
                let config = {
                    headers: {
                        Authorization: "Token " + localStorage.token,
                    }
                }
                axios.get('http://127.0.0.1:8000/articulo/admin/' + this.article.zipe_id_arti + '/', config)
                .then(res => this.ArticleClient = res.data)
            },

            update(){
                axios.put('http://127.0.0.1:8000/pedido/itemped/'+this.findArticle.zipe_id_item_ped + '/', this.element)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            updateCab(){
                axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/', this.elementCab)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            updateArtiOld(){
                axios.put('http://127.0.0.1:8000/pedido/itemped/'+this.ArticleOld.zipe_id_item_ped + '/', this.elementOld)
                .then(res =>{
                    this.dialog = false
                    window.location.reload()
                })
            },
            
            aceptar(){ 
                if (this.$refs.form.validate()){
                    this.element = {  
                        "zipe_cant": this.cantidad,
                        "zipe_devo": this.findArticle.zipe_devo,
                        "zipe_sub_tot": this.totalNewCompra,
                        "zipe_status": this.findArticle.zipe_status,
                        "zipe_color": this.findArticle.zipe_color,
                        "zipe_talla": this.findArticle.zipe_talla,
                        "zipe_id_pedido_cab": this.findArticle.zipe_id_pedido_cab,
                        "zipe_id_arti": this.findArticle.zipe_id_arti,
                        "zica_tipo_articulo":this.tipo,
                    },
                    this.elementCab = {
                        "zped_id_usuario": this.findPedido.zped_id_usuario,
                        "zped_nombre": this.findPedido.zped_nombre,
                        "zped_status": this.findPedido.zped_status,
                        "zped_pagado": this.findPedido.zped_pagado,
                        "zped_fecha": this.findPedido.zped_fecha,
                        "zped_vale": this.findPedido.zped_vale,
                        "zipe_total": this.totalFinal,
                        "zped_id_empleado": this.findPedido.zped_id_empleado,
                    },
                    this.elementOld = {
                        "zipe_cant": this.ArticleOld.zipe_cant,
                        "zipe_devo": this.ArticleOld.zipe_devo,
                        "zipe_sub_tot": this.ArticleOld.zipe_sub_tot,
                        "zipe_status": "Intercambio",
                        "zipe_color": this.ArticleOld.zipe_color,
                        "zipe_talla": this.ArticleOld.zipe_talla,
                        "zipe_id_pedido_cab": this.ArticleOld.zipe_id_pedido_cab,
                        "zipe_id_arti": this.ArticleOld.zipe_id_arti,
                        "zica_tipo_articulo":"Intercambio",
                    }
                    this.update()
                    this.updateCab()
                    this.updateArtiOld()
                }
            },
            cambiarCantidad: function () {
                if (this.pMayoreo == true) {
                    this.total = this.ArticleClient.zaa_prect_mayo * this.cantidad
                    if (this.pDescuento == true) {
                        this.decimal = this.ArticleClient.zaa_oferta / 100
                        this.descuentoStock = this.total * this.decimal
                    }else{
                        this.total = this.ArticleClient.zaa_prect_mayo * this.cantidad
                        this.descuentoStock = 0
                    }
                }else{
                    this.total = this.ArticleClient.zaa_prect_menud * this.cantidad
                    if (this.pDescuento == true) {
                        this.decimal = this.ArticleClient.zaa_oferta / 100
                        this.descuentoStock = this.total * this.decimal
                    }else{
                        this.total = this.ArticleClient.zaa_prect_menud * this.cantidad
                        this.descuentoStock = 0
                    }
                }
            },
        }
    }
</script>