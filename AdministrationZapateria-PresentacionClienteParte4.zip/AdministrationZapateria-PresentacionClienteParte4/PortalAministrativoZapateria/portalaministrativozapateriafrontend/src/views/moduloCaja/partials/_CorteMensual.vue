Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo despliega un Dialog (modal) para generar el PDF de un corte mensual.
<template>
    <div>
      <!-- Dialog-->
      <v-dialog v-model="dialog" persistent max-width="600px">
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="info" dark v-bind="attrs" v-on="on" text>
          Reporte mensual
        </v-btn>
      </template>
      <v-card >
          <v-toolbar flat align="center" justify="space-around"  dark>
            <v-toolbar-title>Reporte mensual</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn @click="dialog = false , reporte = false" text >
                Cerrar
            </v-btn>
          </v-toolbar>
          <v-card-text >
              <v-container>
                <v-row align="center">
                    <v-col cols="7">
                    <v-menu ref="menu" v-model="menu03" :close-on-content-click="false" :return-value.sync="corte.fechaMes" offset-y max-width="290px" min-width="auto">
                        <template v-slot:activator="{ on, attrs }">
                            <v-text-field v-model="corte.fechaMes" label="Seleccionar mes y año para el reporte" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"/>
                        </template>
                        <v-date-picker v-model="corte.fechaMes" type="month" no-title scrollable locale="es-mx">
                        
                        <v-btn text color="red" @click="menu03 = false">
                            Cancelar
                        </v-btn>
                        <v-btn text color="green" @click="$refs.menu.save(corte.fechaMes)" >
                            Ok
                        </v-btn>
                        </v-date-picker>
                    </v-menu>
                    </v-col>
                    <v-col cols="5" class="justify-end">
                      <v-row>
                        <v-btn color="green" text @click="filtrar()">Generar</v-btn>
                        <PDF v-if="reporte == true" :corteData="corte"/>
                      </v-row>
                    </v-col>
                </v-row>
              </v-container>
          </v-card-text>
      </v-card>
    </v-dialog>
      <!-- Fin del Dialog-->
    </div>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
import PDF from "../../../components/PdfReporteMensual"
export default {
    components: {
      PDF,
    },
    data() {
       return {
        corte: {
            corteItems: [],  
            fechaMes: new moment().format('YYYY-MM'),
            total: 0,
            fecha: '',
        },
        reporteMes: false,
        dialog: false,
        modal: false,
        menu03: false,
        reporte: false,
        
       }
   },
   methods: {
       filtrar(){
            this.reporte = true
            this.corte.total = 0
            this.corte.fecha = moment(this.corte.fechaMes).locale('es').format('MMMM YYYY'),
            axios.get('http://127.0.0.1:8000/caja/list/')
                .then(res => {
                    let arr = []
                    let fecha = this.corte.fechaMes
                    for (let i = 0; i < res.data.length; i++) {
                        if (moment(res.data[i].zca_fecha).format('YYYY-MM') == moment(fecha).format('YYYY-MM')) {
                            if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
                                //res.data[i].zca_total = '$' + res.data[i].zca_total
                                arr.push(res.data[i])
                                this.corte.total += res.data[i].zca_total
                            }else{
                                //res.data[i].zca_total = '-$' + res.data[i].zca_total
                                arr.push(res.data[i])
                                this.corte.total -= res.data[i].zca_total
                            }
                        }
                    }
                    for (let i = 0; i < res.data.length; i++) {
                        if (moment(res.data[i].zca_fecha).format('YYYY-MM') == moment(fecha).format('YYYY-MM')) {
                            if (res.data[i].zca_tipo == 'Venta' || res.data[i].zca_tipo == 'Depósito') {
                                res.data[i].zca_total = '$' + res.data[i].zca_total
                            }else{
                                res.data[i].zca_total = '-$' + res.data[i].zca_total
                            }
                        }
                    }
                    this.corte.corteItems = arr
                })
       }
   }, 
}
</script>