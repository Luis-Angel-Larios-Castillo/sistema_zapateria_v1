Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra la información de la venta actual 
<template>
  <v-card>
        <v-card-title class="justify-center">
            <div>
                <h3 >Zapatería Deny´s</h3>
            </div>
        </v-card-title>
        <v-card-subtitle class="subtitle-2 text-center black--text">
            Fecha: {{cab.zca_fecha}} - Hora: {{cab.zca_hora}}
            
                <h5>{{cab.zca_nombre}}</h5> 
                <h6>Empleado: {{cab.zca_empleado}}</h6>
        </v-card-subtitle>
      <v-card-text>
            <v-simple-table>
                <template v-slot:default>
                <thead>
                    <tr>
                    <th class="text-left">
                        #
                    </th>
                    <th class="text-left">
                        Articulo
                    </th>
                    <th class="text-left">
                        Precio
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in items" :key="item.zica_id_item_caj">
                        <th>{{item.zica_cant}}</th>
                        <th>{{item.zca_articulo}}</th>
                        <th>${{item.zica_tot}}</th>
                    </tr>
                </tbody>                    
                </template>                    
            </v-simple-table>
            <br>
            <v-divider/>
            <h3 class="black--text d-flex justify-center" >Total: ${{total}}</h3>
            
        </v-card-text>
        <v-card-actions >
            <v-btn color="green" text @click="terminar">Guardar</v-btn>
            <v-btn color="red" text @click="cancelar">Cancelar</v-btn>
        </v-card-actions>  
  </v-card>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'cab'
    ],
    data () {
      return {
          total: 0,
          items: []
    }
    },
    updated() {
        this.buscarItems()
    },
    created() {
       this.buscarItems() 
    },
    methods:{
        terminar(){
            this.items.forEach (function(ele){
                axios.get('http://127.0.0.1:8000/articulo/admin/' + ele.zica_id_arti + '/')
                    .then(res => {
                            axios.put('http://127.0.0.1:8000/articulo/admin/' + ele.zica_id_arti + '/',{
                                zaa_categoria: res.data.zaa_categoria,
                                zaa_id_sucursal: res.data.zaa_id_sucursal,
                                zaa_cantidad: res.data.zaa_cantidad - ele.zica_cant,
                                zaa_clave: res.data.zaa_clave,  
                                zaa_id_subdep: res.data.zaa_id_subdep,
                                zaa_codigo_bar: res.data.zaa_codigo_bar , 
                                zaa_color: res.data.zaa_color , 
                                zaa_existen: res.data.zaa_existen , 
                                zaa_id_articulo: res.data.zaa_id_articulo , 
                                zaa_id_catalogo: res.data.zaa_id_catalogo , 
                                zaa_marca: res.data.zaa_marca ,
                                zaa_modelo: res.data.zaa_modelo , 
                                zaa_nombre_arti: res.data.zaa_nombre_arti ,
                                zaa_prec_cont: res.data.zaa_prec_cont ,
                                zaa_prec_pag: res.data.zaa_prec_pag , 
                                zaa_prect_mayo: res.data.zaa_prect_mayo , 
                                zaa_prect_menud: res.data.zaa_prect_menud , 
                                zaa_talla: res.data.zaa_talla
                            })
                        })
            })
            axios.put('http://127.0.0.1:8000/caja/cabecera/'+ this.cab.zca_id_pedcab + '/', {
                zca_empleado: this.cab.zca_empleado,
                zca_fecha: this.cab.zca_fecha,
                zca_hora: this.cab.zca_hora,
                zca_id_pedcab: this.cab.zca_id_pedcab,
                zca_id_usuario: this.cab.zca_id_usuario,
                zca_nombre: this.cab.zca_nombre,
                zca_tipo: this.cab.zca_tipo,
                zca_total: this.total
            })
            .then(res => this.$router.replace({ path: '/mostrador/' }))
        },
        buscarItems(){
            if(this.cab.zca_nombre != null){
                axios.get('http://127.0.0.1:8000/caja/itemsbycab/?search=' + this.cab.zca_id_pedcab)
                    .then(res => {
                        this.items = res.data
                        let suma = 0 
                        this.items.forEach (function(ele){
                            let num = ele.zica_tot
                            suma += num
                        })
                        this.total = suma
                    })
            }
        },            
        cancelar(){
            this.items.forEach (function(ele){
                axios.delete('http://127.0.0.1:8000/caja/item/' + ele.zica_id_item_caj)
            })
            axios.delete('http://127.0.0.1:8000/caja/cabecera/' + this.cab.zca_id_pedcab )
                .then(res => this.$router.replace({ path: '/mostrador/' }))
                .catch(err => this.$router.replace({ path: '/mostrador/' }))

        }
    },
  }
</script>