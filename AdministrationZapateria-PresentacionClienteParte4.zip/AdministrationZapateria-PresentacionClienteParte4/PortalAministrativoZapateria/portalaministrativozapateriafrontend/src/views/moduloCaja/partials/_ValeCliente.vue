<template>
    <v-container fluid>
        <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
                <v-switch v-model="switchvales" v-if="switchvales==true" inset color="red" label="Usar Vale" style="margin-left:20px"></v-switch>
                <v-switch v-model="switchvales" v-else inset color="red" label="Usar Vale" @click.stop="dialog = true" v-bind="attrs" v-on="on" v-on:click="getVales()" style="margin-left:20px"></v-switch>
            </template>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="700">
            <v-card>
                <v-toolbar dark>
                    <h3>Seleccionar Vale</h3>
                    <v-spacer/>
                    <strong>Importe total en Vales: ${{rowTotal(findPedido.zped_vale)}}</strong>
                </v-toolbar><br>
                <div v-show="false">
                    Id Cliente: {{this.findPedido.zped_id_usuario}}<br>
                </div>
                <v-card-text>
                    <v-data-iterator :items="findVales" :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" hide-default-footer no-results-text="Sin registros encontrados" no-data-text="No se tienen registros de vales.">
                        <template v-slot:header>
                            <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Búscar..."></v-text-field>
                        </template>
                        <template v-slot:default="props">
                            <v-simple-table dense fixed-header height="200">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th class="text-center">Vale</th>
                                        <th class="text-center">Estatus</th>
                                        <th class="text-center">Fecha</th>
                                        <th class="text-center">Importe</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="item in props.items" :key="item.zdv_id_vale" height="50">
                                        <td v-if="item.zdv_estat_vale == true" class="text-center"><v-icon color="blue">mdi-checkbox-marked-circle</v-icon></td>
                                        <td v-else class="text-center"><v-checkbox v-model="selectVale" :value="item.zdv_importe" style="margin-left:10px;" @click="updateitem(item)"/></td>
                                        
                                        <td>{{item.zdv_folio_vale}}</td>
                                        
                                        <td v-if="item.zdv_estat_vale== false" class="red--text text-center">No Cobrado</td>
                                        <td v-else class="green--text text-center">Cobrado</td>
                                        
                                        <td>{{fecha(item.zdv_fech_crea)}}</td>
                                        <td class="text-center">${{item.zdv_importe}}</td>
                                    </tr>
                                    <div v-show="false">{{rowTotal(findPedido.zped_vale)}}<br></div><br>
                                </tbody>
                            </v-simple-table>
                        </template>
                        
                        <template v-slot:footer>
                            <v-row class="mt-2" align="center" justify="center" >
                                <span class="grey--text" style="margin-left:12px;">Elementos por página</span>
                                <v-menu offset-y>
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                                            {{ itemsPerPage }}
                                            <v-icon>mdi-chevron-down</v-icon>
                                        </v-btn>
                                    </template>
                                    <v-list>
                                        <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                                            <v-list-item-title>{{ number }}</v-list-item-title>
                                        </v-list-item>
                                    </v-list>
                                </v-menu>
                                <v-spacer></v-spacer>
                                <span class="mr-4 grey--text">
                                    Página {{ page }} de {{ numberOfPages }}
                                    <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
                                    <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
                                </span>
                            </v-row>
                        </template>
                    </v-data-iterator>
                    <v-btn class="mr-10" color="green" text rounded @click="dialog=false">
                        Aplicar
                        <v-icon right dark>
                            mdi-cloud-upload
                        </v-icon>
                    </v-btn>
                </v-card-text>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script>
    const axios = require('axios')
    const moment = require('moment')
    
    export default {
        props:[
            'findPedido',
        ],
        data(){
            return {
                switchvales:'',
                dialog: false,
                selectVale:[],
                itemsPerPageArray: [4, 12, 24],
                search: '',
                page: 1,
                itemsPerPage: 10,
                keys: [
                    'zdv_folio_vale',
                    'zdv_estat_vale',
                    'zdv_fech_crea',
                    'zdv_importe',
                    'zdv_id_vale',
                ],
                findVales:[],
                totalFinal:0,
                findVales2:[],
                idUser: '',
            }
        },
        created() {
            this.getVales()
            this.findIdUser()
        },
        computed: {
            numberOfPages () {
                return Math.ceil(this.findVales.length / this.itemsPerPage)
            },
        },
        methods: {
            getVales(){
                axios.get('http://127.0.0.1:8000/vale/?search=' + this.findPedido.zped_id_usuario)
                .then(res => this.findVales = res.data)
            },
            fecha(date){
                return moment(date).locale('MX').format('DD-MM-YYYY LT')
            },
            rowTotal(totalVale) {
                this.totalFinal = (totalVale) + (this.selectVale.reduce((sum,cur) => sum+cur , 0))
                this.$emit("getDataVales", this.totalFinal);
                return this.totalFinal
            },
            updateCab(){
                axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.findPedido.zped_id_pedcab + '/',{
                    "zped_id_usuario": this.findPedido.zped_id_usuario,
                    "zped_nombre": this.findPedido.zped_nombre,
                    "zped_status": this.findPedido.zped_status,
                    "zped_pagado": this.findPedido.zped_pagado,
                    "zped_fecha": this.findPedido.zped_fecha,
                    "zped_vale": this.totalFinal,
                    "zipe_total": this.findPedido.zipe_total,
                    "zped_is_afi": this.findPedido.zped_is_afi,
                    "zped_id_empleado": this.findPedido.zped_id_empleado,
                    "zped_id_sucursal": this.findPedido.zped_id_sucursal,
                })
            },
            updateitem(m){
                axios.get('http://127.0.0.1:8000/vale/'+m.zdv_id_vale+'/')
                .then(res => {this.findVales2 = res.data
                //console.log(this.findVales2.zdv_estat_vale)
                
                if(this.findVales2.zdv_estat_vale == false){
                    const URL = 'http://127.0.0.1:8000/vale/'+m.zdv_id_vale+'/'
                    axios.put(URL,{
                        "zdv_id_cliente": m.zdv_id_cliente,
                        "zdv_id_user_autori": m.zdv_id_user_autori,
                        "zdv_id_user_qcobra_vale": this.idUser,
                        "zdv_folio_vale": m.zdv_folio_vale,
                        "zdv_estat_vale": true,
                        //"zdv_fecha_cobro": m.zdv_fecha_cobro,
                        "zdv_fecha_cobro": moment().format('YYYY-MM-DD'),
                        "zdv_importe": m.zdv_importe,
                        "zdv_id_pedcab": m.zdv_id_pedcab,
                        "zdv_id_empleado": m.zdv_id_empleado,
                        "zdv_id_item_ped": m.zdv_id_item_ped,
                        "zdv_id_sucursal": m.zdv_id_sucursal,
                    })
                }
                else if(this.findVales2.zdv_estat_vale == true){
                    const URL = 'http://127.0.0.1:8000/vale/'+m.zdv_id_vale+'/'
                    axios.put(URL,{
                        "zdv_id_cliente": m.zdv_id_cliente,
                        "zdv_id_user_autori": m.zdv_id_user_autori,
                        "zdv_id_user_qcobra_vale": 'No cobrado aún',
                        "zdv_folio_vale": m.zdv_folio_vale,
                        "zdv_estat_vale": false,
                        "zdv_fecha_cobro": null,
                        "zdv_importe": m.zdv_importe,
                        "zdv_id_pedcab": m.zdv_id_pedcab,
                        "zdv_id_empleado": m.zdv_id_empleado,
                        "zdv_id_item_ped": m.zdv_id_item_ped,
                        "zdv_id_sucursal": m.zdv_id_sucursal,
                    })
                }
                else{
                    //console.log("Todo bien")
                }
                //console.log(this.findArticles2.zipe_status)
                this.updateCab()
                })
            },
            findIdUser(){
                const userToken = localStorage.token
                axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
                .then(res => this.idUser = res.data.user)
                //.then(res=> console.log(res.data))
            },
            nextPage () {
                if (this.page + 1 <= this.numberOfPages) this.page += 1
            },
            formerPage () {
                if (this.page - 1 >= 1) this.page -= 1
            },
            updateItemsPerPage (number) {
                this.itemsPerPage = number
            },
        },
    }
</script>