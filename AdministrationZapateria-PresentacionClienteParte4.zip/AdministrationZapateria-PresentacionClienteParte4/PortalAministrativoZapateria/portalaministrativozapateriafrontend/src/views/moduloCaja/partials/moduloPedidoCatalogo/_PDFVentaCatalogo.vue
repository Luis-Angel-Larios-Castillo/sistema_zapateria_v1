<template>
  <v-container>
    <v-overlay :value="overlay">
      <v-progress-circular :size="70" :width="7" indeterminate/>    
    </v-overlay>
    
    <v-row style="margin-top:-35px;">
      <div v-show="false">{{this.total_final = parseInt(this.pedcabcatdata.zpdcat_total) - (parseInt(this.pedcabcatdata.zpdcat_pagado) + parseInt(this.abono))}}</div>
      
      <div v-show="false" v-if="pedcabcatdata.zpdcat_total == 0">{{this.pagado = 0}}</div>
      <div v-show="false" v-else>{{this.pagado = parseInt(this.pedcabcatdata.zpdcat_pagado) + parseInt(this.abono)}}</div>

      <v-col>
        <v-alert dense text class="text-center" color="green" v-if="pedcabcatdata.zpdcat_pagado == pedcabcatdata.zpdcat_total" type="info">
          <strong style="margin-left:-35px">CUENTA PAGADA</strong>
        </v-alert>
      </v-col>
    </v-row>
    <v-tooltip bottom>
      <template v-slot:activator="{ on, attrs }">
        <v-btn color="orange" outlined v-bind="attrs" v-on="on" rounded block v-on:click=" updateCabCat(), findcliente(pedcabcatdata.zpdcat_id_usuario)">
          Generar Ticket
        </v-btn>
      </template>
      <span>Generar Ticket</span>
    </v-tooltip>
  </v-container>
</template> 

<script>
  import moment from 'moment'
  import jsPDF from "jspdf"; 
  const axios = require('axios')
  
  export default {
    data(){
      return {
        total_final: 0,
        busqnomcli: [],
        busqnomempl: [],
        import_acum: "",
        restant: "",
        total_compra: "",
        abonoimport: "",
        imgData: require('@/assets/logoSneaker.jpg'),
        overlay: false,
      }
    },
    
    props:[
      'pedcabcatdata',
      'abono'
    ],
    
    watch: {
      overlay (val) {
        val && setTimeout(() => {
          this.overlay = false
        }, 2000)
      },
    },
    
    methods: {
      generatePDF() {
        this.import_acum = "$" + this.pedcabcatdata.zpdcat_pagado;
        this.restant = "$" + this.total_final;
        this.total_compra = "$" + this.pedcabcatdata.zpdcat_total;
        this.abonoimport = "$" + this.abono;
        var imgLogo = this.imgData

        var doc = new jsPDF({
            orientation: "portrait",
            unit: "in",
            format: "letter",
        });

        let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth(); 
        doc.setFont(undefined, 'bold').setFontSize(40).text("Zapatería Deny´s", pageWidth / 2, 1.0, {align: 'center'}); 
        doc.setFont(undefined, 'bold').setFontSize(35).text("CALZADO POR CATALOGO", pageWidth / 2, 1.7, {align: 'center'});
        doc.setLineWidth(0.05).line(0.5, 1.8, 8, 1.8); 
        doc.setFont(undefined, 'bold').setFontSize(30).text("Folio de pedido", pageWidth / 2, 2.4, {align: 'center'});
        doc.setDrawColor(0);
        doc.setFillColor(255, 255, 255);
        //Sección de Nombre de Pedido
        doc.setLineWidth(0.05).roundedRect(1.25, 2.6,    6,      0.75,    .3, .3, "FD");
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.pedcabcatdata.zpdcat_nombre, pageWidth / 2, 3.1,  {align: 'center'});
        //Sección de Fecha
        doc.setFont(undefined, 'bold').setFontSize(30).text("Fecha: "+ this.pedcabcatdata.zpdcat_fecha, pageWidth / 2, 3.8,  {align: 'center'});
        //Sección de Cliente 
        doc.setFont(undefined, 'bold').setFontSize(30).text("Cliente: ", pageWidth / 2, 4.4,  {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.busqnomcli.nombre, pageWidth / 2, 5,  {align: 'center'}); 
        //Sección Folio de Cliente
        doc.setFont(undefined, 'bold').setFontSize(30).text("Folio de cliente", pageWidth / 2, 5.6,  {align: 'center'}); 
        doc.setDrawColor(0);
        doc.setFillColor(255, 255, 255);
        //Sección de folio de cliente
        doc.setLineWidth(0.05).roundedRect(1.25, 5.8,    6,      0.75,    .3, .3, "FD");
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.busqnomcli.zc_folio_client, pageWidth / 2, 6.3,  {align: 'center'}); 
        //Sección atendido por
        doc.setFont(undefined, 'bold').setFontSize(30).text("Atendido por", pageWidth / 2, 6.9,  {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(30).text(this.busqnomempl.nombre, pageWidth / 2, 7.4,  {align: 'center'});  
        //Sección de importes
        doc.line(0.5, 7.5, 8, 7.5); // horizontal line


        if(this.pedcabcatdata.zpdcat_total == 0){
          doc.setFont(undefined, 'bold').setFontSize(30).text("Importe Acumulado: $0", pageWidth /2, 8.1,  {align: 'center'});
          doc.setFont(undefined, 'bold').setFontSize(30).text("Efectivo: $0", pageWidth /2, 8.7,  {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(30).text("Restante: $0", pageWidth /2, 9.3,  {align: 'center'});  
          doc.setFont(undefined, 'bold').setFontSize(30).text("TOTAL DE COMPRA: $0", pageWidth /2, 9.9,  {align: 'center'});
        }else{
          doc.setFont(undefined, 'bold').setFontSize(30).text("Importe Acumulado: " + this.import_acum, pageWidth /2, 8.1,  {align: 'center'});
          doc.setFont(undefined, 'bold').setFontSize(30).text("Efectivo: " + this.abonoimport, pageWidth /2, 8.7,  {align: 'center'}); 
          doc.setFont(undefined, 'bold').setFontSize(30).text("Restante: " + this.restant, pageWidth /2, 9.3,  {align: 'center'});  
          doc.setFont(undefined, 'bold').setFontSize(30).text("TOTAL DE COMPRA: " + this.total_compra, pageWidth /2, 9.9,  {align: 'center'});
        }

        doc.autoPrint();
        doc.output('dataurlnewwindow');
      },
      
      findcliente(id_cli) {
        axios.get("http://127.0.0.1:8000/cliente/clientes/?search=" + id_cli)
        .then((res) => {
          this.busqnomcli = res.data[0];
          this.findempl(this.pedcabcatdata.zpdcat_id_empleado);
        });
      },
      
      findempl(id_empl) {
        axios.get("http://127.0.0.1:8000/empleado/?search=" + id_empl)
        .then((res) => {
          this.busqnomempl = res.data[0];
          this.generatePDF();
        });
      },
      
      updateCabCat() {
        axios.put("http://127.0.0.1:8000/pedido/pedcabcat/" + this.pedcabcatdata.zpdcat_id_pedcabcat +"/",{
          zpdcat_id_usuario: this.pedcabcatdata.zpdcat_id_usuario,
          zpdcat_nombre: this.pedcabcatdata.zpdcat_nombre,
          zpdcat_status: this.pedcabcatdata.zpdcat_status,
          zpdcat_pagado: this.pagado,
          zpdcat_fecha: this.pedcabcatdata.zpdcat_fecha,
          zpdcat_total: this.pedcabcatdata.zpdcat_total,
          zpdcat_id_empleado: this.pedcabcatdata.zpdcat_id_empleado,
        })
        .then((res) => {
          this.$emit('pedido', res.data)
          this.overlay = true
        })
        .catch((error) => console.log(error));
        this.newVenta()
      },
      newVenta(){
        if(this.abono > 0){
          let venta = {
            zca_nombre: 'VENTA-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
            zca_tipo: 'Venta',
            zca_concepto: this.pedcabcatdata.zpdcat_nombre,
            zca_fecha: moment().locale('MX').format('YYYY-MM-DD'),
            zca_hora: moment(new Date()).format('H:mm '),
            zca_total: this.abono,
            zca_id_usuario: this.pedcabcatdata.zpdcat_id_empleado
          }
          axios.post('http://127.0.0.1:8000/caja/cabecera/', venta)
          this.overlay = true
        }else{
          this.overlay = true
        }
      }
    },
  }
</script>