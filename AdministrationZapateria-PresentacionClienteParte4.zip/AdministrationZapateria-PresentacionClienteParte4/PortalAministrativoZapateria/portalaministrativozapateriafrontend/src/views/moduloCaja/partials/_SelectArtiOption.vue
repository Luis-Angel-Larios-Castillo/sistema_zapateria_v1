<template>
    <v-container fluid>
        <v-tooltip bottom>
            <template v-slot:activator="{ on, attrs }">
                <v-btn icon color="orange" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
                    <v-icon >mdi-cached</v-icon>
                </v-btn>
            </template>
            <span>Intercambiar</span>
        </v-tooltip>
        <v-dialog v-model="dialog" max-width="650">
            <v-card>
                <v-toolbar dark>
                    <h3>Seleccionar Artículo</h3>
                </v-toolbar>
                <v-alert dense text color="green">
                    <strong>Artículos Opcionales<br></strong>
                </v-alert>
                <div v-show="false">
                    Id Cabecera: {{this.findPedido.zped_id_pedcab}}<br>
                </div>
                <div class="col-12" id="table_cabecera_color">
                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                </div>
                <v-data-table
                    class="col-10"
                    :headers="headers" 
                    :items="findArticles"
                    :search="search"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen registros." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }">
                    <template v-slot:item.zaa_id_articulo="{ item }">
                        <AddArticuloOptPed :article="item" :findPedido="findPedido" :ArticleOld="findArticle"/>
                    </template>
                </v-data-table><br>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script>
    import AddArticuloOptPed from './_AddArticuloOptPed.vue'
    const axios = require('axios')
    
    export default {
        props:[
            'findPedido',
            'findArticle'
        ],

        components:{
            AddArticuloOptPed,
        },

        data(){
            return {
                dialog: false,
                findArticles:[],
                search: '',
                headers: [
                    { text: 'Artículos', align: 'start', filterable: true, value: 'zipe_nombre', sortable: true},
                    { text: 'Módelo', value: 'zipe_modelo', sortable: true },
                    { text: 'Marca', value: 'zipe_marca', sortable: true },
                    { text: 'Color', value: 'zipe_color', sortable: true },
                    { text: 'Talla', value: 'zipe_talla', sortable: true },
                    { text: 'Detalles', value: 'zaa_id_articulo', sortable: false },
                ],
            }
        },
        created() {
            this.getArticles()
        },
        /*updated() {
            this.getArticles()
        },*/
        methods: {
            getArticles(){
                axios.get('http://127.0.0.1:8000/pedido/itempedopc/?search=' + this.findPedido.zped_id_pedcab)
                .then(res => this.findArticles = res.data)
            },
        },
    }
</script>