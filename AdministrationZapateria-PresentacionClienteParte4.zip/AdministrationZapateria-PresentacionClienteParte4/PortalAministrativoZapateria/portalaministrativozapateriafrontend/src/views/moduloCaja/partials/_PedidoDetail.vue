<template>
    <v-card>
        <v-card-title class="justify-center">
            <div>
                <h3 >Zapatería Deny´s</h3>
            </div>
        </v-card-title>
        <v-card-subtitle class="subtitle-2 text-center black--text">
            <h3>Fecha: {{cab.zped_fecha}} </h3>  
            <h3>{{cab.zped_nombre}}</h3>
            <div v-for="cli in cliente" :key="cli.id">
                <h4>Cliente: {{cli.nombre}}</h4>
            </div>
            <h4>Empleado: {{empleado}}</h4>
        </v-card-subtitle> 
        <v-card-text>
            <v-simple-table>
                <template v-slot:default>
                <thead>
                    <tr>
                    <th class="text-left">
                        #
                    </th>
                    <th class="text-left">
                        Modelo
                    </th>
                    <th class="text-left">
                        Color
                    </th>
                    <th class="text-left">
                        Talla
                    </th>
                    <th class="text-left">
                        Precio
                    </th>
                    <th class="text-center">
                        Tipo
                    </th>
                    <th class="text-center">
                        <v-icon>mdi-delete-outline</v-icon>
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in items" :key="item.zica_id_item_caj">
                        <th>{{item.zipe_cant}}</th>
                        <th>{{item.zipe_modelo}}</th>
                        <th>
                            <v-select v-on:change="cambiarColor(item)" :items="item.zipe_colores" v-model="item.zipe_color" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']" required/>
                        </th>
                        <th>
                            <v-select v-on:change="cambiarTalla(item)" :items="item.zipe_tallas" v-model="item.zipe_talla" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar una talla']" width="50px" required/>
                        </th>
                        <th>${{item.zipe_sub_tot}}</th>
                            <th class="green--text" v-if="item.zica_tipo_articulo == 'Preferido'">{{item.zica_tipo_articulo}}</th>
                            <th class="blue--text" v-else>{{item.zica_tipo_articulo}}</th>
                        <th>
                            <v-btn icon color="error" @click="eliminar(item)">
                                <v-icon>mdi-delete-outline</v-icon>
                            </v-btn>
                        </th>
                    </tr>
                </tbody>                    
                </template>                    
            </v-simple-table> 
        </v-card-text>  
        <v-card-text class="black--text">
            <v-divider/>
            <br>
            <v-row> 
                <v-text-field v-model="cab.zped_pagado" label="Anticipo"/> 
                <v-btn text @click="anticipo()" color="success">Guardar anticipo</v-btn>
                <v-spacer/>
            </v-row>
            <br>
            <h2 class=" ">Total: ${{total}}</h2>
            <h2 class=" " v-if="noShowVales == false">Vales: ${{vale}}</h2>
            <h2 class=" ">Restante: ${{restante}}</h2>
        </v-card-text>
        <v-card-actions>
            <v-btn text color="error" @click="cancelar()" >Eliminar</v-btn> 

            <v-btn text color="success" @click.stop="dialogSave = true" v-if="totalitems <= 0">Guardar</v-btn>
            <v-btn text color="success" @click="guardar()" v-else>Guardar</v-btn> 
        </v-card-actions>

        <v-dialog v-model="dialogSave" max-width="410">
            <v-card>
                <v-card-title class="text-h5">
                </v-card-title>
                <v-alert dense text color="warning" type="info">
                    <strong>No se puede guardar este pedido</strong>
                </v-alert>
                <v-divider></v-divider>
                <v-card-text><br>
                    <v-alert class="col-12" dense outlined type="error">No se encuentra con articulos relacionados</v-alert>
                </v-card-text>
                <v-divider></v-divider>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" text @click="dialogSave = false">
                        Aceptar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-card>
</template>
<script>
import moment from 'moment'
const axios = require('axios')
export default {
    props:[
        'cab',
        'cliente',
        'empleado',
        'vale',
        'noShowVales'
    ],
    data () {
      return {
        dialogSave:false,
        model: null,
        total: 0,
        items: [],  
        restante: 0,  
        total: 0, 
        anticipos: [],
        totalitems:0,
    }
    }, 
    created() {   
        this.findItems()  
        this.anticipo() 
    },   
    updated() {   
        this.findItems()   
    },   
    methods:{
        anticipo(){  
            let rest = this.total-this.vale 
            if(this.cab.length != 0){
                if(this.cab.zped_pagado == ''){
                    this.cab.zped_pagado = 0 
                    axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab )
                     
                }else{
                    if(this.cab.zped_pagado < 0){
                        this.cab.zped_pagado = 0 
                        axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab )
                    
                    }else{
                        if(this.cab.zped_pagado<=rest){ 
                            axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab )
                        }else{ 
                            this.cab.zped_pagado = rest
                            axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab )
                        }
                    }
                    
                } 
            }
            

        },
        eliminar(itemPed){
            axios.delete('http://127.0.0.1:8000/pedido/itemped/'+ itemPed.zipe_id_item_ped +'/')
                .then(res => window.location.reload() )
        },
        cambiarColor: function (event) {  
            axios.put('http://127.0.0.1:8000/pedido/itemped/'+ event.zipe_id_item_ped+'/', event)  
        },
        cambiarTalla: function (event) {  
            axios.put('http://127.0.0.1:8000/pedido/itemped/'+ event.zipe_id_item_ped+'/', event)  
        },
        findItems(){ 
            axios.get('http://127.0.0.1:8000/pedido/itempedpre/?search=' + this.cab.zped_id_pedcab )
            //axios.get('http://127.0.0.1:8000/pedido/itemped/?search=' + this.cab.zped_id_pedcab )
                .then(res => {
                    let total = 0
                    this.totalitems = res.data.length
                    this.items = res.data
                    res.data.forEach(element => {
                        total += element.zipe_sub_tot
                    });
                    this.total = total 
                    
                    this.restante = this.total - this.vale - this.cab.zped_pagado  
                })
        },
        guardar(){  
            this.cab.zped_vale = this.vale  
            this.cab.zipe_total = this.total   
            axios.put('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/', this.cab )
                .then(res =>{
                    // Condicion para si se registra un anticipo se cree un registro paralos graficos
                    if(res.data.zped_pagado > 0){
                        let transaccion = {
                            zca_nombre: 'VENTA-' + new Date().toISOString().slice(2,10) + '-' + moment(new Date()).format('H:mm '),
                            zca_tipo: 'Venta',
                            zca_concepto: res.data.zped_nombre,
                            zca_fecha: moment().locale('MX').format('YYYY-MM-DD'),
                            zca_hora: moment(new Date()).format('H:mm '),
                            zca_total: res.data.zped_pagado,
                            zca_id_usuario: res.data.zped_id_empleado
                        } 
                        axios.post('http://127.0.0.1:8000/caja/cabecera/', transaccion)
                        .then(resCaja => {
                            this.$router.replace({ path: '/ventasClientesAfi/' }) 
                        })
                    } else {
                        this.$router.replace({ path: '/ventasClientesAfi/' }) 
                    } 
                } )     
        },
        cancelar(){
            axios.get('http://127.0.0.1:8000/pedido/itemped/?search=' + this.cab.zped_id_pedcab )
                .then(resItems => {
                    resItems.data.forEach(item => {
                        axios.delete('http://127.0.0.1:8000/pedido/itemped/' + item.zipe_id_item_ped + '/' )
                    });
                    axios.delete('http://127.0.0.1:8000/pedido/pedcab/' + this.cab.zped_id_pedcab + '/' )
                        .then(res=>{ 
                            this.$router.replace({ path: '/ventasClientesAfi/' })
                        })
                })
        },
    },
  }
</script>0