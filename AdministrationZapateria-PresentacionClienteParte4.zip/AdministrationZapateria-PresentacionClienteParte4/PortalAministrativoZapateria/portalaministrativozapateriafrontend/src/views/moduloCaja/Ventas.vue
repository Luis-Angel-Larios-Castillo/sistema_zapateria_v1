Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz que muestra un listado de todas las ventas 
<template>
    <v-container fluid>
        <app-header style="z-index: 135"/> 
        <div class="hr-sect"><h2>Historial de ventas</h2></div>
            
        <v-row>
            <v-col cols="md-9 xs-12">
                <v-card>
                    <v-card-title>
                        <v-text-field v-model="search" append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    </v-card-title>
                    <v-data-table 
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen transacciones registradas." 
                        :headers="headers" 
                        :search="search" 
                        :items="items" 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }"
                    >
                        <template v-slot:item.zca_total="{ item }"  >
                            ${{item.zca_total}}
                        </template>
                        <template v-slot:item.zca_id_pedcab="{ item }"  >
                            <v-btn icon @click="detail(item.zca_id_pedcab), select = true" justify-center> 
                                <v-icon color="green">mdi-eye-outline</v-icon>
                            </v-btn>
                        </template>
                    </v-data-table>
                </v-card>
            </v-col>
            <v-col cols="md-3 xs-12">
                <v-card height="100%" v-if="select == false" >
                    <v-container fill-height  justify-center>
                        <h3>No se ha seleccionado ninguna venta.</h3>
                    </v-container>
                        
                </v-card>
                <v-card height="100%" v-else>
                    <v-card-title class="justify-center">
                        <div>
                            <h3 >Zapatería Deny´s</h3>
                        </div>
                    </v-card-title>
                    <v-card-subtitle class="subtitle-2 text-center black--text">
                        Fecha: {{cab.zca_fecha}} <br>
                        Hora: {{cab.zca_hora}}
                        
                            <h5>{{cab.zca_nombre}}</h5> 
                            <h5>Empleado: {{emp.nombre}}</h5> 
                    </v-card-subtitle>
                    <v-card-text class="justify-center"> 
                        <!--
                        <v-simple-table>
                            <template v-slot:default>
                            <thead>
                                <tr>
                                <th class="text-left">
                                    #
                                </th>
                                <th class="text-left">
                                    Articulo
                                </th>
                                <th class="text-left">
                                    Precio
                                </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in itemsDetail" :key="item.zica_id_item_caj">
                                    <th>{{item.zica_cant}}</th>
                                    <th>{{item.zca_articulo}}</th>
                                    <th>${{item.zica_tot}}</th>
                                </tr>
                            </tbody>                    
                            </template>                    
                        </v-simple-table>
                        --> 
                        <v-divider/>
                            <h3 class="black--text d-flex justify-center" >Total: ${{cab.zca_total}}</h3>
                    </v-card-text>
                </v-card>
            </v-col>
        </v-row>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        },
    created() {
        this.getTrans()
        window.document.title = 'Historial de ventas'        
    },
    data() {
        return {
            emp: [],
            select: false,
            search: '',
            headers: [
                {
                    text: 'Transacción',
                    align: 'start',
                    value: 'zca_nombre',
                },
                 
                { text: 'Empleado', value: 'zca_empleado' },
                { text: 'Fecha', value: 'zca_fecha' },
                { text: 'Hora', value: 'zca_hora' },
                { text: 'Tipo', value: 'zca_tipo' },
                { text: 'Total final', value: 'zca_total' },
                { text: 'Seleccionar', value: 'zca_id_pedcab', sortable: false },
            ],
            items: [],
            itemsDetail: Object,
            cab: Object
        }
    },
    methods: {
        getTrans(){
            axios.get('http://127.0.0.1:8000/caja/listventas/')
                .then(res => this.items = res.data)
        },
        detail(id){ 
            axios.get('http://127.0.0.1:8000/caja/listventas/'+ id)
                .then(res => {
                    this.cab = res.data
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + res.data.zca_id_usuario)
                    .then(resEmp => { 
                        this.emp = resEmp.data[0]
                    })
                })
        }    
    },
}
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>