<!--Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los clientes no afiliados que se han dado de alta a traves del formulario de registro-->

<template>
<div fluid>
    <v-row>
      <v-col cols="md-2 xs-12">
        <menuModulos/>
      </v-col>
      
      <v-col cols="md-10 xs-12">
         <app-header style="z-index: 135"/> 
        <div align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">CLIENTES NO AFILIADOS</h1>
        </div><br>
        
        <v-card :elevation="0">
          <v-card-title class="card_title">
            <div class="col-12" id="table_cabecera_color">
              <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
            </div>
          </v-card-title>
          
          <div class="col-12" style="padding-top:0">
            <v-data-table
            
              id="tabla_datos"
              :headers="headers" 
              :items="elements"
              :search="search"
              no-results-text="Sin registros"
              no-data-text="No se tienen registros de clientes no afiliados."
              :footer-props="{
                showFirstLastPage: true,
                itemsPerPageText: 'Elementos por página ',
                
              }"> 
                <template v-slot:item.nombre="{ item }"> 
                  <DetalleClienteNoAfi :element="item"/>
                </template> 
                <template v-slot:item.zc_folio_client="{ item }"> 
                  <strong>{{item.zc_folio_client}}</strong>
                </template> 
            </v-data-table>
          </div>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios') 
  import menuModulos from '../menuModulos'  
  import Header from '../../components/Header'; 
  import DetalleClienteNoAfi from './DetallesClienteNoAfi.vue'
  export default {
    name: 'Header', 
    components:{
      "app-header": Header,
      menuModulos, 
      DetalleClienteNoAfi
    }, 
    created(){
      this.find()
    },
    
    data(){
      return{
        element:Object,
        search: '',
        headers: [
          { text: 'Nombre', align: 'start', value: 'nombre', sortable: true},
          { text: 'Folio', value: 'zc_folio_client', sortable: true, filterable: true, align:'center'},
          { text: 'Número de celular', value: 'zc_num_cell', sortable: false, align:'center'},
          { text: 'Número telefónico', value: 'zc_num_telefono', sortable: false, align:'center'}, 
        ],
        elements: [],
        permissions: {
            can_manage_cli_afi: false,
            //can_manage_cli_afi_hist:false,
        },
      }
    },
    
    methods: {
      find(){ 
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
        .then(resUser => { 
          axios.get('http://127.0.0.1:8000/empleado/?search=' + resUser.data[0].user)
          .then(resEmp => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + resUser.data[0].user + '/')
            .then(resGetData=> {  
              axios.get('http://127.0.0.1:8000/clientes/' )
              .then(res => this.elements = res.data) 
            }) 
          })
        }) 
      }, 
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      }, 
    },
    
  }
</script>