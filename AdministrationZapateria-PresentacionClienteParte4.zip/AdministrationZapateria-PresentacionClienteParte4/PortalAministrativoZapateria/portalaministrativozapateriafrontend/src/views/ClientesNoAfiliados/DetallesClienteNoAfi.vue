Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra los detalles de los datos del cliente no afiliado.

<template>
    <v-container grid-list-xs>
      <v-dialog  max-width="500">
        <template v-slot:activator="{ on, attrs }"> 
            <strong v-bind="attrs" v-on="on" class="gray--text">{{element.nombre}}</strong>  
        </template>
        <v-card> 
          <v-toolbar dark style="background-color:#14213d; font-weight: bold; font-size: 20px;">
            {{element.nombre}} - {{element.zc_folio_client}}  
          </v-toolbar>
          <v-card-text class="black--text" style="font-size: 15px;"> 
            <strong>Folio: </strong>{{element.zc_folio_client}}<br>
            <strong>Número de celular: </strong>{{element.zc_num_cell}}<br>
            <strong>Número telefónico: </strong>{{element.zc_num_telefono}}<br>
            <strong>Dirección: </strong>{{element.zc_direccion}}<br> 
          </v-card-text>
        </v-card>
      </v-dialog>
    </v-container>
</template>
<script> 
export default {
    props:[
        'element'
    ],
    created() {  
    },
    data(){
      return { 
      };
    }, 
  }
</script>