Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra la actualización de los datos del cliente no afiliado.


<template>

<div>
<br><br>
<center><h2 class="title">ACTUALIZAR</h2></center>
<br>
<v-divider></v-divider>
  <v-form style="max-width: 800px" class="mt-5"
    ref="form"
    v-model="valid"
    lazy-validation
  >
    <v-text-field
      v-model="actualizar.zc_nombre"
      :rules="nameRules"
      label="Nombre:"
      required
    ></v-text-field>

    <v-text-field
      v-model="actualizar.zc_apell_pat"
      :rules="apepRules"
      label="Apellido Paterno:"
      required
    ></v-text-field>

    <v-text-field
      v-model="actualizar.zc_apell_mat"
      :rules="apemRules"
      label="Apellido Materno:"
      required
    ></v-text-field>


     <v-text-field
      v-model="actualizar.zc_num_cell"
      :rules="telcRules"
      label="Número de celular:"
      required
    ></v-text-field>

    

<br>



<v-btn
       
        color="#9E9E9E"
        class="mr-6"
        type="submit"
        @click="validate" 
        :disabled="!valid"
      >
        Guardar
<v-icon
        right
        dark
      >
        mdi-cloud-upload
      </v-icon>
  
      </v-btn>

      <v-btn>
<router-link to="/clientesNoAfi"


        exact tag="button"
        color="#9E9E9E"
        class="mr-5"
      
      >
        SALIR
<v-icon
    right
        dark
      
      >
         mdi-minus-circle
      </v-icon>

</router-link>
</v-btn>
   <br>
   <br>
   
  </v-form>
  </div>
</template>

<script>
import axios from "axios";
  export default {
    created() {
      this.buscar()
    },
    data: () => ({
      actualizar:[],
      cliente:[],
      valid: true,

      nameRules: [
        v => !!v || 'Se requiere el nombre.',
      
      ],

      valid: true,
      apepRules: [
        v => !!v || 'Se requiere el apellido paterno.',
    
      ],

      valid: true,
      apemRules: [
        v => !!v || 'Se requiere el apellido materno.',
      ],

      
     

      telcRules: [
        v => !!v || 'Se requiere el número de celular.',
      ],
    

      
    }),
     methods: {
      buscar(){
          axios.get('http://127.0.0.1:8000/clientes/'+ this.$route.params.id +'/')
          .then(res => this.actualizar = res.data)
      },
      validate(){
        this.cliente={
          zc_nombre:this.actualizar.zc_nombre,
          zc_apell_pat:this.actualizar.zc_apell_pat,
          zc_apell_mat:this.actualizar.zc_apell_mat,
          zc_num_cell:this.actualizar.zc_num_cell,
          zc_existen :this.actualizar.zc_existen, 
        }
        this.$refs.form.validate()
        this.submit()
      },
      reset () {
        this.$refs.form.reset()
      },
        submit () {
          axios.put('http://127.0.0.1:8000/clientes/'+ this.$route.params.id +'/',this.cliente)
          then(res =>console.log(res))
         .catch(error => console.log(error));
      
          
          
      }
    }
  }

</script>



