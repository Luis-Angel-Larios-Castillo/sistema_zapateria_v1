Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el formulario para el registro de los datos de los clientes no afiliados.


<template>

<div>
<br><br>
<center><h2 class="title">REGISTRO DE CLIENTES NO AFILIADOS</h2></center>
<br>
<v-divider></v-divider>
  <v-form style="max-width: 800px" class="mt-5"
    ref="form"
    v-model="valid"
    lazy-validation
  >
    <v-text-field
      v-model="name"
      :rules="nameRules"
      label="Nombre:"
      required
    ></v-text-field>

    <v-text-field
      v-model="apep"
      :rules="apepRules"
      label="Apellido Paterno:"
      required
    ></v-text-field>

    <v-text-field
      v-model="apem"
      :rules="apemRules"
      label="Apellido Materno:"
      required
    ></v-text-field>

     <v-text-field
      v-model="telc"
      :rules="telcRules"
      label="Número de Celular:"
      required
    ></v-text-field>
    


<br>


    <v-btn
      color="#9E9E9E"
      class="mr-6"
      @click="reset"
    >
      Limpiar Formulario
    </v-btn>

<v-btn
        
      
        color="#9E9E9E"
        class="mr-6"
        type="submit"
        @click="validate" 
        :disabled="!valid"
      >
        Guardar
<v-icon
        right
        dark
      >
        mdi-cloud-upload
      </v-icon>
      </v-btn>
   <br>
   <br>
  </v-form>
  
  </div>
</template>

<script>
const axios = require('axios')
  export default {

    data: () => ({
      clientes:[], 

      valid: true,  
      


      
      name:'',
      nameRules: [
        v => !!v || 'Se requiere el nombre.',
      
      ],

      valid: true,
      apep:'',
      apepRules: [
        v => !!v || 'Se requiere el apellido paterno.',
    
      ],

      valid: true,
      apem:'',
      apemRules: [
        v => !!v || 'Se requiere el apellido materno.',
    
      ],

      valid: true,
      telc: '',
      telcRules: [
        v => !!v || 'Se requiere el número de celular.',

      ],
  
    }),


     methods: {
      validate(){
        this.clientes={ 
          zc_nombre:this.name,
          zc_apell_pat:this.apep,
          zc_apell_mat:this.apem,
          zc_num_cell:this.telc,

   
        }
        this.$refs.form.validate()
        this.submit()

      },


      reset () {
        this.$refs.form.reset()
      
      },
      submit () {
        axios.post('http://127.0.0.1:8000/clientes/',this.clientes)
    
       .then(res =>console.log(res))
       .catch(error => console.log(error));
     
       
      }
     

    },
  }

</script>

