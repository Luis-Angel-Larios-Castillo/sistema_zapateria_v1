Autor: Elisa Huerta Corona.
Descripción: El presente archivo es para eliminar el cliente no afiliado.

<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="#5B5B5B" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
            <v-icon >mdi-delete</v-icon>
          </v-btn>
        </template>
        <span>Eliminar</span>
    </v-tooltip>
    <v-dialog v-model="dialog" max-width="250">
      <v-card>
        <v-card-title class="gray--text">
          Se va a eliminar el cliente: {{elementD.zc_nombre}}
        </v-card-title>

        <v-card-text>
          ¿Está de acuerdo en eliminarlo?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="gray darken-1" text @click="dialog = false">
            Cancelar 
          </v-btn>

          <v-btn color="gray darken-1" text @click="aceptar()">
            Aceptar 
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>


const axios = require('axios')
export default {
    props:[
        'elementD'
    ],
    data () {
      return {
        dialog: false,
        URL: 'http://127.0.0.1:8000/clientes/'+ this.elementD.zc_id_cliente_NoAfi
    }
    },
    methods:{
        async aceptar(){
           await axios.delete(this.URL)
            this.dialog = false
            window.location.reload()
        }
    },
  }
</script>