<template>
    <div cols="full">
        <v-row>
            <v-col cols="md-2 xs-12" >
                <menuModulos/>
            </v-col>
            <v-col cols="md-10 xs-12" >
                <app-header style="z-index: 135"/> 
                <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">INVENTARIO - CATÁLOGOS</h1>
            </div><br>
                <v-card>
                    <v-tabs>
                    
                        <v-menu offset-y v-for="sucursal in sucursales" :key="sucursal.zdsu_id_sucursal" open-on-hover>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn text v-bind="attrs" v-on="on" :to="'/invCat/'+ sucursal.zdsu_id_sucursal">
                                    {{sucursal.zdsu_nombre}}
                                </v-btn>
                           
                            </template>
                        </v-menu>
                    </v-tabs>
                </v-card>
                
                <v-data-iterator :items="catalogos" :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" hide-default-footer no-results-text="Sin registros" no-data-text="No se tienen registros de catalogos.">
                    
                    <template v-slot:header>
                        <v-toolbar class="mb-2" color="#e4e6eb" flat>
                            <v-toolbar-title>Inventario Catálogos</v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Búscar..."></v-text-field>
                        </v-toolbar>
                    </template>
                    
                    <template v-slot:default="props">
                        <v-row>
                            <v-col v-for="item in props.items" :key="item.name" sm="4">
                                <v-card>
                                    <v-card-title class="subheading font-weight-bold">
                                        <v-img v-if="item.zac_cantidad>=1" class="imgColor white--text align-center"  height="200px" dark>
                                            <h4>{{ item.zca_nombre_ca }}</h4>
                                        </v-img>
                                        <v-img v-else dark class="white--text align-center imgColor" height="200px">
                                            <h2 class="text-center">Agotado</h2>
                                            <h4>{{ item.zca_nombre_ca }}</h4>
                                        </v-img>
                                        
                                    </v-card-title>
                                    
                                    <v-divider></v-divider>
                                    
                                    <v-list dense>
                                        <v-list-item>
                                            <v-list-item-content>Temporada:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zca_temporada }}
                                            </v-list-item-content>
                                        </v-list-item>
                                        
                                        <v-list-item>
                                            <v-list-item-content>Cantidad:</v-list-item-content>
                                                <v-list-item-content>
                                                    <v-chip :color="getColor(item.zac_cantidad)" class="white--text"> 
                                                        {{ item.zac_cantidad }} pzas.
                                                    </v-chip>
                                                </v-list-item-content>
                                        </v-list-item>
                                        
                                        <v-list-item>
                                         <v-list-item-content>Estatus:</v-list-item-content>
                                             <v-list-item-content>
                                                <v-chip
                                                
                                                    :color="colortipo(item.zac_existen)"
                                                    class="white--text"
                                                >
                                                {{status(item.zac_existen)}}
                                                </v-chip>
                                             </v-list-item-content>
                                        </v-list-item> 


                                        <v-list-item>
                                            <v-list-item-content>Precio de Compra:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                $ {{ item.zac_prec_comp }}
                                            </v-list-item-content>
                                        </v-list-item>
                                        
                                        <v-list-item>
                                            <v-list-item-content>Año:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zca_year }}
                                            </v-list-item-content>
                                        </v-list-item>
                                    </v-list>
                                </v-card>
                            </v-col>
                        </v-row>
                    </template>
                    
                    <template v-slot:footer>
                        <v-row class="mt-2" align="center" justify="center" >
                            <span class="grey--text" style="margin-left:12px;">Elementos por página</span>
                            <v-menu offset-y>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                                        {{ itemsPerPage }}
                                        <v-icon>mdi-chevron-down</v-icon>
                                    </v-btn>
                                </template>
                                <v-list>
                                    <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                                        <v-list-item-title>{{ number }}</v-list-item-title>
                                    </v-list-item>
                                </v-list>
                            </v-menu>
                            <v-spacer></v-spacer>
                            <span class="mr-4 grey--text">
                                Página {{ page }} de {{ numberOfPages }}
                                <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
                                <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
                            </span>
                        </v-row>
                    </template>

                </v-data-iterator>
            </v-col>
        </v-row>
    </div>
</template>

<script>
    const axios = require('axios')
    import Header from '../../components/Header';
    import menuModulos from '../menuModulos'
    
    export default {
        name: 'Header', 
        components:{
            "app-header": Header,
            menuModulos,
        },

        created() {
            this.findSucursales()
            this.findCatalogos()
        },

        data() {
            return {
                sucursales: [],
                catalogos: [],

                itemsPerPageArray: [4, 12, 24],
                search: '',
                page: 1,
                itemsPerPage: 10,
                sortBy: 'zca_nombre_ca',
                keys: [
                    'zca_nombre_ca',
                    'zca_temporada',
                    'zac_cantidad',
                    'zac_existen',
                    
                ],
            }
        },

        computed: {
            numberOfPages () {
                return Math.ceil(this.catalogos.length / this.itemsPerPage)
            },
        },

        methods:{

            status(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activó."
          }
          else{
              cam_estatus="Inactivo."
          }
          return cam_estatus
      },
      colortipo(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="green accent-4"
          }
          else{
              color_estatus="red accent-3"
          }
          return color_estatus
      },
      

            findSucursales(){
                axios.get("http://127.0.0.1:8000/sucursal/sucursales/activas/")
                .then(res=> this.sucursales = res.data)
            },

            findCatalogos(){
                axios.get('http://127.0.0.1:8000/catalogo/')
                .then(res => this.catalogos = res.data)              
            },

            getColor (zac_cantidad) {
                if (zac_cantidad < 2) return 'red accent-3'
                else if (zac_cantidad < 5) return 'orange accent-3'
                else return 'green accent-4'
            },
            
            nextPage () {
                if (this.page + 1 <= this.numberOfPages) this.page += 1
            },
            formerPage () {
                if (this.page - 1 >= 1) this.page -= 1
            },
            updateItemsPerPage (number) {
                this.itemsPerPage = number
            },
        },
    }
</script>
