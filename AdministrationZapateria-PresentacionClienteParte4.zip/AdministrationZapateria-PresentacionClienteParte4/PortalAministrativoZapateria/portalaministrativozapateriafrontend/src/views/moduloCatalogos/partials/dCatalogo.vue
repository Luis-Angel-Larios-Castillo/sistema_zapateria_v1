Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un catalogo  
<template>
  <v-row justify="center">
    <v-tooltip bottom >

        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="#5B5B5B" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_catalogos == false">
            <v-icon color="red">mdi-delete</v-icon>
          </v-btn>

        </template>
        <span>Eliminar</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="500">
    
      <v-card>
     <v-container> 
      
          <v-alert dense text color="red" type="info" border="top">
        <strong>Se va a mover el catálogo: <br>{{elementD.item.zca_nombre_ca}} a histórico</strong>
        </v-alert>

        <v-card-text class="black--text">  
         
              ¿Está de acuerdo en moverlo?
          
        </v-card-text>
        <v-card-actions>
        <v-spacer></v-spacer>
          <br>
        <v-row align="center" justify="space-around">
          <v-btn outlined color="red" @click="dialog = false">
            Cancelar 
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn color="success" class="mr-15" outlined  @click="aceptar()">
            Aceptar 
            <v-icon right dark>mdi-check-all</v-icon>
        </v-btn>
         </v-row>
        </v-card-actions>
      </v-container>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios') 
import sArticulo from '../../moduloArticulos/partials/sArticulo.vue'
export default {
  components:{ 
    sArticulo, 
  }, 
  props:[
      'elementD'
  ],
  
  data () {
    return {
      iduser:[],
      dialog: false,
     
    }
  }, 
  created() {
   this.findusuer()
  },
 
    methods:{
 
      findusuer(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                    .then(resuser => {  this.iduser = resuser.data.zdus_id_usuario                    
                      })
                    })
      },

      aceptar(){
        this.elementD.item.zac_usua_delet = this.iduser
        this.elementD.item.zac_is_deleted = true
        this.elementD.item.zac_existen = false
        let URL= 'http://127.0.0.1:8000/catalogo/'+ this.elementD.item.zca_id_catalogo + '/'
          axios.put(URL,this.elementD.item)
            .then(response =>{
                this.dialog = false
                window.location.reload()
            })
      }
    },
  }
</script>