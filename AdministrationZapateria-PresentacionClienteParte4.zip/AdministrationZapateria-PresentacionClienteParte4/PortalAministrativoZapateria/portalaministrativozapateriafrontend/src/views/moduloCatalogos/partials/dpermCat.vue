Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un catalogo  
<template>
  <v-row justify="center">
    <v-tooltip bottom >

        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="#5B5B5B" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
            <v-icon color="red">mdi-delete</v-icon>
          </v-btn>

        </template>
        <span>Eliminar</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="800">
      <v-card>
     <v-container> 
       
          <v-alert dense text color="red" type="info" border="top">
        <strong>Se eliminará el catálogo {{elementD.item.zca_nombre_ca}} de forma permanente</strong>
        </v-alert>

        <v-card-text class="black--text">  
          <p v-if="eliminarValidacion == true">
              ¿Está de acuerdo en eliminarlo?
          </p>
          
            <h2 v-else class="orange--text">No se puede eliminar el catalogo {{elementD.item.zca_nombre_ca}}, ya que tiene articulos globales relacionados </h2>
         <br>
          <v-toolbar dense dark v-if="eliminarValidacion == false">
            <v-toolbar-title>Articulos Globales relacionados</v-toolbar-title>  
            <v-spacer/>
            <v-btn color="red" text @click="eliminarArray()" v-if="itemsDelete >= 1">
              <v-icon>mdi-delete-outline</v-icon>  
              Eliminar seleccionados
            </v-btn> 
          </v-toolbar>
          <v-simple-table dense fixed-header v-if="eliminarValidacion == false" height="220">
            <template v-slot:default>
              <thead>
                <tr> 
                  <th class="text-left"> 
                    
                  </th>
                  <th class="text-left">
                    Imagen
                  </th>
                  <th class="text-left">
                    Nombre
                  </th>
                  <th class="text-left">
                    Clave
                  </th>
                  <th class="text-left">
                    Modelo
                  </th>
                  <th class="text-left">
                    Marca
                  </th>
                  <th class="text-left">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody> 
                <tr v-for="item in elements" :key="item.zaag_id_articulo_global">
                  <td>
                    <v-checkbox v-model="selected" :value="item.zaag_id_articulo_global"/>
                  </td>
                  <td>
                    <v-img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80" width="80"/>
                  </td>
                  <td><sArticuloGlobal :element="item"/></td>
                  <td>{{item.zaag_clave}}</td>
                  <td>{{item.zaag_modelo}}</td>
                  <td>{{item.zaag_marca}}</td> 
                  <td>
                    <v-row align="center" justify="space-around" >
                    <v-btn icon color="red" @click="eliminarItem(item.zaag_id_articulo_global)">
                      <v-icon>mdi-delete-outline</v-icon>
                    </v-btn> 
                    
                    </v-row>
                  </td> 
                </tr>
              </tbody>
            </template>
          </v-simple-table>    
        </v-card-text>
        <v-card-actions>
       
          <br>
        <v-row align="center" justify="space-around">
          <v-btn outlined color="red" @click="dialog = false">
            Cancelar 
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn color="success" class="mr-15" outlined :disabled="!eliminarValidacion" @click="aceptar()">
            Aceptar 
            <v-icon right dark>mdi-check-all</v-icon>
        </v-btn>
         </v-row>
        </v-card-actions>
      </v-container>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios') 
import sArticuloGlobal from '../../moduloArticulosGlobales/partials/sArticuloGlobal.vue'
export default {
  components:{ 
    sArticuloGlobal, 
  }, 
  props:[
      'elementD'
  ],
  watch: {
    "selected" : function(){
      this.itemsDelete = this.selected.length
    }
  },
  data () {
    return {
      itemsDelete: 0,
      eliminarValidacion: false,
      dialog: false,
      elements: [],
      selected: [],
    }
  }, 
  created() {
    this.find()
  },
    updated() {
      this.find()
    },
    methods:{
      find(){
        let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
        axios.get("http://127.0.0.1:8000/articuloglobal/?search=" + this.elementD.item.zca_id_catalogo, config)
        .then(res => { 
          if (res.data.length == 0) {
            this.eliminarValidacion = true
          }else{
            this.elements = res.data
            res.data
            this.eliminarValidacion = false
          }  
        })
      },
      eliminarArray(){
        this.selected.forEach(ID => {
          axios.delete("http://127.0.0.1:8000/articuloglobal/" + ID + "/")
        });
        this.find()
        this.selected = []
      },
      eliminarItem(ID){ 
        axios.delete("http://127.0.0.1:8000/articuloglobal/" + ID + "/")
          .then(resD =>{
            this.find()
          })
      },
      aceptar(){
        let URL= 'http://127.0.0.1:8000/catalogo/'+ this.elementD.item.zca_id_catalogo
          axios.delete(URL)
            .then(response =>{
                this.dialog = false
                window.location.reload()
            })
      }
    },
  }
</script>