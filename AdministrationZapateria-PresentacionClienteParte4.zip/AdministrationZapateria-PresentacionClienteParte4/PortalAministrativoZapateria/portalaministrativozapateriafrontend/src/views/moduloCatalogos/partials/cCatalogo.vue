Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para registrar un catalogo  
<template>
    <v-container fluid>
      <div v-if="permissions.can_manage_catalogos == true">
         <app-header style="z-index: 135"/> 
     
    <v-col cols="md-8 xs-12">
      <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE CATÁLOGOS</h1>
        </div>
        
        <v-card :elevation="0">
          <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
            <v-spacer/>
            <v-btn  outlined class="btn_add" color="#F7F9F9" to="/Catalogos/">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>
          
          <v-container id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation class="col-12">
              <v-row>
                <v-col cols="4" >
                  <v-text-field v-model="nombre" filled :rules="nombreRules" label="Nombre" required :counter="100" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Andrea" maxlength="100"></v-text-field>
                </v-col>
                <v-col cols="4" >
                  <v-text-field v-model="cBarras" filled  :rules="cBarrasRules" label="Código de barras" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="45" placeholder="Ejem. 8414237000157" :counter="45" required/>
                </v-col>
                <v-col cols="4">
                  <v-select v-model="tipo" :items="tipos" filled :rules="[v => !!v || 'Debe seleccionar un tipo de paquete']"  label="Tipo" required/>
                </v-col>
              </v-row>
              <v-row class="align-center">
                <v-col cols="4">
                  <v-select v-model="select" filled :items="proveedores" item-text="zp_nombre" item-value="zp_id_proveedor" :rules="[v => !!v || 'Debe seleccionar un proveedor']"  label="Proveedor" required/>
                </v-col>
                <v-col cols="2" >
                  <v-btn outlined color="blue" to="/RegistroProveedores">
                    agregar
                  </v-btn>
                </v-col>
                <v-col cols="4" >
                  <v-select v-model="sucSelect" filled :items="sucursales" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una Sucursal']"  label="Sucursal" required/>
                </v-col>
                <v-col cols="2" >
                  <v-btn outlined color="blue" to="/cSucursal">
                    agregar
                  </v-btn>
                </v-col>
              </v-row>              
              <v-row>
                  <v-col>
                    <v-select v-model="temp" filled :items="temporadas"  :rules="[v => !!v || 'Debe seleccionar una temporada']"  label="Temporada" required/>
                  </v-col>
                  <v-col>
                    <v-select v-model="year" filled :items="yearsList"  :rules="[v => !!v || 'Debe seleccionar un año.']"  label="Año" required/>
                  </v-col>
                  <v-col>
                  <v-text-field v-model="cantidad" filled :rules="cantidadRules" label="Cantidad" type="number" counter required oninput="this.value=this.value.replace(/[^0-9]/g,'');"></v-text-field>
                </v-col>
              </v-row>
              
              <v-row>
                <v-col cols="4" >
                  <v-text-field v-model="pPreve" filled :rules="pPreveRules" label="Precio en preventa" type="number" counter required></v-text-field>
                </v-col>
                <v-col cols="4" >
                  <v-text-field v-model="pReg" filled :rules="pRegRules" label="Precio regular" type="number" counter required></v-text-field>
                </v-col>
                <v-col cols="4" >
                  <v-text-field v-model="pCom" filled  :rules="pComRules" label="Precio compra" type="number" counter required></v-text-field>
                </v-col>
              </v-row>

              <br><br>
              <v-row align="center" justify="space-around">
                  <v-btn :disabled="!valid" id="btn_agrega_otro_formulario" class="mr-4" @click="validate">
                    Guardar y agregar otro 
                    <v-icon right dark>
                      mdi-reload
                    </v-icon>
                  </v-btn>
                  <v-btn :disabled="!valid" id="btn_guardar_formulario" class="mr-4" @click="validate02">
                    Guardar 
                    <v-icon right dark>
                        mdi-cloud-upload
                    </v-icon>
                  </v-btn>
                  <v-btn  class="mr-4" @click="reset" id="btn_borrar_formulario">
                    Borrar Formulario
                     <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                  </v-btn>
              
              </v-row>
            </v-form>
          </v-container>
        </v-card>
      </v-col>
    
      </div>
      <div v-else>
        <ErrorPage403/>
      </div>
    </v-container>
</template>
<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require('axios')
const moment = require('moment')
  export default {
    name: 'Header', 
    components:{
      "app-header": Header,
      ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.getProveedores()
      this.findSucursal()
      this.yearsList = this.getYears()
    },
    data: () => ({
      element: [],
      proveedores: [],
      dialog:false,
      valid: true,
      nombre: '',
      nombreRules: [
        v => !!v || 'El nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 100) || 'El nombre no debe tener más de 100 caracteres',
      ],
      cBarras: '',
      cBarrasRules: [
        v => !!v || ' El código de barras es obligatorio ',
        v => (v && v.length >= 5) || 'El código de barras debe tener 5 o más caracteres',
        v => (v && v.length <= 45) || 'El código de barras no debe tener más de 45 caracteres',
      ],
      select: null,
      tipo:'',
      tipos:['Normal', 'Six-Pack', 'Oferta'],
      temp: '',
      temporadas:['Primavera - Verano', 'Otoño - Invierno', 'Primavera', 'Verano', 'Otoño', 'Invierno'],
      year: '',      
      yearsList: [],
      yearRules: [
        v => !!v || ' El año es obligatorio ',
      ],
      pPreve: '',
      pPreveRules: [
        v => !!v || 'El precio en preventa es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      pReg: '',
      pRegRules: [
        v => !!v || 'El precio regular es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      pCom: '',
      pComRules: [
        v => !!v || 'El precio compra es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      sucursales: [],
      sucSelect: null,
      cantidad: '',
      cantidadRules: [
        v => !!v || 'La cantidad es obligatoria',
        v => (v && v > 0) || 'No se puede registrar esta cantidad ',
        v => (v && v.length <= 5) || 'La cantidad no debe tener más de 5 caracteres.',
      ],
      permissions: {
            can_manage_catalogos: false,
        },
    }),

    methods: {

       findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_catalogos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_catalogos') { this.permissions.can_manage_catalogos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },


      getYears(){
        let years = []
        let yearFinal = moment(yearFinal).add(2, "years").format('yyyy')
        for (let i = yearFinal; i > 2010; i--) {
          years.push(i)
        }
        return years
      }, 
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zca_nombre_ca:this.nombre,
            zca_year:this.year,
            zca_id_proveedores: this.select,
            zca_temporada:this.temp,
            zca_cod_barras:this.cBarras,
            zca_prec_prev:this.pPreve,
            zca_prec_regul:this.pReg,
            zac_prec_comp:this.pCom,
            zac_existen: true,
            zac_apart: true,
            zac_cantidad: this.cantidad,
            zac_sucursal: this.sucSelect,
            zac_tipo_paquete: this.tipo,

          }
          this.create()
          }  
      },
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zca_nombre_ca:this.nombre,
            zca_year:this.year,
            zca_id_proveedores: this.select,
            zca_temporada:this.temp,
            zca_cod_barras:this.cBarras,
            zca_prec_prev:this.pPreve,
            zca_prec_regul:this.pReg,
            zac_prec_comp:this.pCom,
            zac_existen: true,
            zac_apart: true,
            zac_cantidad: this.cantidad,
            zac_sucursal: this.sucSelect,
            zac_tipo_paquete: this.tipo,

          }
          this.createAndNew()
          }  
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            zca_nombre_ca:this.nombre,
            zca_year:this.year,
            zca_id_proveedores: this.select,
            zca_temporada:this.temp,
            zca_cod_barras:this.cBarras,
            zca_prec_prev:this.pPreve,
            zca_prec_regul:this.pReg,
            zac_prec_comp:this.pCom,
            zac_existen: true,
            zac_apart: true,
            zac_cantidad: this.cantidad,
            zac_sucursal: this.sucSelect,
            zac_tipo_paquete: this.tipo,

          }
          this.create()
          }  
      },
      getProveedores(){
        axios.get('http://127.0.0.1:8000/proveedor/proveedores/activos/')
        .then(res => this.proveedores = res.data)
      },
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
          .then(res => this.sucursales = res.data)
      },
      createAndNew(){
        axios.post('http://127.0.0.1:8000/catalogo/', this.element)
          .then(res => {
            window.location.reload()
          })
          .catch(error => console.log(error));
      },
      create(){
        axios.post('http://127.0.0.1:8000/catalogo/', this.element)
          .then(res => {
            this.$router.go(-1);
            //this.$router.go(-1);
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      reset () {
        this.$refs.form.reset()

      },
    },
  }
</script>
