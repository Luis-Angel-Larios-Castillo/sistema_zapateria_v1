Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como Dialog (modal) que muestra toda la información de un catalogo  
<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zca_nombre_ca}}</strong>
        </p>
  
      </template>
      <v-card>
      <v-card-title class="headline">
  
        </v-card-title>
        <v-card-text>
            <v-alert dense text type="success" v-if="element.zac_existen == true" >
                El catálogo: <strong>{{element.zca_nombre_ca}}</strong> esta habilitado. 
            </v-alert>
            ID:<br> {{element.zca_id_catalogo}}
            <v-alert dense text type="warning" color="red" v-if="element.zac_existen == false" >
                El catálogo: <strong>{{element.zca_nombre_ca}}</strong> esta deshabilitado.
            </v-alert>

            <v-alert color="grey lighten-4" dense align="center">
                    <h4>INFORMACIÓN GENERAL</h4>
                </v-alert>


              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Id: </strong>{{element.zca_id_catalogo}}</td>
                    <td><strong>Año: </strong>{{element.zca_year}}</td>
                  </tr> 
                </tbody>
              </template>
            <v-divider/> 
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Precio en preventa: $</strong>{{element.zca_prec_prev}}</td>
                    <td><strong>Precio regular: $</strong>{{element.zca_prec_regul}}</td>
                    <td><strong>Precio compra: $</strong>{{element.zac_prec_comp}}</td>
                  </tr> 
                </tbody>
              </template>
            </v-simple-table>
            <v-divider/>
            <v-simple-table dense>
              <template v-slot:default>
              <v-alert color="grey lighten-4" dense align="center">
                  <v-row>
                   <v-col align="center">
                   <p class="mb-0"> {{element.zca_temporada}}</p>
                   <p style="font-size:13px;"><strong>Temporada </strong></p>
                  </v-col>
                  <v-col align="center">
                   <p class="mb-0"> {{element.zca_proveedor_nombre}}</p>
                   <p style="font-size:13px;"><strong>Proveedor</strong></p>
                  </v-col>
                  <v-col align="center">
                   <p class="mb-0"> {{element.zac_cantidad}} pzas.</p>
                   <p style="font-size:13px;"><strong>Cantidad</strong></p>
                  </v-col>
                  </v-row>
                  </v-alert>
                  <v-row>
                  <v-col align="center">
                  <p class="mb-0"> {{element.zca_cod_barras}}</p>
                  <p style="font-size:13px;"><strong>Código de barras</strong></p>
                  </v-col> 

                   <v-col align="center">
                  <p class="mb-0"> {{element.zca_sucursal_nombre}}</p>
                  <p style="font-size:13px;"><strong>Sucursal</strong></p>
                  </v-col> 
                </v-row>
                <div v-if="nombre != ''">
                  <v-row>
                  <v-col align="center">
                    <p class="mb-0"> {{nombre}}</p>
                      <p style="font-size:13px;"><strong>Empleado que elimino</strong></p>
                  </v-col> 
                  <v-col align="center">
                    <p class="mb-0"> {{fecha(element.zac_fech_delet)}}</p>
                      <p style="font-size:13px;"><strong>Fecha de eliminación</strong></p>
                  </v-col> 
                  </v-row>
                </div>
              </template>
            </v-simple-table>
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    data(){
        return {
          nombre:[],
        };
    },
    created() {
   this.findusuer()
  },
     methods:{
       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      findusuer(){
        if(this.element.zac_usua_delet != null){
          axios.get('http://127.0.0.1:8000/empleado/?search='+ this.element.zac_usua_delet)
          .then(res => {  this.nombre = res.data[0].nombre                    
          })
        }
        else{
          this.nombre = ''
        }   
      },
    }
}
</script>