Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un catalogo  
<template>
  <v-row justify="center">
    <v-tooltip bottom >

        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="teal" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="element.permissions.can_manage_catalogos == false">
            <v-icon>mdi-cached</v-icon>

          </v-btn>

        </template>
        <span>Restaurar Catálogo</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="500">
    
      <v-card>
     <v-container> 
       
          <v-alert dense text color="primary" type="info" border="top">
        <strong>Restaurar catálogo</strong>
        </v-alert>

        <v-card-text class="black--text">  
         
              ¿Está de acuerdo en restaurar el catalogo {{element.item.zca_nombre_ca}}?
          
        </v-card-text>
        <v-card-actions>
        <v-spacer></v-spacer>
          <br>
        <v-row align="center" justify="space-around">
          <v-btn outlined color="red" @click="dialog = false">
            Cancelar 
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn color="success" class="mr-15" outlined  @click="aceptar()">
            Aceptar 
            <v-icon right dark>mdi-check-all</v-icon>
        </v-btn>
         </v-row>
        </v-card-actions>
      </v-container>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios') 

export default {
  components:{ 
  }, 
  props:[
      'element'
  ],
  
  data () {
    return {
     
      dialog: false,
     
    }
  }, 
  created() {
   
  },
 
    methods:{
 
      aceptar(){
        this.element.item.zac_usua_delet = null
        this.element.item.zac_is_deleted = false
        this.element.item.zac_existen = true
        let URL= 'http://127.0.0.1:8000/catalogo/'+ this.element.item.zca_id_catalogo + '/'
          axios.put(URL,this.element.item)
            .then(response =>{
                this.dialog = false
                window.location.reload()
            })
      }
    },
  }
</script>