Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para actualizar la información de un catalogo  

<template>
    <v-container fluid>
       <div v-if="permissions.can_manage_catalogos == true">
          <app-header style="z-index: 135"/> 
          <br>
          <div class="col-9">
          <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
            <v-toolbar-title>
            <v-icon right dark>
              mdi-rotate-3d-variant
            </v-icon>
            
            <strong id="title_editar"> Actualizar catálogo: {{elementU.zca_nombre_ca}}</strong>
            
            </v-toolbar-title>
            <v-spacer/>
            <v-btn to="/catalogos/" outlined class="btn_add" color="#F7F9F9">
             <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>

          </v-toolbar>
     
          <v-container id="tabla_datos_dos"  class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>
              <v-row>
              <v-col cols="4" >
              <v-text-field v-model="elementU.zca_nombre_ca" filled :rules="nombreRules" label="Nombre" :counter="30" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Andrea" maxlength="30" required/>
              </v-col>
              <v-col cols="4" >
              <v-text-field v-model="elementU.zca_cod_barras" filled :rules="cBarrasRules" label="Código de barras" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="45" placeholder="Ejem. 8414237000157" :counter="45" required/>
              </v-col>
              <v-col cols="4">
                <v-select v-model="elementU.zac_tipo_paquete" :items="tipos" filled :rules="[v => !!v || 'Debe seleccionar un tipo de paquete']"  label="Tipo" required/>
              </v-col>
              </v-row>
              <v-row class="align-center">
                <v-col cols="4" >
                  <v-select v-model="elementU.zca_id_proveedores" filled  :items="proveedores" item-text="zp_nombre" item-value="zp_id_proveedor" :rules="[v => !!v || 'Debe seleccionar un proveedor']"  label="Proveedor" required/>
                </v-col>
                <v-col cols="2" >
                  <v-btn outlined color="blue" to="/RegistroProveedores">
                  Regresar
                </v-btn>
                </v-col>
                <v-col cols="4" >
                  <v-select v-model="elementU.zac_sucursal" filled :items="sucursales" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una Sucursal']"  label="Sucursal" required/>
                </v-col>
                <v-col cols="2" >
                  <v-btn outlined color="blue" to="/cSucursal">
                    agregar
                  </v-btn>
                </v-col>
              </v-row> 
              <v-row>
                  <v-col>
                    <v-select v-model="elementU.zca_temporada" filled  :items="temporadas"  :rules="[v => !!v || 'Debe seleccionar una temporada']"  label="Temporada" required/>
                  </v-col>
                  <v-col>
                      <v-select v-model="elementU.zca_year" filled  :items="yearsList"  :rules="[v => !!v || 'Debe seleccionar un año.']"  label="Año" required/>
                  </v-col>
                  <v-col>
                    <v-text-field v-model="elementU.zac_cantidad" filled :rules="cantidadRules" label="Cantidad" required type="number" counter oninput="this.value=this.value.replace(/[^0-9]/g,'');"></v-text-field>
                  </v-col>
              </v-row>          
              <v-row>
                  <v-col cols="4" >
                    <v-text-field v-model="elementU.zca_prec_prev" filled :rules="pPreveRules" label="Precio en preventa" type="number" counter required/>
                  </v-col>
                  <v-col cols="4" >
                    <v-text-field v-model="elementU.zca_prec_regul" filled  :rules="pRegRules" label="Precio regular" type="number" counter required/>
                  </v-col>
                  <v-col cols="4" >
                    <v-text-field v-model="elementU.zac_prec_comp" filled  :rules="pComRules" label="Precio compra" type="number" counter  required/>
                  </v-col>
              </v-row>
              <br>
              <v-row align="center" justify="space-around">
                  <v-btn :disabled="!valid" class="mr-4" @click="validate" id="btn_actualizar_formulario">
                      Actualizar
                      <v-icon right dark>mdi-update</v-icon>
                  </v-btn>
                  <v-btn  class="mr-4" @click="reset" id="btn_borrar_formulario">
                    Limpiar formulario 
                     <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                  </v-btn>
              </v-row>
            </v-form>
            <br>
          </v-container>
        <br>
         </div>
         </div>
      <div v-else>
        <ErrorPage403/>
      </div>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const moment = require('moment')
const axios = require('axios')
export default {
  name: 'Header', 
  components:{
    "app-header": Header,
    ErrorPage403
  }, 
    data: () => ({
      yearsList: [],
      elementU: [],
      proveedores: [],
      valid: true,
      nombreRules: [
        v => !!v || 'El nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 100) || 'El nombre no debe tener más de 100 caracteres',
      ],
      cBarrasRules: [
        v => !!v || ' El código de barras es obligatorio ',
        v => (v && v.length >= 5) || 'El código de barras debe tener 5 o más caracteres',
        v => (v && v.length <= 45) || 'El código de barras no debe tener más de 45 caracteres',
      ],
      tipos:['Normal', 'Six-Pack', 'Oferta'],
      temporadas:['Primavera - Verano', 'Otoño - Invierno', 'Primavera', 'Verano', 'Otoño', 'Invierno'],
      yearRules: [
        v => !!v || ' El año es obligatorio ',
      ],
      pPreveRules: [
        v => !!v || 'El precio en preventa es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      pRegRules: [
        v => !!v || 'El precio regular es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      pComRules: [
        v => !!v || 'El precio compra es obligatorio',
        v => (v && v > 0) || 'No se puede registrar este precio',
      ],
      sucursales: [],
      cantidadRules: [
        v => !!v || 'La cantidad es obligatoria',
        v => (v && v > 0) || 'No se puede registrar esta cantidad ',
      ],
       permissions: {
            can_manage_catalogos: false,
        },
    }),
    created() {
      this.findpermsisos()
      this.find()
      this.getProveedores()
      this.findSucursal()
      this.yearsList = this.getYears()
    },
    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_catalogos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_catalogos') { this.permissions.can_manage_catalogos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      getYears(){
        let years = []
        let yearFinal = moment(yearFinal).add(2, "years").format('yyyy')
        for (let i = yearFinal; i > 2010; i--) {
          years.push(i)
        }
        return years
      }, 
      find(){
        axios.get('http://127.0.0.1:8000/catalogo/'+ this.$route.params.id +'/')
        .then(res => this.elementU = res.data)
        //then(res =>console.log(res.data))
      },
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
          .then(res => this.sucursales = res.data)
      },
      validate () {
        this.$refs.form.validate()
        
        this.update()
      },
      async update(){
            await axios.put('http://127.0.0.1:8000/catalogo/'+ this.$route.params.id +'/',this.elementU)
            .catch(error => console.log(error))
            this.$router.push({ name: 'Catalogos' });
        },
      reset () {
        this.$refs.form.reset()
      },
      getProveedores(){
        axios.get('http://127.0.0.1:8000/proveedor/proveedor/')
        .then(res => this.proveedores = res.data)
      },
      cancelar () {
        this.$router.push({ name: 'Catalogos' });
      },
    },
  }
</script>