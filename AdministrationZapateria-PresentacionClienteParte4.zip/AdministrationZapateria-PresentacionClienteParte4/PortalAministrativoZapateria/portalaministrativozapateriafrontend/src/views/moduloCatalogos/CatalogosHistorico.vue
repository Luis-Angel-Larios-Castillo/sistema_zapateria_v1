Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los catálogos registrados
<template>
<div cols="full">
    <v-row>
        <v-col cols="md-2 xs-12">
            <menuModulos/>
        </v-col> 
        <v-col cols="md-10 xs-12" class="col-12"> 
            <app-header style="z-index: 135"/> 
             <div align="center">
                 
                 <hr class="line_superior">
                    <h1 id="title">CATÁLOGOS HISTORICO</h1>
                 </div><br>
            <v-card :elevation="0">
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                   <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text :to="'/Catalogos/'" class="btn_add" v-show="permissions.can_manage_catalogos == true">
                            CATÁLOGOS
                        </v-btn>
                        
                    </div>
                </v-card-title>
                <div  class="col-12" style="padding-top:0"> 
                <v-data-table  
                
                    id="tabla_datos"
                    :headers="headers" 
                    :items="cat"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen catalogos registrados."
                    :search="search" :footer-props="{
                    showFirstLastPage: true,
                    itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.zca_nombre_ca="{ item }"  >
                        <sCatalogo :element="item"/>
                    </template>

                   
                    <template v-slot:item.zca_id_catalogo="{ item }">
                        <v-row align="center">

                            <v-col>
                             <restCatalogo  :element="{item, permissions}"/> 
                            </v-col>
                         
                            <v-col>
                                <dpermcat  :elementD="{item, permissions}"/> 
                            </v-col>
                           
                          
                            
                        </v-row>
                    </template>
                </v-data-table>
                </div>
            </v-card>
        </v-col>

    </v-row>
    <br>
</div >
</template>
<script>
import Header from '../../components/Header';
const axios = require('axios')
import menuModulos from '../menuModulos'
import dCatalogo from './partials/dCatalogo'
import dpermcat from './partials/dpermCat'
import sCatalogo from './partials/sCatalogo'
import restCatalogo from './partials/restCatalogo'
import styles from '../../../public/Styles'
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,
        dCatalogo,
        sCatalogo,
        restCatalogo,
        dpermcat
    },
    created() {
        this.find()
    },
    data () {
      return {
        element: Object,
        search: '',
        headers: [
          { text: 'Catalogo', align: 'center', filterable: true, value: 'zca_nombre_ca',},
          { text: 'Año', value: 'zca_year' },
          { text: 'Cantidad', value: 'zac_cantidad',  align: 'center' },
          { text: 'Código de Barras', value: 'zca_cod_barras',  align: 'center' },
          { text: 'Temporada', value: 'zca_temporada',  align: 'center' },
          //{ text: 'Sucursal', value: 'zca_sucursal_nombre',  align: 'center' },
          //{ text: 'Estatus', value: 'zac_existen', sortable: true, align:'center' },
          { text: 'Acciones', value: 'zca_id_catalogo', sortable: false,  align: 'center' },
        ],
        elements: [],
        idUser:[],
       empleadoResult:[],
        permissions: {
            can_manage_catalogos: false,
        },
        cat:[],
        dialog: false,
      }
    },
    methods:{
        find(){

            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_catalogos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_catalogos') { this.permissions.can_manage_catalogos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                }) 

            this.cat = []
            
            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            //console.log(this.idUser)

            
            axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+ this.idUser)
                .then(res=>{this.admin=res.data[0]

                    if(this.admin.is_superuser==false){
                        axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
                        .then(res => { this.empleadoResult = res.data[0]
                        //console.log(this.empleadoResult)
                            axios.get('http://127.0.0.1:8000/catalogo/?search='+ this.empleadoResult.zdem_id_sucursal)
                            .then(res => {this.elements = res.data
                            
                                res.data.forEach(element => { 
                                    if(element.zac_is_deleted ==  true){
                                        this.cat.push(element)
                                    }
                                })
                            })
                        })
                    }else{
                        axios.get('http://127.0.0.1:8000/catalogo/')
                        .then(res => {this.elements = res.data
                        
                            res.data.forEach(element => { 
                                if(element.zac_is_deleted ==  true){
                                    this.cat.push(element)
                                }
                            })
                        })
                    }
                })
            })
        },

       
         activar (n) {
            const URL = 'http://127.0.0.1:8000/catalogo/'+n.zca_id_catalogo+'/'
            axios.put(URL, {
                zca_nombre_ca:n.zca_nombre_ca, 
                zca_year:n.zca_year, 
                zca_temporada: n.zca_temporada, 
                zca_cod_barras: n.zca_cod_barras, 
                zca_prec_prev: n.zca_prec_prev, 
                zca_prec_regul: n.zca_prec_regul, 
                zac_prec_comp: n.zac_prec_comp, 
                zac_existen: true, 
                zac_apart:n.zac_apart,
                zac_cantidad:n.zac_cantidad,
                zac_sucursal:n.zac_sucursal,
                zca_id_proveedores:n.zca_id_proveedores,
                "zac_is_deleted": false,

            }).catch(error => console.log(error))
            window.location.reload()
        },
        
       
        
    },
}
</script>