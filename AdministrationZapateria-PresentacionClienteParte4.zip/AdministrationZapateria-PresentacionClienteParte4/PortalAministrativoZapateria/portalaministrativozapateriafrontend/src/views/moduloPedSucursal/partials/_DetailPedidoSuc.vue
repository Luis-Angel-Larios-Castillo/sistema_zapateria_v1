Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra toda la informacion del pedido
<template> 
    <v-container fluid>    
        <app-header style="z-index: 135"/> 
        <div class="col-10">
        <v-toolbar dark>
            <v-tabs v-model="tab"  icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1">Pedido</v-tab> 
                <v-tab href="#tab-2">Items relacionados</v-tab> 
            </v-tabs>
            <PDF :id="pedCab.zpedsuc_id_ped_sucur"/>
            <v-btn dark text class="btn_add" :to="'/ListPedSucursal/'">
                regresar
            </v-btn> 
        </v-toolbar> 
        <v-tabs-items v-model="tab">
            
                <v-tab-item value="tab-1">   
                <v-card >  
                    <v-card-title>
                        <h3>Pedido Sucursal: {{pedCab.zpedsuc_nombre}}</h3><v-spacer/><h3>{{fecha(pedCab.zpedsuc_fech_creat)}}</h3> 
                    </v-card-title>
                    <v-card-title> 
                        <h4>Creado por: {{emplCrea.nombre}}</h4><v-spacer/><h4>Estatus: {{pedCab.zpedsuc_status_ped}}</h4> 
                    </v-card-title>
                    <v-card-title> 
                        <h4>Proveedor: {{proveedor.zp_nombre}} {{proveedor.zp_apell_pat}} {{proveedor.zp_apell_mat}}</h4><v-spacer/><h4>Identificador: {{proveedor.zp_identify_mark}}</h4> 
                    </v-card-title>
                    <v-card-title v-if="modif == true"> 
                        <h5>Modificado por: {{emplMod.nombre}}</h5>
                        <v-spacer/> 
                        <h5>Fecha de mod: {{fecha(pedCab.zpedsuc_fech_mod)}}</h5> 
                    </v-card-title> 
                    <v-toolbar dense dark v-if="pedCab.zpedsuc_status_ped == 'Llego sucursal'">
                        <v-spacer></v-spacer>
                        <v-btn v-if="pedCab.zpedsuc_puede_editar == true" @click="editar()" text class="btn_gped white--text">dejar de editar</v-btn>
                        <v-btn v-else @click="editar()" text class="btn_gped white--text">Editar</v-btn>
                    </v-toolbar> 
                    <v-card-text> 
                        <v-simple-table dense fixed-header>
                            <template v-slot:default>
                                <thead>
                                    <tr>  
                                        <th class="text-center font-weight-black black--text">Modelo</th>
                                        <th class="text-center font-weight-black black--text">Marca</th>
                                        <th class="text-center font-weight-black black--text">Color</th>
                                        <th class="text-center font-weight-black black--text">Talla</th>  
                                        <th class="text-center font-weight-black black--text">Cantidad solicitada</th>
                                        <th class="text-center font-weight-black black--text">Cantidad recibida</th>
                                    </tr>
                                </thead>
                                <tbody> 
                                    <tr v-for="item in reportes" :key="item.zpedsuca_id_item_caj">   
                                        <td class="text-center">{{item.zpedsuca_model}}</td>
                                        <td class="text-center">{{item.zpedsuca_marca}}</td> 
                                        <td class="text-center">{{item.zpedsuca_color}}</td> 
                                        <td class="text-center">{{item.zpedsuca_talla}}</td>
                                        <td class="text-center">{{item.zpedsuca_cant_ped}}</td>  
                                        <td class="text-center" >                                  
                                            <v-text-field  v-if="pedCab.zpedsuc_status_ped == 'Llego sucursal'"  class="fieldCant" :disabled="pedCab.zpedsuc_puede_editar == false" v-model="item.zpedpro_cant_ped_llego" v-on:change="ingresarCantidad(item)"  label="Cantidad"/>
                                            <p v-else>
                                                {{item.zpedpro_cant_ped_llego}}
                                            </p>
                                        </td> 
                                    </tr>
                                </tbody>
                            </template>
                        </v-simple-table>  
                    </v-card-text>
                </v-card>  
        </v-tab-item>
        <v-tab-item value="tab-2"> 
            <v-card :elevation="0">
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    </div>  
                </v-card-title>  
                <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                        :headers="headers" 
                        :items="itemsPendientes" 
                        :search="search"
                        :items-per-page="5"
                        :items-per-page-options="[5, 10, 15]"
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen pedidos registrados." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }"
                        :header-props="{ sortByText: 'Ordenar por' }"
                    >
                        <template v-slot:item.zipe_id_cliente="{ item }" >  
                            <GetCliente :idCliente="item.zipe_id_cliente"/> 
                        </template>   
                        <template v-slot:item.zipe_id_item_ped="{ item }"  v-if="pedCab.zpedsuc_status_ped == 'Llego sucursal'">  
                            <v-tooltip bottom v-if="item.zipe_status == 'Llego sucursal'">
                                <template v-slot:activator="{ on, attrs }"> 
                                    <v-btn icon @click="cambiarEstatus(item, 'Pendiente')" v-bind="attrs" v-on="on">
                                    <!--<v-btn v-if="item.zipcat_estatus_cat == 'Llego sucursal'" icon @click="cambiarEstatus(item, 'Pendiente')" v-bind="attrs" v-on="on">-->
                                        <v-icon color="blue" >mdi-timetable</v-icon>
                                    </v-btn>
                                </template>
                                <span>Marcar como pendiente</span>
                            </v-tooltip>
                            <v-tooltip bottom v-if="item.zipe_status == 'Llego sucursal'">
                                <template v-slot:activator="{ on, attrs }"> 
                                    <v-btn icon @click="cambiarEstatus(item, 'Listo para entregar')" v-bind="attrs" v-on="on">
                                    <!--<v-btn v-if="item.zipcat_estatus_cat == 'Llego sucursal'" icon @click="cambiarEstatus(item, 'Pendiente')" v-bind="attrs" v-on="on">-->
                                        <v-icon color="green" >mdi-account-arrow-left-outline</v-icon>
                                    </v-btn>
                                </template>
                                <span>Marcar como listo para entregar</span>
                            </v-tooltip>
                            <!--
                            <v-tooltip bottom v-if="item.zipe_status == 'Llego sucursal'">
                                <template v-slot:activator="{ on, attrs }"> 
                                    <v-btn icon @click="cambiarEstatus(item, 'Cancelado')" v-bind="attrs" v-on="on">
                                    
                                        <v-icon color="red" >mdi-file-cancel-outline</v-icon>
                                    </v-btn>
                                </template>
                                <span>Cancelar</span>
                            </v-tooltip>
                            -->
                        </template>  
                        <template v-slot:item.zipe_id_item_ped="{ item }"  v-else>  
                             
                        </template>  
                    </v-data-table>
                </div>
            </v-card>
        </v-tab-item>
    </v-tabs-items> 
    
    </div> 
    <v-snackbar shaped color="green" outlined v-model="snackbar" :timeout="timeout">
        <h2 class="black--text" >{{ text }}</h2> 
        <template v-slot:action="{ attrs }">
            <v-btn color="red" text v-bind="attrs" @click="snackbar = false">
            Cerrar
            </v-btn>
        </template>
    </v-snackbar> 
    </v-container>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import PDF from '../../../components/PDFPedSucArt.vue'
import Header from '../../../components/Header';
import GetCliente from './_GetCliente.vue' 
export default { 
    name: 'Header', 
    components:{ 
        "app-header": Header,  
        GetCliente,
        PDF
    }, 
    data(){
        return {
            snackbar: false,
            text: '',
            timeout: 6000, 
            search: '', 
            tab: null,
            IdEmpleado: '',
            proveedor: [],
            tab: null,
            pedCab: [],
            items: [],
            reportes: [], 
            emplCrea: [],
            emplMod: [],
            modif: false,
            headers: [
                {
                    text: 'Articulo',
                    align: 'start',
                    filterable: true,
                    value: 'zipe_art_nombre', 
                }, 
                { text: 'Modelo', value: 'zipe_modelo'},
                { text: 'Cliente', value: 'zipe_id_cliente'}, 
                { text: 'Marca', value: 'zipe_marca'},
                { text: 'Color', value: 'zipe_color'}, 
                { text: 'Talla', value: 'zipe_talla'},  
                { text: 'Estatus', value: 'zipe_status'}, 
                { text: 'Cantidad', value: 'zipe_cant', align: 'center', sortable: false },
                { text: 'Acciones', value: 'zipe_id_item_ped', align: 'center', sortable: false },
            ],  
            itemsPendientes: []
        }
    },
    created(){ 
        this.find()
    }, 
    methods:{
        cambiarEstatus(item, status){
            item.zipe_status = status  
            if(item.zipe_status = 'Listo para entregar'){
                axios.put('http://127.0.0.1:8000/pedido/Itembyuser/' + item.zipe_id_item_ped + '/', item)
                .then(resItem=>{
                    axios.get('http://127.0.0.1:8000/articulo/admin/' + item.zipe_id_arti + '/')
                    .then(resArticulo=>{
                        resArticulo.data.zaa_cantidad += item.zipe_cant
                        axios.put('http://127.0.0.1:8000/articulo/admin/' + item.zipe_id_arti + '/', resArticulo.data)
                    })
                })
            }else{
                axios.put('http://127.0.0.1:8000/pedido/Itembyuser/' + item.zipe_id_item_ped + '/', item)
            } 
        },
        ingresarCantidad(item){ 
            this.itemsPendientes = []
            this.pedCab.zpedsuc_id_emple_mod = this.IdEmpleado
            axios.put('http://127.0.0.1:8000/pedsuc/item/' + item.zpedsuca_id_item_caj + '/', item)
                .then(resItem => {
                    axios.put('http://127.0.0.1:8000/pedsuc/cab/' + this.$route.params.id + '/', this.pedCab)
                    .then(res =>{
                        this.find()
                    })
                })
        },
        editar(item){
            this.itemsPendientes = []
            this.pedCab.zpedsuc_id_emple_mod = this.IdEmpleado
            this.pedCab.zpedsuc_puede_editar = !this.pedCab.zpedsuc_puede_editar
            axios.put('http://127.0.0.1:8000/pedsuc/cab/' + this.$route.params.id + '/', this.pedCab)
            .then(res =>{
                this.find()
            })
        },
        getEmpleadoCrea(cab){ 
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedsuc_id_emple)
                .then(resEmp => {
                    this.emplCrea = resEmp.data[0]
                })
            if(cab.zpedsuc_id_emple_mod != null){
                axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedsuc_id_emple_mod)
                .then(resEmp =>{
                    this.emplMod = resEmp.data[0]
                    this.modif = true
                })
            } 
        },
        fecha(date){
            return moment(date).locale('MX').format('DD-MM-YYYY LT')
        },    
        find(){ 
            this.itemsPendientes = []
            let repostesBruto = [] 
            axios.get('http://127.0.0.1:8000/pedsuc/cab/' + this.$route.params.id + '/')
            .then(resCab=> {
                axios.get('http://127.0.0.1:8000/pedido/Itembyuser/?search=' + resCab.data.zpedsuc_id_sucursal)
                .then(resItems => {
                    resItems.data.forEach(item => {
                        if(resCab.data.zipe_sucursal == item.zipcat_id_sucursal){
                            if(item.zipe_marca == resCab.data.zpedpro_proveedor_nombre){
                                this.itemsPendientes.push(item)
                            }
                        }    
                    }); 
                })
                axios.get('http://127.0.0.1:8000/proveedor/proveedor/' + resCab.data.zpedsuc_id_provee + '/')
                    .then(resProvee =>{
                        this.proveedor = resProvee.data
                    })
                this.pedCab = resCab.data 
                this.getEmpleadoCrea(resCab.data)
                axios.get('http://127.0.0.1:8000/pedsuc/item/?search=' +this.$route.params.id )
                    .then(resItem => {  
                        resItem.data.forEach(item => { 
                            repostesBruto.push(item) 
                        }); 
                        this.reportes = repostesBruto 
                    })
                }) 
        }
    }
}
</script>
