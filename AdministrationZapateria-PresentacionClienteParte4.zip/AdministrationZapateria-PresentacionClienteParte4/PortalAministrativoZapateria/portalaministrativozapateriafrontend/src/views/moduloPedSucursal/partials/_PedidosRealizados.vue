Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra los pedidos realizados
<template>
    <v-container fluid> 
        <v-card :elevation="0">
            <v-card-title class="card_title">
                <div class="col-12" id="table_cabecera_color">
                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                </div> 
            </v-card-title>  
            <div class="col-12" style="padding-top:0">
                <v-data-table
                    id="tabla_datos"
                    :headers="headers" 
                    :items="pedi" 
                    :search="search"
                    :items-per-page="5"
                    :items-per-page-options="[5, 10, 15]"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen pedidos registrados." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.zpedsuc_nombre="{ item }" >  
                        <strong>{{item.zpedsuc_nombre}}</strong> 
                    </template>      
                    <template v-slot:item.zpedsuc_id_ped_sucur="{ item }" >  
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon :to="'/PedSucursal/'+ item.zpedsuc_id_ped_sucur+'/'" v-bind="attrs" v-on="on">
                                    <v-icon color="blue" >mdi-file-document-multiple-outline</v-icon>
                                </v-btn>
                            </template>
                            <span>Ver pedido</span>
                        </v-tooltip>
                        <v-tooltip bottom >
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn v-if="item.zpedsuc_status_ped == 'En tránsito sucursal'" icon @click="marcarLlego(item)" v-bind="attrs" v-on="on">
                                    <v-icon color="green" >mdi-package-variant</v-icon>
                                </v-btn>
                            </template>
                            <span>Cambiar estatus</span>
                        </v-tooltip>
                    </template>  
                </v-data-table>
            </div>
        </v-card> 
        <v-overlay :value="overlay">
            <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
        </v-overlay>
        <v-snackbar shaped color="green" outlined v-model="snackbar" :timeout="timeout">
            <h2 class="black--text" >{{ text }}</h2> 
            <template v-slot:action="{ attrs }">
                <v-btn color="blue" text v-bind="attrs" @click="snackbar = false">
                Cerrar
                </v-btn>
            </template>
        </v-snackbar> 
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'empleado'
    ],
    data() { 
        return { 
            overlay: false,
            IdEmpleado: '',
            snackbar: false,
            text: '',
            timeout: 3000,
            status: 'Pedido centro de distribución',
            statusItems: [
                'Pedido centro de distribución', 
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor', 
                'Regreso chofer a centro de distribución',
                'En tránsito sucursal',
                'Llego sucursal' 
            ],
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedsuc_nombre', 
            }, 
            { text: 'Sucursal', value: 'zpedsuc_sucursal'}, 
            { text: 'Estatus', value: 'zpedsuc_status_ped'}, 
            { text: 'Acciones', value: 'zpedsuc_id_ped_sucur', sortable: false },
            ],
            pedi: [],

        }
    },
    created() { 
        this.find()
    },
    methods: {
        
        marcarLlego(pedSuc){
            this.overlay = true
            console.log(pedSuc) 
            this.pedi = []
            pedSuc.zpedsuc_id_emple_mod = this.IdEmpleado
            pedSuc.zpedsuc_status_ped = 'Llego sucursal'
            
            //'En tránsito sucursal'
            let itemsPed = 0
            axios.get('http://127.0.0.1:8000/pedido/itemped/')
                .then(resItem =>{
                    resItem.data.forEach(itemPed => { 
                        if(itemPed.zipe_status == 'En tránsito sucursal'){
                            if(pedSuc.zpedpro_proveedor_nombre == itemPed.zipe_marca){
                                if(pedSuc.zpedsuc_id_sucursal == itemPed.zipe_sucursal){
                                    itemPed.zipe_status = 'Llego sucursal'
                                    //console.log(itemPed)  
                                    axios.put('http://127.0.0.1:8000/pedido/itemped/' + itemPed.zipe_id_item_ped + '/', itemPed)  
                                } 
                            } 
                        }
                        itemsPed++; 
                        if(itemsPed === resItem.data.length) {
                            setTimeout(function(){   
                                axios.put('http://127.0.0.1:8000/pedsuc/cab/' + pedSuc.zpedsuc_id_ped_sucur + '/', pedSuc)
                                    .then(res =>{ 
                                        window.location.reload()
                                    })
                            }, 3000);
                        }
                    });
                }) 
        },
        find(){ 
            this.pedi = []
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                    axios.get('http://127.0.0.1:8000/empleado/?search=' + resToken.data[0].user )
                    .then(resEmp => {
                        axios.get('http://127.0.0.1:8000/pedsuc/cab/')
                        .then(res => {
                            res.data.forEach(element => { 
                                if(resEmp.data[0].zdem_id_sucursal == element.zpedsuc_id_sucursal){
                                    if(element.zpedsuc_status_ped ==  this.status){
                                        this.pedi.push(element)
                                    }
                                }
                                
                            }); 
                        })
                    })
                })
            
        }
    },
}
</script>