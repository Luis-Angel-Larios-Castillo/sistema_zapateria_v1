Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra los articulos de un cliente
<template>
    <v-container fluid>
        <v-card width="600px">
            <v-card-actions @click="show = !show" hover>
                <v-btn color="blue"   text>Ver listado </v-btn> 
                <v-spacer></v-spacer> 
                <v-btn icon>
                    <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
                </v-btn>
            </v-card-actions>
            <v-expand-transition> 
                <div v-show="show">
                    <v-divider/> 
                    <v-card-title class="card_title">
                        <div class="col-12" id="table_cabecera_color">
                            
                            <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                        </div> 
                    </v-card-title>   
                    <v-card-text>  
                        <v-simple-table dense fixed-header height="150" item-height="20">
                            <template v-slot:default>
                                <thead>
                                    <tr> 
                                        <th>Cantidad</th>
                                        <th>Modelo</th>
                                        <th>Marca</th>
                                        <th>Color</th>
                                        <th>Talla</th>
                                        <th>Estatus</th>
                                        <th>Tipo</th> 
                                    </tr>
                                </thead>
                                <tbody> 
                                    <tr v-for="item in items" :key="item.zipe_id_item_ped">   
                                        <td>{{item.zipe_cant}}</td>
                                        <td>{{item.zipe_modelo}}</td> 
                                        <td>{{item.zipe_marca}}</td> 
                                        <td>{{item.zipe_color}}</td>
                                        <td>{{item.zipe_talla}}</td> 
                                        <td>{{item.zipe_status}}</td>
                                        <td>{{item.zica_tipo_articulo}}</td>
                                    </tr>
                                </tbody>
                            </template>
                        </v-simple-table>  
                    </v-card-text> 
                </div> 
            </v-expand-transition>
        </v-card> 
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'clienteID'
    ],
    data() {
        return {
            status: 'Pendiente',
            statusItems: [
                'Pendiente',
                'Centro de distribución',
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor', 
                'Regreso chofer a centro de distribución', 
                'En tránsito sucursal',
                'Llego sucursal',
                'Listo para entregar',
                'Cancelado'
            ], 
            items: [],
            show: false,
        }
    },
    created() {
        this.find()
    },
    methods: {
        find(){ 
            this.items = []
            axios.get('http://127.0.0.1:8000/pedido/Itembyuser/?search=' + this.clienteID )
                .then( res => {  
                    res.data.forEach(item => {
                        if(this.status == item.zipe_status){
                            this.items.push(item) 
                        }
                    });  
                })
        }
    },
}
</script>