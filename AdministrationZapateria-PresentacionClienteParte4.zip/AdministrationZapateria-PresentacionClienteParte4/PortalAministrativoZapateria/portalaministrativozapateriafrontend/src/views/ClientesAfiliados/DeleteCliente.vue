<!--Autor: Eliza Huerta - Coautor: Mario Alonso
Descripción: Archivo que contiene una ventana emergente (modal) al momento de querer eliminar un registro y la cual le permite al usuario confirmar la acción solicitada
Autor: Elisa Huerta Corona.
Descripción: El presente archivo es para eliminar el cliente.-->
<template>

  <v-row justify="center">
    <v-tooltip bottom>
      <template v-slot:activator="{ on, attrs }">
        <v-btn icon color="#5B5B5B" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_cli_afi == false">
          <v-icon color="red">mdi-delete</v-icon>
        </v-btn>
      </template>
      <span>Eliminar</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="500">
      <v-card>
        <v-form ref="form" v-model="valid" lazy-validation m><br>
          <v-alert dense text color="red" type="info" border="top">
            <strong>Se va a eliminar el Cliente:<br>{{elementD.item.zc_nombre}} {{elementD.item.zc_apell_pat}} {{elementD.item.zc_apell_mat}}</strong>
          </v-alert>
          <v-card-text class="black--text">
          <v-text-field label="Motivo" filled rounded dense v-model="motivo" :rules="motivoRules" required :counter="50" maxlength="50"></v-text-field>
            <h4>¿Está de acuerdo en eliminarlo?</h4>
          </v-card-text>
          
          <v-text-field v-model="elementD.item.zc_id_cliente" v-if="ocultar" label="Id Cliente" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_id_usuario" v-if="ocultar" label="Id Usuario" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_nombre" v-if="ocultar" label="Nombre" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_apell_pat" v-if="ocultar" label="Apellido Paterno" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_apell_mat" v-if="ocultar" label="Apellido Materno" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_num_telefono" v-if="ocultar" label="Número de Teléfono de Domicilio" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_num_cell" v-if="ocultar" label="Número de Teléfono Celular" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_rfc" v-if="ocultar" label="RFC" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_correo" v-if="ocultar" label="Correo Electrónico" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_calle_1" v-if="ocultar" label="Dirección/Calle Principal" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_calle_2" v-if="ocultar" label="Dirección/Calles de Interconexión" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_cod_postal" v-if="ocultar" label="Código Postal" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_colonia" v-if="ocultar" label="Barrio/Colonia" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_municipio" v-if="ocultar" label="Delegación/Municipio" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_estado" v-if="ocultar" label="Estado" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_pais" v-if="ocultar" label="País" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_num_ext" v-if="ocultar" label="Número Exterior" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_dir_num_int" v-if="ocultar" label="Número Interior" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_fech_nacim" v-if="ocultar" label="Fecha de Nacimiento"></v-text-field>
          <v-text-field v-model="elementD.item.zc_saldo" v-if="ocultar" label="Saldo" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_id_sucursal" v-if="ocultar" label="Id Sucursal" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_fech_crea" v-if="ocultar" label="Fecha de Registro" readonly></v-text-field>
          <v-text-field v-model="elementD.item.zc_fech_mod" v-if="ocultar" label="Fecha de Última Modificación" readonly></v-text-field>
          <v-text-field v-model="idUser" v-if="ocultar" label="Id Administrador/Empleado que elimino el registro" readonly></v-text-field>
          <v-btn outlined color="red" @click="dialog = false">
            Cancelar
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>
          <v-btn outlined color="success" @click="validate" :disabled="!valid">
            Aceptar
            <v-icon right dark>mdi-check-all</v-icon>
          </v-btn><br><br>
        </v-form>
      </v-card>
    </v-dialog>

  </v-row>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')
  
  export default {
    props:[
      'elementD'
    ],
    created() {
      this.findIdUser()
    },
    data () {
      return {
        element:[],
        idUser: '',
        dialog: false,
        ocultar: false,
        valid: true,
        motivo: '',
        motivoRules:[
          v => !!v || 'Se requiere ingresar un Motivo.',
        ],
      }
    },
    methods:{
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zdc_id_cliente: this.elementD.item.zc_id_cliente,
            zdc_id_usuario: this.elementD.item.zc_id_usuario,
            zdc_id_sucursal: this.elementD.item.zc_id_sucursal,
            zdc_nombre: this.elementD.item.zc_nombre,
            zdc_apell_pat: this.elementD.item.zc_apell_pat,
            zdc_apell_mat: this.elementD.item.zc_apell_mat,
            zdc_num_telefono: this.elementD.item.zc_num_telefono,
            zdc_num_cell: this.elementD.item.zc_num_cell,
            zdc_rfc: this.elementD.item.zc_rfc,
            zdc_correo: this.elementD.item.zc_correo,
            zdc_dir_calle_1: this.elementD.item.zc_dir_calle_1,
            zdc_dir_calle_2: this.elementD.item.zc_dir_calle_2,
            zdc_dir_cod_postal: this.elementD.item.zc_dir_cod_postal,
            zdc_dir_colonia: this.elementD.item.zc_dir_colonia,
            zdc_dir_municipio: this.elementD.item.zc_dir_municipio,
            zdc_dir_estado: this.elementD.item.zc_dir_estado,
            zdc_dir_pais: this.elementD.item.zc_dir_pais,
            zdc_dir_num_ext: this.elementD.item.zc_dir_num_ext,
            zdc_dir_num_int: this.elementD.item.zc_dir_num_int,
            zdc_fech_nacim: this.elementD.item.zc_fech_nacim,
            zdc_saldo: this.elementD.item.zc_saldo,
            zdc_enter_client: this.elementD.item.zc_enter_client,
            zdc_tipo_cliente: this.elementD.item.zc_tipo_cliente,
            zdc_folio_client: this.elementD.item.zc_folio_client,
            zdc_fech_crea: this.elementD.item.zc_fech_crea,
            zdc_fech_mod: this.elementD.item.zc_fech_mod,
            zdc_usua_delet: this.idUser,
            zdc_motivo: this.motivo,
            zdc_id_sucursal: this.elementD.item.zc_id_sucursal,
          }
          this.create()
          this.eliminatedUser()
          this.delete()
        }
      },
      delete(){
        let URL= 'http://127.0.0.1:8000/cliente/clientes/'+ this.elementD.item.zc_id_cliente
        axios.delete(URL)
        .then(response => {
          this.dialog = false
          window.location.reload()
        })
      },
      create(){
        axios.post('http://127.0.0.1:8000/cliente/historicoClientes/', this.element)
        .catch(error => console.log(error));
      },
      findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .then(res => this.idUser = res.data.user)
      },
      fecha(date){
        return moment(date).locale('MX').format('YYYY-MM-DD LT')
      },
      eliminatedUser(elementD){
        let URL = 'http://127.0.0.1:8000/usuario/getusuario/'+this.elementD.item.zc_id_usuario+'/'
          axios.put(URL,{
            zdus_correo: this.elementD.item.zc_correo,
            is_active: false,
            is_eliminated: true,
          }).catch(error => console.log(error))
      },
    },
  }
</script>