<!--Autor: Elisa Huerta - Coautor: Mario Alonso
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro
Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra los detalles de los datos del cliente.-->

<template>
    <v-container grid-list-xs>
      <v-dialog  max-width="600">
        <template v-slot:activator="{ on, attrs }">
          <p v-bind="attrs" v-on="on" class="blue--text">
            <strong>{{elements.zc_nombre}} {{elements.zc_apell_pat}} {{elements.zc_apell_mat}}</strong>
        </p>
        
      </template>
      
      <v-card>
        <v-card-title class="headline">
        </v-card-title>
        <v-card-text>

          <v-alert dense text type="success" v-if="elements.zc_existen == true">
            El Cliente: <strong>{{elements.zc_nombre}} {{elements.zc_apell_pat}} {{elements.zc_apell_mat}}</strong> esta habilitado
          </v-alert> 
          <v-alert dense text type="warning" color="red" v-if="elements.zc_existen == false">
            El Cliente: <strong>{{elements.zc_nombre}} {{elements.zc_apell_pat}} {{elements.zc_apell_mat}}</strong> esta deshabilitado
          </v-alert>

          <div class="black--text">
            
             <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DE CONTACTO</h3>
                </v-alert>
            <div align="center">
            <p><strong>Folio </strong><br>{{elements.zc_folio_client}}</p>
             <p><strong>Tipo de Cliente:</strong><br>
                 
              <v-chip
                class="ma-2"
                :color="colortipo(elements.zc_tipo_cliente)"
                outlined
              >
              {{tipo(elements.zc_tipo_cliente)}}
              </v-chip>
              </p>

            <p><strong>Teléfono:</strong> {{elements.zc_num_telefono}} ---- <strong>Celular: </strong>{{elements.zc_num_cell}}</p>
            <p><strong>Correo Electrónico </strong><br>{{elements.zc_correo}}</p>
            <p><strong>Fecha de Nacimiento </strong><br>{{elements.zc_fech_nacim}}</p>
            <v-alert color="grey lighten-4" dense align="center">
             <h3>DATOS DE DIRECCIÓN</h3>
            </v-alert>
            <v-row align="center">
            <v-col align="center">
  
                <p class="mb-0">{{elements.zc_dir_municipio}} {{elements.zc_dir_estado}}, {{elements.zc_dir_pais}}</p>
                <p style="font-size:13px;"><strong>Lugar de recidencia</strong></p> <p class="mb-0"> {{elements.zc_dir_municipio}}</p>
                <p style="font-size:13px;"><strong>Ciudad</strong></p>
               
            </v-col>
           </v-row>
          <v-alert color="grey lighten-4" dense align="center">
           <v-row>
          
             <v-col align="center">
                <p class="mb-0"> {{elements.zc_dir_colonia}}</p>
                <p style="font-size:13px;"><strong>Colonia</strong></p>
            </v-col>

             <v-col align="center">
                <p class="mb-0">  {{elements.zc_dir_calle_1}}</p>
                <p style="font-size:13px;"><strong>Calle Principal</strong></p>
            </v-col>

             <v-col align="center">
            
                <p class="mb-0">  {{elements.zc_dir_calle_2}}</p>
                <p style="font-size:13px;"><strong>Calle Interconexión</strong></p>
            </v-col>
            </v-row>
          </v-alert>
         

            <v-row>
             <v-col align="center">
                <p class="mb-0">  {{elements.zc_dir_num_ext}}</p>
                <p style="font-size:13px;"><strong>N° Exterior</strong></p>
            </v-col>
            <v-col align="center">
                <p class="mb-0">  {{elements.zc_dir_num_int}}</p>
                <p style="font-size:13px;"><strong>N° Interior</strong></p>
            </v-col>
             <v-col align="center">
                <p class="mb-0">  {{elements.zc_dir_cod_postal}}</p>
                <p style="font-size:13px;"><strong>C.P</strong></p>
            </v-col>
           </v-row>
          
          <v-alert color="grey lighten-4" dense align="center">
                  <h3>INFORMACIÓN GENERAL</h3>
          </v-alert>
          
           
            <p><strong>RFC: </strong>{{elements.zc_rfc}} ---- <strong>Saldo: </strong>{{elements.zc_saldo}}</p>
            <p><strong> ¿Cómo se enteró del distribuidor?</strong><br>{{elements.zc_enter_client}}</p>
            <p class="blue--text"><strong>SUCURSAL</strong><br><strong>Nombre:</strong> {{sucursal.zdsu_nombre}}<br><strong>Ubicación:</strong> {{sucursal.zdsu_dir_municipio}} {{sucursal.zdsu_dir_estado}}, {{sucursal.zdsu_dir_pais}}</p>
            <p class="red--text"><strong>Fecha de creación: </strong>{{fecha(elements.zc_fech_crea)}}</p>
            <p class="red--text"><strong>Fecha de ultima modificación: </strong>{{fecha(elements.zc_fech_mod)}}</p>
          </div>
        </div>
        
        </v-card-text>
      </v-card>
      
    </v-dialog>
  </v-container>
</template>

<script>
const moment = require('moment')
const axios = require('axios')
  
  export default {
    props:[
      'elements'
    ],
    created() {
      this.findSucursal()
    },
    data () {
      return {
        sucursal: '',
      }
    },
    methods:{
      tipo(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Mayorista"
          }
          else{
              cam_estatus="No es cliente mayorista"
          }
          return cam_estatus
      },
      colortipo(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/'+ this.elements.zc_id_sucursal +'/').
        then(res => this.sucursal = res.data)
      },
    },
  }
</script>