<!--Autor: Elisa Huerta - Apoyo: Mario Alonso
Descripción: Este archivo muestra un listado de todos los clientes que se han dado de alta a traves del formulario de registro-->

<template>
<div cols="full">
    <v-row>
      <v-col cols="md-2 xs-12">
        <menuModulos/>
      </v-col>
      
      <v-col cols="md-10 xs-12">
         <app-header style="z-index: 135"/> 
        <div align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">CLIENTES AFILIADOS</h1>
        </div><br>
        
        <v-card :elevation="0">
          <v-card-title class="card_title">
            <div class="col-12" id="table_cabecera_color">
              <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
              <v-btn dark text to="/clientesHistorico/" class="btn_csv" v-show="permissions.can_manage_cli_afi == true">
                Historial
              </v-btn>
                
              <v-btn dark text :to="'/Usuario/'" class="btn_add" v-show="permissions.can_manage_cli_afi == true">
                Agregar
              </v-btn>
            </div>
          </v-card-title>
          
          <div class="col-12" style="padding-top:0">
            <v-data-table
            
              id="tabla_datos"
              :headers="headers" 
              :items="elements"
              :search="search"
              no-results-text="Sin registros"
              no-data-text="No se tienen registros de clientes."
              :footer-props="{
                showFirstLastPage: true,
                itemsPerPageText: 'Elementos por página ',
                
              }">
              
                
                <template v-slot:item.zc_nombre="{ item }">
                  <sCliente :elements="item"/>
                </template>

                <template v-slot:item.zc_folio_client="{ item }">
                      {{item.zc_folio_client}}
                </template>
                
                <template v-slot:item.zc_dir_municipio="{ item }">
                  {{item.zc_dir_municipio}} {{item.zc_dir_estado}}, {{item.zc_dir_pais}}
                </template>
                
                
                <template v-slot:item.actions="{ item }">
                  <v-row align="center">
                    <v-col><dCliente :elementD="{item, permissions}"/></v-col>
                    <v-col>
                      <v-tooltip bottom>
                        <template v-slot:activator="{ on, attrs }">
                          <v-btn icon :to="'/acliente/'+ item.zc_id_cliente+'/'" v-bind="attrs" v-on="on" v-if="permissions.can_manage_cli_afi == true">
                            <v-icon color="blue" >mdi-pencil-outline</v-icon>
                          </v-btn>
                           <v-btn icon v-bind="attrs" v-on="on" v-else disabled>
                            <v-icon color="blue" >mdi-pencil-outline</v-icon>
                          </v-btn>
                        </template>
                        <span>Editar</span>
                      </v-tooltip>
                    </v-col>
                    
                    <v-col>
                      <v-tooltip bottom v-if="item.zc_existen == true">
                        <template v-slot:activator="{ on, attrs }">
                          <v-icon color="success" @click="desactivar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_cli_afi == false">
                            mdi-eye
                          </v-icon>
                        </template>
                        <span>Desactivar</span>
                      </v-tooltip>
                      
                      <v-tooltip bottom v-if="item.zc_existen == false">
                        <template v-slot:activator="{ on, attrs }">
                          <v-icon  color="red" @click="activar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_cli_afi == false">
                            mdi-eye-off-outline
                          </v-icon>
                        </template>
                        <span>Activar</span>
                      </v-tooltip>
                    </v-col>
                    
                    <v-col>
                      <Tarjeta :element="{item, permissions}"/>
                    </v-col>
                  </v-row>
                </template>
            </v-data-table>
          </div>
        </v-card>
      </v-col>
    </v-row>
  </div>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')

  import menuModulos from '../menuModulos'
  import Tarjeta from './partials/PDFCliente'
  import sCliente from './DetalleCliente'
  import dCliente from './DeleteCliente'
  import styles from '../../../public/Styles'
  import Header from '../../components/Header';
  
  export default {
    name: 'Header', 
    components:{
      "app-header": Header,
      menuModulos,
      sCliente,
      dCliente,
      Tarjeta
    },
    
    created(){
      this.find()
    },
    
    data(){
      return{
        element:Object,
        search: '',
        headers: [
          { text: 'Nombre', align: 'start', value: 'zc_nombre', sortable: true},
          { text: 'Folio', value: 'zc_folio_client', sortable: true, filterable: true, align:'center'},
          { text: 'Número de celular', value: 'zc_num_cell', sortable: false, align:'center'},
          { text: 'Correo electrónico', value: 'zc_correo', sortable: false, align:'center'},
          { text: 'Acciones', value: 'actions', sortable: false, align:'center'},
        ],
        elements: [],
        permissions: {
            can_manage_cli_afi: false,
            //can_manage_cli_afi_hist:false,
        },
      }
    },
    
    methods: {
      find(){

         axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_cli_afi: true,
                                    //can_manage_cli_afi_hist:true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_clientes_afiliados') { this.permissions.can_manage_cli_afi = true}
                                                        //if(resPer.data.codename == 'manage_clientes_afiliados_histotico') { this.permissions.can_manage_cli_afi_hist = true}
                                                       
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })

        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
        .then(resUser => { 
          axios.get('http://127.0.0.1:8000/empleado/?search=' + resUser.data[0].user)
          .then(resEmp => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + resUser.data[0].user + '/')
            .then(resGetData=> { 
              if (resGetData.data.is_superuser == true){
                axios.get('http://127.0.0.1:8000/cliente/clientes/' )
                .then(res => this.elements = res.data)
              } else{
                axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + resEmp.data[0].zdem_id_sucursal )
                .then(res => this.elements = res.data)
              }
            }) 
          })
        })
        
      },
      
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      
      activar (m) {
        const URL = 'http://127.0.0.1:8000/cliente/clientes/'+m.zc_id_cliente+'/'
        axios.put(URL,{
          zc_nombre:m.zc_nombre,
          zc_apell_pat:m.zc_apell_pat,
          zc_apell_mat:m.zc_apell_mat,
          zc_fech_nacim:m.zc_fech_nacim,
          zc_num_telefono:m.zc_num_telefono,
          zc_num_cell:m.zc_num_cell,
          zc_rfc:m.zc_rfc,
          zc_correo:m.zc_correo,
          zc_dir_pais:m.zc_dir_pais,
          zc_dir_estado:m.zc_dir_estado,
          zc_dir_municipio:m.zc_dir_municipio,
          zc_dir_colonia:m.zc_dir_colonia,
          zc_dir_cod_postal:m.zc_dir_cod_postal,
          zc_dir_calle_1:m.zc_dir_calle_1,
          zc_dir_calle_2:m.zc_dir_calle_2,
          zc_dir_num_int:m.zc_dir_num_int,
          zc_dir_num_ext:m.zc_dir_num_ext,
          zc_saldo:m.zc_saldo,
          zc_existen:true,
          zc_id_sucursal:m.zc_id_sucursal,
          zc_id_usuario:m.zc_id_usuario,
          zc_enter_client:m.zc_enter_client,
          zc_folio_client:m.zc_folio_client,
          zc_tipo_cliente:m.zc_tipo_cliente,
        }).catch(error => console.log(error))
        
        const URLUpdate = 'http://127.0.0.1:8000/usuario/getusuario/'+m.zc_id_usuario+'/'
        axios.put(URLUpdate,{
          zdus_correo:m.zc_correo,
          is_active: true,
        }).catch(error => console.log(error))
        window.location.reload()
      },
      
      desactivar (m) {
        const URL = 'http://127.0.0.1:8000/cliente/clientes/'+m.zc_id_cliente+'/'
        axios.put(URL, {
          zc_nombre:m.zc_nombre,
          zc_apell_pat:m.zc_apell_pat,
          zc_apell_mat:m.zc_apell_mat,
          zc_fech_nacim:m.zc_fech_nacim,
          zc_num_telefono:m.zc_num_telefono,
          zc_num_cell:m.zc_num_cell,
          zc_rfc:m.zc_rfc,
          zc_correo:m.zc_correo,
          zc_dir_pais:m.zc_dir_pais,
          zc_dir_estado:m.zc_dir_estado,
          zc_dir_municipio:m.zc_dir_municipio,
          zc_dir_colonia:m.zc_dir_colonia,
          zc_dir_cod_postal:m.zc_dir_cod_postal,
          zc_dir_calle_1:m.zc_dir_calle_1,
          zc_dir_calle_2:m.zc_dir_calle_2,
          zc_dir_num_int:m.zc_dir_num_int,
          zc_dir_num_ext:m.zc_dir_num_ext,
          zc_saldo:m.zc_saldo,
          zc_existen:false,
          zc_id_sucursal:m.zc_id_sucursal,
          zc_id_usuario:m.zc_id_usuario, 
          zc_enter_client:m.zc_enter_client,
          zc_folio_client:m.zc_folio_client,
          zc_tipo_cliente:m.zc_tipo_cliente,
        }).catch(error => console.log(error))
        
        const URLUpdate = 'http://127.0.0.1:8000/usuario/getusuario/'+m.zc_id_usuario+'/'
        axios.put(URLUpdate,{
          zdus_correo:m.zc_correo,
          is_active: false,
        }).catch(error => console.log(error))
        window.location.reload()
      },
    },
    
  }
</script>