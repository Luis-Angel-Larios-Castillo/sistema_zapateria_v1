<!--Autor: Elisa Huerta - Coautor: Mario Alonso
Descripción: Este archivo permite llevar a cabo la edición de un registro a traves de un formulario
el cual recupera los datos asociados a ese registro
Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra la actualización de los datos del cliente.-->

<template>
    <v-container fluid>
      <div v-if="permissions.can_manage_cli_afi == true">
         <app-header style="z-index: 135"/> 
     <div class="col-10">
           <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          <v-toolbar-title>
            <v-icon right dark>
              mdi-account-convert
            </v-icon>
            <strong id="title_editar"> Edición del cliente: {{elementU.zc_nombre}} {{elementU.zc_apell_pat}} {{elementU.zc_apell_mat}}</strong>
            
            </v-toolbar-title>
            <v-spacer/>
            <v-chip color="#F7F9F9"  outlined> FOLIO: {{elementU.zc_folio_client}}</v-chip>
            <v-spacer/>
            <v-btn to="/Clientes/" outlined class="btn_add" color="#F7F9F9">
              Regresar
            </v-btn>
        </v-toolbar>

       
          <v-container  id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>
              <v-alert id="title_formulario" dense icon="mdi-account-check">
                <strong>DATOS PERSONALES</strong>
              </v-alert>
              <v-row>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zc_nombre" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zc_apell_pat" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zc_apell_mat" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="4">
                <v-menu
                  ref="menu"
                  v-model="menu"
                  :close-on-content-click="false"
                  :return-value.sync="fecha"
                  transition="scale-transition"
                  offset-y
                  min-width="auto">
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      v-model="elementU.zc_fech_nacim"
                      label="Fecha de Nacimiento:"
                      prepend-icon="mdi-calendar"
                      readonly
                      v-bind="attrs"
                      v-on="on">
                    </v-text-field>
                  </template>
                  <v-date-picker
                    v-model="elementU.zc_fech_nacim"
                    no-title
                    locale="es-mx"
                    scrollable>
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                      Cancelar
                    </v-btn>
                    <v-btn
                      text
                      color="primary"
                      @click="$refs.menu.save(fecha)">
                      Guardar
                    </v-btn>
                  </v-date-picker>
                </v-menu>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zc_rfc" :rules="rfcRules" label="RFC:" required :counter="15" oninput="this.value=this.value.replace(/[^A-Za-z-ñÑáÁéÉíÍóÓúÚ0-9 ]/g,'');" placeholder="Ejem. SND-861121" maxlength="15"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zc_saldo" :rules="saldoRules" label="Saldo:" required :counter="8" oninput="this.value=this.value.replace(/[^0-9.]/g,'');" placeholder="Ejem. 1500" maxlength="8"></v-text-field>
                </v-col>
              </v-row>
             <v-alert id="title_formulario" dense icon="mdi-home">
                <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
              </v-alert>
              <v-row>
                <v-col>
                  <v-text-field v-model="elementU.zc_dir_pais" :rules="paisRules" label="País:" required :counter="20" readonly></v-text-field>
                </v-col>
                <v-col>
                  <v-select v-model="elementU.zc_dir_estado" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="[v => !!v || 'Se requiere seleccionar un Estado.']" label="Estado:" required/>
                </v-col>
                <v-col>
                  <v-select v-model="elementU.zc_dir_municipio" :items="municipio" item-text="name" :rules="[v => !!v || 'Se requiere seleccionar un Municipio.']" label="Municipio:" required/>
                </v-col>
                <v-col>
                  <v-text-field v-model="elementU.zc_dir_colonia" :rules="colRules" label="Barrio/Colonia:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. El Bosque" maxlength="20"></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col>
                  <v-text-field v-model="elementU.zc_dir_calle_1" :rules="callPrinRules" label="Calle Principal:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos" maxlength="50"></v-text-field>
                </v-col>
                <v-col>
                  <v-text-field v-model="elementU.zc_dir_calle_2" :rules="callIntRules" label="Calle/s de Interconexión:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita" maxlength="50"></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_dir_cod_postal" :rules="codPostalRules" label="Código Postal:" oninput="this.value=this.value.replace(/[^0-9]/g,'');" required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_dir_num_ext" :rules="numExtRules" label="Núm. Exterior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_dir_num_int" :rules="numIntRules" label="Núm. Interior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N"></v-text-field>
                </v-col>
                <v-col cols="3" >
                  <v-select v-model="elementU.zc_id_sucursal" :items="sucursales" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una Sucursal']"  label="Sucursal de entrega" required/>
                </v-col>
              </v-row>
              <v-alert id="title_formulario" dense icon="mdi-card-account-phone">
                <strong>INFORMACIÓN DE CONTACTO</strong>
              </v-alert>
              <v-row>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_num_telefono" v-mask="'###-###-##-##'" max="13" :rules="telDomRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono Domiciliar:" required counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos"></v-text-field>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_num_cell" v-mask="'###-###-##-##'" max="13" :rules="telCelRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Número de Celular:" required counter placeholder="Ejem. 245-875-35-20" title="Sólo se permiten datos númericos"></v-text-field>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zc_correo" :rules="correoRules" label="Correo Electrónico:" required :counter="30" maxlength="30"></v-text-field>
                </v-col>
                <v-col cols="3" >
                <v-switch
                  v-model="elementU.zc_tipo_cliente" 
                  inset 
                  label="¿Es mayorista?"></v-switch>
                      
                </v-col>
              </v-row>
               <v-row>
              <v-col
                  cols="20"
                  md="12"
                >
                <v-textarea solo v-model="elementU.zc_enter_client" :rules="enterarseRules" outlined label="¿Cómo se enteró del distribuidor?" required :counter="150"  maxlength="150" background-color="#D5D8DC" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');"></v-textarea>
              </v-col>
              </v-row>   
              <br><br>
              <v-row align="center" justify="space-around">
                <v-btn :disabled="!valid" x-large id="btn_actualizar_formulario" class="mr-4" @click="validate">
                    Actualizar 
                    <v-icon right dark>
                        mdi-update
                    </v-icon>
                </v-btn>
                <v-btn  x-large class="mr-4" id="btn_cancelar_formulario" @click="cancelar">
                   Cancelar
                    <v-icon right dark>
                        mdi-close-circle
                    </v-icon>
                </v-btn>
            </v-row>
            </v-form>
          </v-container>
       
        </div>
      </div>
      <div v-else>
         <ErrorPage403/>
      </div>
    </v-container>
</template>

<script>
  import Header from '../../components/Header';
  import ErrorPage403 from '../../components/ErrorPage403.vue'
  import esta from "../../assets/json/muni.json";
  const axios = require('axios')
  
  export default {
     name: 'Header', 
    components:{
      "app-header": Header,
    ErrorPage403
  },
    data: () => ({
      elementU:[],
      valid: true,
      search: null,
      menu: false,
      fecha: new Date().toISOString().substr(0, 10),

      //Sección de datos personales
      nameRules: [
        v => !!v || 'Se requiere ingresar un Nombre.',
        v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
      ],
      apepRules: [
        v => !!v || 'Se requiere ingresar un Apellido Paterno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
      ],
      apemRules: [
        v => !!v || 'Se requiere ingresar un Apellido Materno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',
      ],
      rfcRules: [
        v => !!v || 'Se requiere ingresar un RFC.',
        v => (v && v.length >= 10) || 'El campo "RFC" debe tener más de 10 caracteres.',
        v => (v && v.length <= 15) || 'El campo "RFC" no debe tener más de 15 caracteres.',
      ],
      saldoRules: [
        v => !!v || 'Se requiere ingresar un Saldo.',
        //v => (v && v.length >= 1) || 'El campo "Saldo" debe tener más de 1 caracter.',
        //v => (v && v.length <= 5) || 'El campo "Saldo" no debe tener más de 5 caracteres.',
      ],
       enterarseRules:[
       v => !!v || 'Se requiere ingresar ¿Cómo se enteró del distribuidor?.',
       v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
       v => (v && v.length >= 15) || 'El campo debe tener más de 15 caracteres.',
       v => (v && v.length <= 150) || 'El campo no debe tener más de 150 caracteres.',
      
     ],
      //Sección de datos de lugar de residencia
      paisRules: [
        v => !!v || 'Se requiere ingresar un País.',
        v => (v && v.length >= 3) || 'El campo "País" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "País" no debe tener más de 20 caracteres.',
      ],
      estado: esta,
      municipio: [],
      colRules: [
        v => !!v || 'Se requiere ingresar una Colonia.',
        v => (v && v.length >= 5) || 'El campo "Colonia" debe tener más de 5 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Colonia" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Colonia" debe ser mayúscula',
      ],
      callPrinRules: [
        v => !!v || 'Se requiere ingresar una Calle Principal.',
        v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El campo "Calle Principal" no debe tener más de 50 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',
      ],
      callIntRules: [
        v => !!v || 'Se requiere ingresar entre que calles se encuentra su domicilio.',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El registro no debe tener más de 50 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
      ],
      codPostalRules: [
        v => !!v || 'Se requiere ingresar un Código Postal.',
        v => (v && v.length == 5) || 'El campo "Código Postal" debe tener 5 caracteres.',
      ],
      numExtRules: [
        v => !!v || 'Se requiere ingresar un Número Exterior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Exterior" no debe tener más de 25 caracteres.',
      ],
      numIntRules: [
        v => !!v || 'Se requiere ingresar un Número Interior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Interior" no debe tener más de 25 caracteres.',
      ],
      sucursales: [],

      //Sección de datos de contacto
      telDomRules: [
        v => !!v || 'Se requiere ingresar un Número de Teléfono Domiciliar.',
        v => (v && v.length == 13) || 'El campo "Teléfono Domiciliar" debe tener al menos 10 caracteres.',
      ],
      telCelRules: [
        v => !!v || 'Se requiere ingresar un Número de Celular.',
        v => (v && v.length == 13) || 'El campo "Número de Celular" debe tener al menos 10 caracteres.',
      ],
      correoRules: [
        v => !!v || 'Se requiere ingresar un Correo electrónico.',
        v => /.+@.+\..+/.test(v) || 'El campo "Correo Electrónico" tine que ser valido',
        v => (v && v.length <= 30) || 'El campo "Correo Electrónico" no debe tener más de 30 caracteres.',
      ],
      permissions: {
            can_manage_cli_afi: false,
        },

    }),

    created() {
      this.busqpermisos()
      this.find()
      this.findSucursal()
    },
    
    methods: {

      busqpermisos(){

         axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_cli_afi: true,
                                 }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_clientes_afiliados') { this.permissions.can_manage_cli_afi = true}
                                                        
                                                       
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })
      },


      filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.elementU.zc_dir_estado )
            this.municipio = this.estado[i].municipios
        } 
      },
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
          .then(res => this.sucursales = res.data)
      },
      find(){
        axios.get('http://127.0.0.1:8000/cliente/clientes/'+ this.$route.params.id +'/').
        then(res => {
          this.elementU = res.data
          this.filtar()
        })
      },
      validate () {
        this.$refs.form.validate()
        this.update()
        this.updatedEmailUser()
      },
      async update(){
        await axios.put('http://127.0.0.1:8000/cliente/clientes/'+ this.$route.params.id +'/',this.elementU)
        .catch(error => console.log(error));
        this.$router.push({ name: 'Clientes' });
      },
      updatedEmailUser(elementU){
        let URL = 'http://127.0.0.1:8000/usuario/getusuario/'+this.elementU.zc_id_usuario+'/'
          axios.put(URL,{
            zdus_correo: this.elementU.zc_correo,
          }).catch(error => console.log(error))
      },
      cancelar () {
        this.$router.push({ name: 'Clientes' });
      },
    },
  }
</script>