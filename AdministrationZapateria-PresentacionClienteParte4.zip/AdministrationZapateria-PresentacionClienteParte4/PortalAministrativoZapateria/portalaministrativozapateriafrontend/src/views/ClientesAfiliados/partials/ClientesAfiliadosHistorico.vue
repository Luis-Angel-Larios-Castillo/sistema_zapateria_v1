<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo muestra un listado de todos los clientes que han sido eliminados por
un administrador u empleado-->
<template>
    <div cols="full">
        <v-row>
            <v-col cols="md-2 xs-12">
                <menuModulos/>
            </v-col>
            <v-col cols="md-10 xs-12">
                 <div align="center" justify="space-around">
                    <hr class="line_superior">
                    <h1 id="title"> HISTÓRICO DE CLIENTES</h1>
                 </div><br>

                <v-card :elevation="0">
                    <v-card-title class="card_title">
                         <div class="col-12" id="table_cabecera_color">
                         <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                         <v-btn to="/Clientes/" outlined class="btn_add" color="#F7F9F9">
                        <v-icon>
                        mdi-arrow-left-circle
                        </v-icon>
                        Regresar
                        </v-btn>
                         </div>
                    </v-card-title>

                <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                        :headers="headers" 
                        :items="elements"
                        :search="search"
                        no-results-text="Sin registros"
                        no-data-text="No se tienen clientes eliminados." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }">
                        <template v-slot:item.zdc_nombre="{ item }">
                                <sClientesHistorico :element="item"/>
                        </template>

                        <template v-slot:item.zdc_dir_municipio="{ item }">
                                {{item.zdc_dir_municipio}} {{item.zdc_dir_estado}}, {{item.zdc_dir_pais}}
                        </template>
                        <template v-slot:item.zdc_fech_crea="{ item }">
                                {{fecha(item.zdc_fech_crea)}}
                        </template>
                        <template v-slot:item.zdc_fech_delet="{ item }">
                                {{fecha(item.zdc_fech_delet)}}
                        </template>
                    </v-data-table>
                </div>
                </v-card>
            </v-col>
        </v-row><br>
    </div>
</template>

<script>
import menuModulos from '../../menuModulos'
import sClientesHistorico from './sClientesHistorico'

    const moment = require('moment')
    const axios = require('axios')
    export default {
        components:{
            menuModulos,
            sClientesHistorico,
        },
        created() {
            this.find()
        },
        data () {
            return {
                element: Object,
                search: '',
                headers: [
                    { text: 'Nombre', align: 'start', filterable: true, value: 'zdc_nombre', sortable: true},
                    { text: 'Folio', align: 'start', value: 'zdc_folio_client', sortable: false},
                    { text: 'Número de contacto', value: 'zdc_num_cell', sortable: false },
                    { text: 'Correo electrónico', value: 'zdc_correo', sortable: false },
                    { text: 'Lugar de residencia', value: 'zdc_dir_municipio', sortable: true },
                    { text: 'Fecha de creación', value: 'zdc_fech_crea', sortable: true },
                    { text: 'Fecha de eliminación', value: 'zdc_fech_delet', sortable: true },
                ],
                elements: [],
            }
        },
        methods:{
            find(){
                axios.get('http://127.0.0.1:8000/cliente/historicoClientes/')
                .then(res => this.elements = res.data)
            },
            fecha(date){
                return moment(date).locale('MX').format('DD-MM-YYYY LT')
            },
        },
    }
</script>