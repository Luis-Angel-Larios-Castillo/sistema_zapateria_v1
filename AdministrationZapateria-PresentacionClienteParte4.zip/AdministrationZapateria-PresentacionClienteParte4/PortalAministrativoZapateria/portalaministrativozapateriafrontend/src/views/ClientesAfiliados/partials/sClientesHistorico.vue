<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zdc_nombre}} {{element.zdc_apell_pat}} {{element.zdc_apell_mat}}</strong>
        </p>
      </template>

      <v-card>
        <v-card-title class="headline">
        </v-card-title>
        <v-card-text>
          <v-alert dense type="info">
            Cliente: <strong>{{element.zdc_nombre}} {{element.zdc_apell_pat}} {{element.zdc_apell_mat}}</strong>
          </v-alert>
          <div class="black--text"> 
           <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DE CONTACTO</h3>
              </v-alert>
            <div align="center">
             <p><strong>Folio </strong><br>{{element.zdc_folio_client}}</p>
             <p><strong><i>Tipo de Cliente:</i></strong><br>
             <v-chip
                class="ma-2"
                :color="colortipo(element.zdc_tipo_cliente)"
                outlined
              >
              {{tipo(element.zdc_tipo_cliente)}}
              </v-chip>
              </p>
            <p><strong>Teléfono:</strong> {{element.zdc_num_telefono}} ---- <strong>Celular: </strong>{{element.zdc_num_cell}}</p>
            <p><strong>Correo Electrónico </strong><br>{{element.zdc_correo}}</p>
            <p><strong>Fecha de Nacimiento </strong><br>{{element.zdc_fech_nacim}}</p>
            <v-alert color="grey lighten-4" dense align="center">
             <h3>DATOS DE DIRECCIÓN</h3>
            </v-alert>
             <v-row align="center">
            <v-col align="center">
  
                <p class="mb-0">{{element.zdc_dir_municipio}} {{element.zdc_dir_estado}}, {{element.zdc_dir_pais}}</p>
                <p style="font-size:13px;"><strong>Lugar de recidencia</strong></p> <p class="mb-0"> {{element.zdc_dir_municipio}}</p>
                <p style="font-size:13px;"><strong>Ciudad</strong></p>
               
            </v-col>
           </v-row>

           <v-alert color="grey lighten-4" dense align="center">
           <v-row>
          
             <v-col align="center">
                <p class="mb-0"> {{element.zdc_dir_colonia}}</p>
                <p style="font-size:13px;"><strong>Colonia</strong></p>
            </v-col>

             <v-col align="center">
                <p class="mb-0">  {{element.zdc_dir_calle_1}}</p>
                <p style="font-size:13px;"><strong>Calle Principal</strong></p>
            </v-col>

             <v-col align="center">
            
                <p class="mb-0">  {{element.zdc_dir_calle_2}}</p>
                <p style="font-size:13px;"><strong>Calle Interconexión</strong></p>
            </v-col>
            </v-row>
          </v-alert>
         

            <v-row>
             <v-col align="center">
                <p class="mb-0">  {{element.zdc_dir_num_ext}}</p>
                <p style="font-size:13px;"><strong>N° Exterior</strong></p>
            </v-col>
            <v-col align="center">
                <p class="mb-0">  {{element.zdc_dir_num_int}}</p>
                <p style="font-size:13px;"><strong>N° Interior</strong></p>
            </v-col>
             <v-col align="center">
                <p class="mb-0">  {{element.zdc_dir_cod_postal}}</p>
                <p style="font-size:13px;"><strong>C.P:</strong></p>
            </v-col>
           </v-row>
            <v-alert color="grey lighten-4" dense align="center">
                  <h3>INFORMACIÓN GENERAL</h3>
          </v-alert>
            <p><strong>RFC: </strong>{{element.zdc_rfc}} ---- <strong>Saldo: </strong>{{element.zdc_saldo}}</p>
            <p class="black--text"><strong>Motivo: </strong><br>{{element.zdc_motivo}}</p>
            <p><strong> ¿Cómo se enteró del distribuidor?</strong><br>{{element.zdc_enter_client}}</p>
            <!--<p class="black--text">
              {{findEmpleado(element.zdc_usua_delet)}}
              <div v-for="empleado in empleado" :key="empleado.id"><strong>Usuario que elimino el registro: </strong><br>
                {{empleado.zdem_nombre}} {{empleado.zdem_apell_pat}} {{empleado.zdem_apell_mat}}<br>
              </div>
            </p>
            <p><strong>Correo del usuario que elimino el registro: </strong><br>{{elements.zdus_correo}}</p>-->
            <p class="black--text" v-if="this.elements.is_superuser==false">
              <strong>Empleado que elimino el registro: </strong><br>
                {{empleado.nombre}}<br>
            </p>
            <p v-else><strong>Correo del usuario que elimino el registro: </strong><br>{{elements.zdus_correo}}</p>
            
            <p class="blue--text"><strong>SUCURSAL</strong><br><strong>Nombre:</strong> {{sucursal.zdsu_nombre}}<br><strong>Ubicación:</strong> {{sucursal.zdsu_dir_municipio}} {{sucursal.zdsu_dir_estado}}, {{sucursal.zdsu_dir_pais}}</p>

            <v-chip class="ma-2" color="primary" outlined pill v-if="usuario.is_active == true">
              Usuario Activo
              <v-icon right>
                mdi-account-outline
              </v-icon>
            </v-chip>
            <v-chip class="ma-2" color="pink" outlined pill v-if="usuario.is_active == false">
              Usuario Inactivo
              <v-icon right>
                mdi-account-outline
              </v-icon>
            </v-chip>
            <v-chip class="ma-2" color="success" outlined pill v-if="usuario.is_superuser == true">
              Super Usuario
              <v-icon right>
                mdi-account-outline
              </v-icon>
            </v-chip>
            <v-chip class="ma-2" color="orange" outlined pill v-if="usuario.is_superuser == false">
              No Super Usuario
              <v-icon right>
                mdi-account-outline
              </v-icon>
            </v-chip><br><br>
            <p class="red--text"><strong>Fecha de creación: </strong>{{fecha(element.zdc_fech_crea)}}</p>
            <p class="red--text"><strong>Fecha de eliminación: </strong>{{fecha(element.zdc_fech_delet)}}</p>
          </div>
        </div>
        </v-card-text>
      </v-card>
      
    </v-dialog>
  </v-container>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')

  export default {
    props:[
      'element'
    ],
    created() {
      this.findUsuaDelete()
      this.findUsuario()
      //this.findEmpleado()
      this.findSucursal()
    },
    data () {
      return {
        elements: '',
        usuario: '',
        empleado: '',
        sucursal: '',
      }
    },
    
    methods:{
      tipo(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Mayorista"
          }
          else{
              cam_estatus="No es cliente mayorista"
          }
          return cam_estatus
      },
      colortipo(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      findUsuaDelete(){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ this.element.zdc_usua_delet +'/').
        then(res => {this.elements = res.data
        axios.get('http://127.0.0.1:8000/empleado/?search='+ this.element.zdc_usua_delet)
        .then(res => this.empleado = res.data[0])
        })
      },
      findUsuario(){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ this.element.zdc_id_usuario +'/').
        then(res => this.usuario = res.data)
      },
      /*findEmpleado(id_usuario){
        axios.get('http://127.0.0.1:8000/empleado/?search='+ id_usuario)
        .then(res => this.empleado = res.data)
      },*/
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/'+ this.element.zdc_id_sucursal + '/')
        .then(res => this.sucursal = res.data)
      },
    },
  }
</script>