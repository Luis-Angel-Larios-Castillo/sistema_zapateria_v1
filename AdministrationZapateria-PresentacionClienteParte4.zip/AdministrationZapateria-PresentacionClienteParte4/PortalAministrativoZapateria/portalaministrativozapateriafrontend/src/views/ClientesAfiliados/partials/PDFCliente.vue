<template>
  <v-container > 
    <v-tooltip bottom>
      <template v-slot:activator="{ on, attrs }">
        <v-btn icon @click="generatePDF" v-bind="attrs" v-on="on" :disabled="element.permissions.can_manage_cli_afi == false">
          <v-icon color="orange">mdi-file-document</v-icon>
        </v-btn>
      </template>
      <div v-show="false">{{fechaCreacion = fecha(this.element.item.zc_fech_crea)}}</div>
      <span>Tarjeta</span>
    </v-tooltip> 
  </v-container>
</template> 
<script>

const moment = require('moment')
import jsPDF from "jspdf"; 
export default {
  data() {
    return {
      fechaCreacion:'',
    }
  },
  props:[
    'element'
  ], 
  methods: {
    fecha(date){
      return moment(date).locale('MX').format('DD-MM-YYYY')
    },
    generatePDF() {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "in",
        format: "letter"
      });  
              
        //DIseño de la tarjeta
        doc.setDrawColor(0);
        doc.setFillColor(222, 222, 222 ); 
        //Ubicación X, Ubicación Y, Largo, Alto, curbeado de las orillas
        doc.setLineWidth(0.05).roundedRect(1.70, 1.5, 3.5, 2.2, .3, .3, "FD");

        //Cuadrado blanco
        doc.setDrawColor(0);
        doc.setFillColor(255, 255, 255); 
        doc.setLineWidth(0.05).roundedRect(1.9, 1.7, 1.0, 1.10, 0, 0, "FD");

        let pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();
        //Sección de firma y sello
        doc.setFont(undefined, 'bold').setFontSize(7).text("Firma y/o Sello", pageWidth / 3.55, 1.9, {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(7).text("de Autorización", pageWidth / 3.55, 2.02, {align: 'center'});
        
        //Sección de cabezado de la tarjeta
        doc.setFont(undefined, 'bold').setFontSize(18).text("Zapatería Deny´s", pageWidth / 2.1, 1.9, {align: 'center'}); 
        doc.setFont(undefined, 'bold').setFontSize(8).text("CALZADO POR CATÁLOGO", pageWidth / 2.1, 2.1, {align: 'center'});

        //Sección del nombre del cliente
        doc.setFont(undefined, 'bold').setFontSize(11).text("NOMBRE", pageWidth / 2.50, 2.35, {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(10).text(this.element.item.zc_apell_pat, pageWidth / 2.77, 2.50,  {align: 'left'});
        doc.setFont(undefined, 'bold').setFontSize(10).text(this.element.item.zc_apell_mat, pageWidth / 2.77, 2.66,  {align: 'left'});
        doc.setFont(undefined, 'bold').setFontSize(10).text(this.element.item.zc_nombre, pageWidth / 2.77, 2.82,  {align: 'left'});

        //Sección fecha de registro
        doc.setFont(undefined, 'bold').setFontSize(11).text("FECHA DE", pageWidth / 1.85, 2.35, {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(11).text("REGISTRO", pageWidth / 1.85, 2.50, {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(10).text(this.fechaCreacion, pageWidth / 1.85, 2.72,  {align: 'center'});

        //Linea Azul
        doc.setDrawColor(0);
        doc.setFillColor(20, 33, 61); 
        doc.setLineWidth(0.05).roundedRect(1.7, 2.9, 3.5, .15, 0, 0, "FD");

        //Sección de domicilio
        doc.setFont(undefined, 'bold').setFontSize(11).text("DOMICILIO", pageWidth / 2.5, 3.25, {align: 'center'}); 
        doc.setFont(undefined, 'bold').setFontSize(9).text("C "+this.element.item.zc_dir_calle_1 + " " + this.element.item.zc_dir_num_ext + ", entre " + this.element.item.zc_dir_calle_2, pageWidth / 2.55, 3.41,  {align: 'center'});
        doc.setFont(undefined, 'bold').setFontSize(9).text(this.element.item.zc_dir_colonia + " " + this.element.item.zc_dir_cod_postal + " " + this.element.item.zc_dir_municipio + ", " + this.element.item.zc_dir_estado, pageWidth / 2.45, 3.55,  {align: 'center'});
        doc.save(`${'Tarjeta Cliente - ' + this.element.item.nombre}.pdf`);
    }
  },
}
</script> 