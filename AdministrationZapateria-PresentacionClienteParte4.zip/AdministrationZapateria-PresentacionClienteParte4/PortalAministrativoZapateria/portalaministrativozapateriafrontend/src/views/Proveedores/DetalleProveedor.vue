Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra los detalles de los datos del proveedor.

<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{elements.zp_nombre}}  {{elements.zp_apell_pat}} {{elements.zp_apell_mat}} </strong>
        </p>
          
      </template>
      <v-card>
        <v-card-title class="headline">
  
        </v-card-title>
        <v-card-text>
            <v-alert dense text type="success" v-if="elements.zp_existen == true" >
                El proveedor: <strong>{{elements.zp_nombre}} {{elements.zp_apell_pat}} {{elements.zp_apell_mat}}</strong> Esta habilitado. 
            </v-alert>
            <v-alert dense text type="warning"  color="red" v-if="elements.zp_existen == false" >
                El proveedor: <strong>{{elements.zp_nombre}} {{elements.zp_apell_pat}} {{elements.zp_apell_mat}}</strong> Esta deshabilitado.
            </v-alert>

            <div class="black--text"> 

              <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DE CONTACTO</h3>
                </v-alert>

                <p><strong>RFC:  </strong> {{elements.zp_rfc}}   ---- <strong>Identificador:  </strong>{{elements.zp_identify_mark}} </p>
                <p><strong>Teléfono: </strong>{{elements.zp_num_telefono}}  ---- <strong>Celular: </strong>{{elements.zp_num_cell}} </p>
                <p><strong>Correo: </strong> <br>{{elements.zp_correo}}</p>
                <v-alert color="grey lighten-4" dense align="center">
                <h3>DATOS DE DIRECCIÓN</h3>
                </v-alert>
                <v-row align="center">
                <v-col align="center">  
                <p class="mb-0">{{elements.zp_dir_municipio}} {{elements.zp_dir_estado}},  {{elements.zp_dir_pais}} </p>
                    <p style="font-size:13px;"><strong>Lugar de recidencia</strong></p> <p class="mb-0"> {{elements.zp_dir_municipio}}</p>
                    <p style="font-size:13px;"><strong>Ciudad</strong></p>

                
                </v-col>
               </v-row>
               <v-alert color="grey lighten-4" dense align="center">
                <v-row>
                 <v-col align="center">
                <p class="mb-0"> {{elements.zp_dir_colonia}}</p>
                <p style="font-size:13px;"><strong>Colonia</strong></p>
                </v-col>
                 <v-col align="center">
                <p class="mb-0">  {{elements.zp_dir_calle_prin}}</p>
                <p style="font-size:13px;"><strong>Calle Principal</strong></p>
                </v-col>
               <v-col align="center">
            
                <p class="mb-0">  {{elements.zp_dir_calle_inter}}</p>
                <p style="font-size:13px;"><strong>Calle Interconexión</strong></p>
               </v-col>
                 </v-row>
                 </v-alert>
                 <v-row>
                <v-col align="center">
                <p class="mb-0">  {{elements.zp_dir_num_ext}}</p>
                <p style="font-size:13px;"><strong>N° Exterior</strong></p>
               </v-col>
               <v-col align="center">
                <p class="mb-0">  {{elements.zp_dir_num_int}}</p>
                <p style="font-size:13px;"><strong>N° Interior</strong></p>
               </v-col>  
                <v-col align="center">
                <p class="mb-0">  {{elements.zp_dir_cod_postal}}</p>
                <p style="font-size:13px;"><strong>C.P</strong></p>
            </v-col>
                </v-row>
                <v-col align="center">
                <p class="red--text"><strong>Fecha de creación: </strong> {{fecha(elements.zp_fech_crea)}}</p>
                <p class="red--text"><strong>Fecha de modificación: </strong> {{fecha(elements.zp_fech_mod)}}</p>
                </v-col>
            </div>
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const moment = require('moment')
export default {
    props:[
        'elements'
    ],
    data(){
        return {          
        };
    },
    methods:{
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
    },
}
</script>