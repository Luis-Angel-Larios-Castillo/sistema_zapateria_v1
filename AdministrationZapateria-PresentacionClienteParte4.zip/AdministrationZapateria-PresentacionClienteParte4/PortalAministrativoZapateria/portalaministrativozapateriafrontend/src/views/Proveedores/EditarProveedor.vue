Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra la actualización de los datos del proveedor.
<template>
  <v-container fluid>   
     <div v-if="permissions.can_manage_proveedores == true">
        <app-header style="z-index: 135"/> 
        <br>
    <div class="col-10">
     <v-toolbar style="max-width: 1300px" class="" flat align="center" justify="space-around" id="table_cabecera_color_formulario">
       <v-toolbar-title>
            <v-icon right dark>
              mdi-account-convert
            </v-icon>
            <strong id="title_editar"> Edición del proveedor: {{actualizar.zp_nombre}} {{actualizar.zp_apell_pat}} {{actualizar.zp_apell_mat}}</strong>
            
            </v-toolbar-title>
            <v-spacer/>
            <v-btn to="/Proveedores/" outlined class="btn_add" color="#F7F9F9">
              Regresar
            </v-btn>
       </v-toolbar>
  
        <v-container>
          <v-form ref="form" id="tabla_datos_dos" v-model="valid" lazy-validation  class="col-12" style="padding-top:30">
          <v-alert id="title_formulario" dense icon="mdi-account-check">
                <strong>DATOS PERSONALES</strong>
              </v-alert> 
        
        
          <v-row>
            <v-col cols="4">
              <v-text-field v-model="actualizar.zp_nombre" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"> </v-text-field>
            </v-col>
            <v-col cols="4">
              <v-text-field v-model="actualizar.zp_apell_pat" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
            </v-col>
            <v-col cols="4">
              <v-text-field v-model="actualizar.zp_apell_mat" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
            </v-col>
          </v-row>
          <v-row>
          <v-col>
          <v-text-field v-model="actualizar.zp_rfc" :rules="rfcRules" label="RFC:" required :counter="15" oninput="this.value=this.value.replace(/[^A-Za-z-ñÑáÁéÉíÍóÓúÚ0-9 ]/g,'');" placeholder="Ejem. SND-861121" maxlength="15"></v-text-field>
          </v-col>
          <v-col>
          <v-text-field v-model="actualizar.zp_identify_mark" :rules="identifyRules" label="Identificador:" required :counter="15" oninput="this.value=this.value.replace(/[^A-Za-z-ñÑáÁéÉíÍóÓúÚ0-9 ]/g,'');" placeholder="Ejem. AND" maxlength="15"></v-text-field>
          </v-col>
          </v-row>
      
         <!-- Fin Datos Personales -->
          <br>


          <!-- Dirección - Lugar de Residencia -->
         
         
        <v-alert id="title_formulario" dense icon="mdi-home">
        <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
        </v-alert>
         
         <v-card-text>  
          <v-row>
            <v-col cols="3">
              <v-text-field v-model="actualizar.zp_dir_pais" readonly :rules="[v => !!v || 'Se requiere el país.']" label="País:" required :counter="20"/>
            </v-col> 
            <v-col cols="4">
              <v-select v-model="actualizar.zp_dir_estado" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="[v => !!v || 'Se requiere seleccionar un Estado.']" label="Estado:" required/>
            </v-col> 
            <v-col cols="5">
              <v-select v-model="actualizar.zp_dir_municipio" :items="municipio" item-text="name" :rules="[v => !!v || 'Se requiere seleccionar un Municipio.']" label="Municipio:" required/>
            </v-col> 
          </v-row>
          <v-row>
            <v-col cols="3">
              <v-text-field v-model="actualizar.zp_dir_colonia" :rules="coloniaRules" label="Barrio/Colonia:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. El Bosque" maxlength="20"/>
            </v-col>
            <v-col cols="4">
              <v-text-field v-model="actualizar.zp_dir_calle_prin" :rules="callpRules" label="Calle principal:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos" maxlength="50"/>
            </v-col>
            <v-col cols="5">
              <v-text-field v-model="actualizar.zp_dir_calle_inter" :rules="calliRules" label="Calle Interconexión:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita" maxlength="50"/>
            </v-col>  
             
             
          </v-row>
          <v-row>
            <v-col cols="3">
              <v-text-field v-model="actualizar.zp_dir_cod_postal" :rules="codigoRules" label="Código Postal:" oninput="this.value=this.value.replace(/[^0-9]/g,'');" required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
            </v-col>
             <v-col cols="5">
              <v-text-field v-model="actualizar.zp_dir_num_ext" :rules="numeRules" label="Número Exterior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"/>
            </v-col> 
            <v-col cols="4">
              <v-text-field v-model="actualizar.zp_dir_num_int" :rules="numRules" label="Número Interior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N"/>
            </v-col>  
           
          </v-row>
          </v-card-text>
         
         
         <!-- Inicio Información de Contacto -->
         
          <v-alert id="title_formulario" dense icon="mdi-card-account-phone">
          <strong>INFORMACIÓN DE CONTACTO</strong>
          </v-alert>

         <v-card-text> 
          <v-text-field v-model="actualizar.zp_correo" :rules="correoRules" label="Correo:" required :counter="30" maxlength="30"/>
          <v-row>
            <v-col cols="6">
              <v-text-field  v-model="actualizar.zp_num_telefono" v-mask="'###-###-##-##'" max="13" :rules="telRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono Domiciliar:" required counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos"></v-text-field>
                
            </v-col> 
            <v-col cols="6">
              <v-text-field  v-model="actualizar.zp_num_cell" v-mask="'###-###-##-##'" max="13" :rules="telcRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Número de Celular:" required counter placeholder="Ejem. 245-875-35-20" title="Sólo se permiten datos númericos"></v-text-field>
            </v-col> 
          </v-row>
         </v-card-text>
        
         <!-- Fin Información de Contacto -->  
         <br>
         
              
         <br>
         <v-row align="center" justify="space-around">
          <v-btn :disabled="!valid" x-large id="btn_actualizar_formulario" class="mr-4" @click="validate">
         Actualizar 
         <v-icon right dark>
         mdi-update
         </v-icon>
         </v-btn>
         <v-btn x-large id="btn_cancelar_formulario" class="mr-4" @click="cancelar">
          Cancelar
         <v-icon right dark>
          mdi-close-circle
         </v-icon>
         </v-btn> 
        
       </v-row> 
      </v-form> <br>

     </v-container>
   
    </div>
    </div>
      <div v-else>
         <ErrorPage403/>
      </div>
  </v-container>  
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
import esta from "../../assets/json/muni.json";
import axios from "axios";
  export default {
     name: 'Header', 
    components:{
         "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.buscar()
      
    },
    data: () => ({
      actualizar:[],
      proveedor:[],
      valid: true,

      identify_mark:'',
      identifyRules:[
       v => !!v || 'Se requiere el identificador.', 
       v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Identificador" debe ser mayúscula',
       v => (v && v.length >= 1) || 'El campo "Identificador" debe tener más de 10 caracteres.',
       v => (v && v.length <= 15) || 'El campo "Identificador" no debe tener más de 15 caracteres.',
      ],
      coloniaRules: [
        v => !!v || 'Se requiere el nombre de la colonia.',
        v => (v && v.length >= 5) || 'La colonia debe tener 5 o más caracteres',
      ], 
      nameRules: [
        v => !!v || 'Se requiere el nombre.',
        v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
      
      ],
      apepRules: [
        v => !!v || 'Se requiere el apellido paterno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
        
    
      ],

      apemRules: [
        v => !!v || 'Se requiere el apellido materno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',    
      ],
      pais: [
       
      ],
      estado: esta, 
      municipio: [],

      codigoRules: [
        v => !!v || 'Se requiere ingresar un Código Postal.',
        v => (v && v.length == 5) || 'El campo "Código Postal" debe tener 5 caracteres.',
      ],
      numRules: [
        v => !!v || 'Se requiere ingresar un Número Exterior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Exterior" no debe tener más de 25 caracteres.',
      ],
      callpRules: [
        v => !!v || 'Se requiere ingresar una Calle Principal.',
        v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El campo "Calle Principal" no debe tener más de 50 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',
      ],
      calliRules: [
       v => !!v || 'Se requiere ingresar entre que calles se encuentra su domicilio.',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El registro no debe tener más de 50 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
      ],
      numeRules: [
        v => !!v || 'Se requiere ingresar un Número Interior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Interior" no debe tener más de 25 caracteres.',
      ],

      rfcRules: [
         v => !!v || 'Se requiere ingresar un RFC.',
        v => (v && v.length >= 10) || 'El campo "RFC" debe tener más de 10 caracteres.',
        v => (v && v.length <= 15) || 'El campo "RFC" no debe tener más de 15 caracteres.',
      ],
      correoRules: [
        v => !!v || 'Se requiere el correo.',
        v => /.+@.+\..+/.test(v) || 'El correo tine que ser valido',
      ],

      telRules: [
        v => !!v || 'Se requiere ingresar un Número de Teléfono Domiciliar.',
        v => (v && v.length == 13) || 'El campo "Teléfono Domiciliar" debe tener al menos 10 caracteres.',
      ],

      telcRules: [
       
        v => !!v || 'Se requiere el número de celular.',
        v => (v && v.length == 13) || 'El campo "Número de Celular" debe tener al menos 10 caracteres.',
      ],

      correoRules: [
        v => !!v || 'Se requiere ingresar un Correo electrónico.',
        v => /.+@.+\..+/.test(v) || 'El campo "Correo Electrónico" tine que ser valido',
        v => (v && v.length <= 30) || 'El campo "Correo Electrónico" no debe tener más de 30 caracteres.',
      ],
      checkbox: false,
      permissions: {
          can_manage_proveedores: false,
        }, 
    }), 
     methods: { 
       findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_proveedores: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_proveedores') { this.permissions.can_manage_proveedores = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.actualizar.zp_dir_estado )
            this.municipio = this.estado[i].municipios
        } 
      },
      buscar(){
          axios.get('http://127.0.0.1:8000/proveedor/proveedor/'+ this.$route.params.id +'/')
          .then(res => {
            this.actualizar = res.data,
            this.filtar()
            })
      },
      validate(){
        this.proveedor={
          zp_nombre:this.actualizar.zp_nombre,
          zp_apell_pat:this.actualizar.zp_apell_pat,
          zp_apell_mat:this.actualizar.zp_apell_mat,
          zp_num_telefono:this.actualizar.zp_num_telefono.replace(/-/g, ""),
          zp_num_cell:this.actualizar.zp_num_cell.replace(/-/g, ""),
          zp_rfc:this.actualizar.zp_rfc,
          zp_correo:this.actualizar.zp_correo,
          zp_dir_pais:this.actualizar.zp_dir_pais,
          zp_dir_estado:this.actualizar.zp_dir_estado,
          zp_dir_municipio:this.actualizar.zp_dir_municipio,
          zp_dir_colonia:this.actualizar.zp_dir_colonia,
          zp_dir_cod_postal:this.actualizar.zp_dir_cod_postal,
          zp_dir_calle_prin:this.actualizar.zp_dir_calle_prin,
          zp_dir_calle_inter:this.actualizar.zp_dir_calle_inter,
          zp_dir_num_int:this.actualizar.zp_dir_num_int,
          zp_dir_num_ext:this.actualizar.zp_dir_num_ext,
          zp_identify_mark:this.actualizar.zp_identify_mark,
          zp_existen :this.actualizar.zp_existen, 
        }
        this.$refs.form.validate()
        this.submit()
      },
      reset () {
        this.$refs.form.reset()
        
      },

      cancelar () {
        this.$router.push({ name: 'Proveedores' });
      },
        submit () {
          axios.put('http://127.0.0.1:8000/proveedor/proveedor/'+ this.$route.params.id +'/',this.proveedor)
          .then(res => this.$router.replace({ path: '/Proveedores/' }) )
          .catch(error => console.log(error));
          
          
      }
      
    }
  }

</script>



