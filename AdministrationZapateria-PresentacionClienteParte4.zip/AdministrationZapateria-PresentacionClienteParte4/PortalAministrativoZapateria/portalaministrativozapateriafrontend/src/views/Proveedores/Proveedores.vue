Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el registro de los datos del proveedor.


<template>
<div cols="full">
    <v-row>
    
      <v-col cols="md-2 xs-12" >
          <menuModulos/>
      </v-col> 
      <v-col cols="md-10 xs-12" >
        <app-header style="z-index: 135"/> 

<div align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">PROVEEDORES</h1>
        </div><br>
        
        <v-card :elevation="0">
          <v-card-title class="card_title">
            <div class="col-12" id="table_cabecera_color">
              <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
              <v-btn dark text :to= "'/proveedorhist/'" class="btn_csv" v-show="permissions.can_manage_proveedores == true">
                Historial
              </v-btn>
               
              <v-btn dark text to="/RegistroProveedores" class="btn_add" v-show="permissions.can_manage_proveedores == true">
                Agregar
              </v-btn>
            </div>
          </v-card-title>
        
     <div class="col-12" style="padding-top:0">
      <v-data-table
        id="tabla_datos"
        :headers="headers"
        :search="search"
        :items="elementsa"
        
        :footer-props="{
      
     showFirstLastPage: true,

   showFirstLastPage: true,
  itemsPerPageText: 'Elementos por página ',
  }"
  :header-props="{ sortByText: 'Ordenar por' }"
  >

    <template v-slot:top>
      <v-toolbar
        flat
     
      </v-toolbar>
    </template>
   
  <template v-slot:item.zp_nombre="{ item }">
    <dproveedor :elements="item" />
  </template>

   
        <template v-slot:item.actions="{ item }">
           <v-row align="center">
      <v-btn icon :to="'/aproveedor/'+ item.zp_id_proveedor+'/'" v-if="permissions.can_manage_proveedores == true">
        <v-icon color="blue" >mdi-pencil-outline</v-icon>
      </v-btn>
      <v-btn icon v-else disabled>
        <v-icon color="blue" >mdi-pencil-outline</v-icon>
      </v-btn>
      <eproveedor :elementE="{item, permissions}"/> 
       <v-tooltip bottom v-if="item.zp_existen == true" >
            <template v-slot:activator="{ on, attrs }">
                <v-icon  color="success" @click="desactivar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_proveedores == false">
                    mdi-eye
                </v-icon>
            </template>
            <span>Desactivar</span>
        </v-tooltip>
        <v-tooltip bottom v-if="item.zp_existen == false">
            <template v-slot:activator="{ on, attrs }">
                <v-icon  color="red" @click="activar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_proveedores == false">
                    mdi-eye-off-outline
                </v-icon>
            </template>
            <span>Activar</span>
        </v-tooltip>

        </v-row>
        
        </template>            
      </v-data-table>
     </div>
    </v-card>
    </v-col>
    </v-row> 
</div>
</template>


<script>
const axios = require('axios')
const moment = require('moment')
import Header from '../../components/Header';
import menuModulos from '../menuModulos' 
import dproveedor from './DetalleProveedor'
import eproveedor from './DeleteProveedor'
  export default {
    name: 'Header', 
    components:{
      "app-header": Header,
      menuModulos,
      dproveedor,
      eproveedor
    },

    created(){
      this.find()
    },
    data () {
      return{
     
      elements:Object,
      search: '',
      headers: [
        {
          text: 'Nombre',
          align: 'start',
          sortable: false,
          value: 'zp_nombre',
        },
        //{ text: 'Nombre', value: 'nombre' },
          { text: 'Número de Celular', value: 'zp_num_cell' },
          { text: 'RFC', value: 'zp_rfc' },
          { text: 'Indetificador', value: 'zp_identify_mark' },
          { text: 'Correo', value: 'zp_correo' },
          { text: 'Acciones', value: 'actions', sortable: false, align:'center' },
       
      
      ],
      elementsa:[],
      permissions: {
                    can_manage_proveedores: false,
                    //can_manage_proveedores_hist: false,
                },
      
      }

          },
  
    methods: {
      find(){

        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_proveedores: true,
                                    //can_manage_proveedores_hist:true,
                                    
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_proveedores') { this.permissions.can_manage_proveedores = true}
                                                        //if(resPer.data.codename == 'manage_proveedores_historico') { this.permissions.can_manage_proveedores_hist = true}
                                                        
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })


        axios.get('http://127.0.0.1:8000/proveedor/proveedor/')
          .then(res => this.elementsa = res.data)
          .catch(error => console.log(error))
      },
       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      activar (e) {
        const URL = 'http://127.0.0.1:8000/proveedor/proveedor/'+e.zp_id_proveedor+'/'
        axios.put(URL, {
          zp_nombre:e.zp_nombre,
          zp_apell_pat:e.zp_apell_pat,
          zp_apell_mat:e.zp_apell_mat,
          zp_num_telefono:e.zp_num_telefono,
          zp_num_cell:e.zp_num_cell,
          zp_rfc:e.zp_rfc,
          zp_correo:e.zp_correo,
          zp_dir_pais:e.zp_dir_pais,
          zp_dir_estado:e.zp_dir_estado,
          zp_dir_municipio:e.zp_dir_municipio,
          zp_dir_colonia:e.zp_dir_colonia,
          zp_dir_cod_postal:e.zp_dir_cod_postal,
          zp_dir_calle_prin:e.zp_dir_calle_prin,
          zp_dir_calle_inter:e.zp_dir_calle_inter,
          zp_dir_num_int:e.zp_dir_num_int,
          zp_dir_num_ext:e.zp_dir_num_ext,
          zp_existen : true, 
          zp_identify_mark:e.zp_identify_mark,
        }).catch(error => console.log(error))
        window.location.reload()
      },  
      desactivar (e) {
        const URL = 'http://127.0.0.1:8000/proveedor/proveedor/'+e.zp_id_proveedor+'/'
        axios.put(URL, {
          zp_nombre:e.zp_nombre,
          zp_apell_pat:e.zp_apell_pat,
          zp_apell_mat:e.zp_apell_mat,
          zp_num_telefono:e.zp_num_telefono,
          zp_num_cell:e.zp_num_cell,
          zp_rfc:e.zp_rfc,
          zp_correo:e.zp_correo,
          zp_dir_pais:e.zp_dir_pais,
          zp_dir_estado:e.zp_dir_estado,
          zp_dir_municipio:e.zp_dir_municipio,
          zp_dir_colonia:e.zp_dir_colonia,
          zp_dir_cod_postal:e.zp_dir_cod_postal,
          zp_dir_calle_prin:e.zp_dir_calle_prin,
          zp_dir_calle_inter:e.zp_dir_calle_inter,
          zp_dir_num_int:e.zp_dir_num_int,
          zp_dir_num_ext:e.zp_dir_num_ext,
          zp_existen : false, 
          zp_identify_mark:e.zp_identify_mark,
        }).catch(error => console.log(error))
        window.location.reload()
      },
    },
  }
</script>
