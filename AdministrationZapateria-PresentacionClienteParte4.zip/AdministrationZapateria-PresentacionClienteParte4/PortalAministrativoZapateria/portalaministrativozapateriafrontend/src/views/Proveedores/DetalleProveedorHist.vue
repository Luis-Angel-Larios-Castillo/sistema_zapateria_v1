Autor: MiguelAngel Zamora Carmona.
Descripción: En el presente archivo se muestra los detalles de los datos del proveedor Historico.
<template>

    <v-container grid-list-xs>
        <v-dialog  max-width="600">
        <template v-slot:activator="{ on, attrs }">
          <p v-bind="attrs" v-on="on" class="blue--text">
            <strong>{{elements.zdp_nombre}} {{elements.zdp_apell_pat}} {{elements.zdp_apell_mat}}</strong> 
          </p>  
        </template>

        <v-card>
          <v-card-title class="headline">

          </v-card-title>

          <v-card-text>
            <v-alert dense type="info">
            Proveedor: <strong>{{elements.zdp_nombre}} {{elements.zdp_apell_pat}} {{elements.zdp_apell_mat}}</strong>
             </v-alert>

              <div class="black--text">
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DE CONTACTO</h3>
                </v-alert> 
                <p><strong>RFC:  </strong> {{elements.zdp_rfc}}   ---- <strong>Identificador:  </strong>{{elements.zdp_identify_mark}} </p>
                <p><strong>Teléfono: </strong>{{elements.zdp_num_telefono}}  ---- <strong>Celular: </strong>{{elements.zdp_num_cell}} </p>
                <p><strong>Correo: </strong> <br>{{elements.zdp_correo}}</p>
                <v-alert color="grey lighten-4" dense align="center">
                <h3>DATOS DE DIRECCIÓN</h3>
                </v-alert>
                                <v-row align="center">
                <v-col align="center">  
                <p class="mb-0">{{elements.zdp_dir_municipio}} {{elements.zdp_dir_estado}},  {{elements.zdp_dir_pais}} </p>
                    <p style="font-size:13px;"><strong>Lugar de recidencia</strong></p> <p class="mb-0"> {{elements.zdp_dir_municipio}}</p>
                    <p style="font-size:13px;"><strong>Ciudad</strong></p>

                
                </v-col>
               </v-row>
               <v-alert color="grey lighten-4" dense align="center">
                <v-row>
                 <v-col align="center">
                <p class="mb-0"> {{elements.zdp_dir_colonia}}</p>
                <p style="font-size:13px;"><strong>Colonia</strong></p>
                </v-col>
                 <v-col align="center">
                <p class="mb-0">  {{elements.zdp_dir_calle_prin}}</p>
                <p style="font-size:13px;"><strong>Calle Principal</strong></p>
                </v-col>
               <v-col align="center">
            
                <p class="mb-0">  {{elements.zdp_dir_calle_inter}}</p>
                <p style="font-size:13px;"><strong>Calle Interconexión</strong></p>
               </v-col>
                 </v-row>
                 </v-alert>
                 <v-row>
                <v-col align="center">
                <p class="mb-0">  {{elements.zdp_dir_num_ext}}</p>
                <p style="font-size:13px;"><strong>N° Exterior</strong></p>
               </v-col>
               <v-col align="center">
                <p class="mb-0">  {{elements.zdp_dir_num_int}}</p>
                <p style="font-size:13px;"><strong>N° Interior</strong></p>
               </v-col>  
                <v-col align="center">
                <p class="mb-0">  {{elements.zdp_dir_cod_postal}}</p>
                <p style="font-size:13px;"><strong>C.P</strong></p>
            </v-col>
                </v-row>
                
                  
               
                  <v-alert color="grey lighten-4" dense align="center">
                  <h3>INFORMACIÓN GENERAL</h3>
                </v-alert>
                  <p class="black--text"><strong>Motivo de Eliminación: </strong><br>{{elements.zdp_motivo}}</p>
                  
                    
                    <strong>Usuario que elimino el registro: </strong><br>
                      {{empleado.nombre}}
                      <br>
                    </div>
                  
                  <p class="black--text"><strong>Correo del usuario que elimino el registro: </strong><br>{{usuariodele.zdus_correo}}</p>
                  <p class="red--text"><strong>Fecha de creación: </strong> {{fecha(elements.zdp_fech_crea)}}</p>
                  <p class="red--text"><strong>Fecha de eliminación: </strong> {{fecha(elements.zdp_fech_delet)}}</p>
                 
              </div>
          </v-card-text>
        </v-card>
      </v-dialog>
    </v-container>
</template>
<script>
const moment = require('moment')
const axios = require('axios')

export default {
    props:[
        'elements'
    ],
    created(){
     
      this.findUsuaDelete()
    },
    data(){
        return { 
          empleado:[], 
          usuariodele:'',        
        };
    },
    methods:{
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },

      findUsuaDelete(){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ this.elements.zdp_usua_delet +'/').
        then(res =>{ this.usuariodele = res.data
        axios.get('http://127.0.0.1:8000/empleado/?search='+ this.elements.zdp_usua_delet)
        .then(res => this.empleado = res.data[0])
        
        })
      },
      

    },
}
</script>