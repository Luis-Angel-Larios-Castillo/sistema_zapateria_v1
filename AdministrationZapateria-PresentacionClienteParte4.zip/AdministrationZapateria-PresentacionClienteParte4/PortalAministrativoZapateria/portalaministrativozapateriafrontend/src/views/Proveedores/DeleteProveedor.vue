Autor: Elisa Huerta Corona.
Descripción: El presente archivo es para eliminar el proveedor.


<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="#5B5B5B" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementE.permissions.can_manage_proveedores == false">
            <v-icon  color="red"> mdi-delete</v-icon>
          </v-btn>
        </template>

        <span>Eliminar</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="500">
      <v-card>
        <v-container> 
          <v-alert dense text color="red" type="info" border="top">
            <strong>Se va a eliminar el Proveedor:<br>{{elementE.item.zp_nombre}} {{elementE.item.zp_apell_pat}} {{elementE.item.zp_apell_mat}}</strong>
          </v-alert>

          <v-card-text class="black--text">
           <v-text-field label="Motivo" filled rounded dense v-model="motivo" :rules="motivoRules" required :counter="50" maxlength="50"></v-text-field>
            <h4>¿Está de acuerdo en eliminarlo?</h4>
            <v-text-field v-if="ocultar" v-model="idUser" label="Id Administrador/Empleado que elimino el registro" readonly></v-text-field>
          </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <br>
          <v-row align="center" justify="space-around">

          <v-btn  color="red" outlined  @click="dialog = false">
            Cancelar 
          <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn  color="success" class="mr-15" outlined :disabled="!eliminarValidacion" @click="aceptar()">
            Aceptar 
          <v-icon right dark>mdi-check-all</v-icon>
          </v-btn>
          </v-row>
        </v-card-actions>
        </v-container>
      </v-card>
      
      
    </v-dialog>
 
  </v-row>
  
</template>
<script>

const axios = require('axios')
export default {
    props:[
        'elementE'
    ],
    data () {
      return {
        eliminarValidacion: false,
        dialog: false,
        idUser:'',
        motivo: '',
        ocultar: false,
        motivoRules: [
          v => !!v || 'El motivo es obligatorio',
          v => (v && v.length >= 5) || 'El motivo debe tener 5 o más caracteres',
          v => (v && v.length <= 150) || 'El nombre no debe tener más de 150 caracteres',
        ],
      
    }
    },
    created() {
      //this.getUser()
      this.findIdUser()
      axios.get('http://127.0.0.1:8000/catalogo/?search=' + this.elementE.item.zp_id_proveedor )
        .then(res=> {
          if (res.data.length == 0) {
            this.eliminarValidacion = true
          }else{
            this.eliminarValidacion = false
          }  
        })
        
    },
     /*getUser(){ 
        axios.get("http://127.0.0.1:8000/usuario/token/?search=" + localStorage.token )
          .then(res => this.User = res.data[0].user ) 
     },*/
    methods:{
      findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
        .then(res => this.idUser = res.data.user)
      },
      aceptar(){
        let  URL= 'http://127.0.0.1:8000/proveedor/proveedor/'+ this.elementE.item.zp_id_proveedor
          let data = {
            "zdp_nombre": this.elementE.item.zp_nombre,
            "zdp_apell_pat": this.elementE.item.zp_apell_pat,
            "zdp_apell_mat": this.elementE.item.zp_apell_mat,
            "zdp_num_telefono": this.elementE.item.zp_num_telefono,
            "zdp_num_cell": this.elementE.item.zp_num_cell,
            "zdp_rfc": this.elementE.item.zp_rfc,
            "zdp_correo": this.elementE.item.zp_correo,
            "zdp_dir_pais": this.elementE.item.zp_dir_pais,
            "zdp_dir_estado": this.elementE.item.zp_dir_estado,
            "zdp_dir_municipio": this.elementE.item.zp_dir_municipio,
            "zdp_dir_colonia": this.elementE.item.zp_dir_colonia,
            "zdp_dir_cod_postal": this.elementE.item.zp_dir_cod_postal,
            "zdp_dir_calle_prin": this.elementE.item.zp_dir_calle_prin,
            "zdp_dir_calle_inter": this.elementE.item.zp_dir_calle_inter,
            "zdp_dir_num_int": this.elementE.item.zp_dir_num_int,
            "zdp_dir_num_ext": this.elementE.item.zp_dir_num_ext,
            "zdp_fech_crea": this.elementE.item.zp_fech_crea,
            "zdp_fech_delet": this.elementE.item.zp_fech_mod,
            "zdp_motivo": this.motivo,
            "zdp_usua_delet": this.idUser,
            "zdp_identify_mark":this.elementE.item.zp_identify_mark,

          }
          axios.delete(URL)
            .then(res => {
              axios.post('http://127.0.0.1:8000/proveedor/histo/', data)
                .then(r => {
                  this.dialog = false
                  window.location.reload()
                })
            })
            
        }
    },
  }
</script>
