<!--Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el formulario para el registro de los datos del proveedor.-->
<template>
    <v-container fluid> 
      <div v-if="permissions.can_manage_proveedores == true">
          <app-header style="z-index: 135"/> 
   
      <v-col cols="md-8 xs-12">
        <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE PROVEEDORES</h1>
        </div><br>

         <v-card :elevation="0">  
          <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          <v-spacer/>
          <v-btn to="/Proveedores/" outlined class="btn_add" color="#F7F9F9">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>    

          <v-container id="tabla_datos_dos" class="col-12"> 
              <v-form ref="form" v-model="valid" lazy-validation>
                <!-- Inicio Datos Personales -->
                <v-alert id="title_formulario" dense icon="mdi-account-check">
                <strong>DATOS PERSONALES</strong>
              </v-alert>
                 
                    <v-row>
                      <v-col cols="4">
                        <v-text-field v-model="name" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                      </v-col>

                      <v-col cols="4">
                        <v-text-field v-model="apep" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                      </v-col>
                      <v-col cols="4">
                        <v-text-field v-model="apem" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                      </v-col>
                    </v-row>
                    <v-row>
                      <v-col>
                      <v-text-field v-model="rfc" :rules="rfcRules" label="RFC:" required :counter="15" oninput="this.value=this.value.replace(/[^A-Za-z-ñÑáÁéÉíÍóÓúÚ0-9 ]/g,'');" placeholder="Ejem. SND-861121" maxlength="15"></v-text-field>
                      </v-col>
                      <v-col>
                      <v-text-field v-model="identify_mark" :rules="identifyRules" label="Identificador:" required :counter="15" oninput="this.value=this.value.replace(/[^A-Za-z-ñÑáÁéÉíÍóÓúÚ0-9 ]/g,'');" placeholder="Ejem. AND" maxlength="15"></v-text-field>
                      </v-col>
                    </v-row>
                  
                <!-- Fin Datos Personales -->
        
                <!-- Inicio de DIRECCIÓN - LUGAR DE RECIDENCIA -->
                
                  <v-alert id="title_formulario" dense icon="mdi-home">
                  <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
                  </v-alert>
                  <v-row>
                      <v-col cols="3">
                        <v-text-field v-model="sel0" readonly :rules="[v => !!v || 'Se requiere el país.']" label="País:" required :counter="20"></v-text-field>
                      </v-col> 

                      <v-col cols="4">
                        <v-select v-model="sel1" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="[v => !!v || 'Se requiere seleccionar un Estado.']" label="Estado:" required/>
                      </v-col>

                      <v-col cols="5">
                        <v-select v-model="sel2" :items="municipio" item-text="name" :rules="[v => !!v || 'Se requiere seleccionar un Municipio.']" label="Municipio:" required/>
                      </v-col> 
                    </v-row>

                       <v-row>
                      <v-col cols="3">
                        <v-text-field v-model="sel3" :rules="coloniaRules" label="Barrio/Colonia:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. El Bosque" maxlength="20"></v-text-field>
                      </v-col> 

                      <v-col cols="4">
                        <v-text-field v-model="callp" :rules="callpRules" label="Calle principal:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos" maxlength="50"></v-text-field>
                      </v-col> 

                      <v-col>
                        <v-text-field v-model="calli" :rules="calliRules" label="Calle/s de Interconexión:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita" maxlength="50"></v-text-field>
                      </v-col>

                      
                    </v-row>
                    <v-row>
                    <v-col cols="3">
                        <v-text-field v-model="codigo" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="codigoRules" label="Código Postal:"  required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                      </v-col> 
                       
                       <v-col cols="4">
                        <v-text-field v-model="nume" :rules="numeRules" label="Núm. Exterior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                      </v-col> 
                      <v-col>
                        <v-text-field v-model="num" :rules="numRules" label="Núm. Interior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N"></v-text-field>
                      </v-col>  
                     
                    </v-row>


                    <v-alert id="title_formulario" dense icon="mdi-card-account-phone">
                <strong>INFORMACIÓN DE CONTACTO</strong>
              </v-alert>

                  <v-card-text> 
                    <v-text-field v-model="correo" :rules="correoRules" label="Correo:" required :counter="30" maxlength="30"></v-text-field>
                    <v-row >
                      <v-col cols="6"> 
                        <v-text-field  v-model="tel" v-mask="'###-###-##-##'" max="13" :rules="telRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono Domiciliar:" required counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos">
                          <v-tooltip slot="append" bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                              <v-icon  color="blue" v-bind="attrs" v-on="on">
                                mdi-help-circle-outline
                              </v-icon> 
                            </template> 
                            <div>
                              Escribir el número telefónico con lada: <br>
                              Ejemplo: 241-000-00-00
                              <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p> 
                            </div> 
                          </v-tooltip> 
                        </v-text-field>
                      </v-col> 
                      <v-col cols="6">
                        <v-text-field  v-model="telc" v-mask="'###-###-##-##'" max="13" :rules="telcRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Número de Celular:" required counter placeholder="Ejem. 245-875-35-20" title="Sólo se permiten datos númericos">
                          <v-tooltip slot="append" bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-icon  color="blue" v-bind="attrs" v-on="on">
                                  mdi-help-circle-outline
                                </v-icon> 
                            </template>
                            <div>
                              Escribir el número telefónico con lada: <br>
                              Ejemplo: 241-000-00-00
                              <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p>
                            </div>
                          </v-tooltip> 
                        </v-text-field>
                      </v-col> 
                    </v-row>
                  </v-card-text>
                
                <!-- Fin Información de Contacto -->  
                <br>
                <!-- Dirección - Lugar de Residencia -->
                 
                    
                      
                   
                 
                <!-- Dirección - Lugar de Residencia -->       
                <br>
                <v-row align="center" justify="space-around">
                  <v-btn  x-large class="mr-6" id="btn_borrar_formulario" @click="reset">
                    Borrar Formulario

                    <v-icon right dark>
                    mdi-eraser
                  </v-icon>
                  </v-btn> 
                  <v-btn  x-large class="mr-4" id="btn_cancelar_formulario" @click="cancelar">
                    Cancelar
                  <v-icon right dark>
                    mdi-close-circle
                  </v-icon>
                  </v-btn>
                  <v-btn @click="validate" :disabled="!valid" x-large  id="btn_guardar_formulario" >
                      Guardar
                    <v-icon right dark >
                      mdi-cloud-upload
                    </v-icon>
                  </v-btn>
                </v-row> 
            </v-form> <br>
          </v-container>
        </v-card> 
      </v-col>
      
      </div>
      <div v-else>
         <ErrorPage403/>
      </div>
    </v-container> 
</template>

<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
import esta from "../../assets/json/muni.json";
import axios from "axios"; 
  export default {
     name: 'Header', 
    components:{
      "app-header": Header,
      ErrorPage403
  }, 
    data: () => ({
      proveedor:[],                     
      valid: true,
      identify_mark:'',
      identifyRules:[
       v => !!v || 'Se requiere el identificador.', 
       v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Identificador" debe ser mayúscula',
       v => (v && v.length >= 1) || 'El campo "Identificador" debe tener más de 10 caracteres.',
       v => (v && v.length <= 15) || 'El campo "Identificador" no debe tener más de 15 caracteres.',
      ],
      
      name:'',
      nameRules: [
        v => !!v || 'Se requiere el nombre.', 
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
       
      ],  
      apep:'',
      apepRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
        v => !!v || 'Se requiere el apellido paterno.', 
        v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.',
        
      ], 
      apem:'',
      apemRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',
        v => !!v || 'Se requiere el apellido materno.', 
        v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.',
       
      ], 
      sel0: 'México',
      sel1: 'Tlaxcala',
      estado: esta, 
      sel2: null,
      municipio: [],
      sel3: null,
      coloniaRules: [
        
        v => !!v || 'Se requiere el nombre de la colonia.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Colonia" debe ser mayúscula',
        v => (v && v.length >= 5) || 'El campo "Colonia" debe tener más de 5 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Colonia" no debe tener más de 20 caracteres.',
    
      ],  
      codigo: '',
      codigoRules: [
        v => !!v || 'Se requiere el código postal.',
        v => (v && v.length == 5) || 'El campo "Código Postal" debe tener 5 caracteres.',
       ], 
      num: '',
      numRules: [
        v => !!v || 'Se requiere el número exterior.', 
         v => (v && v.length <= 25) || 'El campo "Núm. Exterior" no debe tener más de 25 caracteres.',
      ], 
      callp:'',
      callpRules: [
        v => !!v || 'Se requiere la calle principal.',
         v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',
        v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El campo "Calle Principal" no debe tener más de 50 caracteres.',
      ], 
      calli: '',
      calliRules: [
        v => !!v || 'Se requiere ingresar entre que calles se encuentra su domicilio.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El registro no debe tener más de 50 caracteres.',

      ], 
      nume: '',
      numeRules: [
          v => !!v || 'Se requiere ingresar un Número Interior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Interior" no debe tener más de 25 caracteres.',
      ],
      rfc: '',
      rfcRules: [
       v => !!v || 'Se requiere ingresar un RFC.',
        v => (v && v.length >= 10) || 'El campo "RFC" debe tener más de 10 caracteres.',
        v => (v && v.length <= 15) || 'El campo "RFC" no debe tener más de 15 caracteres.',
      ],
      correo: '',
      correoRules: [
       v => /.+@.+\..+/.test(v) || 'El campo "Correo Electrónico" tine que ser valido',
       v => (v && v.length <= 30) || 'El campo "Correo Electrónico" no debe tener más de 30 caracteres.',
      ], 
      tel: '',
      telRules: [
        v => !!v || 'Se requiere el número teléfonico.', 
        v => (v && v.length == 13) || 'El número telefónico debe ser valido.',
      ], 
      telc: '',
      telcRules: [
        v => !!v || 'Se requiere el número de celular.', 
        v => (v && v.length == 13) || 'El número telefónico debe ser valido.',
      ],
      permissions: {
          can_manage_proveedores: false,
        }, 
    }),
    created() {
      this.findpermsisos()
      this.filtar()
    },
     methods: {
       findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_proveedores: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_proveedores') { this.permissions.can_manage_proveedores = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.sel1 )
            this.municipio = this.estado[i].municipios
        } 
      },
      validate(){
        this.proveedor={
          zp_nombre:this.name,
          zp_apell_pat:this.apep,
          zp_apell_mat:this.apem,
          zp_num_telefono:this.tel,
          zp_num_cell:this.telc,
          zp_rfc:this.rfc,
          zp_correo:this.correo,
          zp_dir_pais:this.sel0,
          zp_dir_estado:this.sel1,
          zp_dir_municipio:this.sel2,
          zp_dir_colonia:this.sel3,
          zp_dir_cod_postal:this.codigo,
          zp_dir_calle_prin:this.callp,
          zp_dir_calle_inter:this.calli,
          zp_dir_num_int:this.num,
          zp_dir_num_ext:this.nume,
          zp_identify_mark:this.identify_mark,
        }
        this.$refs.form.validate()
        this.submit() 
      }, 
      reset () {
        this.name = '',
        this.apep = '',
        this.apem = '',
        this.tel = '',
        this.telc = '',
        this.rfc = '',
        this.correo = ''  
        this.sel2 = '',
        this.sel3 = '',
        this.codigo = '',
        this.callp = '',
        this.calli = '',
        this.num = '',
        this.nume = '',
        this.identify_mark='',
        this.$refs.form.resetValidation()
      }, 

      cancelar () {
        this.$router.push({ name: 'Proveedores' });
      },
      submit () {
        axios.post('http://127.0.0.1:8000/proveedor/proveedor/',this.proveedor)
          .then(res => { 
            this.$router.go(-1);
          })
          .catch(error => console.log(error));
       
      } 
    },
  } 
</script>


