
<template>
    <div cols="full">

      <v-row>
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col> 
        <v-col cols="md-10 xs-12" >
           <div align="center" justify="space-around">
           <hr class="line_superior">
           <h1 id="title"> HISTÓRICO DE PROVEEDORES</h1>
          </div><br>

        <v-card :elevation="0">
          <v-card-title class="card_title">
              <div class="col-12" id="table_cabecera_color">
              <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
               <v-btn to="/Proveedores/" outlined class="btn_add" color="#F7F9F9">
                  <v-icon>
                  mdi-arrow-left-circle
                  </v-icon>
                  Regresar
               </v-btn>
              </div>
          </v-card-title>
        <div class="col-12" style="padding-top:0">
        <v-data-table 
        id="tabla_datos"
        :headers="headers" :search="search" :items="elementsa" no-results-text="Sin registros"
          no-data-text="No se tienen clientes eliminados." 
          :footer-props="{
            showFirstLastPage: true,
            showFirstLastPage: true,
            itemsPerPageText: 'Elementos por página ',
          }"
          :header-props="{ sortByText: 'Ordenar por' }"
        >
        
        <template v-slot:item.zdp_nombre="{ item }">
          <sProveedor :elements="item"/>
        </template>   
        <template v-slot:item.zdp_fech_crea="{ item }">
           {{fecha(item.zdp_fech_crea)}}
        </template>
        <template v-slot:item.zdp_fech_delet="{ item }">
            {{fecha(item.zdp_fech_delet)}}
        </template>                             
      </v-data-table>
      
     </div>
    </v-card>
    </v-col>
      </v-row> 
   </div>
</template>
<script>
const axios = require('axios')
const moment = require('moment')
import menuModulos from '../menuModulos' 
import sProveedor from './DetalleProveedorHist.vue'

  export default {
    components:{
      menuModulos,
      sProveedor
    },
    created(){
      this.find()
    },
    data () {
      return{
      elements:Object,
      search: '',
      headers: [
         
          { text: 'Nombre', align: 'start', filterable: true, value:'zdp_nombre', sortable: true},
          { text: 'RFC', value: 'zdp_rfc', },
          { text: 'Indetificador', value: 'zdp_identify_mark' },
          { text: 'Número de Celular', value: 'zdp_num_cell' },
          { text: 'Correo', value: 'zdp_correo' },
          { text: 'Fecha de creación', value: 'zdp_fech_crea', sortable: true },
          { text: 'Fecha de eliminación', value: 'zdp_fech_delet', sortable: true },

        

          /*
          { text: 'Teléfono de Casa', value: 'zdp_num_telefono' },
          { text: 'Apellido Paterno', value: 'zdp_apell_pat' },
          { text: 'Apellido Materno', value: 'zdp_apell_mat' },
          { text: 'RFC', value: 'zdp_rfc' },
          { text: 'Correo', value: 'zdp_correo' },
          { text: 'País', value: 'zdp_dir_pais' },
          { text: 'Estado', value: 'zdp_dir_estado' },
          { text: 'Municipio', value: 'zdp_dir_municipio' },
          { text: 'Colonia', value: 'zdp_dir_colonia' },
          { text: 'Codigo Postal', value: 'zdp_dir_cod_postal' },
          { text: 'Calle principal', value: 'zdp_dir_calle_prin' },
          { text: 'Calle Interconexión', value: 'zdp_dir_calle_inter' },
          { text: 'Número Interior', value: 'zdp_dir_num_int' },
          { text: 'Número Exterior', value: 'zdp_dir_num_ext' },
          */
           
      ],
      elementsa:[],
      
      
      }

          },
  
    methods: {
      find(){
        axios.get('http://127.0.0.1:8000/proveedor/histo/')
          .then(res => this.elementsa = res.data)
          .catch(error => console.log(error))
      },
      fecha(date){
      return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
    },
  }
</script>
