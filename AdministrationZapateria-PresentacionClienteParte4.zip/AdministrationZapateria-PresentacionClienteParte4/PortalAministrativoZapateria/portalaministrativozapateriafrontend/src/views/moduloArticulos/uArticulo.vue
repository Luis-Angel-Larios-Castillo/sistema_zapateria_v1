Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para actualizar la información de un articulo
<template>
  <v-container fluid>
    <div v-if="permissions.can_manage_arti == true">
      <app-header style="z-index: 135"/> 
      <br>
      <div class="col-8">
      <v-toolbar
        flat
        align="center"
        justify="space-around"
        id="table_cabecera_color_formulario"
      >
        <v-toolbar-title>
          <v-icon right dark> mdi-rotate-3d-variant </v-icon>
          <strong id="title_editar">
            Actualizar el articulo: {{ elementU.zaa_nombre_arti }}</strong
          >
        </v-toolbar-title>
        <v-spacer />
        <v-btn to="/articulos/" outlined class="btn_add" color="#F7F9F9">
          <v-icon> mdi-arrow-left-circle </v-icon>
          Regresar
        </v-btn>
      </v-toolbar>

    
        <v-container  id="tabla_datos_dos" class="col-12">
          <v-form
            ref="form"
            v-model="valid"
            lazy-validation
          >
            <v-row>
              <v-col cols="6">
                <v-select
                  v-model="elementU.zaa_id_arti_global"
                  :items="artglobal"
                  filled
                  item-text="zaag_nombre_arti"
                  item-value="zaag_id_articulo_global"
                  :rules="[
                    (v) => !!v || 'Debe seleccionar una articulo global',
                  ]"
                  label="Articulo Global"
                  required
                />
              </v-col>

              <v-col cols="6">
                <v-select
                  v-model="elementU.zaa_id_sucursal"
                  :items="sucursales"
                  filled
                  item-text="zdsu_etiqueta"
                  item-value="zdsu_id_sucursal"
                  :rules="[(v) => !!v || 'Debe seleccionar una sucursal']"
                  label="Sucursal"
                  required
                />
              </v-col>
            </v-row>
            <v-row>
              <v-col cols="md-6">
                <v-combobox
                  hint="Seleccione uno"
                  :rules="[requiredColor]"
                  v-model="coloresModel"
                  :filter="filter"
                  filled
                  :hide-no-data="!search"
                  :items="coloresItems"
                  :search-input.sync="search"
                  hide-selected
                  label="Colores"
                  multiple
                  small-chips
                >
                  <template v-slot:no-data>
                    <v-list-item>
                      <span class="subheading">Agregar</span>
                      <v-chip label small>
                        {{ search }}
                      </v-chip>
                    </v-list-item>
                  </template>
                  <template
                    v-slot:selection="{ attrs, item, parent, selected }"
                  >
                    <v-chip
                      v-if="item === Object(item)"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                    >
                      <span class="pr-2">
                        {{ item.text }}
                      </span>
                      <v-icon small @click="parent.selectItem(item)">
                        mdi-close
                      </v-icon>
                    </v-chip>
                  </template>
                  <template v-slot:item="{ index, item }">
                    <v-text-field
                      v-if="editing === item"
                      v-model="editing.text"
                      autofocus
                      flat
                      background-color="transparent"
                      hide-details
                      solo
                      @keyup.enter="edit(index, item)"
                    />
                    <v-chip v-else dark label small>
                      {{ item.text }}
                    </v-chip>
                    <v-spacer />
                    <v-list-item-action @click.stop>
                      <v-btn icon @click.stop.prevent="edit(index, item)">
                        <v-icon>{{
                          editing !== item ? "mdi-pencil" : "mdi-check"
                        }}</v-icon>
                      </v-btn>
                    </v-list-item-action>
                  </template>
                </v-combobox>
              </v-col>
              <v-col cols="md-6">
                <v-combobox
                  hint="Seleccione uno"
                  :rules="[requiredTalla]"
                  filled
                  v-model="tallaModel"
                  :filter="filter"
                  :hide-no-data="!search"
                  :items="tallaItems"
                  :search-input.sync="search"
                  hide-selected
                  label="Talla"
                  multiple
                  small-chips
                >
                  <template v-slot:no-data>
                    <v-list-item>
                      <span class="subheading">Agregar</span>
                      <v-chip label small>
                        {{ search }}
                      </v-chip>
                    </v-list-item>
                  </template>
                  <template
                    v-slot:selection="{ attrs, item, parent, selected }"
                  >
                    <v-chip
                      v-if="item === Object(item)"
                      v-bind="attrs"
                      :input-value="selected"
                      label
                      small
                    >
                      <span class="pr-2">
                        {{ item.text }}
                      </span>
                      <v-icon small @click="parent.selectItem(item)">
                        mdi-close
                      </v-icon>
                    </v-chip>
                  </template>
                  <template v-slot:item="{ index, item }">
                    <v-text-field
                      v-if="editing === item"
                      v-model="editing.text"
                      autofocus
                      flat
                      background-color="transparent"
                      hide-details
                      solo
                      @keyup.enter="edit(index, item)"
                    />
                    <v-chip v-else dark label small>
                      {{ item.text }}
                    </v-chip>
                    <v-spacer />
                    <v-list-item-action @click.stop>
                      <v-btn icon @click.stop.prevent="edit(index, item)">
                        <v-icon>{{
                          editing !== item ? "mdi-pencil" : "mdi-check"
                        }}</v-icon>
                      </v-btn>
                    </v-list-item-action>
                  </template>
                </v-combobox>
              </v-col>
            </v-row>
            <v-row>
              <v-col>
                <v-text-field
                  v-model="elementU.zaa_cantidad"
                  filled
                  :rules="cantidadRules"
                  label="Cantidad"
                  type="number"
                  required
                ></v-text-field>
              </v-col>
            </v-row>
            <v-row> </v-row>

            <br />
            <v-row align="center" justify="space-around">
              <v-btn
                :disabled="!valid"
                class="mr-4"
                @click="validate"
                x-large
                id="btn_actualizar_formulario"
              >
                Actualizar
                <v-icon right dark> mdi-update </v-icon>
              </v-btn>
              <v-btn
                id="btn_borrar_formulario"
                class="mr-4"
                x-large
                @click="cancelar"
              >
                Regresar
                <v-icon right dark> mdi-eraser </v-icon>
              </v-btn>
            </v-row>
          </v-form>
          <br>
        </v-container>
        </div>
      <br />
   
    </div>
    <div v-else>
      <ErrorPage403/>
    </div>
  </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const axios = require("axios");
export default {
  name: 'Header', 
  components:{
    "app-header": Header,
    ErrorPage403
  },
  data: () => ({
    artglobal: [],
    activator: null,
    attach: null,
    editing: null,
    coloresItems: [
      { header: "Seleccione un color o agregue uno" },
      {
        text: "Negro",
      },
      {
        text: "Blanco",
      },
    ],
    coloresModel: [],
    tallaItems: [
      { header: "Seleccione una talla o agregue una" },
      {
        text: "25",
      },
      {
        text: "20",
      },
    ],
    tallaModel: [],
    search: null,

    elementU: [],

    valid: true,

    sucursales: [],

    tallaRules: [
      (v) => !!v || "La talla es obligatorio ",
      (v) => (v && v.length >= 0) || "Ingrese una talla valida",
      (v) => (v && v.length <= 50) || "Ingrese una talla valida",
    ],
    cantidadRules: [
      (v) => !!v || "La cantidad es obligatorio ",
      (v) => (v && v > 0) || "No se puede registrar esta cantidad ",
    ],
    //select: '',//this.elementU.zca_id_catalogo,
    pagina: "50",
    paginaRules: [
      (v) => !!v || "La página es obligatorio ",
      (v) => (v && v > 0) || "No se puede registrar esta página ",
    ],
    permissions: {
            can_manage_arti: false,
        },
  }),
  created() {
    this.busqpermisos();
    this.findartiglobal();
    this.find();
    this.findSucursal();
  },
  watch: {
    coloresModel(val, prev) {
      if (val.length === prev.length) return;
      this.coloresModel = val.map((v) => {
        if (typeof v === "string") {
          v = {
            text: v,
          };
          this.coloresItems.push(v);
        }
        return v;
      });
    },
    tallaModel(val, prev) {
      if (val.length === prev.length) return;
      this.tallaModel = val.map((v) => {
        if (typeof v === "string") {
          v = {
            text: v,
          };
          this.tallaItems.push(v);
        }
        return v;
      });
    },
  },
  methods: {
    busqpermisos(){
      let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
       axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_arti: true,
                                }
                            } 
                           else {

                              

                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   

                                        
                                            resUs.data.groups.forEach(group => {
                                             
                                                group.permissions.forEach(permission => {  
                                                 
                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/', config)
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos') { this.permissions.can_manage_arti = true
                                                        }
                                                    })
                                                    
                                                })
                                              })
                                            })
                            }

                        })
                    
                })   
    },
    findartiglobal() {
      axios
        .get("http://127.0.0.1:8000/articuloglobal/")
        .then((res) => (this.artglobal = res.data));
    },

    findSucursal() {
      axios
        .get("http://127.0.0.1:8000/sucursal/sucursales/activas/")
        .then((res) => (this.sucursales = res.data));
    },

    requiredColor(value) {
      if (value instanceof Array && value.length == 0) {
        return "Seleccione un color.";
      }
      return !!value || "Seleccione un color.";
    },
    requiredTalla(value) {
      if (value instanceof Array && value.length == 0) {
        return "Seleccione una talla.";
      }
      return !!value || "Seleccione una talla.";
    },
    edit(index, item) {
      if (!this.editing) {
        this.editing = item;
        this.editingIndex = index;
      } else {
        this.editing = null;
        this.editingIndex = -1;
      }
    },
    filter(item, queryText, itemText) {
      if (item.header) return false;
      const hasValue = (val) => (val != null ? val : "");
      const text = hasValue(itemText);
      const query = hasValue(queryText);
      return (
        text.toString().toLowerCase().indexOf(query.toString().toLowerCase()) >
        -1
      );
    },

    find() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .get(
          "http://127.0.0.1:8000/articulo/admin/" + this.$route.params.id + "/",
          config
        )
        .then((res) => {
          this.elementU = res.data;
          this.coloresModel = res.data.zaa_color;
          this.tallaModel = res.data.zaa_talla;
        });
      //then(res =>console.log(res.data))
    },
    validate() {
      this.elementU.zaa_talla = this.tallaModel;
      this.elementU.zaa_color = this.coloresModel;
      if (this.$refs.form.validate()) {
        this.update();
      }
    },
    update() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .put(
          "http://127.0.0.1:8000/articulo/admin/" + this.$route.params.id + "/",
          this.elementU,
          config
        )
        .then((res) => this.$router.push({ name: "Articulos" }))
        .catch((error) => console.log(error));
    },

    reset() {
      this.$refs.form.reset();
    },
    cancelar() {
      this.$router.push({ name: "Articulos" });
    },
  },
};
</script>
