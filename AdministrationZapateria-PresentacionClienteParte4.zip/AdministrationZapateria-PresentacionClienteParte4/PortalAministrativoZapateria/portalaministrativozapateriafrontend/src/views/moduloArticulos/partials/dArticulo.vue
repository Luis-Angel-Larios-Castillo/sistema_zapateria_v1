Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un articulo 
<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">  
          <v-btn icon color="#5B5B5B" @click="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_arti == false">
            <v-icon color="red" >mdi-delete</v-icon>
          </v-btn>
        </template>
        <span>Eliminar</span>
    </v-tooltip>
    

    <v-dialog
      v-model="dialog"
      max-width="300"
    >
      <v-card>
        <v-card-title class="red--text">
          Se va a eliminar el articulo: {{elementD.item.zaa_nombre_arti}}
        </v-card-title>

        <v-card-text>
          ¿Está seguro que quiere eliminarlo?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="green darken-1" text @click="dialog = false">
            Cancelar 
          </v-btn>

          <v-btn color="green darken-1" text @click="aceptar()">
            Aceptar 
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'elementD'
    ],
    data () {
      return {
        dialog: false
    }
    },
    methods:{
      aceptar(){
        let config = {
            headers: {
            Authorization: "Token " + localStorage.token,
            }
        }
          let URL= 'http://127.0.0.1:8000/articulo/admin/'+ this.elementD.item.zaa_id_articulo
              axios.delete(URL, config)
              .then(response =>{
                  this.dialog = false
                  window.location.reload()
              })
             
        }
    },
  }
</script>