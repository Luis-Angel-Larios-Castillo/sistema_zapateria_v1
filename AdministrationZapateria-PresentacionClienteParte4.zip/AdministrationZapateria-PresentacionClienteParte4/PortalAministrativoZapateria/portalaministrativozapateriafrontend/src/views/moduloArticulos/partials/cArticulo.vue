Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para registrar un articulo 
<template>
  <v-container fluid>
    <div v-if="permissions.can_manage_arti == true">
      <app-header style="z-index: 135"/> 
    <v-col cols="md-8 xs-12">
      <div flat align="center" justify="space-around">
        <hr class="line_superior" />
        <h1 id="title">REGISTRO DE ARTICULOS</h1>
      </div>
     
   
      <v-card :elevation="0">
        <v-toolbar
          flat
          align="center"
          justify="space-around"
          id="table_cabecera_color_formulario"
        >
          <v-spacer />
          <v-btn to="/articulos/" outlined class="btn_add" color="#F7F9F9">
            <v-icon> mdi-arrow-left-circle </v-icon>
            Regresar
          </v-btn>
        </v-toolbar>

        <v-form
          ref="form"
          v-model="valid"
          lazy-validation
          class="col-12"
          style="background-color:#f5f5f5;"
        >
          <v-row>
            <v-col class="col-10">
              <v-select
                v-model="artiglobalselect"
                :items="artglobal"
                filled
                item-text="zaag_nombre_arti"
                item-value="zaag_id_articulo_global"
                :rules="[(v) => !!v || 'Debe seleccionar una articulo global']"
                label="Articulo Global"
                required
              />
            </v-col>
            <v-col class="col-2">
              <v-btn color="blue" class="mt-3" icon outlined :to="'/carticuloglobal/'"
              
                ><v-icon>mdi mdi-plus</v-icon></v-btn
              >
            </v-col>
          </v-row>
          <v-row>
            <v-col class="col-12">
              <v-text-field
                filled
                v-model="cantidad"
                :rules="cantidadRules"
                label="Cantidad"
                type="number"
                required
                oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                counter
              ></v-text-field>
            </v-col>
          </v-row>
          <v-row>
            <v-col cols="md-6">
              <v-combobox
                filled
                hint="Seleccione uno"
                :rules="[requiredColor]"
                v-model="coloresModel"
                :filter="filter"
                :hide-no-data="!search"
                :items="coloresItems"
                :search-input.sync="search"
                hide-selected
                label="Colores"
                multiple
                small-chips
              >
                <template v-slot:no-data>
                  <v-list-item>
                    <span class="subheading">Agregar</span>
                    <v-chip label small>
                      {{ search }}
                    </v-chip>
                  </v-list-item>
                </template>
                <template v-slot:selection="{ attrs, item, parent, selected }">
                  <v-chip
                    v-if="item === Object(item)"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                  >
                    <span class="pr-2">
                      {{ item.text }}
                    </span>
                    <v-icon small @click="parent.selectItem(item)">
                      mdi-close
                    </v-icon>
                  </v-chip>
                </template>
                <template v-slot:item="{ index, item }">
                  <v-text-field
                    v-if="editing === item"
                    v-model="editing.text"
                    autofocus
                    flat
                    background-color="transparent"
                    hide-details
                    solo
                    @keyup.enter="edit(index, item)"
                  />
                  <v-chip v-else dark label small>
                    {{ item.text }}
                  </v-chip>
                  <v-spacer />
                  <v-list-item-action @click.stop>
                    <v-btn icon @click.stop.prevent="edit(index, item)">
                      <v-icon>{{
                        editing !== item ? "mdi-pencil" : "mdi-check"
                      }}</v-icon>
                    </v-btn>
                  </v-list-item-action>
                </template>
              </v-combobox>
            </v-col>
            <v-col cols="md-6">
              <v-combobox
                filled
                hint="Seleccione uno"
                :rules="[requiredTalla]"
                v-model="tallaModel"
                :filter="filter"
                :hide-no-data="!search"
                :items="tallaItems"
                :search-input.sync="search"
                hide-selected
                label="Talla"
                multiple
                small-chips
              >
                <template v-slot:no-data>
                  <v-list-item>
                    <span class="subheading">Agregar</span>
                    <v-chip label small>
                      {{ search }}
                    </v-chip>
                  </v-list-item>
                </template>
                <template v-slot:selection="{ attrs, item, parent, selected }">
                  <v-chip
                    v-if="item === Object(item)"
                    v-bind="attrs"
                    :input-value="selected"
                    label
                    small
                  >
                    <span class="pr-2">
                      {{ item.text }}
                    </span>
                    <v-icon small @click="parent.selectItem(item)">
                      mdi-close
                    </v-icon>
                  </v-chip>
                </template>
                <template v-slot:item="{ index, item }">
                  <v-text-field
                    v-if="editing === item"
                    v-model="editing.text"
                    autofocus
                    flat
                    background-color="transparent"
                    hide-details
                    solo
                    @keyup.enter="edit(index, item)"
                  />
                  <v-chip v-else dark label small>
                    {{ item.text }}
                  </v-chip>
                  <v-spacer />
                  <v-list-item-action @click.stop>
                    <v-btn icon @click.stop.prevent="edit(index, item)">
                      <v-icon>{{
                        editing !== item ? "mdi-pencil" : "mdi-check"
                      }}</v-icon>
                    </v-btn>
                  </v-list-item-action>
                </template>
              </v-combobox>
            </v-col>
          </v-row>
          <v-row>
            <v-col class="col-10">
              <v-select
                v-model="sucursal"
                :items="sucursales"
                filled
                item-text="zdsu_etiqueta"
                item-value="zdsu_id_sucursal"
                :rules="[(v) => !!v || 'Debe seleccionar una sucursal']"
                label="Sucursal"
                required
              />
            </v-col>
            <v-col class="col-2">
              <v-btn color="blue" outlined class="mt-3" icon to="/cSucursal/"><v-icon>mdi mdi-plus</v-icon></v-btn>
            </v-col>
          </v-row>

          <v-row align="center" justify="space-around">
            <v-btn
              :disabled="!valid"
              id="btn_agrega_otro_formulario"
              class="mr-4"
              @click="validate"
            >
              Guardar y agregar otro
              <v-icon right dark> mdi-reload </v-icon>
            </v-btn>
            <v-btn
              :disabled="!valid"
              id="btn_guardar_formulario"
              class="mr-4"
              @click="validate02"
            >
              Guardar
              <v-icon right dark> mdi-cloud-upload </v-icon>
            </v-btn>
            <v-btn id="btn_borrar_formulario" class="mr-4" @click="reset">
              Borrar formulario
            </v-btn>
            <v-btn to="/articulos/" id="btn_cancelar_formulario">
              Cancelar
            </v-btn>
          </v-row>
          <br />
        </v-form>
      </v-card>
    </v-col>
    </div>
    <div v-else>
      <ErrorPage403/>
    </div>
  </v-container>
</template>
<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require("axios");
export default {
   name: 'Header', 
  components:{
     "app-header": Header,
    ErrorPage403
  }, 
  created() {
    this.busqpermisos();
    this.findSucursal();
    this.findartiglobal();
  },
  data() {
    return {
      permissions: {
            can_manage_arti: false,
        },
      activator: null,
      attach: null,
      editing: null,
      sucursal: "",
      sucursales: [],
      coloresItems: [
        { header: "Seleccione un color o agregue uno" },
        { text: "Negro" },
        { text: "Blanco" },
      ],
      coloresModel: [],
      tallaItems: [
        { header: "Seleccione una talla o agregue una" },
        { text: "25" },
        { text: "20" },
      ],
      tallaModel: [],
      search: null,
      element: [],
      valid: true,
      artglobal: [],
      artiglobalselect: [],
      cantidad: "",
      cantidadRules: [
        (v) => !!v || "La cantidad es obligatorio ",
        (v) => (v && v > 0) || "No se puede registrar esta cantidad ",
      ],
      select: null,
      pagina: "50",
      paginaRules: [
        (v) => !!v || "La página es obligatorio ",
        (v) => (v && v > 0) || "No se puede registrar esta página ",
      ],
      
    };
  },
  watch: {
    coloresModel(val, prev) {
      if (val.length === prev.length) return;
      this.coloresModel = val.map((v) => {
        if (typeof v === "string") {
          v = {
            text: v,
          };
          this.coloresItems.push(v);
        }
        return v;
      });
    },
    tallaModel(val, prev) {
      if (val.length === prev.length) return;
      this.tallaModel = val.map((v) => {
        if (typeof v === "string") {
          v = {
            text: v,
          };
          this.tallaItems.push(v);
        }
        return v;
      });
    },
  },
  methods: {
    busqpermisos(){
      let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
       axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_arti: true,
                                }
                            } 
                           else {

                              

                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   

                                        
                                            resUs.data.groups.forEach(group => {
                                             
                                                group.permissions.forEach(permission => {  
                                                 
                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/', config)
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos') { this.permissions.can_manage_arti = true
                                                        }
                                                    })
                                                    
                                                })
                                              })
                                            })
                            }

                        })
                    
                })   
    },
    findSucursal() {
      axios
        .get("http://127.0.0.1:8000/sucursal/sucursales/activas/")
        .then((res) => (this.sucursales = res.data));
    },

    requiredColor(value) {
      if (value instanceof Array && value.length == 0) {
        return "Seleccione un color.";
      }
      return !!value || "Seleccione un color.";
    },
    requiredTalla(value) {
      if (value instanceof Array && value.length == 0) {
        return "Seleccione una talla.";
      }
      return !!value || "Seleccione una talla.";
    },
    edit(index, item) {
      if (!this.editing) {
        this.editing = item;
        this.editingIndex = index;
      } else {
        this.editing = null;
        this.editingIndex = -1;
      }
    },
    filter(item, queryText, itemText) {
      if (item.header) return false;
      const hasValue = (val) => (val != null ? val : "");
      const text = hasValue(itemText);
      const query = hasValue(queryText);
      return (
        text.toString().toLowerCase().indexOf(query.toString().toLowerCase()) >
        -1
      );
    },

    validate() {
      if (this.$refs.form.validate()) {
        this.element = {
          zaa_id_sucursal: this.sucursal,
          zaa_color: this.coloresModel,
          zaa_cantidad: this.cantidad,
          zaa_talla: this.tallaModel,
          zaa_existen: true,
          zaa_id_arti_global: this.artiglobalselect,
        };
        this.createAndNew();
      }
    },
    validate02() {
      if (this.$refs.form.validate()) {
        this.element = {
          zaa_id_sucursal: this.sucursal,
          zaa_color: this.coloresModel,
          zaa_cantidad: this.cantidad,
          zaa_talla: this.tallaModel,
          zaa_existen: true,
          zaa_id_arti_global: this.artiglobalselect,
        };
        this.create();
      }
    },
    findartiglobal() {
      axios
        .get("http://127.0.0.1:8000/articuloglobal/")
        .then((res) => (this.artglobal = res.data));
    },
    createAndNew() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .post("http://127.0.0.1:8000/articulo/admin/", this.element, config)
        .then((res) => {
          window.location.reload();
          this.dialog = false;
        })
        .catch((error) => console.log(error));
    },
    create() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .post("http://127.0.0.1:8000/articulo/admin/", this.element, config)
        .then((res) => {
          this.$router.go(-1);
          this.dialog = false;
        })
        .catch((error) => console.log(error));
    },
    reset() {
      this.$refs.form.reset();
    },
    


  },
};
</script>
