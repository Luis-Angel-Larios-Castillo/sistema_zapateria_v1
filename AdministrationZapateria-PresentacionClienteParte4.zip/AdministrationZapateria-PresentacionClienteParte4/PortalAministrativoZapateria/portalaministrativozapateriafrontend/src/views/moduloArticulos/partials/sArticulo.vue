Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como Dialog (modal) que muestra toda la información de un articulo 
<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zaa_nombre_arti}}</strong>
          
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
        </v-card-title>
        <v-card-text>

            <v-alert dense text type="success" v-if="element.zaa_existen == true" >
                El producto: <strong>{{element.zaa_nombre_arti}}</strong> esta habilitado. 
            </v-alert>
            <v-alert dense text type="warning" color="red" v-if="element.zaa_existen == false" >
                El producto: <strong>{{element.zaa_nombre_arti}}</strong> esta deshabilitado.
            </v-alert>            
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Clave</strong></td>
                    <td>{{element.zaa_clave}}</td>
                  </tr>
                  <tr>
                    <td><strong>Código de barras</strong></td>
                    <td>{{element.zaa_codigo_bar}}</td>
                  </tr>
                  <tr>
                    <td><strong>Categoría</strong></td>
                    <td>{{element.zaa_categoria}}</td>
                  </tr>
                  <tr>
                    <td><strong>Sucursal</strong></td>
                    <td>{{element.zaa_sucursal}}</td>
                  </tr>
                  <tr>
                    <td><strong>Catálogo</strong></td>
                    <td>{{element.zaa_cata_name}}</td>
                  </tr>
                  <tr>
                    <td><strong>Departamento: </strong>{{element.zaa_dpto_name}}</td>
                    <td><strong>SubDepartamento: </strong>{{element.zaa_subdpto_name}}</td>
                  </tr>  
                  <tr>
                    <td><strong>Cantidad</strong></td>
                    <td>{{element.zaa_cantidad}}</td>
                  </tr> 
                  <tr>
                    <td><strong>Marca</strong></td>
                    <td>{{element.zaa_marca}}</td>
                  </tr>
                  <tr>
                    <td><strong>Modelo</strong></td>
                    <td>{{element.zaa_modelo}}</td>
                  </tr> 
                </tbody>
              </template>
            </v-simple-table> 
            <v-divider/>
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Colores: </strong> {{colores}} </td> 
                  </tr>
                  <tr>
                    <td><strong>Tamaños: </strong> {{sizes}}</td> 
                  </tr>
                </tbody>
              </template>
            </v-simple-table> 
            <v-divider/>
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Precio al contado: $</strong>{{element.zaa_prec_cont}}</td>
                    <td><strong>Precio en pagos: $</strong>{{element.zaa_prec_pag}}</td>
                  </tr>
                  <tr>
                    <td><strong>Precio de mayoreo: $</strong>{{element.zaa_prect_mayo}}</td>
                    <td><strong>Precio menudeo: $</strong>{{element.zaa_prect_menud}}</td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table> 
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    data(){
        return {
          colores: '',
          sizes: ''
        };
    },
    created() {
      this.getColors()
      this.getSizes()
    },
    methods:{
      getColors(){
        let extn = this.element.zaa_color.length
        let colo = ''
        for (let i = 0; i < extn; i++) {
          if (i == extn -1) {
            colo = colo + this.element.zaa_color[i].text
            this.colores = colo
          }else{
            colo = colo + this.element.zaa_color[i].text + " - "
          }
        }
      },
      getSizes(){
        let extn = this.element.zaa_talla.length
        let size = ''
        for (let i = 0; i < extn; i++) {
          if (i == extn -1) {
            size = size + this.element.zaa_talla[i].text
            this.sizes = size
          }else{
            size = size + this.element.zaa_talla[i].text + " - "
          }
        }
      },

    }
}
</script>