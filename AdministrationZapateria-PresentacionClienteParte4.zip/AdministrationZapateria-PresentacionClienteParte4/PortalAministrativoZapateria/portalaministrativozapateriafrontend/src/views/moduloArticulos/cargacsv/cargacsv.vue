<!-- 
   ♣ Autor: Luis Angel Larios Castillo
   ♣ Apoyo: Miguel Angel Zamora Carmona
   ♣ Descripción: Este modulo se encarga de realizar la carga masiva de productos
                atraves de un archivo CSV, para que vue permita cargar documentos 
                CSV.

                Este modulo contempla cuatro factores importantes para la carga csv
                   ♣ componente: vue-csv-import que se encarga de cargar el archivo csv
                                  en este apartado se integran los nombre de los campos
                                  a de la base de datos. 
                   ♣ Funcion CSV: que se encarga de almacenar los datos que contenga el
                                  csv dentro de array con objetos independientes.
                   ♣ Funcion imprimirfor: que se encarga recorrer el array con objetos, 
                                          ademas de convertir los campos de talla y color
                                          tipo string a tipo json para ser leidos por la 
                                          api como campos especiales.

-->
 
 <template>
     <div class="col-10">
       <div class="a_right">
         <link rel="icon" href="<%= BASE_URL %>manualcsv.pdf">
        <v-btn
      class="ma-1"
      outlined
      fab
      color="indigo"
      href="/manualcsv.pdf"
      target="_blank"
    >
      <v-icon>mdi-help</v-icon>
    </v-btn>
       
       </div>
      <div class="v-row">
          <div class="col-12">
            <div style="float:left;">
                    <v-btn
                    elevation="2"
                    icon
                    :to="'/articulosglobales/'"
                    >
                <v-icon>mdi-arrow-left-circle-outline</v-icon>
                </v-btn>
                </div>
              <h1 class="h2">Carga de archivo CSV</h1>
          </div> 
        </div>
      <div>
      <br>
      <v-card
        elevation="2"
        class="col-12"
      >
       <vue-csv-import
        id="file"
          v-model="csv"
          :map-fields="[
            'Nombre', 
            'Clave', 
            'Codigo_de_barras', 
            'Modelo', 
            'Categoria', 
            'Marca', 
            'Precio_de_contado', 
            'Precio_en_pagos', 
            'Precio_de_mayoreo', 
           'Precio_de_menudeo', 
           'Oferta', 
           'Id_Catalogo', 
           'Id_subdepartamento' 
          ]"
                     
           
            >
                  <template slot="hasHeaders" slot-scope="{headers, toggle}">
                   
                    <v-btn
                      outlined
                      color="primary"
                      dark
                      @click.stop="dialog = true"
                      block
                    >
                      Ver tipos de campos para csv
                    </v-btn>

                    <v-alert
                      border="bottom"
                      colored-border
                      color="#ccc"
                      elevation="0"
                    >
                    </v-alert>
                    <v-alert
                          border="bottom"
                          colored-border
                          type="info"
                          color="#ccc"
                          elevation="0"
                        >
                        <v-checkbox
                          label=" Marque la casilla en caso de que contenga titulos"
                          color="info"
                          hide-details
                          type="checkbox"
                          id="hasHeaders"
                          :value="headers"
                          @change="toggle"
                          class="mb-10"
                        >
                        </v-checkbox>
                        </v-alert>
                    </template>
                    <template slot="error">
                        El tipo de archivo es invalido
                    </template>
                    <template slot="thead">
                        <tr>
                            <th align="left" class="td"><h3>Almacener en :</h3></th>
                            <th class="td"><h3>Columnas del archivo</h3></th>
                        </tr>
                    </template>
          <vue-csv-map :auto-match="true"></vue-csv-map>
                  <template slot="next" slot-scope="{load}"><br>
                  <v-alert
                      border="top"
                      colored-border
                      color="#ccc"
                      elevation="0"
                  >
                      <v-btn
                      depressed
                      color="primary"
                      block
                      @click.prevent="load" 
                      >
                      Cargar Archivo
                    </v-btn> 
                    </v-alert>
                  </template>
                <template slot="submit" slot-scope="{submit}">
                    <button @click.prevent="submit">Enviar</button>
                    
                </template>
        </vue-csv-import>
      </v-card>
    </div>
  <div class="v-col col-12" v-show="csv">
    
    
         <v-btn
              dark
              color="orange"
              block
              @click="imprimirfor()"
            > 
              <i class="ri-align-left">Guardar Datos</i>
              <v-icon
                  right
                  dark
              >
              mdi-cloud-upload
              </v-icon>
          </v-btn>
      
     
  </div>
  


 <v-simple-table dense>
    <template v-slot:default>
      <thead>
        <tr>
          <th class="text-left">
            Nombre
          </th>
          <th class="text-left">
            Clave
          </th>
          <th class="text-left">
            Codigo de barras
          </th>
          <th class="text-left">
            Modelo
          </th>
          <th class="text-left">
            Categoria
          </th>
          <th class="text-left">
            Marca
          </th>
          <th class="text-left">
            Precio de contado
          </th>
          <th class="text-left">
            Precio en pagos
          </th>
          <th class="text-left">
            Precio de mayoreo
          </th>
          <th class="text-left">
            Precio de menudeo
          </th>
          <th class="text-left">
            Oferta
          </th>
          <th class="text-left">
            Id de catalogo
          </th>
          <th class="text-left">
            Id de subdepartamento
          </th>
          
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="item in csv"
          :key="item.Nombre"
        >
          <td>{{ item.Nombre }}</td>
          <td>{{ item.Clave }}</td>
           <td>{{ item.Codigo_de_barras }}</td>
            <td>{{ item.Modelo }}</td>
          <td>{{ item.Categoria }}</td>
           <td>{{ item.Marca }}</td>
          <td>{{ item.Precio_de_contado }}</td>
           <td>{{ item.Precio_en_pagos }}</td>
          <td>{{ item.Precio_de_mayoreo }}</td>
           <td>{{ item.Precio_de_menudeo }}</td>
          <td>{{ item.Oferta }}</td>
           <td>{{ item.Id_Catalogo }}</td>
          <td>{{ item.Id_subdepartamento }}</td>
        </tr>
      </tbody>
    </template>
  </v-simple-table>



 

<v-snackbar

      absolute
      bottom
      color="red"
       v-model="snackbar"
        :timeout="timeout"
         
    >

<h2>Algo salio mal!</h2>
      {{ text }}

      <template v-slot:action="{ attrs }">
        <v-btn color="blue" text v-bind="attrs" @click="snackbar = false, rec()">
          Cerrar
        </v-btn>
      </template>
    </v-snackbar>

    <v-dialog
      v-model="dialog"
      max-width="600"
    >
      <v-card>
        <v-card-title>
          Tipos de campos para cargar CSV al sistema
        </v-card-title>

        <v-card-text>
          

<v-card>
          <v-simple-table>
            <thead>
              <tr>
              <td class="text-center"><strong>Nombre del campo</strong></td><td class="text-center"><strong>Dato que requiere</strong></td>
            </tr>
            </thead>
            <tbody>
            <tr v-for="cam in infocampos" :key="cam.id">
              <td style="color:#000;" class="text-center"><strong>{{cam.ncampo}}</strong></td>
              <td class="text-center" style="color:red;" v-if="cam.id == 7 || cam.id == 16 || cam.id == 17">{{cam.descrip}}</td>
              <td class="text-center" style="color:green;" v-else-if="cam.id == 2 || cam.id == 10">{{cam.descrip}}</td>
              <td class="text-center" style="color:blue;" v-else-if="cam.id == 15">{{cam.descrip}}</td>
              <td class="text-center" style="color:#000;" v-else>{{cam.descrip}}</td>
            </tr>
            </tbody>
            
          </v-simple-table>
</v-card>

        </v-card-text>

        <h3>TODOS LOS CAMPOS SON OBLIGATORIOS</h3>
        <br>
      </v-card>
    </v-dialog>

</div>
</template>
<script>
      import VueCsvImport  from 'vue-csv-import'; 
      const axios = require('axios');   
    
      export default {
        name: "CSVUpload",
        components: {
          VueCsvImport,
          
        },
        
        data() {
          return {
            snackbar: false,
            text: 'Revisa tu archivo CSV por que algunos articulos no se guardarón por que los catalgos, sucursales y/o sub departamentos podrian no existir',
            timeout: 10000,
            csv: null,
            dialog: false,
             
            infocampos:[

           {id:1, ncampo:'zaa_nombre_arti', descrip:'Acepta texto y numeros'},
           {id:2, ncampo:'zaa_color', descrip:'Acepta texto, en caso de mas colores separar por comas sin espacios'},
           {id:3, ncampo:'zaa_codigo_bar', descrip:'Acepta numeros'},
           {id:4, ncampo:'zaa_cantidad', descrip:'Acepta numeros enteros'},
           {id:5, ncampo:'zaa_modelo', descrip:'Acepta texto y numeros'},
           {id:6, ncampo:'zaa_categoria', descrip:'Acepta texto'},
           {id:7, ncampo:'zaa_id_sucursal', descrip:'Requiere el ID de alguna sucursal'},
           {id:8, ncampo:'zaa_clave', descrip:'Acepta texto y numeros'},
           {id:9, ncampo:'zaa_marca', descrip:'Acepta texto y numeros'},
           {id:10, ncampo:'zaa_talla', descrip:'Acepta numeros, en caso de mas tallas separar por comas sin espacios'},
           {id:11, ncampo:'zaa_prec_cont', descrip:'Acepta numeros enteros y decimales'},
           {id:12, ncampo:'zaa_prec_pag', descrip:'Acepta numeros enteros y decimales'},
           {id:13, ncampo:'zaa_prect_mayo', descrip:'Acepta numeros enteros y decimales'},
           {id:14, ncampo:'zaa_prect_menud', descrip:'Acepta numeros enteros y decimales'},
           {id:15, ncampo:'zaa_existen', descrip:'Acepta true para activo o false para inactivo'},
           {id:16, ncampo:'zaa_id_catalogo', descrip:'Requiere el ID de algun catalogo'},
           {id:17, ncampo:'zaa_id_subdep', descrip:'Requiere el ID de algun subdepartamento'} 
            ]
          }
        },
        
        methods: {
          rec(){
           location.reload;
          },

         async imprimirfor(){
           
        await this.csv.forEach(element => {
            
              axios.post('http://127.0.0.1:8000/articuloglobal/',{

                    zaag_nombre_arti: element.Nombre,
                    zaag_clave: element.Clave,
                    zaag_codigo_bar: element.Codigo_de_barras,
                    zaag_modelo: element.Modelo,
                    zaag_categoria: element.Categoria,
                    zaag_marca: element.Marca,
                    zaag_prec_cont: element.Precio_de_contado,
                    zaag_prec_pag: element.Precio_en_pagos,
                    zaag_prect_mayo: element.Precio_de_mayoreo,
                    zaag_prect_menud: element.Precio_de_menudeo,
                    zaag_oferta: element.Oferta,
                    zaag_id_catalogo: element.Id_Catalogo,
                    zaag_id_subdep: element.Id_subdepartamento,



                    
                }).catch(error => { this.snackbar = true })
 
                 
            })
            setTimeout('location.reload()',4000);
            
          },
          stringcolor(arrcolor){
            let arr = []
              arrcolor.split(',').forEach(element => {
                let v = {
                  text: element,
                }
                arr.push(v)
              });
            return arr
          },
          stringtalla(arrtalla){
            let arr = []
              arrtalla.split(',').forEach(element => {
                let v = {
                  text: element,
                }
                arr.push(v)
              });
            return arr
            },         
          },
          
        }
</script>
    
<style scope>
    
    .option{
       text-decoration-color: blue;
    }
      .td{
        color: #000;
        font-size: 16px;
        width: 50%;
      }

      input[type="file"]{
        border: 2px solid #ccc;
        width: 100%;
        border-radius: 5px;
      }
      .a_right{
        float: right;
      }
</style>

<style>
  select{
      width: 100%;
      border: 2px solid #ccc;
      border-radius: 5px;
      
    }
</style>

