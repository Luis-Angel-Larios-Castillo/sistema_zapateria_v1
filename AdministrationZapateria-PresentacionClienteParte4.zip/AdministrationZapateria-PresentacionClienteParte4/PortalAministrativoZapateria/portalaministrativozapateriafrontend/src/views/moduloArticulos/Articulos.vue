<!--Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los artículos registrados-->
<template>
<div cols="full">
    <v-row>
        <v-col cols="md-2 xs-12">
            <menuModulos/>
        </v-col> 
       
        <v-col cols="md-10 xs-12" >  
            <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">ARTICULOS</h1>
            </div><br>
            <v-card :elevation="0">
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                        <!--<v-btn dark text to="/cargacsv/" class="btn_csv" v-show="permissions.can_manage_arti == true">
                            Cargar CSV
                        </v-btn>-->
                        <v-btn dark text :to="'/carticulos/'" class="btn_add" v-show="permissions.can_manage_arti == true">
                            Agregar
                        </v-btn>
                    </div>
                </v-card-title>  
                <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                        :headers="headers"
                        :items="elements"
                        :search="search"
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen articulos registrados." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }"
                        :header-props="{ sortByText: 'Ordenar por' }">
                        <template v-slot:item.zaa_nombre_arti="{ item }">
                            <sArticulo :element="item"/>
                        </template>
                        <template v-slot:item.zaa_cantidad="{ item }">
                        <v-chip :color="getColor(item.zaa_cantidad)" class="white--text"> 
                            {{ item.zaa_cantidad }}
                        </v-chip>
                        </template>
                    
                        <template v-slot:item.zaa_prec_cont="{ item }">
                            ${{ item.zaa_prec_cont }}
                        </template>
                        <template v-slot:item.zaa_id_articulo="{ item }">
                            <v-row align="center">
                             <v-col>
                                    <v-tooltip bottom>
                                        <template v-slot:activator="{ on, attrs }">

                                            <v-btn icon :to="'/uarticulo/'+ item.zaa_id_articulo+'/'" v-bind="attrs" v-on="on"   v-if="permissions.can_manage_arti == true">
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                             <v-btn icon v-bind="attrs" v-on="on" v-else disabled>
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Editar</span>
                                    </v-tooltip>
                                    
                                </v-col>
                                <v-col>
                                    <dArticulo  :elementD="{item, permissions}"/> 
                                </v-col>
                               
                                <v-col>
                                    <v-tooltip bottom v-if="item.zaa_existen == true">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-icon  color="success" @click="desactivar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_arti == false">
                                                mdi-eye
                                            </v-icon>
                                        </template>
                                        <span>Desactivar</span>
                                    </v-tooltip>
                                    <v-tooltip bottom v-if="item.zaa_existen == false">
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-icon  color="red" @click="activar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_arti == false">
                                                mdi-eye-off-outline
                                            </v-icon>
                                        </template>
                                        <span>Activar</span>
                                    </v-tooltip>  
                                </v-col>
                            </v-row>
                        </template>
                    </v-data-table>
                </div>
            </v-card>
        </v-col>

    </v-row>
</div>
</template>

<script>
import Header from '../../components/Header';
import menuModulos from '../menuModulos' 
import dArticulo from './partials/dArticulo'
import sArticulo from './partials/sArticulo'
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,
        sArticulo,
        dArticulo,
    },    
    created() {
        
        this.find()
    },
    data () {
      return {
        element: Object,
        search: '', 
        idUser:[],
        empleadoResult:[],
        permissions: {
            can_manage_arti: false,
        },
        headers: [
          {
            text: 'Articulo',
            align: 'start',
            filterable: true,
            value: 'zaa_nombre_arti',

          },
          { text: 'Código de Barras', value: 'zaa_codigo_bar' },
          { text: 'Catalogo', value: 'zaa_cata_name' },
          { text: 'Cantidad', value: 'zaa_cantidad' },
          { text: 'Precio al contado', value: 'zaa_prec_cont' },
          { text: 'Acciones', value: 'zaa_id_articulo', sortable: false, align: "start"},
        ],
        elements: [],
       
      }
    },
    methods:{

        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }

            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user

            axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+ this.idUser)
                .then(res=>{this.admin=res.data[0]

                    if(this.admin.is_superuser==false){
                        axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
                        .then(res => { this.empleadoResult = res.data[0]
                        axios.get('http://127.0.0.1:8000/articulo/admin/?search=' + this.empleadoResult.zdem_id_sucursal,config)
                            .then(res => this.elements = res.data)
                        })
                    }
                    else{
                        axios.get('http://127.0.0.1:8000/articulo/admin/')
                            .then(res => this.elements = res.data)
                    }
                })
            })

                 
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_arti: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {   
                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/', config)
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos') { this.permissions.can_manage_arti = true}
                                                       
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })      
        },
        getColor (zaa_cantidad) {
            if (zaa_cantidad < 2) return 'red accent-3'
            else if (zaa_cantidad < 5) return 'orange accent-3'
            else return 'green accent-4'
        },
        activar (n) {
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            const URL = 'http://127.0.0.1:8000/articulo/admin/'+n.zaa_id_articulo+'/'
            axios.put(URL, {
                zaa_id_sucursal: n.zaa_id_sucursal,
                zaa_cantidad: n.zaa_cantidad,
                zaa_existen: true,
                zaa_id_articulo: n.zaa_id_articulo,
                zaa_talla: n.zaa_talla,
                zaa_color: n.zaa_color,
                zaa_id_arti_global:n.zaa_id_arti_global
            }, config)
            .then(res => window.location.reload() )
            .catch(error => console.log(error))
        }, 
        desactivar (n) {
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            const URL = 'http://127.0.0.1:8000/articulo/admin/'+n.zaa_id_articulo+'/'
            axios.put(URL, {
                
                zaa_id_sucursal: n.zaa_id_sucursal,
                zaa_cantidad: n.zaa_cantidad,
                zaa_existen: false,
                zaa_id_articulo: n.zaa_id_articulo,
                zaa_talla: n.zaa_talla,
                zaa_color: n.zaa_color,
                zaa_id_arti_global:n.zaa_id_arti_global
            }, config)
            .then(res => window.location.reload() )
            .catch(error => console.log(error))
        },
        getcatalogo(id){
            console.log(id)
        }
    },
  }
</script>