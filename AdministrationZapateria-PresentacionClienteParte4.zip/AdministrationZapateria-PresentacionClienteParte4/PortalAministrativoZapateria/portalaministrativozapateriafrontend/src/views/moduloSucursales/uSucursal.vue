<template>
    <v-container fluid>
       <div v-if="permissions.can_manage_sucursal == true">
          <app-header style="z-index: 135"/> 
          <br>
        <div class="col-9">
        <v-toolbar class="" flat align="center" justify="space-around" id="table_cabecera_color_formulario">
         <v-toolbar-title>
            <v-icon right dark>
              mdi-rotate-3d-variant
            </v-icon>
            <strong id="title_editar"> Edición de la sucursal {{elementU.zdsu_nombre}}</strong>
         </v-toolbar-title>
          <v-spacer/>
          <v-btn to="/sucursal/" outlined class="btn_add" color="#F7F9F9">
              Regresar
          </v-btn>
        </v-toolbar>

      
          <v-container id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>
              <v-alert id="title_formulario" dense icon="mdi-file-edit">
                <strong>INFORMACIÓN GENERAL</strong>
              </v-alert>
                <v-row>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_nombre" :rules="nombreRules" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" label="Nombre de la sucursal" required :counter="50" maxlength="50" ></v-text-field>
                    </v-col>
                    <v-col>
                          <v-text-field v-model="elementU.zdsu_num_tel" :rules="telefonoRules" v-mask="'###-###-##-##'" max="13" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono" required placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos" counter>
                          <v-tooltip slot="append" bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                              <v-icon  color="blue" v-bind="attrs" v-on="on">
                                mdi-help-circle-outline
                              </v-icon> 
                            </template> 
                            <div>
                              Escribir el número telefónico con lada: <br>
                              Ejemplo: 241-000-00-00
                              <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p> 
                            </div> 
                          </v-tooltip> 
                          </v-text-field>
                    </v-col>

                     <v-col>
                       <v-row>
                          <v-col class="col-2">
                           
                        </v-col>
                      <v-col>
                       <v-switch
                        v-model="elementU.zdsu_estat_sucur"
                        inset
                        label="Estatus"
                      ></v-switch>
                      
                     </v-col>
                        </v-row>
                    </v-col>
                    
                   
                </v-row>
                <br>
                
                <v-alert id="title_formulario" dense icon="mdi-home">
                  <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
                  </v-alert>
                 <v-row>
                    <v-col>
                         <v-text-field v-model="elementU.zdsu_dir_pais" :rules="paisRules" label="Pais" :counter="40" maxlength="40" readonly filled></v-text-field>
                    </v-col>
                     <v-col>
                        <v-select  v-model="elementU.zdsu_dir_estado" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="estadoRules" label="Estado" required :counter="50" maxlength="50" readonly filled></v-select>
                    </v-col>
                   <v-col>
                        <v-select v-model="elementU.zdsu_dir_municipio" :items="municipio" :rules="municipioRules" label="Municipio" item-text="name" required :counter="50" maxlength="50" readonly filled></v-select>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_dir_colonia" :rules="coloniaRules" label="Barrio/Colonia:" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');" placeholder="Ejem. El Bosque" filled></v-text-field>
                    </v-col>

                </v-row>

               
                <v-row>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_dir_calle_1" :rules="calleRules" label="Calle principal" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');"  placeholder="Ejem. Calle López Mateos"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_dir_calle_2" :rules="calle2Rules" label="Calle interconexión" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita"></v-text-field>
                    </v-col>
                   
                </v-row>
               
                <v-row>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_dir_cod_postal" :rules="cod_postalRules" oninput="this.value=this.value.replace(/[^0-9]/g,'');" label="Codigo Postal" required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="elementU.zdsu_dir_num_ext" :rules="num_extRules" label="Núm. Exterior:"  :counter="25" maxlength="25" required title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                    </v-col>
                    <v-col>
                         <v-text-field v-model="elementU.zdsu_dir_num_int"  :rules="num_inteRules" label="Núm. Interior:" required  :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N"></v-text-field>
                    </v-col>
                     <v-col>
                        <v-text-field v-model="elementU.zdsu_folio_surcur" :rules="folio_sucRules" label="Folio" required  maxlength="50" readonly filled></v-text-field>
                    </v-col>
                    

                </v-row>
              
              
              <br><br>
                <v-row align="center" justify="space-around">
                  <v-btn :disabled="!valid" x-large id="btn_actualizar_formulario" class="mr-4" @click="validate">
                      Actualizar
                      <v-icon right dark>mdi-update</v-icon>
                  </v-btn>
                  <v-btn id="btn_cancelar_formulario"  x-large class="mr-4" @click="cancelar" >Cancelar<v-icon right dark>mdi-close-circle</v-icon></v-btn>
              </v-row>
            </v-form>
          </v-container>
      
      </div>
     </div>
       <div v-else>
         <ErrorPage403/>
        </div>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const axios = require('axios')
import esta from "../../assets/json/muni.json";
  export default {
     name: 'Header', 
    components:{
       "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.filtar()
      this.find()
    },
    data () {
      return {
      elementU: [],
      valid: true,      
      nombre: '',
      nombreRules: [
        v => !!v || 'El campo nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo nombre debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El nombre no debe tener más de 50 caracteres',
      
      ],
      calle2: '',
      calle2Rules:[
        v => !!v || 'Se requiere ingresar entre que calles se encuentra la sucursal.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El registro no debe tener más de 50 caracteres.',

      ],
      calle: '',
      calleRules: [
         v => !!v || 'Se requiere la calle principal.',
         v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',
         v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
         v => (v && v.length <= 50) || 'El campo "Calle Principal" no debe tener más de 50 caracteres.',
      ],
      
      colonia: '',
      coloniaRules: [
        v => !!v || 'El campo colonia es obligatorio',
         v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo colonia debe ser mayúscula',
        v => (v && v.length >= 4) || 'La colonia debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'La colonia no debe tener más de 50 caracteres',
       
      ],
      camp_municipio: '',
      municipio: [],
      municipioRules: [
        v => !!v || 'El campo municipio es obligatorio',
        v => (v && v.length >= 4) || 'El municipio debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El municipio no debe tener más de 50 caracteres',
      ],
      
      camp_estado: 'Tlaxcala',
      estado: esta, 
      estadoRules: [
        v => !!v || 'El campo estado es obligatorio',
        v => (v && v.length >= 4) || 'El estado debe tener más de 3 caracteres',
        v => (v && v.length <= 40) || 'El estado no debe tener más de 40 caracteres',
      ],
      camp_pais: 'Mexico',
       paisRules: [
        v => !!v || 'El campo pais es obligatorio',
        v => (v && v.length >= 4) || 'El pais debe tener más de 3 caracteres',
        v => (v && v.length <= 40) || 'El pais no debe tener más de 40 caracteres',
      ],
      cod_postal: '',
      cod_postalRules: [
        v => !!v || 'El campo código Postal  es obligatorio',
        v => (v && v.length > 4) || 'El código postal debe tener 5 caracteres.',
        v => (v && v.length <= 5) || 'El código postal no debe tener más de 5 caracteres.',
      ],
      num_ext: '',
      num_extRules: [
        v => !!v || 'Se requiere el número exterior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Exterior" no debe tener más de 25 caracteres.',
      ],
      num_inte: '',
      num_inteRules: [
        v => !!v || 'Se requiere el número interior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Interior" no debe tener más de 25 caracteres.',
      ],
      telefono: '',
      telefonoRules: [
        v => !!v || 'El campo número de telefono es obligatorio',
        v => (v && v.length == 13) || 'El campo número de telefono debe tener 10 caracteres.',
      ],
      folio_suc: '',
      folio_sucRules: [
        v => !!v || 'El campo folio es obligatorio',
        v => (v && v.length >= 5) || 'El folio debe tener más de 5 caracteres',
        v => (v && v.length <= 50) || 'El folio no debe tener más de 50 caracteres',
      ],
      
      elements: [],
      permissions: {
                    can_manage_sucursal: false,
                  
                },
      }
    },
    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_sucursal: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_sucursales') { this.permissions.can_manage_sucursal = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
        filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.camp_estado )
            this.municipio = this.estado[i].municipios
          } 
        },
         find(){
            axios.get('http://127.0.0.1:8000/sucursal/'+ this.$route.params.id +'/').
                then(res => {
                  this.elementU = res.data
                })
        },
        validate () {
        this.$refs.form.validate()
        this.update()
      },
        async update(){
          await axios.put('http://127.0.0.1:8000/sucursal/'+ this.$route.params.id +'/',this.elementU)
          .catch(error => console.log(error));
          this.$router.push({ name: 'Sucursal' });
        },
     
     reset () {
        this.$refs.form.reset()
      },
      cancelar () {
        this.$router.push({ name: 'Sucursal' });
      },
     
     
     
    },
  }
</script>