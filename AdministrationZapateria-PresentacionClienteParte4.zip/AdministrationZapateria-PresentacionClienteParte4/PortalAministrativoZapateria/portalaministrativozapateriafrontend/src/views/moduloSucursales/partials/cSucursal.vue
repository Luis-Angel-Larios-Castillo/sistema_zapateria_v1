<template>

    <v-container fluid>
      <div v-if="permissions.can_manage_sucursal == true">
         <app-header style="z-index: 135"/> 
       
        <v-col cols="md-10 xs-12">
        <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE SUCURSALES</h1>
        </div><br>
        <v-card :elevation="0"> 
        <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          
          <v-spacer/>
          <v-btn to="/sucursal/" outlined class="btn_add" color="#F7F9F9">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>  

        
          <v-container class="col-12" id="tabla_datos_dos">
            <v-form ref="form" v-model="valid" lazy-validation>
               <v-alert id="title_formulario" dense icon="mdi-file-edit">
                <strong>INFORMACIÓN GENERAL</strong>
              </v-alert>
                <v-row>
                    <v-col>
                        <v-text-field v-model="nombre" :rules="nombreRules" label="Nombre de la sucursal" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Apizaco" title="Sólo se permiten letras"></v-text-field>
                    </v-col>
                    
                    <v-col>
                          <v-text-field v-model="telefono" v-mask="'###-###-##-##'" max="13" :rules="telefonoRules" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono" required counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos">
                          <v-tooltip slot="append" bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                              <v-icon  color="blue" v-bind="attrs" v-on="on">
                                mdi-help-circle-outline
                              </v-icon> 
                            </template> 
                            <div>
                              Escribir el número telefónico con lada: <br>
                              Ejemplo: 241-000-00-00
                              <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p> 
                            </div> 
                          </v-tooltip> 
            
                          </v-text-field>
                    </v-col>
                     <v-col v-show="camp_municipio">

                      <v-chip
                      class="ma-2"
                      color="indigo darken-3"
                      outlined
                    >
                       {{obtfoli(camp_municipio)}}
                     
                    </v-chip>
                    </v-col>
   
                </v-row>
                <br>
                <v-alert id="title_formulario" dense icon="mdi-home">
                  <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
                  </v-alert>
                 <v-row>
                    <v-col>
                         <v-text-field v-model="camp_pais" :rules="paisRules" label="Pais" :counter="40" maxlength="40"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-select  v-model="camp_estado" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="estadoRules" label="Estado" required :counter="50" maxlength="50"></v-select>
                    </v-col>
                    <v-col>
                        <v-select v-model="camp_municipio" :items="municipio" :rules="municipioRules" label="Municipio" item-text="name" required :counter="50" maxlength="50"></v-select>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="colonia" :rules="coloniaRules" label="Barrio/Colonia:" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');" placeholder="Ejem. El Bosque"></v-text-field>
                    </v-col>

                </v-row>
                <v-row>
                    <v-col>
                        <v-text-field v-model="calle1" :rules="calleRules" label="Calle principal" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="calle2" :rules="calle2Rules" label="Calle/s de Interconexión:" required :counter="50" maxlength="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ 0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita"></v-text-field>
                    </v-col>
                </v-row>
               
                <v-row>
                    <v-col>
                        <v-text-field v-model="cod_postal" :rules="cod_postalRules" oninput="this.value=this.value.replace(/[^0-9]/g,'');" label="Codigo Postal" required :counter="5"  placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-text-field v-model="num_ext" :rules="num_extRules" label="Núm. Exterior:"  :counter="25" maxlength="25" required title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                    </v-col>
                    <v-col>
                         <v-text-field v-model="num_inte"  :rules="num_inteRules" label="Núm. Interior:" required  :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N"></v-text-field>
                    </v-col>
                    <v-col>
                        <v-switch
                        v-model="estatus_su"
                        inset
                        label="Estatus"
                      ></v-switch>
                      
                     </v-col>
                </v-row>
                 
              <br><br>
                <v-row align="center" justify="space-around">
                    <v-btn :disabled="!valid"  id="btn_agrega_otro_formulario"  class="mr-4" @click="validate">
                        Guardar y agregar otro 
                        <v-icon right dark>
                            mdi-reload
                        </v-icon>
                    </v-btn>
                    <v-btn :disabled="!valid" id="btn_guardar_formulario"   class="mr-4" @click="validate02">
                        Guardar 
                        <v-icon right dark>
                            mdi-cloud-upload
                        </v-icon>
                    </v-btn>
                    <v-btn id="btn_borrar_formulario" class="mr-4" @click="reset">
                        Borrar Formulario
                      <v-icon right dark>mdi-eraser</v-icon>
                    </v-btn>
                    <v-btn to="/sucursal/" id="btn_cancelar_formulario">
                      Cancelar
                      <v-icon right dark>mdi-close-circle</v-icon>
                    </v-btn> 
                </v-row>
            </v-form>
          </v-container>
      </v-card> 
      </v-col>
      </div>
       <div v-else>
         <ErrorPage403/>
        </div>


    </v-container>
</template>
<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require('axios')
import esta from "../../../assets/json/muni.json";
  export default {
     name: 'Header', 
    components:{
       "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.filtar()
    },
    data () {
      return {
      element: [],
      valid: true,      
      
      nombre: '',
      nombreRules: [
        
        v => !!v || 'El campo nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo nombre debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El nombre no debe tener más de 50 caracteres',
       
      ],
      calle2: '',
      calle2Rules:[
        v => !!v || 'Se requiere ingresar entre que calles se encuentra la sucursal.',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 50) || 'El registro no debe tener más de 50 caracteres.',

      ],
      calle1: '',
      calleRules: [
         v => !!v || 'Se requiere la calle principal.',
         v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',
         v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
         v => (v && v.length <= 50) || 'El campo "Calle Principal" no debe tener más de 50 caracteres.',
      ],
      colonia: '',
      coloniaRules: [
        v => !!v || 'El campo colonia es obligatorio',
         v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo colonia debe ser mayúscula',
        v => (v && v.length >= 4) || 'La colonia debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'La colonia no debe tener más de 50 caracteres',
       
      ],
      camp_municipio: '',
      municipio: [],
      municipioRules: [
        v => !!v || 'El campo municipio es obligatorio',
        v => (v && v.length >= 4) || 'El municipio debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El municipio no debe tener más de 50 caracteres',
      ],
      
      camp_estado: 'Tlaxcala',
      estado: esta, 
      estadoRules: [
        v => !!v || 'El campo estado es obligatorio',
        v => (v && v.length >= 4) || 'El estado debe tener más de 3 caracteres',
        v => (v && v.length <= 40) || 'El estado no debe tener más de 40 caracteres',
      ],
      camp_pais: 'Mexico',
       paisRules: [
        v => !!v || 'El campo pais es obligatorio',
        v => (v && v.length >= 4) || 'El pais debe tener más de 3 caracteres',
        v => (v && v.length <= 40) || 'El pais no debe tener más de 40 caracteres',
      ],
      cod_postal: '',
      cod_postalRules: [
        v => !!v || 'El campo código postal es obligatorio',
        v => (v && v.length > 4) || 'El código postal debe tener 5 caracteres.',
        v => (v && v.length <= 5) || 'El código postal no debe tener más de 5 caracteres.',
      ],
      num_ext: '',
      num_extRules: [
        v => !!v || 'Se requiere el número exterior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Exterior" no debe tener más de 25 caracteres.',
      ],
      num_inte: '',
      num_inteRules: [
        v => !!v || 'Se requiere el número interior.',
        v => (v && v.length <= 25) || 'El campo "Núm. Interior" no debe tener más de 25 caracteres.',
      ],
      telefono: '',
      telefonoRules: [
        v => !!v || 'El campo número de teléfono es obligatorio',
        v => (v && v.length == 13) || 'El campo número de telefono debe tener 10 caracteres.',
      ],
      folio_suc: '',
      folio_sucRules: [
        v => !!v || 'El campo folio es obligatorio',
        v => (v && v.length >= 5) || 'El folio debe tener más de 5 caracteres',
        v => (v && v.length <= 50) || 'El folio no debe tener más de 50 caracteres',
      ],
      estatus_su: false,
      elements: [],
      num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
       permissions: {
                    can_manage_sucursal: false,
                  
                },
      }
    },
    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_sucursal: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_sucursales') { this.permissions.can_manage_sucursal = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
        filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.camp_estado )
            this.municipio = this.estado[i].municipios
          } 
        },
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zdsu_nombre: this.nombre,
            zdsu_dir_calle_1: this.calle1,
            zdsu_dir_calle_2: this.calle2,
            zdsu_dir_colonia: this.colonia,
            zdsu_dir_municipio: this.camp_municipio,
            zdsu_dir_estado: this.camp_estado,
            zdsu_dir_pais: this.camp_pais,
            zdsu_dir_cod_postal: this.cod_postal,
            zdsu_dir_num_ext: this.num_ext,
            zdsu_dir_num_int: this.num_inte,
            zdsu_num_tel: this.telefono,
            zdsu_estat_sucur: this.estatus_su,
            zdsu_folio_surcur: "Fol" + " - "+ this.camp_municipio.slice(0,3) +" - "+ this.num_random,
          

          }
        this.createAndNew()
        }        
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            zdsu_nombre: this.nombre,
            zdsu_dir_calle_1: this.calle1,
            zdsu_dir_calle_2: this.calle2,
            zdsu_dir_colonia: this.colonia,
            zdsu_dir_municipio: this.camp_municipio,
            zdsu_dir_estado: this.camp_estado,
            zdsu_dir_pais: this.camp_pais,
            zdsu_dir_cod_postal: this.cod_postal,
            zdsu_dir_num_ext: this.num_ext,
            zdsu_dir_num_int: this.num_inte,
            zdsu_num_tel: this.telefono,
            zdsu_estat_sucur: this.estatus_su,
            zdsu_folio_surcur: "Fol" + " - "+ this.camp_municipio.substr(0,3) +" - "+ this.num_random,
          
          }
        this.create() 
        }        
      },
      createAndNew(){
        axios.post('http://127.0.0.1:8000/sucursal/', this.element)
          .then(res => {
            window.location.reload()
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      create(){
        axios.post('http://127.0.0.1:8000/sucursal/', this.element)
          .then(res => {
            this.$router.go(-1);
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      reset () {
            this.nombre=""
            this.calle1=""
            this.calle2=""
            this.colonia=""
            this.camp_municipio=""
            this.camp_estado=""
            this.camp_pais=""
            this.cod_postal=""
            this.num_ext=""
            this.num_inte=""
            this.telefono=""
            this.folio_suc=""
      },
      obtfoli(muni){
        let obtfol=""
        obtfol=  "Fol" + " - "+ muni.substr(0,3) +" - "+ this.num_random;
        return obtfol
      }
    },
  }
</script>