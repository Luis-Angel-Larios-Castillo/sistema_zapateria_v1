<!--
Autor: Luis Angel Larios Castillo
Descripción: Archivo que contiene la ventana emergente al momento de querer eliminar un registro y la cual le permite al usuario confirmar la acción solicitada
-->

<template>
  <v-row justify="center">
    <v-tooltip bottom >
      <template v-slot:activator="{ on, attrs }">
        <v-btn icon color="red" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_sucursal == false">
          <v-icon color="red">mdi-delete</v-icon>
        </v-btn>
      </template>
      <span>Eliminar</span>
    </v-tooltip>
    
    <v-dialog v-model="dialog" max-width="331">
      <v-card>
       
 <v-alert
      border="bottom"
      colored-border
      type="warning"
      color="red"
      v-model="snackbaralert"
    >
    
     <strong>Se va a eliminar la sucursal:<br>{{elementD.item.zdsu_nombre}}</strong>
    </v-alert>

    
       
       <v-alert
        border="bottom"
        colored-border
        type="warning"
        color="red"
    
        v-model="snackbar"
        dense
        >
        {{ text }}
        </v-alert>

         <v-alert
        border="bottom"
        colored-border
        type="warning"
        color="red"
        v-model="snackbar2"
        dense
        >
        {{ text2 }}
        </v-alert>

        
         <v-alert
        border="bottom"
        colored-border
        type="warning"
        color="red"
        v-model="snackbar3"
        dense
        >
        {{ text3 }}
        </v-alert>

<div v-show="snackbar">

<v-btn outlined color="red" rounded @click="dialog = false">
          Cancelar
          <v-icon right dark>mdi-close-circle</v-icon>
        </v-btn>
</div>


<div v-show="snackbar2">

<v-btn outlined color="red" rounded @click="dialog = false">
          Cancelar
          <v-icon right dark>mdi-close-circle</v-icon>
        </v-btn>
</div>

<div v-show="snackbar3">

<v-btn outlined color="red" rounded @click="dialog = false">
          Cancelar
          <v-icon right dark>mdi-close-circle</v-icon>
        </v-btn>
</div>


      <div v-show="snackbaralert">
        <v-card-text class="black--text">
          <h4>¿Está de acuerdo en eliminarlo?</h4>
        </v-card-text>
        
      

        <v-btn outlined color="red" rounded @click="dialog = false">
          Cancelar
          <v-icon right dark>mdi-close-circle</v-icon>
        </v-btn>
&nbsp;
        <v-btn outlined color="success" rounded @click="aceptar()" >
          Aceptar
          <v-icon right dark>mdi-check-all</v-icon>
        </v-btn>
        </div>





         <br>

        

      </v-card>
    </v-dialog>

  </v-row>

</template>

<script>
  const axios = require('axios')
  
  export default {
    props:[
      'elementD'
    ],
    
    data () {
      return {
        dialog: false,
        elements:[],
        elementscafi:[],
        elementsarti:[],
        snackbar: false,
        snackbar2: false,
        snackbar3: false,
        text: 'Esta sucursal no se puede eliminar por que tiene empleados asociados',
        text2: 'Esta sucursal no se puede eliminar por que tiene clientes afiliados asociados',
        text3: 'Esta sucursal no se puede eliminar por que tiene articulos asociados',
        snackbaralert: true,
       

      }
    },
    
    methods:{
      aceptar(){
        
         axios.get('http://127.0.0.1:8000/empleado/empleados/sucursal/?search='+ this.elementD.item.zdsu_id_sucursal)
                .then(res => {
                  this.elements = res.data
                  if(this.elements.length != 0){
                        this.snackbar = true 
                        this.snackbaralert=false
                        //console.log('hay empleados')
                     
                  }
                  else {
                    

                    axios.get('http://127.0.0.1:8000/cliente/suc/?search='+ this.elementD.item.zdsu_id_sucursal)
                      .then(res => {
                        this.elementscafi = res.data
                        if(this.elementscafi.length != 0){
                              this.snackbar2 = true 
                              this.snackbaralert=false
                              //console.log('hay clientes')
                            }
                    else{

                    axios.get('http://127.0.0.1:8000/articulo/invSuc/?search='+ this.elementD.item.zdsu_id_sucursal)
                      .then(res => {
                        this.elementsarti = res.data
                        if(this.elementsarti.length != 0){
                              this.snackbar3 = true 
                              this.snackbaralert=false
                              //console.log('hay articulos')
                            }
                        
                            
                        
                              
                        else{
                            let URL = 'http://127.0.0.1:8000/sucursal/'+ this.elementD.item.zdsu_id_sucursal
                             axios.delete(URL)
                                .then(response => {
                                  this.dialog = false
                                  window.location.reload()
                                })
                               // console.log('No hay clientes ni empleados')
                          }

                      })
                    
                    } })
                  }
                })
      
                
      },
    },
  }
</script>