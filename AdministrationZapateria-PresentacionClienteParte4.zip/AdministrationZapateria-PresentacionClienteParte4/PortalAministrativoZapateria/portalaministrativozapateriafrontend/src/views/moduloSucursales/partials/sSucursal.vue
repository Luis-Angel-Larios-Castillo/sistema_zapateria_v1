<!--
♣ Autor: Luis Angel Larios Castillo
♣ Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro
-->

<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zdsu_nombre}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
        
        </v-card-title>
        
        <v-card-text>
          <v-alert color="info" dark dense align="left">
            <h3>  <v-icon>mdi-store</v-icon>
           Sucursal: {{element.zdsu_nombre}}</h3>
          </v-alert>
           
           
          <div class="black--text">                
            <div align="left" style="font-size:15px;">
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DE CONTACTO</h3>
                </v-alert>
                <div align="center">
                <p><strong>ID: </strong> {{element.zdsu_id_sucursal}}</p>
                <p><strong>Folio: </strong> {{element.zdsu_folio_surcur}}</p>
                <p><strong><i>Telefono :</i></strong> {{element.zdsu_num_tel}}</p>
                
                 <p><strong><i>Estatus :</i></strong> 
                 
                 <v-chip
                class="ma-2"
                :color="colorestatus(element.zdsu_estat_sucur)"
                outlined
              >
              {{funestatus(element.zdsu_estat_sucur)}}
              </v-chip>
                 
                 </p>
                </div>
                <v-alert color="grey lighten-4" dense align="center">
                
                 <h3>DATOS DE DIRECCIÓN</h3>
                </v-alert>

               
               
                   <v-row align="center">
                    <v-col align="center">
                         <p class="mb-0"> {{element.zdsu_dir_pais}}</p>
                         <p style="font-size:10px;"><strong>País</strong></p>
                    </v-col>
                    <v-col align="center">
                         <p class="mb-0">{{element.zdsu_dir_estado}}</p>
                         <p style="font-size:10px;"><strong>Estado</strong></p>
                    </v-col>
                    <v-col align="center">
                        <p class="mb-0"> {{element.zdsu_dir_municipio}}</p>
                        <p style="font-size:10px;"><strong>Municipio</strong></p>
                    </v-col>
                </v-row>

                <v-row align="center">
                    <v-col align="center">
                         <p class="mb-0">  {{element.zdsu_dir_calle_1}}</p>
                         <p style="font-size:10px;"><strong>Calle Principal</strong></p>
                    </v-col>
                    <v-col align="center">
                         <p class="mb-0">{{element.zdsu_dir_calle_2}}</p>
                         <p style="font-size:10px;"><strong>Calle Interconexión</strong></p>
                    </v-col>
                    <v-col align="center">
                        <p class="mb-0"> {{element.zdsu_dir_colonia}}</p>
                        <p style="font-size:10px;"><strong>Colonia</strong></p>
                    </v-col>
                </v-row>
                <v-alert color="grey lighten-5" dense align="center">
                 <p><strong>Codigo postal :</strong> {{element.zdsu_dir_cod_postal}} ---- <strong>N° Exterior :</strong> {{element.zdsu_dir_num_ext}} ---- <strong>N° Interior :</strong> {{element.zdsu_dir_num_int}}</p>
                </v-alert> 
                <v-col align="center">
                  <p class="red--text"><strong>Fecha de creación: </strong>{{fecha(element.zdsu_fech_crea)}}</p>
                  <p class="red--text"><strong>Fecha de modificación: </strong>{{fecha(element.zdsu_fech_mod)}}</p> 
                </v-col>
            </div>
        </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
const moment = require('moment')
  export default {
    props:[
      'element'
    ],
    
    methods:{
      funestatus(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activa"
          }
          else{
              cam_estatus="Inactiva"
          }
          return cam_estatus
      },
      colorestatus(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },
       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
    },
  }
</script>