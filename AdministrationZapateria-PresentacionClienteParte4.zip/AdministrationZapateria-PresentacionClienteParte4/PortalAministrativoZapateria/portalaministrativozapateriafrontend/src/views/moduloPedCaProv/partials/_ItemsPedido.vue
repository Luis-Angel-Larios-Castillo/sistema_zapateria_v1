Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra los catalogos de un pedido
<template>
    <v-container fluid> 
        <v-card width="600px">
            <v-card-actions @click="show = !show" hover>
                <v-btn color="blue"   text>Ver listado </v-btn> 
                <v-spacer></v-spacer> 
                <v-btn icon>
                    <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
                </v-btn>
            </v-card-actions>
            <v-expand-transition>
                <div v-show="show">
                    <v-divider></v-divider>  
                    <v-simple-table dense fixed-header>
                        <template v-slot:default>
                            <thead>
                                <tr>  
                                    <th class="text-center font-weight-black black--text">Nombre</th> 
                                    <th class="text-center font-weight-black black--text">Marca</th> 
                                    <th class="text-center font-weight-black black--text">Cantidad solicitada</th>
                                    <th class="text-center font-weight-black black--text">Cantidad recibida</th>
                                </tr>
                            </thead>
                            <tbody> 
                                <tr v-for="item in items" :key="item.zpedsucat_id_item_ped_cat">   
                                    <td class="text-center">{{item.zpedsucat_nombre}}</td>  
                                    <td class="text-center">{{item.zpedsucat_marca}}</td> 
                                    <td class="text-center">{{item.zpedsucat_cant_ped}}</td> 
                                    <td class="text-center">{{item.zpedsucat_cant_ped_llego}}</td> 
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>  
                </div> 
            </v-expand-transition> 
        </v-card>  
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[ 
        'items'
    ],
    data() {
        return {
            tab: null, 
            show: false,
        }
    }, 
}
</script>