Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra toda la informacion del pedido
<template>
    <v-container fluid>   
          <app-header style="z-index: 135"/> 
          <div class="col-10">
        <v-card>  
            <v-card-title>
                <h3>Pedido Proveedor: {{pedCab.zpedpr_nombre}}</h3>
                <v-spacer/>
                <h3>{{fecha(pedCab.zpedpr_fech_creat)}}</h3>
                <v-spacer/>
                <v-btn dark text color="purple" :to="'/ListPedCatalogoPro/'">
                    regresar
                </v-btn> 
            </v-card-title>
            <v-card-title> 
                <h4>Creado por: {{emplCrea.nombre}}</h4>
                <v-spacer/> 
                <h4>Estatus: {{pedCab.zpedpr_status_ped}}</h4> 
            </v-card-title>
            <v-card-title> 
                <h4>Proveedor: {{proveedor.zp_nombre}} {{proveedor.zp_apell_pat}} {{proveedor.zp_apell_mat}}</h4>
                <v-spacer/>
                <h4>Identificador: {{proveedor.zp_identify_mark}}</h4> 
            </v-card-title>
            <v-card-title v-if="modif == true"> 
                <h5>Modificado por: {{emplMod.nombre}}</h5>
                <v-spacer/> 
                <h5>Fecha de mod: {{fecha(pedCab.zpedpr_fech_mod)}}</h5> 
            </v-card-title> 
            <v-toolbar dense dark v-if="pedi.length != 0">
                <h3>Pedidos a entregar</h3> 
                <v-spacer></v-spacer>
                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                
            </v-toolbar> 
            <v-data-table
                v-if="pedi.length != 0"
                id="tabla_datos"
                :headers="headers" 
                :items="pedi" 
                :search="search"
                :items-per-page="5"
                :items-per-page-options="[5, 10, 15]"
                no-results-text="No hay resultados."
                no-data-text="No se tienen pedidos registrados." 
                :footer-props="{
                    showFirstLastPage: true,
                    itemsPerPageText: 'Elementos por página ',
                }"
                :header-props="{ sortByText: 'Ordenar por' }"
            >
                <template v-slot:item.zpedcsuc_nombre="{ item }" >  
                    <strong>{{item.zpedcsuc_nombre}}</strong>  
                </template>      
                <template v-slot:item.zpedcsuc_proveedor_nombre="{ item }" >  
                    <strong>{{item.zpedcsuc_proveedor_nombre}}</strong>  
                </template> 
                <template v-slot:item.zpedcsuc_id_ped_cat_sucur="{ item }" >
                    <v-row>
                        <PDF :id="item.zpedcsuc_id_ped_cat_sucur"/>  
                        <v-tooltip bottom> 
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon color="primary" @click="entregar(item)" v-bind="attrs" v-on="on">
                                    <v-icon>mdi-package-variant-closed</v-icon>
                                </v-btn>
                            </template>
                            <span>Enviar a la sucursal</span>
                        </v-tooltip>   
                    </v-row>
                </template>  
            </v-data-table>
            <br>
            <v-toolbar dense dark v-if="pedCab.zpedpr_status_ped == 'Regreso chofer a centro de distribución'">
                <v-spacer></v-spacer>
                <v-btn v-if="pedCab.zpedpr_puede_editar == true" @click="editar()" text class="btn_gped white--text">dejar de editar</v-btn>
                <v-btn v-else @click="editar()" text class="btn_gped white--text">Editar</v-btn> 
                <v-btn @click="finalizar()" text class="btn_gped white--text">Finalizar</v-btn>
            </v-toolbar> 
            <v-card-text> 
                <v-simple-table dense fixed-header>
                    <template v-slot:default>
                        <thead>
                            <tr>  
                                <th class="text-center font-weight-black black--text">Nombre</th>
                                <th class="text-center font-weight-black black--text">Marca</th> 
                                <th class="text-center font-weight-black black--text">Cantidad solicitada</th>
                                <th class="font-weight-black black--text">Cantidad recibida</th> 
                            </tr>
                        </thead>
                        <tbody> 
                            <tr v-for="item in reportes" :key="item.zpedproit_id_item_caj">   
                                <td class="text-center">{{item.zpedipr_nombre}}</td>
                                <td class="text-center">{{item.zpedipr_marca}}</td>  
                                <td class="text-center">{{item.zpedipr_cant_ped}}</td> 
                                <td class="text-center" >                                  
                                    <v-text-field  v-if="pedCab.zpedpr_status_ped == 'Regreso chofer a centro de distribución'"  class="fieldCant" :disabled="pedCab.zpedpr_puede_editar == false" v-model="item.zpedipr_cant_ped_llego" v-on:change="ingresarCantidad(item)"  label="Cantidad"/>
                                    <p v-else>
                                        {{item.zpedipr_cant_ped_llego}}
                                    </p>
                                </td> 
                                
                            </tr>
                        </tbody>
                    </template>
                </v-simple-table>  
            </v-card-text> 
        </v-card>
          </div> 
        <v-snackbar shaped color="green" outlined v-model="snackbar" :timeout="timeout">
            <h2 class="black--text" >{{ text }}</h2> 
            <template v-slot:action="{ attrs }">
                <v-btn color="blue" text v-bind="attrs" @click="snackbar = false">
                Cerrar
                </v-btn>
            </template>
        </v-snackbar> 
        <v-overlay :value="overlay">
            <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
        </v-overlay> 

    </v-container>
</template>
<script>
import PDF from '../../../components/PDFPedSucCat.vue'
import Header from '../../../components/Header';
const moment = require('moment')
const axios = require('axios')
export default { 
    name: 'Header', 
    components:{
        "app-header": Header,  
        PDF
    }, 
    data(){
        return {
            overlay: false,
            snackbar: false,
            text: '',
            timeout: 3000,
            IdEmpleado: '',
            tab: null,
            pedCab: [],
            items: [],
            reportes: [], 
            emplCrea: [],
            emplMod: [],
            modif: false,
            proveedor: [],
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedcsuc_nombre', 
            }, 
            { text: 'Sucursal', value: 'zpedcsuc_sucursal'}, 
            { text: 'Proveedor', value: 'zpedcsuc_proveedor_nombre'}, 
            { text: 'Estatus', value: 'zpedcsuc_status_ped'}, 
            { text: 'Acciones', value: 'zpedcsuc_id_ped_cat_sucur', sortable: false },
            ],
            pedi: [], 
        }
    },
    created(){ 
        this.find()
    }, 
    methods:{ 
        callbackCabPSuc (item, pedProv) {  
            setTimeout(function(){ 
                console.log(item) 
                axios.put('http://127.0.0.1:8000/pedcatsuc/cab/' + item.zpedcsuc_id_ped_cat_sucur + '/', item)
                    .then(res => {
                        setTimeout(function(){ 
                             window.location.reload()
                        }, 3000);
                    })  
            }, 3000);
        },
        entregar(item){
            this.overlay = true
            this.pedi = []
            /*
            this.text = 'El pedido se envio al la sucursal: ' + item.zpedcsuc_sucursal
            this.snackbar = true
            */
            item.zpedcsuc_id_emple_mod = this.IdEmpleado
            item.zpedcsuc_status_ped = 'En tránsito sucursal'
            
            let itemsPed = 0
            
            axios.get('http://127.0.0.1:8000/pedido/itempedcat/')
            .then(resItems =>{
                resItems.data.forEach(itemPed => {
                    if(itemPed.zipcat_estatus_cat == 'Regreso chofer a centro de distribución'){
                        if(this.pedCab.zpedpr_proveedor_nombre == itemPed.zipcat_marca){
                            if(item.zpedcsuc_id_sucursal == itemPed.zipcat_id_sucursal){
                                itemPed.zipcat_estatus_cat = 'En tránsito sucursal'
                                axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + itemPed.zipcat_id_itemped_cat + '/', itemPed)
                            } 
                        } 
                    }
                    itemsPed++;
                    if(itemsPed === resItems.data.length) {
                        this.callbackCabPSuc(item, this.pedCab);
                    }
                });
            })
        },
        finalizar(){
            this.pedCab.zpedpro_status_ped = 'Finalizado'
            console.log(this.pedCab)
        }, 
        editar(){
            this.pedCab.zpedpr_id_emple_mod = this.IdEmpleado
            this.pedCab.zpedpr_puede_editar = !this.pedCab.zpedpr_puede_editar
            axios.put('http://127.0.0.1:8000/pedcatprov/cab/' + this.$route.params.id + '/', this.pedCab)
            .then(res =>{
                this.find()
            })
        },
        ingresarCantidad(item){ 
            this.pedCab.zpedpr_id_emple_mod = this.IdEmpleado
            axios.put('http://127.0.0.1:8000/pedcatprov/item/' + item.zpedipr_id_item_ped_cat + '/', item)
                .then(resItem => {
                    axios.put('http://127.0.0.1:8000/pedcatprov/cab/' + this.$route.params.id + '/', this.pedCab)
                    .then(res =>{
                        this.find()
                    })
                })
        },
        getEmpleadoCrea(cab){ 
            axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedpr_id_emple)
                .then(resEmp => {
                    this.emplCrea = resEmp.data[0]
                })
            if(cab.zpedpr_id_emple_mod != null){
                axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedpr_id_emple_mod)
                .then(resEmp =>{
                    this.emplMod = resEmp.data[0]
                    this.modif = true
                })
            } 
        },
        fecha(date){
            return moment(date).locale('MX').format('DD-MM-YYYY LT')
        },    
        getPedSuc(pedProv){
            this.pedi = []
            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/')
                .then(resPedSuc =>{
                    resPedSuc.data.forEach(pedido => {
                        if(pedido.zpedcsuc_status_ped == 'Regreso chofer a centro de distribución'){
                            if(pedProv.zpedpr_proveedor_nombre == pedido.zpedcsuc_proveedor_nombre){
                                this.pedi.push(pedido) 
                            }
                        } 
                    });
                })
        },
        find(){
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            let repostesBruto = [] 
            axios.get('http://127.0.0.1:8000/pedcatprov/cab/' + this.$route.params.id + '/')
            .then(resCab=> {
                this.getPedSuc(resCab.data)
                this.pedCab = resCab.data 
                axios.get('http://127.0.0.1:8000/proveedor/proveedor/' + resCab.data.zpedpr_id_provee + '/')
                    .then(resProvee =>{
                        this.proveedor = resProvee.data
                    })
                this.getEmpleadoCrea(resCab.data)
                axios.get('http://127.0.0.1:8000/pedcatprov/item/?search=' +this.$route.params.id )
                    .then(resItem => {  
                        resItem.data.forEach(item => { 
                            repostesBruto.push(item) 
                        }); 
                        this.reportes = repostesBruto 
                    })
                })  
        },
    }
}
</script>
