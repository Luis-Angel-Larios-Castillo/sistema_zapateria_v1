Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los pedidos catalogos de los proveedores
<template>
<div cols="full"> 
    <v-row> 
        <v-col cols="md-2 xs-12">
            <menuModulos/>
        </v-col>  
        <v-col cols="md-10 xs-12">   
             <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">PEDIDOS CATÁLOGOS PROVEEDOR</h1>
            </div><br> 
            <v-tabs v-model="tab" centered icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1">Pedidos de sucursales</v-tab> 
                <v-tab href="#tab-2">Pedidos realizados</v-tab> 
            </v-tabs>
            <v-tabs-items v-model="tab">
                <v-tab-item value="tab-1">
                    <v-card :elevation="0">
                        <v-card-title class="card_title">
                            <div class="col-12" id="table_cabecera_color">
                                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                <v-btn @click="generarPedido()" :disabled="canCReporte == false" text class="btn_gped white--text">Generar pedido</v-btn>
                                <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                            </div> 
                            
                        </v-card-title>  
                        <div class="col-12" style="padding-top:0">
                            <v-data-table
                                id="tabla_datos"
                                :headers="headers" 
                                :items="pedi" 
                                :search="search"
                                :items-per-page="5"
                                :items-per-page-options="[5, 10, 15]"
                                no-results-text="No hay resultados."
                                no-data-text="No se tienen pedidos registrados." 
                                :footer-props="{
                                    showFirstLastPage: true,
                                    itemsPerPageText: 'Elementos por página ',
                                }"
                                :header-props="{ sortByText: 'Ordenar por' }"
                            >
                                <template v-slot:item.zpedcsuc_nombre="{ item }" >  
                                    <strong>{{item.zpedcsuc_nombre}}</strong>  
                                </template>      
                                <template v-slot:item.zpedcsuc_proveedor_nombre="{ item }" >  
                                    <strong>{{item.zpedcsuc_proveedor_nombre}}</strong>  
                                </template>  
                                <template v-slot:item.zpedcsuc_id_ped_cat_sucur="{ item }" >  
                                    <ItemsPedido :items="item.items" />
                                </template> 
                            </v-data-table>
                        </div>
                    </v-card> 
                </v-tab-item>
                <v-tab-item value="tab-2">
                    <PedidosRealizados :empleado="IdEmpleado"/>    
                </v-tab-item>
            </v-tabs-items> 
        </v-col>
    </v-row> 
    <v-overlay :value="overlay">
        <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
    </v-overlay>  
    <br>   
</div> 
</template>  
<script> 
import Header from '../../components/Header';
import menuModulos from '../menuModulos'   
import ItemsPedido from './partials/_ItemsPedido.vue' 
import PedidosRealizados from './partials/_PedidosRealizados.vue'
const moment = require('moment') 
const axios = require('axios')
  export default {
      name: 'Header', 
    components:{ 
        "app-header": Header,
        menuModulos,  
        ItemsPedido,
        PedidosRealizados
    },     
    data() {
        return { 
            overlay: false,
            canCReporte: true,
            IdEmpleado: '',
            status: 'Pedido centro de distribución',
            statusItems: [
                'Pedido centro de distribución', 
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor',
                'Regreso chofer a centro de distribución',
                'En tránsito sucursal',
                'Llego sucursal',
                'Activo'
            ],
            tab: null,
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedcsuc_nombre', 
            }, 
            { text: 'Sucursal', value: 'zpedcsuc_sucursal'}, 
            { text: 'Proveedor', value: 'zpedcsuc_proveedor_nombre'}, 
            { text: 'Estatus', value: 'zpedcsuc_status_ped'}, 
            { text: 'Acciones', value: 'zpedcsuc_id_ped_cat_sucur', sortable: false },
            ],
            pedi: [],
            reportes: [],
        }
    },
    created() { 
        this.find()
    },
    methods: {
        sumarItems(ITEMS){ 
            let pedidoSinDuplicados = ITEMS.reduce((acumulado, itemActual) => { 
            let ItemSimilar = acumulado.find(elemento => elemento.zpedipr_id_cat === itemActual.zpedipr_id_cat);
            if (ItemSimilar) {
                return acumulado.map((elemento) => {
                    if (elemento.zpedipr_id_cat === itemActual.zpedipr_id_cat) {
                        return {
                            ...elemento,
                            zpedipr_cant_ped: elemento.zpedipr_cant_ped + itemActual.zpedipr_cant_ped
                        }
                    } 
                    return elemento;
                });
                } 
                return [...acumulado, itemActual];
            }, []); 
            return pedidoSinDuplicados 
        }, 
        async generarPedido(){
            this.reportes = []
            this.overlay = true  
            axios.get('http://127.0.0.1:8000/proveedor/proveedor/')  
            .then(resProv => {
                resProv.data.forEach(prov => {
                    this.reportes.push({
                        idProveedor: prov.zp_id_proveedor,
                        nombre: prov.zp_identify_mark,
                        items: []
                    });
                }); 
                axios.get('http://127.0.0.1:8000/pedcatsuc/item/')
                .then(resItemsS => {
                    this.reportes.forEach(rep => {  
                        resItemsS.data.forEach(item => { 
                            if(item.zpedsucat_status == 'Pedido centro de distribución'){
                                if(item.zpedsucat_marca == rep.nombre){
                                    rep.items.push({
                                        "zpedipr_id_ped_cat_prov": '',
                                        "zpedipr_id_cat": item.zpedsucat_id_cat, 
                                        "zpedipr_cant_ped": item.zpedsucat_cant_ped
                                    })
                                }
                            }
                        }); 
                    });  
                    function callbackFin () { 
                        console.log('Fin'); 
                        setTimeout(function(){
                            console.log('Recargar')   
                            window.location.reload()
                        }, 3000);
                    } 
                    let pedidosSuc = 0
                    function callbackPedidoSucursal (IdEmpleado) { 
                        setTimeout(function(){
                            //console.log('Funcion para cambiar el estatus de los pedido de sucursal')  
                            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/')
                            .then(resPedSuc => {    
                                resPedSuc.data.forEach(pedido => {
                                    if(pedido.zpedcsuc_status_ped == 'Pedido centro de distribución'){ 
                                        pedido.zpedcsuc_id_emple_mod = IdEmpleado,
                                        pedido.zpedcsuc_status_ped = 'Pedido a Proveedor' 
                                        //console.log(pedido)
                                        axios.put('http://127.0.0.1:8000/pedcatsuc/cab/' + pedido.zpedcsuc_id_ped_cat_sucur + '/', pedido)
                                    }  
                                    pedidosSuc++;
                                    if(pedidosSuc === resPedSuc.data.length) {
                                        callbackFin();
                                    }
                                }); 
                            }) 
                        }, 3000); 
                    } 
                    let catalogoPed = 0
                    function callbackItemPedido (IdEmpleado) { 
                        setTimeout(function(){
                        axios.get('http://127.0.0.1:8000/pedido/itempedcat/')
                            .then(resCat => {
                                resCat.data.forEach(item => {
                                    
                                    if(item.zipcat_estatus_cat == "Pedido centro de distribución"){ 
                                        item.zipcat_estatus_cat = 'Pedido a Proveedor'  
                                        axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + item.zipcat_id_itemped_cat + '/', item)
                                    }  
                                    catalogoPed++;
                                    if(catalogoPed === resCat.data.length) {
                                        callbackPedidoSucursal(IdEmpleado);
                                    }
                                }); 
                            })  
                        }, 3000);  
                    } 
                    let pedNuevo = 0
                    this.reportes.forEach(repNew => {
                        if(repNew.items.length != 0){
                            let cab = {
                                zpedpr_nombre: repNew.nombre + '-' + moment().locale('MX').format('YYMMDDHHmmSS'),
                                zpedpr_id_emple: this.IdEmpleado,
                                zpedpr_status_ped: 'Pedido a Proveedor',
                                zpedpr_id_provee: repNew.idProveedor
                            }
                            //console.log(cab)
                            axios.post('http://127.0.0.1:8000/pedcatprov/cab/', cab)
                            .then(resNewPedC => {
                                this.sumarItems(repNew.items).forEach(itemNew => {
                                    itemNew.zpedipr_id_ped_cat_prov = resNewPedC.data.zpedpr_id_ped_cat_prov
                                    //console.log(itemNew)
                                    axios.post('http://127.0.0.1:8000/pedcatprov/item/', itemNew)
                                });
                            }) 
                        } 
                        pedNuevo++;
                        if(pedNuevo === this.reportes.length) {
                            callbackItemPedido(this.IdEmpleado);
                        }
                    });
                    
                })
            }) 
        },   
        find(){ 
            this.pedi = []
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/')
                .then(resCabSuc => {
                    let CabSuc = []
                    resCabSuc.data.forEach(pedCab => {
                        if(pedCab.zpedcsuc_status_ped == 'Pedido centro de distribución'){
                            CabSuc.push(pedCab)
                        }
                    });
                    if(CabSuc.length == 0){
                        this.canCReporte = false
                    }  

                })
            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/')
                .then(res => {
                    res.data.forEach(element => { 
                        if(element.zpedcsuc_status_ped ==  this.status){
                            axios.get('http://127.0.0.1:8000/pedcatsuc/item/?search=' + element.zpedcsuc_id_ped_cat_sucur)
                            .then(resItem =>{
                                this.pedi.push({
                                    zpedcsuc_fech_creat: element.zpedcsuc_fech_creat, 
                                    zpedcsuc_fech_mod: element.zpedcsuc_fech_mod, 
                                    zpedcsuc_id_emple: element.zpedcsuc_id_emple, 
                                    zpedcsuc_id_emple_mod: element.zpedcsuc_id_emple_mod, 
                                    zpedcsuc_id_ped_cat_sucur: element.zpedcsuc_id_ped_cat_sucur, 
                                    zpedcsuc_id_provee: element.zpedcsuc_id_provee, 
                                    zpedcsuc_id_sucursal: element.zpedcsuc_id_sucursal, 
                                    zpedcsuc_nombre: element.zpedcsuc_nombre, 
                                    zpedcsuc_status_ped: element.zpedcsuc_status_ped, 
                                    zpedcsuc_sucursal: element.zpedcsuc_sucursal,
                                    zpedcsuc_proveedor_nombre: element.zpedcsuc_proveedor_nombre,
                                    items: resItem.data
                                })
                            })                             
                        }
                    }); 
                })
        }
    },
}
</script>