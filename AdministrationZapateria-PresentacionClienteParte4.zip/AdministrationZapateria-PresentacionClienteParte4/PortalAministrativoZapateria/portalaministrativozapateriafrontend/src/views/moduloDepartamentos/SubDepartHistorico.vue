Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los subdepartamentos registrados
<template>
<div cols="full">
    <v-row>
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col> 
        <v-col cols="md-10 xs-12" > 
            <app-header style="z-index: 135"/> 
             <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">SUBDEPARTAMENTOS</h1>
            </div><br>
           <v-card :elevation="0">
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text :to="'/subdep/'" class="btn_add" v-show="permissions.can_manage_subdepartamentos == true">
                            Subdepartamentos
                        </v-btn>
                        </div>
                         </v-card-title>
                     <div class="col-12" style="padding-top:0">
                <v-data-table  
                    id="tabla_datos"
                    :headers="headers" 
                    :items="subdepar"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen SubDepartamentos registrados."
                    :search="search" :footer-props="{
                    showFirstLastPage: true,
                    itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                 <template v-slot:item.zsude_nombre="{ item }"  >
                    <v-row align="center">
                        <v-col>
                            <dsubdep  :element="{item, permissions}"/> 
                        </v-col>
                    </v-row>
                </template>
                <template v-slot:item.zsude_id_subdep="{ item }"  >
                    <v-row align="center">
                        <v-col>
                            <restsubdepart  :elementD="{item, permissions}"/> 
                        </v-col>
                        <v-col>
                            <dpermSubDepart  :elementD="{item, permissions}"/> 
                        </v-col>
                    </v-row>
                </template>
                </v-data-table>
                 </div>
            </v-card>
        </v-col>    
    </v-row>
    <br>
</div >
</template>

<script>
const axios = require('axios')
import menuModulos from '../menuModulos'
import dpermSubDepart from './partials/dpermSubDepart'
import styles from '../../../public/Styles'
import Header from '../../components/Header';
import Restsubdepart from './partials/restsubdepart.vue'
import Dsubdep from './partials/dsubdep.vue'
export default {
     name: 'Header', 
    components:{
        "app-header": Header,
        dpermSubDepart,
        menuModulos,
        Restsubdepart,
        Dsubdep,
    },
    created() {
        this.find()
    },
    data () {
      return {
        search: '',
        headers: [
          {
            text: 'SubDepartamento',
            align: 'start',
            filterable: true,
            value: 'zsude_nombre', 
          },  
          { text: 'Departamento', value: 'zsude_departamento'},
           { text: 'Categoría', value: 'zsude_categoria'},
          { text: 'ID', value: 'ID'},
          { text: 'Acciones', value: 'zsude_id_subdep', sortable: false, align:'center' },
        ],
        items:[],
        permissions: {
            can_manage_subdepartamentos: false,
        },
        subdepar:[],
      }
    },
    methods:{
        find(){

             axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_subdepartamentos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_subdepartamentos') { this.permissions.can_manage_subdepartamentos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                }) 

                 this.subdepar = []

            axios.get("http://127.0.0.1:8000/departamentos/subdep/")
                .then(res => {this.items = res.data
                
                 res.data.forEach(element => { 
                            if(element.zsude_is_deleted ==  true){
                                this.subdepar.push(element)
                            }
                        }); 

                })
        }
    },
}
</script>