Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los departamentos registrados
<template>
<div cols="full">
    <v-row>
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col> 
        <v-col cols="md-10 xs-12" > 
            <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">HISTÓRICO DE DEPARTAMENTOS</h1>
            </div><br>
            
           <v-card :elevation="0">
               <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
               <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text  :to="'/dep/'" class="btn_add" v-show="permissions.can_manage_departamentos == true">
                            <v-icon>
                        mdi-arrow-left-circle
                        </v-icon>
                            Regresar
                        </v-btn>
                        </div>
                </v-card-title>
                <div class="col-12" style="padding-top:0">
                <v-data-table  
                    id="tabla_datos"
                    :headers="headers" 
                    :items="depar"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen Departamentos registrados."
                    :search="search" :footer-props="{
                    showFirstLastPage: true,
                    itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                <template v-slot:item.zde_nombre="{ item }"  >
                    <v-row align="center">
                        <v-col>
                         <ddepart  :element="{item}"/> 
                        </v-col>
                    </v-row>
                </template>
                <template v-slot:item.zde_id_dep="{ item }"  >
                    <v-row align="center">
                        <v-col>
                            <restdepart  :element="{item, permissions}"/> 
                        </v-col>
                        <v-col>
                            <dpermDepart  :elementD="{item, permissions}"/> 
                        </v-col>
                    </v-row>
                </template>
                </v-data-table>
                </div>
            </v-card>
        </v-col>
    </v-row>
    <br>
</div>
</template>

<script>
const axios = require('axios')
import Header from '../../components/Header';
import menuModulos from '../menuModulos'
import dpermDepart from './partials/dpermDepart'
import restdepart from './partials/restdepart'
import styles from '../../../public/Styles'
import ddepart from './partials/ddepart.vue';
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,
        dpermDepart,
        restdepart,
        ddepart,
    },
    created() {
        this.find()
    },
    data () {
      return {
        search: '',
        headers: [
          {
            text: 'Departamento',
            align: 'start',
            filterable: true,
            value: 'zde_nombre',
          }, 
          { text: 'Código de departamento', value: 'ID', sortable: false },
          { text: 'Acciones', value: 'zde_id_dep', sortable: false, align:'center' },
        ],
        items:[],
        permissions: {
            can_manage_departamentos: false,
        },
        depar:[],
      }
    },
    methods:{
        
        find(){

            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_departamentos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_departamentos') { this.permissions.can_manage_departamentos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                }) 

             this.depar = []

            axios.get("http://127.0.0.1:8000/departamentos/dep/")
                .then(res => {this.items = res.data
                
                 res.data.forEach(element => { 
                            if(element.zde_is_deleted ==  true){
                                this.depar.push(element)
                            }
                        }); 
                
                
                })
        }
    },
}
</script>