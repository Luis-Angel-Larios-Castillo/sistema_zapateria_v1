Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para actualizar la información de un departamento   
<template>
    <v-container fluid>
        <div v-if="permissions.can_manage_departamentos == true">
             <app-header style="z-index: 135"/> 
     <div class="col-9" >
        <v-toolbar style="max-width: 1300px" class="" flat align="center" justify="space-around" id="table_cabecera_color_formulario">
        <v-toolbar-title>
            <v-icon right dark>
              mdi-rotate-3d-variant
            </v-icon>
            <strong id="title_editar"> Edición del departamento: {{item.zde_nombre}}</strong>
            
            </v-toolbar-title>
            <v-spacer/>
            <v-btn to="/dep/" outlined class="btn_add" color="#F7F9F9">
              Regresar
            </v-btn>
        </v-toolbar>
       
        <v-container id="tabla_datos_dos" class="col-12">

        <v-form ref="form" v-model="valid" lazy-validation>
            <v-text-field v-model="item.zde_nombre" filled :rules="nombreRules" label="Nombre" required :counter="30" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Mujer" maxlength="30"></v-text-field>
            <br>
            <v-row align="center" justify="space-around">
                <v-col>
                <v-btn :disabled="!valid" id="btn_actualizar_formulario" class="col-12" @click="validate">
                    Actualizar 
                    <v-icon right dark>mdi-update</v-icon>
                </v-btn>
                </v-col>
                <v-col>
                <v-btn id="btn_borrar_formulario" class="col-12" @click="reset" text>Borrar
                 <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                </v-btn> 
                </v-col>
            </v-row>
        </v-form>
        <br>
     </v-container>
     </div>
     </div>
    <div v-else>
      <ErrorPage403/>
    </div>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
    "app-header": Header,
    ErrorPage403
  }, 
    data() {
        return {
            item: [],
            element: [],
            valid: true,
            nombre: '',
            nombreRules: [
                v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
                v => !!v || 'El nombre es obligatorio',
                v => (v && v.length >= 3) || 'El nombre debe tener más de 2 caracteres',
                v => (v && v.length <= 30) || 'El nombre no debe tener más de 30 caracteres',
            ],
            permissions: {
            can_manage_departamentos: false,
        },
        }
    },
    created() {
         this.findpermsisos()
        axios.get("http://127.0.0.1:8000/departamentos/dep/" + this.$route.params.id + '/')
            .then(res => this.item = res.data)
    },
    methods: {
        findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_departamentos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_departamentos') { this.permissions.can_manage_departamentos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },

        validate () {
            if (this.$refs.form.validate()){
            this.element = {
                zde_nombre:this.item.zde_nombre,
            }
            this.create()
            }
        },
        async create(){
            await axios.put('http://127.0.0.1:8000/departamentos/dep/'+ this.$route.params.id +'/',this.element)
            .catch(error => console.log(error));
            this.$router.push({ name: 'Departamentos' });
        },
        reset () {
            this.$refs.form.reset()
        }
    },
}
</script>