Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un subdepartamento    
<template>
  <div>
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="teal" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_subdepartamentos == false">
          <v-icon>mdi-cached</v-icon>
          </v-btn>
        </template>
         <span>Restaurar Departamento</span>
    </v-tooltip>

    <v-dialog
      v-model="dialog"
      max-width="500"
    >
      <v-card>
     
        <v-alert dense text color="primary" type="info" border="top">
          <strong> Se va a restaurar el subdepartamento:<br> {{elementD.item.zsude_nombre}}</strong>
         </v-alert>

        <v-card-text class="black--text">
          <h4>¿Está de acuerdo en restaurarlo?</h4>
        </v-card-text>
       
        <v-card-actions> 
          <v-spacer></v-spacer>

          <v-btn outlined color="red" @click="dialog = false">
            Cancelar
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn outlined color="success"  @click="aceptar()">
            Aceptar
           <v-icon right dark>mdi-check-all</v-icon>
          </v-btn><br><br> 
        
      
        </v-card-actions>
      
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'elementD'
    ],
    data () {
      return {
        dialog: false,
        iduser:[],
    }
    },
    created() {
        this.findusuer()
    },
   
    methods:{
      findusuer(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                    .then(resuser => { this.iduser = resuser.data.zdus_id_usuario                   
                      })
                    })
      },
        aceptar(){
          this.elementD.item.zsude_is_deleted = false
          this.elementD.item.zsude_usua_delet = this.iduser
          let URL= 'http://127.0.0.1:8000/departamentos/subdep/'+ this.elementD.item.zsude_id_subdep +'/'
              axios.put(URL, this.elementD.item)
              .then(response =>{
                  this.dialog = false
                  window.location.reload()
              })
             
        }
    },
  }
</script>