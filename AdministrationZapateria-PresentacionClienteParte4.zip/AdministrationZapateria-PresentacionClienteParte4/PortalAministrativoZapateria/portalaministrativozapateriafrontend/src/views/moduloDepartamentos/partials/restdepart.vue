Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un departamento   
<template>
  <div>
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
        <v-btn icon color="teal" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="element.permissions.can_manage_departamentos == false">
          <v-icon>mdi-cached</v-icon>
        </v-btn>
      </template>
      <span>Restaurar Departamento</span>
    </v-tooltip>

    <v-dialog
      v-model="dialog"
      max-width="500"
    >
      <v-card>
      <br>
        <v-alert dense text color="red" border="top">
            <strong>Rstaurar departamento <br>{{element.item.zde_nombre}}</strong>
          </v-alert>
        <v-card-text class="black--text">
         <h4>¿Está de acuerdo en restaurarlo?</h4>
            </v-card-text>

          <v-spacer></v-spacer>

           <v-btn outlined color="red" @click="dialog = false">
            Cancelar
            <v-icon right dark>mdi-close-circle</v-icon>
          </v-btn>

          <v-btn outlined color="success" @click="aceptar()">
            Aceptar 
          <v-icon right dark>mdi-check-all</v-icon>
          </v-btn><br><br>
      
      
      
      </v-card>
    </v-dialog>
  </div>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    data () {
      return {
       
        dialog: false,
        iduser:[],
    }
    },
    created() {
     
    },

    methods:{
      
      aceptar(){
           this.element.item.zde_is_deleted = false
           this.element.item.zde_usua_delet = null

          let URL= 'http://127.0.0.1:8000/departamentos/dep/'+ this.element.item.zde_id_dep +'/'
              axios.put(URL, this.element.item)
              .then(response =>{
                  this.dialog = false
                  window.location.reload()
              })
             
        }
    },
  }
</script>