Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo funciona como formulario para registrar un subdepartamento    
<template>
    <v-container fluid>
      <div v-if="permissions.can_manage_subdepartamentos == true">
        <app-header style="z-index: 135"/> 
      
      <v-col cols="md-10 xs-12">
        <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE SUBDEPARTAMENTO</h1>
        </div><br>
        <v-card :elevation="0">
          <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario">
            <v-spacer/>
        <v-btn to="/subdep/" outlined class="btn_add" color="#F7F9F9">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>
         </v-card>

          <v-container id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>

              <v-text-field v-model="nombre" filled :rules="nombreRules" label="Nombre" required :counter="30" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Zapatos" maxlength="30"></v-text-field>
                  <v-select v-model="categoria" :items="categories" filled :rules="[v => !!v || 'Debe seleccionar una categoría']"  label="Categoría" required/>
              <v-row class="align-center"> 
                <v-col cols="10" >
                  <v-select v-model="select" filled :items="depar" item-text="zde_nombre" item-value="zde_id_dep" :rules="[v => !!v || 'Debe seleccionar un Departamento']"  label="Departamento" required/>
                </v-col>
                <v-col cols="2" >
                  <v-btn color="blue" outlined to="/cDepartamento/">agregar</v-btn>
                </v-col>
              </v-row>
              <br><br>
              <v-row align="center" justify="space-around">
                  <v-btn :disabled="!valid" id="btn_agrega_otro_formulario" class="mr-4" @click="validate">
                    Guardar y agregar otro 
                    <v-icon right dark>
                        mdi-reload
                    </v-icon>
                  </v-btn>
                  <v-btn :disabled="!valid" id="btn_guardar_formulario" class="mr-4" @click="validate02">
                      Guardar 
                      <v-icon right dark>
                          mdi-cloud-upload
                      </v-icon>
                  </v-btn>
                  <v-btn class="mr-4" @click="reset" id="btn_borrar_formulario">
                      Borrar Formulario

                        <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                  </v-btn>
                
              </v-row>
            </v-form>
          </v-container>
        
       </v-col>
      
      </div>
      <div v-else>
        <ErrorPage403/>
      </div>
  </v-container>
</template>
<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
    "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.find()
    },
    data: () => ({
      element: [],
      dpto: [],
      dialog:false,
      valid: true,
      select: null,
      nombre: '',
      nombreRules: [

        v => !!v || 'El nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 3) || 'El nombre debe tener más de 2 caracteres',
        v => (v && v.length <= 30) || 'El nombre no debe tener más de 30 caracteres',
      ],
      permissions: {
            can_manage_subdepartamentos: false,
        },
        depar:[],
        categoria:'',
         categories:['Calzado', 'Ropa', 'Accesorios'],
    }),
    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_subdepartamentos: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_subdepartamentos') { this.permissions.can_manage_subdepartamentos = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      find(){
         this.depar = []

        axios.get('http://127.0.0.1:8000/departamentos/dep/')
          .then(res => {this.dpto = res.data
          
          res.data.forEach(element => { 
                            if(element.zde_is_deleted ==  false){
                                this.depar.push(element)
                            }
                        }); 
          
          })
      },
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zsude_nombre:this.nombre,
            zsude_id_dep: this.select
          }
          this.createAndNew()
          }  
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            zsude_nombre:this.nombre,
            zsude_id_dep: this.select,
            zsude_categoria:this.categoria
          }
          this.create()
          }  
      },
      createAndNew(){
        axios.post('http://127.0.0.1:8000/departamentos/subdep/', this.element)
          .then(res => {
            window.location.reload()
          })
          .catch(error => console.log(error));
      },
      create(){
        axios.post('http://127.0.0.1:8000/departamentos/subdep/', this.element)
          .then(res => {
            this.$router.go(-1);
            //this.$router.go(-1);
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      reset () {
        this.$refs.form.reset()
      }
    },
  }
</script>