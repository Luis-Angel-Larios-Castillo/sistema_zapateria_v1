Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un departamento   
<template>
  <div>
      <v-dialog  max-width="600">
        <template v-slot:activator="{ on, attrs }">
          <p v-bind="attrs" v-on="on" class="blue--text">
            <strong>{{element.item.zde_nombre}}</strong>
          </p>
        </template>
        <v-card>
          <v-card-title class="headline">
          </v-card-title>
          <v-card-text>
            <v-alert dense text type="error">
              Usuario que elimino: <strong>{{nombre}}</strong>
            </v-alert>
            
            <div class="black--text"> 
              <p><strong>Fecha de eliminación:</strong><br>{{ fecha(element.zde_fech_delet)}}</p>
            

            </div>
          </v-card-text>
        </v-card>
    </v-dialog>
  </div>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    data () {
      return {
       nombre:[],
        
    }
    },
    created() {
      this.busqnomempl()
    },

    methods:{
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
     busqnomempl(){
 
                axios.get('http://127.0.0.1:8000/empleado/?search='+ this.element.item.zde_usua_delet)
                .then(res => {  this.nombre = res.data[0].nombre       

                })
                 
           
        },
    },
  }
</script>