Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz para editar todo lo concerniente a un pedido 
<template>
  <v-container fluid>
      <app-header style="z-index: 135"/> 
      <br>
      <div class="col-10">
    <v-alert dense outlined color="blue" v-if="btnFin == false">
        Alguno de los productos no cuenta con las unidades suficientes para finalizar el pedido.
    </v-alert>
  
      <v-card>
        <v-card-title class="headline">
        <v-btn
        elevation="2"
        icon
        :to="'/pedidos/'"
        >
         <v-icon>mdi-arrow-left-circle-outline</v-icon>
        </v-btn>

         <strong>{{elementE.zped_nombre}}</strong>
         <v-spacer/>
         <strong>Fecha: </strong>{{elementE.zped_fecha}} 
         <v-spacer/>
         <strong>Total: $</strong>{{elementE.zipe_total}} 
        </v-card-title> 
        <v-divider/>
        <v-card-subtitle class="black--text" align="center"><br>
             <strong>Folio del cliente: </strong>{{foliclie}} 
            <v-spacer/>
             <strong>Nombre del cliente: </strong>{{nomclie}}
            <p v-if="elementE.zped_status == 'Finalizado'" class="green--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
            <p v-if="elementE.zped_status == 'Pendiente'" class="blue--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
            <p v-if="elementE.zped_status == 'Devolución'" class="green--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
            <p v-if="elementE.zped_status == 'Espera'" class="blue--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
            <p v-if="elementE.zped_status == 'Listo para entregar cliente'" class="blue--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
            <p v-if="elementE.zped_status == 'Cancelado'" class="red--text"><strong class="black--text">Estatus: </strong>{{elementE.zped_status}}</p>
              <v-btn color="green" :disabled="!btnFin"  text @click="finalizar (elementE)" v-if="elementE.zped_status == 'Espera' || elementE.zped_status == 'Pendiente'" >
                Finalizar
              </v-btn>
              <v-btn color="red" :disabled="!btnCan"  text @click="cancelar(elementE)" v-if="elementE.zped_status == 'Espera' || elementE.zped_status == 'Pendiente'" >
                Cancelar
              </v-btn>
        </v-card-subtitle>
        <v-card-text>
            <v-simple-table>
                <template v-slot:default>
                <thead>
                    <tr>
                    <th class="text-left">
                        Articulo
                    </th>
                    <th class="text-left">
                        Cantidad
                    </th>
                    <th class="text-left">
                        Color
                    </th>
                    <th class="text-left">
                        Talla
                    </th>
                    <th class="text-left">
                        Subtotal
                    </th>
                    <th class="text-left">
                        Estatus
                    </th>
                    <th class="text-left">
                        Acciones
                    </th> 
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in items" :key="item.zipe_id_item_ped" >
                    <td align-center>
                        <sArticulo :element="item"/>
                    </td>
                    <td align-center >{{ item.zipe_cant }}</td>
                    <td>{{ item.zipe_color }}</td>
                    <td>{{ item.zipe_talla }}</td>
                    <td>${{ item.zipe_sub_tot }}</td>
                    <td>
                        <p v-if="item.zipe_devo >= 1"> Devuelto {{item.zipe_devo}}</p>
                        <div v-if="item.zipe_status == 'Entregado'" class="green--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Pendiente'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Espera'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Listo para entregar cliente'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Listo para entregar'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Cancelado'" class="red--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Devolución'" class="purple--text">{{ item.zipe_status }}</div>  
                    </td> 
                    <td>
                        <v-tooltip bottom v-if="item.zipe_status == 'Espera' || item.zipe_status == 'Pendiente' || item.zipe_status == 'Listo para entregar cliente' || item.zipe_status == 'Devolución' || item.zipe_status == 'Listo para entregar'">
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon  color="green" @click="marcarEntregado (item)" v-bind="attrs" v-on="on">
                                    mdi-truck-delivery-outline
                                </v-icon>
                            </template>
                            <span>Entregar</span>
                        </v-tooltip>
                        <v-tooltip bottom v-if="item.zipe_status == 'Espera' || item.zipe_status == 'Pendiente' || item.zipe_status == 'Listo para entregar cliente' || item.zipe_status == 'Devolución' || item.zipe_status == 'Listo para entregar' " >
                            <template v-slot:activator="{ on, attrs }">
                                <v-icon  color="red" @click="cancelarItem (item)" v-bind="attrs" v-on="on">
                                    mdi-cancel
                                </v-icon>
                            </template>
                            <span>Cancelar</span>
                        </v-tooltip>
                    </td> 
                    </tr>
                </tbody>                    
                </template>                    
            </v-simple-table>
        </v-card-text>
      </v-card>
    <div class="text-center">
        <v-snackbar v-model="snackbar" :timeout="timeout" >
        {{ text }}

        <template v-slot:action="{ attrs }">
            <v-btn color="blue" text v-bind="attrs" @click="snackbar = false" >
            Cerrar
            </v-btn>
        </template>
        </v-snackbar>
    </div>
    </div>
    {{validar(items)}}
    {{validarCancelar(items)}}
  </v-container>
</template>
<script>
import Header from '../../../../components/Header';
import sArticulo from './sArticulo'
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
         "app-header": Header,
        sArticulo,
    },   
    created() {
        this.find()
        this.getItems() 
    },
    data(){
        return {
            URL: 'http://127.0.0.1:8000/pedido/itembpc/?search='+this.$route.params.id ,
            items: [],
            dialog: false,
            snackbar: false,
            text: '',
            estoa: true,
            timeout: 2000,
            elementE: Object,
            btnFin: true,
            btnCan: true,
            datos:[],
         nomclie:[],
         foliclie:[],
         datosclinoafi:[],
        };
    },
    methods:{
        validar(ITEMS){
            if(ITEMS.length >0){
                var i
                for(i = 0; i < ITEMS.length; i++){
                    var cant = ITEMS[i].zipe_cant
                    if(ITEMS[i].zipe_status == 'Espera'){
                        if(ITEMS[i].zipe_cant > ITEMS[i].zipe_id_arti.zaa_cantidad){
                            this.btnFin = false
                        }
                    }                     
                }
            }
        },
        validarCancelar(ITEMS){
            if(ITEMS.length >0){
                var i
                for(i = 0; i < ITEMS.length; i++){
                    if(ITEMS[i].zipe_status == 'Entregado'){
                        this.btnCan = false
                    }                     
                }
            }
        },
        async cancelar(cabecera){
            const URL = 'http://127.0.0.1:8000/pedido/pcadmin/'+this.$route.params.id+'/'
            var i
            for(i = 0; i < this.items.length; i++){
                if(this.items[i].zipe_status == 'Espera'){
                axios.put('http://127.0.0.1:8000/pedido/itembpc/'+ this.items[i].zipe_id_item_ped + '/', {
                    zipe_cant: this.items[i].zipe_cant,
                    zipe_sub_tot: this.items[i].zipe_sub_tot,
                    zipe_talla: this.items[i].zipe_talla,
                    zipe_color: this.items[i].zipe_color,
                    zipe_status: 'Cancelado',
                    zipe_id_pedido_cab: this.items[i].zipe_id_pedido_cab.zped_id_pedcab,
                    zipe_id_arti: this.items[i].zipe_id_arti.zaa_id_articulo
                }).catch(error => console.log(error))
                }
            }

            await axios.put(URL, {
                zdus_correo: cabecera.zdus_correo,
                zipe_total: cabecera.zipe_total,
                zped_fecha: cabecera.zped_fecha,
                zped_id_usuario: cabecera.zped_id_usuario,
                zped_nombre: cabecera.zped_nombre,
                zped_status: 'Cancelado'
            }).catch(error => console.log(error))
            window.location.reload()
        },
        find(){
            axios.get('http://127.0.0.1:8000/pedido/pcadmin/'+ this.$route.params.id +'/').
                then(res => {this.elementE = res.data
                    axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.elementE.zped_id_usuario)
                    .then(res =>{ this.datos = res.data           
                if(res.data.length  > 0){
                    this.nomclie = this.datos[0].nombre
                    this.foliclie = this.datos[0].zc_folio_client

                    //console.log(this.datos[0].nombre)
                }
                else{
                    axios.get('http://127.0.0.1:8000/clientes/'+this.elementE.zped_id_usuario+'/')
                    .then(res =>{ this.datosclinoafi = res.data 
                        this.nomclie = this.datosclinoafi.nombre
                         this.foliclie = this.datosclinoafi.zc_folio_client
                    
                    })          
                }
                
                })           
                    
                    

                     })
      },
      getItems(){ 
        axios.get(this.URL)
        .then(res => this.items = res.data)
        
      },
        cancelarItem(it){ 
            const urlCancelItem = 'http://127.0.0.1:8000/pedido/itemped/'+ it.zipe_id_item_ped + '/'
            const urlCabUpdate = 'http://127.0.0.1:8000/pedido/pcadmin/'+this.$route.params.id+'/'
            const itemCancel = {
                zipe_cant: it.zipe_cant,
                zipe_devo: it.zipe_devo,
                zipe_id_arti: it.zipe_id_arti.zaa_id_articulo,
                zipe_talla: it.zipe_talla,
                zipe_color: it.zipe_color,
                zipe_id_pedido_cab: it.zipe_id_pedido_cab.zped_id_pedcab,
                zipe_status: 'Cancelado',
                zipe_sub_tot: it.zipe_sub_tot
            }
            const cabe = {
                zdus_correo: this.elementE.zdus_correo,
                zipe_total: this.elementE.zipe_total - itemCancel.zipe_sub_tot,
                zped_fecha: this.elementE.zped_fecha,
                zped_id_pedcab: this.elementE.zped_id_pedcab,
                zped_id_usuario: this.elementE.zped_id_usuario,
                zped_nombre: this.elementE.zped_nombre,
                zped_status: this.elementE.zped_status
            }
            axios.put(urlCancelItem, itemCancel)
                .then(res =>{
                    axios.put(urlCabUpdate, cabe)
                        .then(res=> window.location.reload())
                })
        },
        async marcarEntregado(i){
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            await axios.get('http://127.0.0.1:8000/articulo/client/'+ i.zipe_id_arti.zaa_id_articulo + '/', config)
                .then(res => {
                    if(res.data.zaa_cantidad >= i.zipe_cant){
                        axios.put('http://127.0.0.1:8000/articulo/client/'+ res.data.zaa_id_articulo + '/', {
                            
                            zaa_id_sucursal: res.data.zaa_id_sucursal,
                            zaa_cantidad: res.data.zaa_cantidad  - i.zipe_cant,
                            zaa_color: res.data.zaa_color,
                            zaa_existen: res.data.zaa_existen,
                            zaa_id_articulo: res.data.zaa_id_articulo,
                            zaa_talla: res.data.zaa_talla,
                            zaa_id_arti_global:res.data.zaa_id_arti_global
                        , config})
                        .then(res => {
                            axios.put('http://127.0.0.1:8000/pedido/itemped/'+ i.zipe_id_item_ped + '/', {
                                zipe_cant: i.zipe_cant,
                                zipe_sub_tot: i.zipe_sub_tot,
                                zipe_devo: i.zipe_devo,
                                zipe_talla: i.zipe_talla,
                                zipe_color: i.zipe_color,
                                zipe_status: 'Entregado',
                                zipe_id_pedido_cab: i.zipe_id_pedido_cab.zped_id_pedcab,
                                zipe_id_arti: i.zipe_id_arti.zaa_id_articulo
                            })
                            .then(res=>window.location.reload())
                            .catch(error => console.log(error))
                        })
                        .catch(error => console.log(error))
                         
                    }else{
                        this.text =  'El articulo '+ res.data.zaa_nombre_arti + ' no tiene suficientes unidades '
                        this.snackbar = true                        
                    }
                }).catch(error => console.log(error))
      },
        async marcarEntregado02(i){
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            await axios.get('http://127.0.0.1:8000/articulo/client/'+ i.zipe_id_arti.zaa_id_articulo + '/', config)
                .then(res => {
                    if(res.data.zaa_cantidad >= i.zipe_cant){
                        axios.put('http://127.0.0.1:8000/pedido/itemped/'+ i.zipe_id_item_ped + '/', {
                            zipe_cant: i.zipe_cant,
                            zipe_sub_tot: i.zipe_sub_tot,
                            zipe_talla: i.zipe_talla,
                            zipe_devo: i.zipe_devo,
                            zipe_color: i.zipe_color,
                            zipe_status: 'Entregado',
                            zipe_id_pedido_cab: i.zipe_id_pedido_cab.zped_id_pedcab,
                            zipe_id_arti: i.zipe_id_arti.zaa_id_articulo
                        })
                        .catch(error => console.log(error))
                        axios.put('http://127.0.0.1:8000/articulo/client/'+ res.data.zaa_id_articulo + '/', {
                            zaa_id_sucursal: res.data.zaa_id_sucursal,
                            zaa_cantidad: res.data.zaa_cantidad  - i.zipe_cant,
                            zaa_color: res.data.zaa_color,
                            zaa_existen: res.data.zaa_existen,
                            zaa_id_articulo: res.data.zaa_id_articulo,
                            zaa_talla: res.data.zaa_talla,
                            zaa_id_arti_global:res.data.zaa_id_arti_global
                        }, config)
                        .catch(error => console.log(error))
                        
                    }else{
                        this.text =  'El articulo '+ res.data.zaa_nombre_arti + ' no tiene suficientes unidades '
                        this.snackbar = true                        
                    }
                }).catch(error => console.log(error))
      },
        finalizar(cabecera){
            const URL = 'http://127.0.0.1:8000/pedido/pcadmin/'+this.$route.params.id+'/'
            var i
            var finVerd = false
            for(i = 0; i <=  this.items.length; i++){
                if(i==this.items.length){
                    finVerd = true
                }else{
                    if(this.items[i].zipe_status == 'Espera'){
                    this.marcarEntregado02(this.items[i])  
                }  
                }                                   
            }
            if(finVerd == true){
                axios.put(URL, {
                zdus_correo: cabecera.zdus_correo,
                zipe_total: cabecera.zipe_total,
                zped_fecha: cabecera.zped_fecha,
                zped_id_usuario: cabecera.zped_id_usuario,
                zped_nombre: cabecera.zped_nombre,
                zped_status: 'Finalizado'
                })
                .then(res=>window.location.reload())
            }       
        }
    }
}
</script>