Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran un Dialog (modal) con la información de un artículo de un pedido 
<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" >
          <v-tooltip bottom v-if="element.zipe_cant > producto.zaa_cantidad" >
            <template v-slot:activator="{ on, attrs }">
                <strong class="red--text" v-bind="attrs" v-on="on">{{producto.zaa_nombre_arti}}</strong>
            </template>
            <span>No se tienen las unidades necesarias</span>
          </v-tooltip>
          <strong class="blue--text" v-else>{{producto.zaa_nombre_arti}}</strong>      
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
          {{producto.zaa_nombre_arti}}
        </v-card-title>
        <v-card-text>
            <v-alert dense text type="success" v-if="producto.zaa_existen == true" >
                El producto: <strong>{{producto.zaa_nombre_arti}}</strong> esta habilitado. 
            </v-alert>
            <v-alert dense text type="warning" v-if="producto.zaa_existen == false" >
                El producto: <strong>{{producto.zaa_nombre_arti}}</strong> esta deshabilitado.
            </v-alert>
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Clave</strong></td>
                    <td>{{producto.zaa_clave}}</td>
                  </tr>
                  <tr>
                    <td><strong>Código de barras</strong></td>
                    <td>{{producto.zaa_codigo_bar}}</td>
                  </tr>
                  <tr>
                    <td><strong>Categoría</strong></td>
                    <td>{{producto.zaa_categoria}}</td>
                  </tr>
                  <tr>
                    <td><strong>Sucursal</strong></td>
                    <td>{{producto.zaa_sucursal}}</td>
                  </tr>
                  <tr>
                    <td><strong>Catálogo</strong></td>
                    <td>{{producto.zaa_cata_name}}</td>
                  </tr>
                  <tr>
                    <td><strong>Departamento: </strong>{{producto.zaa_dpto_name}}</td>
                    <td><strong>SubDepartamento: </strong>{{producto.zaa_subdpto_name}}</td>
                  </tr>  
                  <tr>
                    <td><strong>Cantidad</strong></td>
                    <td>{{producto.zaa_cantidad}}</td>
                  </tr> 
                  <tr>
                    <td><strong>Marca</strong></td>
                    <td>{{producto.zaa_marca}}</td>
                  </tr>
                  <tr>
                    <td><strong>Modelo</strong></td>
                    <td>{{producto.zaa_modelo}}</td>
                  </tr> 
                </tbody>
              </template>
            </v-simple-table> 
            <v-divider/>
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Colores: </strong> {{colores}} </td> 
                  </tr>
                  <tr>
                    <td><strong>Tamaños: </strong> {{sizes}}</td> 
                  </tr>
                </tbody>
              </template>
            </v-simple-table> 
            <v-divider/>
            <v-simple-table dense>
              <template v-slot:default>
                <tbody> 
                  <tr>
                    <td><strong>Precio al contado: $</strong>{{producto.zaa_prec_cont}}</td>
                    <td><strong>Precio en pagos: $</strong>{{producto.zaa_prec_pag}}</td>
                  </tr>
                  <tr>
                    <td><strong>Precio de mayoreo: $</strong>{{producto.zaa_prect_mayo}}</td>
                    <td><strong>Precio menudeo: $</strong>{{producto.zaa_prect_menud}}</td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table> 
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    data(){
        return {
          colores: '',
          sizes: '',
          producto: []
        };
    },
    created() {
      this.getItem()
    },
    methods:{
      getItem(){
        let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
        axios.get('http://127.0.0.1:8000/articulo/admin/' + this.element.zipe_id_arti.zaa_id_articulo, config )
        .then(res => {
          this.producto = res.data 
          this.getColors(res.data.zaa_color)
          this.getSizes(res.data.zaa_talla)
        })
      },
      getColors(colores){
        let extn = colores.length
        let colo = ''
        for (let i = 0; i < extn; i++) {
          if (i == extn -1) {
            colo = colo + colores[i].text
            this.colores = colo
          }else{
            colo = colo + colores[i].text + " - "
          }
        }
      },
      getSizes(tallas){
        let extn = tallas.length
        let size = ''
        for (let i = 0; i < extn; i++) {
          if (i == extn -1) {
            size = size + tallas[i].text
            this.sizes = size
          }else{
            size = size + tallas[i].text + " - "
          }
        }
      },

    }
}
</script>