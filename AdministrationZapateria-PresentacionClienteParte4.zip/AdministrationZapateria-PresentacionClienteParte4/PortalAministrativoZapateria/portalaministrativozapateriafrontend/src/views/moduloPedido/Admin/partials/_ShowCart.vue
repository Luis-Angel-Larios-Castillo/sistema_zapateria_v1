Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran un Dialog (modal) con la información de un pedido 
<template>
    <div >
        <v-dialog  max-width="800">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zped_nombre}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
         <strong>{{element.zped_nombre}}</strong>
         <v-spacer/>
         <strong>Fecha: </strong>{{element.zped_fecha}} 
         <v-spacer/>
         <strong>Total: $</strong>{{element.zipe_total}} 
        </v-card-title> 
        <v-divider/>
        <v-card-subtitle class="black--text" align="center"><br>
        <strong>Folio del cliente: </strong>{{foliclie}} 
            <v-spacer/>
             <strong>Nombre del cliente: </strong> {{nomclie}}
            <p v-if="element.zped_status == 'Finalizado'" class="green--text"><strong class="black--text">Estatus: </strong>{{element.zped_status}}</p>
            <p v-if="element.zped_status == 'Espera'" class="blue--text"><strong class="black--text">Estatus: </strong>{{element.zped_status}}</p>
            <p v-if="element.zped_status == 'Cancelado'" class="red--text"><strong class="black--text">Estatus: </strong>{{element.zped_status}}</p>
        </v-card-subtitle>
        <v-card-text>
            <v-simple-table>
                <template v-slot:default>
                <thead>
                    <tr>
                    <th class="text-left">
                        Articulo
                    </th>
                    <th class="text-left">
                        Cantidad
                    </th>
                    <th class="text-left">
                        Color
                    </th>
                    <th class="text-left">
                        Talla
                    </th>
                    <th class="text-left">
                        Subtotal
                    </th>
                    <th class="text-left">
                        Estatus
                    </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in items" :key="item.zipe_id_item_ped" >
                    <td>{{ item.zipe_art_nom }}</td>
                    <td class="text-center">{{ item.zipe_cant }}</td>
                    <td>{{ item.zipe_color }}</td>
                    <td>{{ item.zipe_talla }}</td>
                    <td>${{ item.zipe_sub_tot }}</td>
                    <td>                           
                        <div v-if="item.zipe_status == 'Entregado'" class="green--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Espera'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Pendiente'" class="blue--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Devolución'" class="purple--text">{{ item.zipe_status }}</div>
                        <div v-if="item.zipe_status == 'Listo para entregar cliente'" class="blue--text">{{ item.zipe_status }}</div> 
                        <div v-if="item.zipe_status == 'Listo para entregar'" class="blue--text">{{ item.zipe_status }}</div> 
                        <div v-if="item.zipe_status == 'Cancelado'" class="red--text">{{ item.zipe_status }}</div>  
                    </td>
                    </tr>
                </tbody>                    
                </template>                    
            </v-simple-table>
        </v-card-text>
      </v-card>
    </v-dialog>
    </div>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    created() {
      this.getItems()
      this.getclient()
      
    },
    data(){
        return {
          URL: 'http://127.0.0.1:8000/pedido/itembpc/?search='+this.element.zped_id_pedcab,
          items: [],
         datos:[],
         nomclie:[],
         foliclie:[],
         datosclinoafi:[],
        };
    },
    methods:{
      getItems(){
        axios.get(this.URL)
        .then(res => this.items = res.data)
      },
      getclient(){
             axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.element.zped_id_usuario)
                .then(res =>{ this.datos = res.data           
                if(res.data.length  > 0){
                    this.nomclie = this.datos[0].nombre
                    this.foliclie = this.datos[0].zc_folio_client

                    //console.log(this.datos[0].nombre)
                }
                else{
                    axios.get('http://127.0.0.1:8000/clientes/'+this.element.zped_id_usuario+'/')
                    .then(res =>{ this.datosclinoafi = res.data 
                        this.nomclie = this.datosclinoafi.nombre
                         this.foliclie = this.datosclinoafi.zc_folio_client
                    
                    })          
                }
                
                })           
        }
    }
}
</script>