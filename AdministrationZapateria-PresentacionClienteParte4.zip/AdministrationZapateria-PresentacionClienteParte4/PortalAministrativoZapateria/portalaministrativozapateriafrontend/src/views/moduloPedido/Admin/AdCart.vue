Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los pedidos realizados 
<template>
<div cols="full">
    <v-row>
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col> 
        <v-col cols="md-10 xs-12" > 
             <app-header style="z-index: 135"/> 
             <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">PEDIDOS</h1>
            </div><br>

                   <v-card :elevation="0">
                     <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                      <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                       <v-select v-model="tiposelect" v-on:change="find()" :items="tiposItems"  class="select_status" item-text="texttipos" item-value="valtiposItems"  dense rounded solo   label="Clientes" required/>
                        </div>
                    </v-card-title>
                     <div class="col-12" style="padding-top:0">
                    <v-data-table
                    id="tabla_datos"
                        class="col-10"
                        :headers="headers" 
                        :items="pedi"
                        :search="search" 
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen pedidos registrados." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }"
                        :header-props="{ sortByText: 'Ordenar por' }"
                    >
                    <template v-slot:item.zped_nombre="{ item }"  >
                        <ShowCart :element="item"/>
                    </template>
                    <template v-slot:item.zped_status="{ item }"  >
                        <div v-if="item.zped_status == 'Finalizado'" class="green--text">{{item.zped_status}}</div>
                        <div v-if="item.zped_status == 'Espera'" class="blue--text">{{item.zped_status}}</div>
                        <div v-if="item.zped_status == 'Pendiente'" class="blue--text">Espera</div>
                        <div v-if="item.zped_status == 'Cancelado'" class="red--text">{{item.zped_status}}</div>
                    </template>
                    <template v-slot:item.zipe_total="{ item }"  >
                        $ {{item.zipe_total}}
                    </template>
                     <template v-slot:item.zped_id_usuario="{ item }"  >
                         <Shownomclien :element="item"/>
                    </template>
                    <template v-slot:item.zped_id_pedcab="{ item }"  >
                        <v-tooltip bottom >
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn icon :to="'/epedido/'+ item.zped_id_pedcab+'/'" v-bind="attrs" v-on="on" v-if="permissions.can_manage_ped_art == true">
                                    <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                </v-btn>
                                 <v-btn icon v-bind="attrs" v-on="on" v-else disabled>
                                    <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                </v-btn>
                            </template>
                            <span>Editar</span>
                        </v-tooltip>
                    </template>
                </v-data-table>
                </div>
            </v-card>
        </v-col>
    </v-row>
    <br>
</div>
</template>
<script>
const axios = require('axios')
import Header from '../../../components/Header';
import menuModulos from '../../menuModulos'
import ShowCart from './partials/_ShowCart'
import EditCart from './partials/_EditCart'
import Shownomclien from './partials/_Shownomclien'
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,   
        ShowCart, 
        EditCart,
        Shownomclien
    },
    created() {
        this.find()
    },
    data () {
      return {
        
        search: '',
        headers: [
          {
            text: 'Pedidos',
            align: 'start',
            filterable: true,
            value: 'zped_nombre',

          },          
          { text: 'Fecha', value: 'zped_fecha' },
          { text: 'Estatus', value: 'zped_status' },
          { text: 'Total', value: 'zipe_total' },
          { text: 'Usuario', value: 'zped_id_usuario', filterable: true, },
          { text: 'Acciones', value: 'zped_id_pedcab', sortable: false },
        ],
        pedi:[],
        tiposelect:true,
        tiposItems: [
                { valtiposItems: true, texttipos: 'Clientes Afiliados'},
                { valtiposItems: false, texttipos: 'Clientes No Afiliados'},
            ],
            idUser:[],
            empleadoResult:[],
            permissions: {
            can_manage_ped_art: false,
        },
      }
    },
    methods:{
        async cancelar(i){
            await axios.put('http://127.0.0.1:8000/pedido/pedcab/'+ i.zped_id_pedcab+'/',{
                zipe_total: i.zipe_total,
                zped_fecha: i.zped_fecha,
                zped_id_usuario: i.zped_id_usuario,
                zped_nombre: i.zped_nombre,
                zped_status: 'Cancelado'
                }).then(res => window.location.reload())
        },
        find(){

             axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_ped_art: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_pedidos_articulos') { this.permissions.can_manage_ped_art = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                }) 


             this.pedi = []
             
            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            //console.log(this.idUser)
            axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
            .then(res => { this.empleadoResult = res.data[0]
            //console.log(this.empleadoResult)

            axios.get('http://127.0.0.1:8000/pedido/pcadmin/?search='+ this.empleadoResult.zdem_id_sucursal)
                .then(res => {
                
                    res.data.forEach(element => { 
                            if(element.zped_is_afi ==  this.tiposelect){
                                this.pedi.push(element)
                            }
                        }); 
                
                    }) 
                })
            })                
        },
        finalizar(i){
            const URL = 'http://127.0.0.1:8000/pedido/pcadmin/'+i.zped_id_pedcab+'/'
            axios.put(URL, {
                zdus_correo: i.zdus_correo,
                zipe_total: i.zipe_total,
                zped_fecha: i.zped_fecha,
                zped_id_usuario: i.zped_id_usuario,
                zped_nombre: i.zped_nombre,
                zped_status: 'Finalizado'
            }).catch(error => console.log(error))
            window.location.reload()
        },
        ponerEspera(i){
            
            const URL = 'http://127.0.0.1:8000/pedido/pcadmin/'+i.zped_id_pedcab+'/'            
            axios.put(URL, {
                zdus_correo: i.zdus_correo,
                zipe_total: i.zipe_total,
                zped_fecha: i.zped_fecha,
                zped_id_usuario: i.zped_id_usuario,
                zped_nombre: i.zped_nombre,
                zped_status: 'Espera'
            }).catch(error => console.log(error))
            window.location.reload()
        
        },
        
    },
}
</script>