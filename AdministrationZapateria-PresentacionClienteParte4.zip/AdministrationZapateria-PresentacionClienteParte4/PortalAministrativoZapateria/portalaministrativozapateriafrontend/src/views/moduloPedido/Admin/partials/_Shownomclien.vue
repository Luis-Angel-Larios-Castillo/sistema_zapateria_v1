Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran un Dialog (modal) con la información de un pedido 
<template>
    <div>
        {{nomclie}}
    </div>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'element'
    ],
    created() {
      this.getclient()
      
    },
    data(){
        return {
         datos:[],
         nomclie:[],
         datosclinoafi:[],
        };
    },
    methods:{
      getclient(){
             axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.element.zped_id_usuario)
                .then(res =>{ this.datos = res.data           
                if(res.data.length  > 0){
                    this.nomclie = this.datos[0].nombre
                    //console.log(this.datos[0].nombre)
                }
                else{
                    axios.get('http://127.0.0.1:8000/clientes/'+this.element.zped_id_usuario+'/')
                    .then(res =>{ this.datosclinoafi = res.data 
                        this.nomclie = this.datosclinoafi.nombre
                    
                    })          
                }
                
                })           
        }
    }
}
</script>