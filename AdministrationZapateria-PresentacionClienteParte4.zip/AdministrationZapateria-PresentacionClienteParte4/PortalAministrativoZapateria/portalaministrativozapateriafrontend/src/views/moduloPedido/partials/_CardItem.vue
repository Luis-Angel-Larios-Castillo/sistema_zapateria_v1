Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo cuenta con un Card que contiene los datos del articulo para hacer un intercambio
<template >
    <v-hover>
        <v-card>
            <v-row>
                <v-col cols="6">
                    <v-img v-if="CardData.item.zaa_cantidad >= 1" src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80" dark class="white--text align-end" gradient="to bottom, rgba(0,0,0,.10), rgba(0,0,0,.5)" height="200px">
                        <v-card-title>{{CardData.item.zaa_nombre_arti}}</v-card-title>
                    </v-img>
                    <v-img  v-if="CardData.item.zaa_cantidad == 0" src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80" dark class="white--text align-end" gradient="to bottom, rgba(0,0,0,0.7) , rgba(0,0,0,0.7)" height="200px">
                        <h2  class="text-center">Agotado</h2>
                        <v-card-title>{{CardData.item.zaa_nombre_arti}}</v-card-title>
                    </v-img>
                </v-col>
                <v-col cols="6">
                    <v-card-text class=" black--text">
                        <p class="text-center"><strong>Catalogo: </strong>{{CardData.item.zaa_cata_name}}</p>
                        <p class="text-center"><strong>Depto: </strong>{{CardData.item.zaa_dpto_etiqueta}}</p>
                        <p class="text-center"><strong>Temporada: </strong>{{CardData.item.zaa__temporada}}</p>
                        <p class="headline"><strong>$</strong>{{CardData.item.zaa_prec_cont}}</p>
                    </v-card-text>  
                    <v-card-actions v-if="CardData.item.zaa_cantidad != 0">
                        <v-form ref="form" v-model="valid" lazy-validation m>
                            <v-row>
                                <v-col cols="6">
                                    <v-select v-model="colorSel" :items="colores" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']"  label="Color" required/>
                                </v-col>
                                <v-col cols="6">
                                    <v-select v-model="sizeSel" :items="sizes" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un talla']"  label="Talla" required/>
                                </v-col>
                            </v-row>
                            <v-row align="center">
                                <v-col cols="2"/>
                                <v-col cols="4" >
                                    <v-select v-model="cantidad" :items="cantidad02" :rules="[v => !!v || 'Debe seleccionar una cantidad']"  label="Cantidad" required/>
                                </v-col>
                                <v-col cols="4" >
                                    <v-btn text  color="primary" :disabled="!valid" @click="validate">
                                        Seleccionar  
                                    </v-btn>
                                </v-col>
                                <v-col cols="2"/>
                            </v-row>
                        </v-form>
                    </v-card-actions>
                </v-col>
            </v-row>
        </v-card>
    </v-hover>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'CardData',
    ],
    data () {
        return {
            valid: true,
            dialog: false,
            colores: [],
            colorSel: '',
            sizes: [],
            sizeSel: '',
            cantidad: 1,
            cantidad02: [],
            idUser:'',
            name: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1)),
            elementG: [],
            cab: [],
            itemPed: [],
            cantRules: [
                v => !!v || 'Cantidad inválida.',
                v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                v => (v && v < this.cantidad+1) || 'No se puede seleccionar esta cantidad +',
            ],
        }
    },
    created() {
        this.colores = this.CardData.item.zaa_color
        this.sizes = this.CardData.item.zaa_talla
        let cant = []
        for (let i = 1; i <= this.CardData.item.zaa_cantidad; i++) {               
            cant.push(i)
        }
        this.cantidad02 = cant
        axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
        .then(res => this.idUser = res.data.user)
    },
    methods: {
        validate(){
            let artOriginal = []
            let idItemOriginal = this.CardData.intercambioData.zipe_id_item_ped 
            let URLArtOriginal = 'http://127.0.0.1:8000/articulo/client/' + this.CardData.intercambioData.zipe_id_arti.zaa_id_articulo + '/'
            let URLItemPedOri = 'http://127.0.0.1:8000/pedido/itemped/' + this.CardData.intercambioData.zipe_id_item_ped + '/'
             
            artOriginal = {
                zaa_cantidad: this.CardData.intercambioData.zipe_id_arti.zaa_cantidad + this.CardData.intercambioData.zipe_cant,
                zaa_categoria: this.CardData.intercambioData.zipe_id_arti.zaa_categoria,
                zaa_clave: this.CardData.intercambioData.zipe_id_arti.zaa_clave,
                zaa_codigo_bar: this.CardData.intercambioData.zipe_id_arti.zaa_codigo_bar,
                zaa_color: this.CardData.intercambioData.zipe_id_arti.zaa_color,
                zaa_existen: this.CardData.intercambioData.zipe_id_arti.zaa_existen,
                zaa_id_catalogo: this.CardData.intercambioData.zipe_id_arti.zaa_id_catalogo,
                zaa_id_subdep: this.CardData.intercambioData.zipe_id_arti.zaa_id_subdep,
                zaa_marca: this.CardData.intercambioData.zipe_id_arti.zaa_marca,
                zaa_modelo: this.CardData.intercambioData.zipe_id_arti.zaa_modelo,
                zaa_nombre_arti: this.CardData.intercambioData.zipe_id_arti.zaa_nombre_arti,
                zaa_prec_cont: this.CardData.intercambioData.zipe_id_arti.zaa_prec_cont,
                zaa_prec_pag: this.CardData.intercambioData.zipe_id_arti.zaa_prec_pag,
                zaa_prect_mayo: this.CardData.intercambioData.zipe_id_arti.zaa_prect_mayo,
                zaa_prect_menud: this.CardData.intercambioData.zipe_id_arti.zaa_prect_menud,
                zaa_id_sucursal: this.CardData.intercambioData.zipe_id_arti.zaa_id_sucursal,
                zaa_talla: this.CardData.intercambioData.zipe_id_arti.zaa_talla,
            }
            
            if (this.$refs.form.validate()){
                axios.post('http://127.0.0.1:8000/pedido/pedcab/', {
                zped_status: 'Espera',
                zped_fecha: new Date().toISOString().slice(0,10),
                zipe_total: this.cantidad * this.CardData.item.zaa_prec_cont,
                zped_id_usuario: this.idUser,
                zped_nombre: 'PED-DEV-'+ this.name +'-'+ new Date().toISOString().slice(5,10),
                })
                .then(res => {
                    axios.post('http://127.0.0.1:8000/pedido/itemped/', {
                        zipe_status: 'Espera',
                        zipe_cant: this.cantidad,
                        zipe_color: this.colorSel,
                        zipe_devo: this.CardData.intercambioData.zipe_devo + 1,
                        zipe_id_arti: this.CardData.item.zaa_id_articulo,
                        zipe_id_pedido_cab: res.data.zped_id_pedcab,
                        zipe_sub_tot: this.cantidad * this.CardData.item.zaa_prec_cont,
                        zipe_talla: this.sizeSel
                    })
                    .then(newres => {
                        axios.post('http://127.0.0.1:8000/pedido/iteminter/', {
                            zpd_id_item_ori: idItemOriginal,
                            zpd_id_item_nue: newres.data.zipe_id_item_ped
                        })
                        .then(tabaux => {
                            axios.put(URLArtOriginal, artOriginal)
                            .then(artiori => {
                                axios.put(URLItemPedOri, {
                                    zipe_status: 'Devolución',
                                    zipe_cant: this.CardData.intercambioData.zipe_cant,
                                    zipe_color: this.CardData.intercambioData.zipe_color,
                                    zipe_devo: this.CardData.intercambioData.zipe_devo,
                                    zipe_id_arti: this.CardData.intercambioData.zipe_id_arti.zaa_id_articulo,
                                    zipe_id_pedido_cab: this.CardData.intercambioData.zipe_id_pedido_cab.zped_id_pedcab,
                                    zipe_sub_tot: this.CardData.intercambioData.zipe_sub_tot,
                                    zipe_talla: this.CardData.intercambioData.zipe_talla
                                })
                                .then(itemori => {
                                    window.location.reload()
                                })
                            })
                        })
                    })
                })
            }
        }
    },
  }
</script>