Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran un Dialog (modal) para eliminar el item del carrito 
<template>
  <v-row justify="center">
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="red" dark @click.stop="dialog = true" v-bind="attrs" v-on="on">
            <v-icon >mdi-delete-outline</v-icon>
          </v-btn>
        </template>
        <span>Eliminar</span>
    </v-tooltip>
    

    <v-dialog
      v-model="dialog"
      max-width="500"
    >
      <v-card>
        <v-card-title class="red--text">
          Se va a eliminar el articulo: {{ elementD.zipe_id_arti.zaa_nombre_arti }}
        </v-card-title>

        <v-card-text>
          ¿Está seguro que quiere eliminarlo?
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="green darken-1" text @click="dialog = false">
            Cancelar 
          </v-btn>

          <v-btn color="green darken-1" text @click="aceptar()">
            Aceptar 
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'elementD'
    ],
    data () {
      return {
        dialog: false,
    }
    },
    methods:{
      aceptar(){
        let URL = 'http://127.0.0.1:8000/pedido/itemped/'+ this.elementD.zipe_id_item_ped
        axios.delete(URL)
          .then(res => {
            this.dialog = false
            window.location.reload()
          })
        }
    },
  }
</script>