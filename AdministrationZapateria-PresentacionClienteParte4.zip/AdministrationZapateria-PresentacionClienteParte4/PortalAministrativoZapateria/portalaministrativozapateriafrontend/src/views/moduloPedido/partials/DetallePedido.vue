Autor: ???
Descripción: ????
<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="350">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="gray--text">
          <strong>{{elements.zdem_nombre}}</strong>
          
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
          {{elements.zdem_nombre}}
        </v-card-title>
        <v-card-text>
            <v-alert dense text type="success" v-if="elements.zdem_existen == true" >
                El Empleado: <strong>{{elements.zdem_nombre}}</strong> Esta habilitado. 
            </v-alert>
            <v-alert dense text type="warning" v-if="elements.zdem_existen == false" >
                El Empleado: <strong>{{elements.zdem_nombre}}</strong> Esta deshabilitado.
            </v-alert>
            <div class="black--text"> 
                <p>Apellido Paterno: {{elements.zdem_apell_pat}}</p>
                <p>Apellido Materno: {{elements.zdem_apell_mat}}</p>
                <p>Teléfono de Casa: {{elements.zdem_num_tel}}</p>
                <p>Número de Celular: {{elements.zdem_num_cel}}</p>
                <p>Fecha de Nacimiento: {{elements.zdem_fech_nacim}}</p>
                <p>País: {{elements.zdem_dir_pais}}</p>
                <p>Estado: {{elements.zdem_dir_estado}}</p>
                <p>Municipio {{elements.zdem_dir_municipio}}</p>
                <p>Colonia: {{elements.zdem_dir_colonia}}</p>
                <p>Codigo Postal: {{elements.zdem_dir_cod_postal}}</p>
                <p>Calle Principal: {{elements.zdem_dir_calle_1}}</p>
                <p>Calle Interconexión: {{elements.zdem_dir_calle_2}}</p>
                <p>Número Ixterior: {{elements.zdem_dir_num_int}}</p>
                <p>Número Exterior: {{elements.zdem_dir_num_ext}}</p>
            </div>
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'elements'
    ],
    created() {
      this.getEmpleado()
    
    },
    data(){
        return {
           URL: 'http://127.0.0.1:8000/empleado/'+this.elements.zdem_id_empleado+'/',
          empleado: [],
          
        };
    },
    methods:{
         getEmpleado(){ 
        axios.get(this.URL)
        .then(res => this.empleado = res.data)
      
    },
}}
</script>