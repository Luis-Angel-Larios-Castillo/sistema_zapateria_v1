<template>
<div class="text-center">
    <v-dialog
      v-model="dialog"
      width="500"
    >
   <v-text-field v-model="idUser" label="Id Usuario" readonly required v-if="ocultar"></v-text-field>
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          dark
          v-bind="attrs"
          v-on="on"
          @click="dialog=true" v-if="devolucion.zipe_status == 'Entregado'" color="red">
          
         Devolución
        </v-btn>
      </template>

      <v-card>
          
        <v-card-title class="headline">
          {{devolucion.zipe_id_arti.zaa_nombre_arti}} {{devolucion.zped_fecha}}
          
        </v-card-title>
        Veces que se devolvio: {{vecesdevo}}
        
        <v-col></v-col> 
        <v-divider></v-divider>
        <v-card-text>
        <p>Cantidad: {{devolucion.zipe_cant}}</p>
        </v-card-text>
        <v-card-text>
         <p>Color: {{devolucion.zipe_color}}</p>
         </v-card-text>
         <v-card-text>
        <p>Talla: {{devolucion.zipe_talla}}</p>
        </v-card-text>
         <v-card-text>
        <p>Total: {{devolucion.zipe_sub_tot}}</p>
        </v-card-text>

        <v-divider></v-divider>
          <v-alert dense outlined color="red" v-if="vecesdevo == 3 || fecha  >= 10">
        El pedido ha excedido su plazo para ser devuelto o el producto no puede ser devulto más de tres veces.

        </v-alert>
          
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            :disabled="vecesdevo == 3 || fecha >= 10"  @click="devArticulo" v-if="devolucion.zipe_status == 'Entregado'" color="primary">

         Devolucion
          </v-btn>


          <v-btn
            color="primary"

            @click="dialog = false"
          >
            Salir

            <v-icon
         right
         dark
      
      >
         mdi-minus-circle
      </v-icon>
          </v-btn>
        </v-card-actions>
                    
           </v-card>

          </v-dialog>
      </div>
</template>

<script>
import { isDate } from 'moment'

const axios = require('axios')
const moment = require('moment')
export default {
    props:[
        'devolucion'
    ],
    data () {
      return {
       ocultar: false,
        items: [],
        idUser: '',
        dialog: false,
        vecesdevo: 0,
        fecha: 0,
        num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
          
      }
    },
    created(){
     this.vecesdevo=this.devolucion.zipe_devo
     this.fecha=this.devolucion.zped_fecha     
     
     axios.get ('http://127.0.0.1:8000/pedido/pedcab/')
      .then(res => {this.items = res.data }) 
          let f01 = moment(new Date())
          let f02 = moment(this.devolucion.zped_fecha)
          let dias = f01.diff(f02, 'days')
          this.fecha=dias

     this.findIdUser()
    },
        
    methods:{
      findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
          .then(res => this.idUser = res.data.user)
          //.then(res=> console.log(res.data))
      },
        devArticulo(){       
           console.log(this.devolucion.zipe_devo)
           console.log(this.devolucion.zped_fecha)
             
              let URL = 'http://127.0.0.1:8000/pedido/itemped/'+ this.devolucion.zipe_id_item_ped + '/' 
                
            axios.put(URL,{
                zipe_color: this.devolucion.zipe_color,
                zipe_talla: this.devolucion.zipe_talla,
                zipe_cant: this.devolucion.zipe_cant,
                zipe_id_arti: this.devolucion.zipe_id_arti.zaa_id_articulo,
                zipe_id_pedido_cab:this.devolucion.zipe_id_pedido_cab.zped_id_pedcab,
                zipe_devo:this.devolucion.zipe_devo,
                zipe_status: 'Devolución',
                zipe_sub_tot: this.devolucion.zipe_sub_tot,
            })
/*
          let fecha_vale =  new Date().toISOString().slice(0,10)
            
          axios.post("http://127.0.0.1:8000/vale/",{                

                            zdv_estat_vale: false,
                            zdv_gen_vale: 'Vale-'+fecha_vale + '-'+this.num_random,
                            //zdv_fecha_cobro: new Date().toISOString().slice(0,10),
                            zdv_importe:500,
                            zdv_id_usuario:this.idUser,
                            zdv_id_sucursal:this.devolucion.zipe_id_arti.zaa_id_sucursal,
                            zdv_id_item_ped:this.devolucion.zipe_id_item_ped
                        }) 
*/
            .then(res=> axios.put("http://127.0.0.1:8000/articulo/client/" + this.devolucion.zipe_id_arti.zaa_id_articulo + '/',{
                zaa_id_subdep: this.devolucion.zipe_id_arti.zaa_id_subdep,
                zaa_nombre_arti: this.devolucion.zipe_id_arti.zaa_nombre_arti,
                zaa_color: this.devolucion.zipe_id_arti.zaa_color,
                zaa_codigo_bar: this.devolucion.zipe_id_arti.zaa_codigo_bar,
                zaa_cantidad: this.devolucion.zipe_id_arti.zaa_cantidad+this.devolucion.zipe_cant,
                zaa_modelo: this.devolucion.zipe_id_arti.zaa_modelo,
                zaa_clave: this.devolucion.zipe_id_arti.zaa_clave,
                zaa_marca: this.devolucion.zipe_id_arti.zaa_marca,
                zaa_talla: this.devolucion.zipe_id_arti.zaa_talla,
                zaa_prec_cont: this.devolucion.zipe_id_arti. zaa_prec_cont,
                zaa_prec_pag: this.devolucion.zipe_id_arti.zaa_prec_pag,
                zaa_prect_mayo: this.devolucion.zipe_id_arti.zaa_prect_mayo,
                zaa_prect_menud: this.devolucion.zipe_id_arti.zaa_prect_menud,
                zaa_existen: this.devolucion.zipe_id_arti.zaa_existen,
                zaa_id_catalogo: this.devolucion.zipe_id_arti.zaa_id_catalogo,
                zaa_categoria: this.devolucion.zipe_id_arti.zaa_categoria,
                zaa_id_sucursal: this.devolucion.zipe_id_arti.zaa_id_sucursal,

            })

          
            .then(res=> {          
            axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
            .then((res) => {
                axios.get('http://127.0.0.1:8000/pedido/pcuactiv/?search='+res.data.user)
                .then((r) => {
                console.log(r.data[0].zped_id_pedcab)
                axios.post("http://127.0.0.1:8000/pedido/itemped/",{
                    zipe_color: this.devolucion.zipe_color,
                    zipe_talla: this.devolucion.zipe_talla,
                    zipe_cant: this.devolucion.zipe_cant,
                    zipe_id_arti: this.devolucion.zipe_id_arti.zaa_id_articulo,
                    zipe_id_pedido_cab:r.data[0].zped_id_pedcab,
                    zipe_devo:this.devolucion.zipe_devo + 1,
                    zipe_status: 'Espera',
                    zipe_sub_tot: this.devolucion.zipe_sub_tot,
                    zipe_talla: this.devolucion.zipe_talla
                })
            
            })
          .then(res=> window.location.reload())
    
                })           
            })
            
            
            
            )    


        }
    },
  }

</script>
