Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran el detalle de un pedido previamente realizado 
<template>
    <v-card>
        <v-toolbar dense>
            <v-spacer/>
                <v-toolbar-title><strong>{{elementDetail.zped_nombre}}</strong></v-toolbar-title>
            <v-spacer/>
                <strong>Fecha: {{elementDetail.zped_fecha}}</strong>
            <v-spacer/>
                <v-btn text @click="cancelar()" v-if="elementDetail.zped_status == 'Espera'" color="red">
                    Cancelar
                </v-btn>
                <v-btn text disabled v-if="elementDetail.zped_status == 'Finalizado'" color="red">
                    Devolucion
                </v-btn>
               <pdf :pedidoData="datos"/> 

        </v-toolbar>  
        <v-card-title >
                <v-spacer/>
                    <p v-if="elementDetail.zped_status == 'Espera'">Pedido: <v-chip class="ma-2" color="blue" label outlined >{{elementDetail.zped_status}} </v-chip><br></p> 
                    <p v-if="elementDetail.zped_status == 'Finalizado'">Pedido: <v-chip class="ma-2" color="green" label outlined >{{elementDetail.zped_status}} </v-chip></p> 
                    <p v-if="elementDetail.zped_status == 'Cancelado'">Pedido: <v-chip class="ma-2" color="red" label outlined >{{elementDetail.zped_status}} </v-chip></p> 
                    <p v-if="elementDetail.zped_status == 'Devolución'">Pedido: <v-chip class="ma-2" color="red" label outlined >{{elementDetail.zped_status}} </v-chip></p> 
                    
                <v-spacer/>
                   <p><strong>Total: </strong> ${{elementDetail.zipe_total}}</p> 
                <v-spacer/>
                
        </v-card-title>
        <v-divider/>
        <v-card-text class="black--text">
    <v-card-actions>Detalles
      <v-spacer/>
      <v-btn icon @click="show = !show">
        <v-icon>{{ show ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
      </v-btn>
    </v-card-actions>
    <v-expand-transition>
    <div v-show="show">
        <v-simple-table>
            <template v-slot:default>
            <thead>
                <tr>
                <th class="text-left">
                    #
                </th>
                <th class="text-left">
                    Articulo
                </th>
                <th class="text-left">
                    Color
                </th>
                <th class="text-left">
                    Talla
                </th>
                <th class="text-left">
                    Subtotal
                </th>
                <th class="text-left">
                    Estado
                </th>
                
                <!--<th class="text-left">
                    Acciones
                </th>-->
                </tr>
            </thead>             
            <tbody>
                <tr v-for="item in items" :key="item.zipe_id_item_ped">
                <td>{{ item.zipe_cant }}</td>
                <td>{{ item.zipe_art_nom }}</td>
                <td>{{ item.zipe_color }}</td>
                <td>{{ item.zipe_talla }}</td>
                <td>${{item.zipe_sub_tot }}</td>

                
                <td>
                    {{item.zipe_status}}
                    <!--
                    <p v-if="item.zipe_status == 'Espera'"><v-chip class="ma-2" color="blue" label outlined >{{item.zipe_status}} </v-chip><br></p> 
                    <p v-if="item.zipe_status == 'Entregado'"><v-chip class="ma-2" color="green" label outlined >{{item.zipe_status}} </v-chip></p> 
                    <p v-if="item.zipe_status == 'Cancelado'"><v-chip class="ma-2" color="red" label outlined >{{item.zipe_status}} </v-chip></p> 
                    <p v-if="item.zipe_status == 'Devolución'"><v-chip class="ma-2" color="red" label outlined >{{item.zipe_status}} </v-chip></p> 
                    -->
                </td>
                <!--<td>
                    <v-row>
                        inicio intercambio
                            <Intercambio :intercambioData="item"/>
                        inicio intercambio  
                        <v-spacer/>
                        <devolucion :devolucion="item"/>
                                
                        <v-spacer/>
                    </v-row>
                </td>-->
                </tr>        
            </tbody>
            
            </template>
    
        </v-simple-table>
    </div>
    
    
    </v-expand-transition>
            <v-divider/>
            <br>
            
        </v-card-text>
        <div class="text-center">
        <v-snackbar v-model="snackbar"  :timeout="timeout"  >
        {{ text }}

        <template v-slot:action="{ attrs }">
            <v-btn color="red lighten-2" text v-bind="attrs" @click="snackbar = false" >
            Aceptar
            </v-btn>
        </template>
        </v-snackbar>

        
    </div>
    </v-card>
    
    
</template>
<script>
import Intercambio from './_Intercambio'
const axios = require('axios')
const moment = require('moment')
import pdf from "../../../components/PdfPedido"
import devolucion from "./Devolucion"


export default {
    components:{
        Intercambio,
        pdf,
        devolucion,
    },
    props:[
        'elementDetail'
    ],
    created() {
        this.find()
    },
    data () {
      return {
          datos:{
              cabecera:this.elementDetail,
              items: [],
          },
          items: [],
          show: false,
          text: '',
          snackbar: false,
          timeout: 10000,
          dialog: false,
    }
    },
    methods: {
        find(){
            axios.get('http://127.0.0.1:8000/pedido/itembpc/?search='+this.elementDetail.zped_id_pedcab)
                .then(res=> {
                    this.datos.items=res.data
                    this.items = res.data })
        },
        cancelar(){
            var i
            for(i = 0; i < this.items.length; i++){
                axios.put('http://127.0.0.1:8000/pedido/itembpc/'+ this.items[i].zipe_id_item_ped + '/', {
                    zipe_cant: this.items[i].zipe_cant,
                    zipe_sub_tot: this.items[i].zipe_sub_tot,
                    zipe_status: 'Cancelado',
                    zipe_id_pedido_cab: this.items[i].zipe_id_pedido_cab.zped_id_pedcab,
                    zipe_id_arti: this.items[i].zipe_id_arti.zaa_id_articulo
                }).catch(error => console.log(error))
            }
            axios.put('http://127.0.0.1:8000/pedido/pedcab/'+ this.elementDetail.zped_id_pedcab+'/',{
                zipe_total: this.elementDetail.zipe_total,
                zped_fecha: this.elementDetail.zped_fecha,
                zped_id_usuario: this.elementDetail.zped_id_usuario,
                zped_nombre: this.elementDetail.zped_nombre,
                zped_status: 'Cancelado'
                }).then(res => window.location.reload())        
       
        },
        devolucion(e,cab){
            let f01 = moment(new Date())
            let f02 = moment(cab.zped_fecha)
            let dias = f01.diff(f02, 'days')
                        
            if(dias<=10){
                if(e.zipe_devo <= 2){
                axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                .then((res) => {
                    axios.get('http://127.0.0.1:8000/pedido/pcuactiv/?search='+res.data.user)
                        .then((r) => {
                            console.log(r.data[0].zped_id_pedcab)
                            
                            axios.post("http://127.0.0.1:8000/pedido/itemped/",{
                                zipe_color: e.zipe_color,
                                zipe_talla: e.zipe_talla,
                                zipe_cant: e.zipe_cant,
                                zipe_id_arti: e.zipe_id_arti.zaa_id_articulo,
                                zipe_id_pedido_cab:r.data[0].zped_id_pedcab,
                                zipe_devo:e.zipe_devo + 1,
                                zipe_status: 'Espera',
                                zipe_sub_tot: e.zipe_sub_tot,
                                zipe_talla: e.zipe_talla
                            })
                            
                        })
                })
                
                axios.put("http://127.0.0.1:8000/pedido/itembpc/" + e.zipe_id_item_ped + "/",{
                    zipe_cant: e.zipe_cant,
                    zipe_id_arti: e.zipe_id_arti.zaa_id_articulo,
                    zipe_id_pedido_cab:e.zipe_id_pedido_cab,
                    zipe_devo:e.zipe_devo + 1,
                    zipe_status: 'Devolución',
                    zipe_sub_tot: e.zipe_sub_tot,
                    zipe_color: e.zipe_color,
                    zipe_talla: e.zipe_talla
                })  
                
                axios.get("http://127.0.0.1:8000/articulo/client/" + e.zipe_id_arti.zaa_id_articulo + "/")
                    .then(res=> 
                    axios.put("http://127.0.0.1:8000/articulo/client/" + e.zipe_id_arti.zaa_id_articulo + "/",{
                    zaa_categoria: res.data.zaa_categoria,
                    zaa_id_sucursal: res.data.zaa_id_sucursal,
                    zaa_id_subdep: res.data.zaa_id_subdep,
                    zaa_nombre_arti: res.data.zaa_nombre_arti ,
                    zaa_color: res.data.zaa_color ,
                    zaa_codigo_bar: res.data.zaa_codigo_bar ,
                    zaa_cantidad: res.data.zaa_cantidad+e.zipe_cant,
                    zaa_modelo: res.data.zaa_modelo ,
                    zaa_clave: res.data.zaa_clave ,
                    zaa_marca: res.data.zaa_marca ,
                    zaa_talla: res.data.zaa_talla ,
                    zaa_prec_cont: res.data. zaa_prec_cont ,
                    zaa_prec_pag: res.data.zaa_prec_pag ,
                    zaa_prect_mayo: res.data.zaa_prect_mayo ,
                    zaa_prect_menud: res.data.zaa_prect_menud ,
                    zaa_existen: res.data.zaa_existen ,
                    zaa_id_catalogo: res.data.zaa_id_catalogo ,
                    zaa_id_subdep: res.data.zaa_id_subdep
                       
                       }
                     
                       )
                       
                    )
                     .then(res=> window.location.reload())  
                }
                
                
                else{
   
            this.text =  'El producto no puede ser devulto más de tres veces'
                        this.snackbar = true 
                }
            }
            else{
                this.text = 'El pedido ha excedido su plazo para ser devuelto.'
                         this.snackbar = true
            }
  
         },
        
            
                
        
    
        },
}
</script>