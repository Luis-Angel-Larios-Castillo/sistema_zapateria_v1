Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestran la interfaz con el carrito activo que utiliza el componente dItemCart para borrar el item del carrito y listado de los pedidos realizados con el componente _CartDetail
<template>
    <v-container fluid> 
         <app-header style="z-index: 135"/> 
        <div class="hr-sect"><h1>Pedidos realizados</h1></div>
        <!--
        <v-card >
            <v-card-title primary-title v-if="pedidoActivo.zped_status">
                <div>
                    <h3 class="headline mb-0">Pedido: {{pedidoActivo.zped_status}}</h3>
                    <div><strong>Fecha: </strong>{{pedidoActivo.zped_fecha}}</div>
                </div>
            </v-card-title>
            <v-card-text>
                <v-simple-table dense>
                    <template v-slot:default>
                    <thead>
                        <tr>
                        <th class="text-left">
                            Articulo
                        </th>
                        <th class="text-left">
                            Cantidad
                        </th>
                        <th class="text-left">
                            Color
                        </th>
                        <th class="text-left">
                            Talla
                        </th>
                        <th class="text-left">
                            Subtotal
                        </th>
                        <th class="text-left">
                            Acciones
                        </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in items" :key="item.zipe_id_item_ped">
                        <td>
                            <v-btn text color="blue" :to="'/detailarti/'+ item.zipe_id_arti.zaa_id_articulo+'/'">
                                {{ item.zipe_id_arti.zaa_nombre_arti }}                                
                            </v-btn>
                        </td>
                        <td>
                            <v-form ref="form" v-model="valid" lazy-validation m>
                                <v-text-field v-model="item.zipe_cant" 
                                v-on:change="cambiarCantidad(item)" 
                                min="1"    
                                :rules="[   v => !!v || 'Cantidad inválida.', 
                                            v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                                            v => (v && v < item.zipe_id_arti.zaa_cantidad+1) || 'No se puede seleccionar esta cantidad' ]"  
                                label="Cantidad" type="number" required/>
                            </v-form>
                        </td>
                        <td>
                            <v-row align="center" >
                                <v-col cols="3">
                                    <h4>{{item.zipe_color}}</h4>
                                </v-col>
                                <v-col cols="9">
                                    <v-select v-model="item.zipe_color" v-on:change="cambiarColor(item)" :items="item.zipe_id_arti.zaa_color" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']"  label="Cambiar color" required/>
                                </v-col>
                            </v-row>                            
                        </td>
                        <td>
                            <v-row align="center" >
                                <v-col cols="3">
                                    <h4>{{item.zipe_talla}}</h4>                             
                                </v-col>
                                <v-col cols="9">
                                    <v-select v-on:change="cambiarTalla(item)" :items="item.zipe_id_arti.zaa_talla" v-model="item.zipe_talla" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un talla']"  label="Cambiar talla" required/>
                                </v-col>
                            </v-row>   
                             
                            
                        </td>
                        <td>${{ item.zipe_sub_tot }}</td>
                        <td><dItemCart  :elementD="item"/></td>
                        </tr>
                    </tbody>                    
                    </template>                    
                </v-simple-table>
                <v-divider/>
                <br>
                <div class="text-right black--text">
                    {{sumField(items)}}
                    <h3>Total: ${{total}}</h3>
                </div>
                <br>
                <div class="text-center">
                    <v-btn color="success" outlined @click="finalizar()" v-if="itemsExis" :disabled="!valid" > 
                        finalizar pedido
                    </v-btn>
                
                    
                </div>
                
            </v-card-text>
        </v-card> 
        -->
        <v-data-iterator :items="pedEspera" no-data-text="No se tienen pedidos registrados." no-results-text="No hay resultados." :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" :sort-by="sortBy.toLowerCase()" :sort-desc="sortDesc" hide-default-footer>
            <template v-slot:header>
                <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar"/>
            </template>

            <template v-slot:default="props">
                <br>
                <v-row>
                <v-col v-for="item in props.items" :key="item.zped_id_pedcab" cols="12">
                    <CartDetail :elementDetail="item"/>
                </v-col>
                </v-row>
                <br>
            </template>
                <!-- Paginación inicio -->
            <template v-slot:footer>
                <v-row class="mt-2" align="center" justify="center" >
                <span class="grey--text">Elementos por página</span>
                <v-menu offset-y>
                    <template v-slot:activator="{ on, attrs }">
                    <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                        {{ itemsPerPage }}
                        <v-icon>mdi-chevron-down</v-icon>
                    </v-btn>
                    </template>
                    <v-list>
                    <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                        <v-list-item-title>{{ number }}</v-list-item-title>
                    </v-list-item>
                    </v-list>
                </v-menu>
                <v-spacer></v-spacer>
                <span class="mr-4 grey--text">
                    Página {{ page }} de {{ numberOfPages }}
                </span>
                    <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
                    <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
                <!-- Paginación fin -->
                </v-row>
            </template> 
        </v-data-iterator> <br>
    </v-container>
</template>
<script> 
import Header from '../../components/Header';
const axios = require('axios')
import dItemCart from './partials/dItemCart'
import CartDetail from './partials/_CartDetail'
export default {
     name: 'Header', 
    components:{
         "app-header": Header,
        dItemCart,
        CartDetail,
    },
    created() {
        this.comprobarToken()
        
    },
    data() {
        return {
            valid: true,
            count : 0,
            cartActive: Object,
            pedidoActivo: Object,
            items: Object.items,
            itemsExis: true,
            total: 0,
            lengthItems:0,
            idUser:'',
            name: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
            page: 1,
            itemsPerPage: 10,
            sortBy: 'zped_status',
            keys: [
                'zped_status',
                'zped_fecha',
                'zped_nombre'
            ],
            pedEspera:[],
            itemsPerPageArray: [10, 15, 20],
            search: '',
            filter: {},
            sortDesc: false,
        }
    },
    computed: {
      numberOfPages () {
        return Math.ceil(this.pedEspera.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Name')
      },
    },
    methods: {
        validate(x, y){
            if (this.valid == true){

                axios.put('http://127.0.0.1:8000/pedido/itemped/'+ y.zipe_id_item_ped+'/', {
                    zipe_id_arti: y.zipe_id_arti,
                    zipe_sub_tot: x * y.precio,
                    zipe_status: y.zipe_status,
                    zipe_color: y.zipe_color,
                    zipe_talla: y.zipe_talla,
                    zipe_id_pedido_cab: y.zipe_id_pedido_cab,
                    zipe_cant: x
                })
                .then(res => window.location.reload())
                .catch(err => window.location.reload())
            }else {
                window.location.reload()
            }         
        },
        cambiarCantidad: function (event) {
            let camb =  event.zipe_cant
            let itemG

            axios.get('http://127.0.0.1:8000/pedido/itempric/'+ event.zipe_id_item_ped)
                .then(res=> {
                    itemG = res.data, 
                    this.validate(camb, itemG)
                    })
            
        },
        cambiarColor: function (event) {
            console.log(event)

            axios.put('http://127.0.0.1:8000/pedido/itemped/'+ event.zipe_id_item_ped+'/', {
                zipe_id_arti: event.zipe_id_arti.zaa_id_articulo,
                zipe_sub_tot: event.zipe_sub_tot,
                zipe_status: event.zipe_status,
                zipe_color: event.zipe_color,
                zipe_talla: event.zipe_talla,
                zipe_id_pedido_cab: event.zipe_id_pedido_cab.zped_id_pedcab,
                zipe_cant: event.zipe_cant
            })
                .then(res => window.location.reload())
                .catch(err => window.location.reload())
            
        },
        cambiarTalla: function (event) {
            console.log(event)

            axios.put('http://127.0.0.1:8000/pedido/itemped/'+ event.zipe_id_item_ped+'/', {
                zipe_id_arti: event.zipe_id_arti.zaa_id_articulo,
                zipe_sub_tot: event.zipe_sub_tot,
                zipe_status: event.zipe_status,
                zipe_color: event.zipe_color,
                zipe_talla: event.zipe_talla,
                zipe_id_pedido_cab: event.zipe_id_pedido_cab.zped_id_pedcab,
                zipe_cant: event.zipe_cant
            })
                .then(res => window.location.reload())
                .catch(err => window.location.reload())
            
        },
        nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
        },
        formerPage () {
            if (this.page - 1 >= 1) this.page -= 1
        },
        updateItemsPerPage (number) {
            this.itemsPerPage = number
        },
        getPedidos(id){

            axios.get('http://127.0.0.1:8000/pedido/pcespbyu/?search='+id)
            .then(res=> {this.pedEspera = res.data})
        },
        finalizar(){
            axios.put('http://127.0.0.1:8000/pedido/pedcab/'+this.pedidoActivo.zped_id_pedcab+'/',{
                zped_status: 'Espera',
                zped_fecha: new Date().toISOString().slice(0,10),
                zipe_total: this.total,
                zped_id_usuario: this.pedidoActivo.zped_id_usuario,
                zped_nombre: 'PED-'+ this.name +'-'+ new Date().toISOString().slice(5,10),
            })
            .then(res=> window.location.reload())


        },
        comprobarToken(){
            if(localStorage.token){
                axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                .then((res) => {
                    this.idUser = res.data.user
                    this.getPedidos(res.data.user)  
                    this.pedidoActivo = res.data[0]
                })
                .catch(error=> { localStorage.token = '', this.$router.replace({name: 'Home'})})
            }else{
                localStorage.token = ''
                this.$router.replace({name: 'Home'})
            }
        },
        sumField(n){
            let sum = 0;
            for(let i = 0; i < this.lengthItems; i++){
                sum += n[i].zipe_sub_tot
            }
            this.total = sum
        }
        
    }
}
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>