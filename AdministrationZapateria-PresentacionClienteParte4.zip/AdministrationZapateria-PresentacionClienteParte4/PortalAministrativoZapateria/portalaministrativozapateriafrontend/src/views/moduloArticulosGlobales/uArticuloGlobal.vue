Autor: Luis Angel Larios Castillo
Descripción: Este archivo funciona como formulario para registrar un articulo 
<template>
    <v-container fluid>  
       <div v-if="permissions.can_manage_arti_global == true">
           <app-header style="z-index: 135"/> 
      <v-col cols="md-9 xs-12">   
            <br>
        <v-card> 
        <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          <h2 style="color:#fff;">ACTUALIZAR ARTICULO GLOBAL</h2>
          

        </v-toolbar> 
        <v-container style="background-color:#f5f5f5;"> 
           <v-form ref="form" v-model="valid" lazy-validation > 
            <v-row>
                <v-col cols="6">
                 <v-text-field v-model="elementU.zaag_nombre_arti" filled :rules="nombreRules" v-on:change="generarClave(elementU.zaag_nombre_arti)" label="Nombre del articulo"  required :counter="100" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Zapatillas" maxlength="100"></v-text-field>
                </v-col>
                <v-col cols="6">
                  <v-text-field v-model="elementU.zaag_clave" filled readonly :rules="claveRules" label="Clave" required></v-text-field>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="12">
                  <v-text-field v-model="elementU.zaag_codigo_bar" filled  :rules="cBarrasRules" label="Código de barras" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="45" placeholder="Ejem. 8414237000157" :counter="45" required/>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="4">
                  <v-text-field v-model="elementU.zaag_modelo" filled :rules="modeloRules" label="Modelo"  maxlength="20" placeholder="Ejem. VN0AU3BXL4" :counter="20" required/>
                </v-col>
                <v-col cols="4">
                 
                  <v-select v-model="elementU.zaag_categoria" :items="categories" filled :rules="[v => !!v || 'Debe seleccionar una categoría']"  label="Categoría" required/>
                </v-col>
                <v-col cols="4">
                   <v-select v-model="elementU.zaag_marca" filled :items="busqmarcas" :rules="[v => !!v || 'Debe seleccionar una marca']"  label="Marcas"  required/>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="6">
                  <v-select v-model="elementU.zaag_id_catalogo" filled :items="busqcatalogos" item-text="zca_nombre_ca" item-value="zca_id_catalogo" :rules="[v => !!v || 'Debe seleccionar un catalogo']"  label="Catalogo" required/>
                </v-col>
                <v-col cols="6">
                  <v-select v-model="elementU.zaag_id_subdep" filled :items="busqsubdpto" item-text="zsude_etiqueta" item-value="zsude_id_subdep" :rules="[v => !!v || 'Debe seleccionar un SubDepartamento']"  label="SubDepartamento" required/>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zaag_prec_cont" prefix="$" filled  label="Precio de contado"  required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zaag_prec_pag" prefix="$" filled  label="Precio en pagos "  required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zaag_prect_mayo" prefix="$" filled label="Precio de mayoreo"   required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="elementU.zaag_prect_menud" prefix="$" filled  label="Precio menudeo "   required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
            </v-row>

            <v-row>
              <v-col>
                <v-text-field label="Porcentaje de oferta" v-model="elementU.zaag_oferta" filled outlined type="text" maxlength="5" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');"  required v-show="false" readonly></v-text-field>
              </v-col>
              <v-col>
                <v-switch v-model="switchOfertas" v-if="elementU.zaag_oferta >= 1 && switchOfertas == false" inset color="blue" label="Editar Oferta" style="margin-left:30px" @click.stop="dialog = true"></v-switch>
                <v-switch v-model="switchOfertas" v-else-if="elementU.zaag_oferta <= 0 && switchOfertas == false" inset color="blue" label="Asignar Oferta" style="margin-left:30px" @click.stop="dialog = true"></v-switch>
                <v-switch v-model="switchOfertas" v-else inset color="blue" label="Asignar Oferta" style="margin-left:30px" readonly></v-switch>
              </v-col>
              <v-col></v-col>
            </v-row>
            <v-dialog v-model="dialog" width="300">
              <v-card>
                <v-card-title></v-card-title>
                <v-card-text>
                  <v-form ref="form" v-model="valid" lazy-validation>
                    <v-text-field label="Porcentaje de oferta ( % )" v-model="elementU.zaag_oferta" outlined type="text" maxlength="4" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');"  required></v-text-field>
                  </v-form>
                  <v-btn :disabled="!valid" text color="primary" @click="dialog = false" v-on:click="validate">
                    Aplicar
                  </v-btn>
                </v-card-text>
              </v-card>
            </v-dialog>
              <div class="hr-sect">Acciones</div>
            
           <br>
           
            <v-row align="center" justify="space-around">
                <v-col cols="6" >
               <v-btn  id="btn_borrar_formulario" class="col-12"  to="/articulosglobales/" >
                    CANCELAR
                  </v-btn> 
                 </v-col>
                 <v-col cols="6" >
               <v-btn :disabled="!valid" class="col-12" @click="validate" id="btn_actualizar_formulario">
                    Actualizar
                    <v-icon right dark>
                        mdi-update
                    </v-icon>
                  </v-btn>
                 </v-col>
                
            </v-row>
            </v-form>
             <br>
        </v-container>  
      </v-card> 
      </v-col>
      </div>
     <div v-else>
        <ErrorPage403/>
     </div>
      
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const axios = require('axios')
  export default {
       name: 'Header', 
    components:{
      "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.find()
      this.findsubdpto()
      this.findcatalogos()
      this.findmarcas()
    },
    data () {
      return {
        dialog: false, 
        switchOfertas: false,
         permissions: {
            can_manage_arti_global: false,
        },
        elementU:[],
        valid: true,
        busqsubdpto:[],
        busqcatalogos:[],
        busqmarcas:[],
        categories:['Accesorios', 'Botas', 'Gorras', 'Chamarras', 'Zapatos', 'Playeras', 'Tenis'],
        nombreRules: [
        v => !!v || 'El nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 100) || 'El nombre no debe tener más de 100 caracteres',
      ],
        claveRules: [
          v => !!v || 'La clave es obligatoria',
          v => (v && v.length >= 4) || 'La clave debe tener más de 3 caracteres',
          v => (v && v.length <= 45) || 'La clave no debe tener más de 45 caracteres',
        ],
        cBarrasRules: [
        v => !!v || ' El código de barras es obligatorio ',
        v => (v && v.length >= 5) || 'El código de barras debe tener 5 o más caracteres',
        v => (v && v.length <= 45) || 'El código de barras no debe tener más de 45 caracteres',
      ],
        modeloRules: [
        v => !!v || 'El modelo es obligatorio ',
        v => (v && v.length > 2) || 'El modelo debe tener más de 2 caracteres',
        v => (v && v.length <= 20) || 'El modelo no debe tener más de 20 caracteres',
      ],
      }
    },
    
    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_arti_global: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos_globales') { this.permissions.can_manage_arti_global = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      findmarcas(){ 
        axios.get('http://127.0.0.1:8000/proveedor/proveedores/activos/')
        .then(res => {
          res.data.forEach(element => {
            this.busqmarcas.push(element.zp_identify_mark)  
              
          });
        }) 
      },
      findsubdpto(){
        axios.get('http://127.0.0.1:8000/departamentos/subdep/')
          .then(res => this.busqsubdpto = res.data)
      },
      findcatalogos(){
        axios.get('http://127.0.0.1:8000/catalogo/catalogos/activos/')
        .then(res => this.busqcatalogos = res.data)
      },
      find(){ 

        axios.get('http://127.0.0.1:8000/articuloglobal/'+ this.$route.params.id +'/').
            then(res => {
              this.elementU = res.data
             
            })
               
        },
        generarClave: function (event) { 
        let nume = ''
        for (let i = 0; i <= 8; i++) {
          nume = nume + Math.floor(Math.random() * (10 - 1)) 
        }
        this.elementU.zaag_clave = event.slice(0,3).toUpperCase() + '-' + nume
      },
      validate () {
        if(this.$refs.form.validate()){
          this.update()
        }
      },
      update(){ 

        axios.put('http://127.0.0.1:8000/articuloglobal/'+ this.$route.params.id +'/',this.elementU)
          .then(res => this.$router.push({ name: 'ArticulosGlobales' }) )
          .catch(error => console.log(error)); 
      },
          
    },
  }
</script>
