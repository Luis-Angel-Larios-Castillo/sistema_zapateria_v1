Autor: Luis Angel Larios Castillo
Descripción: Este archivo funciona como formulario para registrar un articulo 
<template>
    <v-container fluid>  
     <div v-if="permissions.can_manage_arti_global == true">
        <app-header style="z-index: 135"/> 
      <v-col cols="md-8 xs-12">   
            <br>
        <v-card> 
        <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          <h2 style="color:#fff;">REGISTRO DE ARTICULOS GLOBALES</h2>
          <v-spacer/>
          <v-btn to="/articulosglobales/"  outlined class="btn_add" color="#F7F9F9">
            Cancelar 
          </v-btn>
        </v-toolbar> 
        <v-container style="background-color:#f5f5f5;"> 
           <v-form ref="form" v-model="valid" lazy-validation > 
            <v-row>
                <v-col cols="6">
                 <v-text-field v-model="nombre" filled :rules="nombreRules" v-on:change="generarClave(nombre)" label="Nombre del articulo"  required :counter="100" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. Zapatillas" maxlength="100"></v-text-field>
                </v-col>
                <v-col cols="6">
                  <v-text-field v-model="clave" filled readonly :rules="claveRules" label="Clave" required></v-text-field>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="12">
                  <v-text-field v-model="cod_bar" filled  :rules="cBarrasRules" label="Código de barras" oninput="this.value=this.value.replace(/[^0-9]/g,'');" maxlength="45" placeholder="Ejem. 8414237000157" :counter="45" required/>
                </v-col>
            </v-row>
            <v-row>
                <v-col cols="4">
                  <v-text-field v-model="modelo" filled :rules="modeloRules" label="Modelo"  maxlength="20" placeholder="Ejem. VN0AU3BXL4" :counter="20" required/>
                </v-col>
                <v-col cols="4">
                 
                  <v-select v-model="categoria" :items="categories" filled :rules="[v => !!v || 'Debe seleccionar una categoría']"  label="Categoría" required/>
                </v-col>
                <v-col cols="4">
                   <v-select v-model="marca" filled :items="busqmarcas" :rules="[v => !!v || 'Debe seleccionar una marca']"  label="Marcas"  required/>
                </v-col>
            </v-row>
            <v-row>
                <v-col class="col-4 xs-col-9">
                  <v-select v-model="catalogo" filled :items="busqcatalogos" item-text="zca_nombre_ca" item-value="zca_id_catalogo" :rules="[v => !!v || 'Debe seleccionar un catalogo']"  label="Catalogo" required/>
                </v-col>
                <v-col class="col-2 xs-col-3" >
                      <v-btn color="blue"  class="mt-3" icon outlined to="/ccatalogo/"><v-icon>mdi mdi-plus</v-icon></v-btn>
                  </v-col>
                <v-col class="col-4 xs-col-9">
                  <v-select v-model="sub_dep" filled :items="subdepar" item-text="zsude_etiqueta" item-value="zsude_id_subdep" :rules="[v => !!v || 'Debe seleccionar un SubDepartamento']"  label="SubDepartamento" required/>
                </v-col>
                <v-col class="col-2 xs-col-3">
                      <v-btn color="blue" class="mt-3"  icon outlined to="/csubdepartamento/"><v-icon>mdi mdi-plus</v-icon></v-btn>
                    </v-col>
            </v-row>
            <v-row>
                <v-col cols="3">
                  <v-text-field v-model="pre_cont" prefix="$" filled  label="Precio de contado"  required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="pre_pag" prefix="$" filled  label="Precio en pagos "  required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="pre_mayo" prefix="$" filled label="Precio de mayoreo"   required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="pre_menu" prefix="$" filled  label="Precio menudeo "   required maxlength="6" oninput="this.value=this.value.replace(/[^0-9]/g,'');" :rules="[v => !!v || 'Este campo es obligatorio']" :counter="6"/>
                </v-col>
            </v-row>
            <v-row>
              <v-col>
                <v-text-field label="Porcentaje de oferta" v-model="oferta" outlined type="text" maxlength="5" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');"  required v-show="false" readonly></v-text-field>
              </v-col>
              <v-col>
                <v-switch v-model="switchOfertas" v-if="switchOfertas == false" inset color="red" label="Asignar Oferta" style="margin-left:30px" @click.stop="dialog = true"></v-switch>
                <v-switch v-model="switchOfertas" v-else inset color="blue" label="Asignar Oferta" style="margin-left:30px" readonly></v-switch>
              </v-col>
              <v-col></v-col>
            </v-row>
            <v-dialog v-model="dialog" width="300">
              <v-card>
                <v-card-title></v-card-title>
                <v-card-text>
                  <v-form ref="form" v-model="valid" lazy-validation>
                    <v-text-field label="Porcentaje de oferta ( % )" v-model="oferta" outlined type="text" maxlength="4" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');"  required></v-text-field>
                  </v-form>
                  <v-btn :disabled="!valid" text color="primary" @click="dialog = false">
                    Aplicar
                  </v-btn>
                </v-card-text>
              </v-card>
            </v-dialog>
           
               <div class="hr-sect">Acciones</div>
            
           <br>
           
            <v-row align="center" justify="space-around">
                <v-col cols="6" >
                <v-btn  id="btn_agrega_otro_formulario" class="col-12" @click="validate" :disabled="!valid" >
                    Guardar y agregar otro 
                    <v-icon right dark>
                        mdi-reload
                    </v-icon>
                </v-btn>
                 </v-col>
                 <v-col cols="6" >
                <v-btn  id="btn_guardar_formulario" class="col-12" @click="validate02" :disabled="!valid" >
                    Guardar 
                    <v-icon right dark>
                        mdi-cloud-upload
                    </v-icon>
                </v-btn>
                 </v-col>
                
            </v-row>
            </v-form>
             <br>
        </v-container>  
      </v-card> 
      </v-col>
     </div>
     <div v-else>
        <ErrorPage403/>
     </div>
    </v-container>
</template>
<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
    "app-header": Header,
    ErrorPage403
  }, 
    created() {
     this.findpermsisos()
     this.findsubdpto()
     this.findcatalogos()
     this.findmarcas()
    },
    data () {
      return {
        dialog: false, 
        switchOfertas: false,
        nombre:'',
        clave:'',
        cod_bar:'',
        modelo:'',
        oferta:0,
        categoria:'',
        marca:'',
        catalogo:'',
        sub_dep:'',
        pre_cont:'',
        pre_pag:'',
        pre_mayo:'',
        pre_menu:'',
       
        element:[],
        valid: true,
        busqsubdpto:[],
        busqcatalogos:[],
        busqmarcas:[],
        categories:['Accesorios', 'Botas', 'Gorras', 'Chamarras', 'Zapatos', 'Playeras', 'Tenis'],
        nombreRules: [
        v => !!v || 'El nombre es obligatorio',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
        v => (v && v.length <= 100) || 'El nombre no debe tener más de 100 caracteres',
      ],
        claveRules: [
          v => !!v || 'La clave es obligatoria',
          v => (v && v.length >= 4) || 'La clave debe tener más de 3 caracteres',
          v => (v && v.length <= 45) || 'La clave no debe tener más de 45 caracteres',
        ],
        cBarrasRules: [
        v => !!v || ' El código de barras es obligatorio ',
        v => (v && v.length >= 5) || 'El código de barras debe tener 5 o más caracteres',
        v => (v && v.length <= 45) || 'El código de barras no debe tener más de 45 caracteres',
      ],
        modeloRules: [
        v => !!v || 'El modelo es obligatorio ',
        v => (v && v.length > 2) || 'El modelo debe tener más de 2 caracteres',
        v => (v && v.length <= 20) || 'El modelo no debe tener más de 20 caracteres',
      ],
      permissions: {
            can_manage_arti_global: false,
        },
        subdepar:[]
      }
    },
    
    methods: {

      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_arti_global: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos_globales') { this.permissions.can_manage_arti_global = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },



      findmarcas(){ 
        axios.get('http://127.0.0.1:8000/proveedor/proveedores/activos/')
        .then(res => {
          res.data.forEach(element => {
            this.busqmarcas.push(element.zp_identify_mark)  
              
          });
        }) 
      },
      findsubdpto(){
         this.subdepar = []
        axios.get('http://127.0.0.1:8000/departamentos/subdep/')
          .then(res => {this.busqsubdpto = res.data
          
            res.data.forEach(element => { 
                            if(element.zsude_is_deleted ==  false){
                                this.subdepar.push(element)
                            }
                        }); 
          
          
          })
      },
      findcatalogos(){
        axios.get('http://127.0.0.1:8000/catalogo/catalogos/activos/')
        .then(res => this.busqcatalogos = res.data)
      },
      generarClave: function (event) { 
        let nume = ''
        for (let i = 0; i <= 8; i++) {
          nume = nume + Math.floor(Math.random() * (10 - 1)) 
        }
        this.clave = this.nombre.slice(0,3).toUpperCase() + '-' + nume
      }, 
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            "zaag_nombre_arti":this.nombre,
            "zaag_clave":this.clave,
            "zaag_codigo_bar":this.cod_bar,
            "zaag_modelo":this.modelo,
            "zaag_categoria":this.categoria,
            "zaag_marca":this.marca,
            "zaag_prec_cont":this.pre_cont ,
            "zaag_prec_pag":this.pre_pag ,
            "zaag_prect_mayo":this.pre_mayo ,
            "zaag_prect_menud":this.pre_menu ,
            "zaag_id_catalogo":this.catalogo ,
            "zaag_id_subdep":this.sub_dep,
            "zaag_oferta":this.oferta,
          }
        this.createAndNew() 
        }        
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            "zaag_nombre_arti":this.nombre,
            "zaag_clave":this.clave,
            "zaag_codigo_bar":this.cod_bar,
            "zaag_modelo":this.modelo,
            "zaag_categoria":this.categoria,
            "zaag_marca":this.marca,
            "zaag_prec_cont":this.pre_cont ,
            "zaag_prec_pag":this.pre_pag ,
            "zaag_prect_mayo":this.pre_mayo ,
            "zaag_prect_menud":this.pre_menu ,
            "zaag_id_catalogo":this.catalogo ,
            "zaag_id_subdep":this.sub_dep,
            "zaag_oferta":this.oferta,
          }
        this.create() 
        }        
      },
      create(){
       
        axios.post('http://127.0.0.1:8000/articuloglobal/', this.element,)
          .then(res => {
            this.$router.go(-1); 
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      createAndNew(){
         axios.post('http://127.0.0.1:8000/articuloglobal/', this.element)
          .then(res => {window.location.reload()})
          .catch(error => console.log(error));
      }
      
    },
  }
</script>
