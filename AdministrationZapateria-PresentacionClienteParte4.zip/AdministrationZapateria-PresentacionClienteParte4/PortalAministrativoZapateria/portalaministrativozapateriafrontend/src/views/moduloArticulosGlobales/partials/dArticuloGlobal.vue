Autor: Luis Angel Larios Castillo
Descripción: Este archivo como Dialog (modal) que tiene la función de confirmar si se quiere eliminar un articulo globales
<template>
  <v-row justify="center">
    <v-tooltip bottom>
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          icon
          color="#5B5B5B"
          @click="dialog = true"
          v-bind="attrs"
          v-on="on"
          :disabled="elementD.permissions.can_manage_arti_global == false"
        >
          <v-icon color="red">mdi-delete</v-icon>
        </v-btn>
      </template>
      <span>Eliminar</span>
    </v-tooltip>

    <v-dialog v-model="dialog" max-width="300">
      <v-card>
        <v-card-title class="red--text">
          Se va a eliminar el articulo: {{ elementD.item.zaag_nombre_arti }}
        </v-card-title>

        <v-card-text> ¿Está seguro que quiere eliminarlo? </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn color="green darken-1" text @click="dialog = false">
            Cancelar
          </v-btn>

          <v-btn color="green darken-1" text @click="aceptar()">
            Aceptar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script>
const axios = require("axios");
export default {
  props: ["elementD"],
  data() {
    return {
      dialog: false,
    };
  },
  methods: {
    aceptar() {
      let URL =
        "http://127.0.0.1:8000/articuloglobal/" +
        this.elementD.item.zaag_id_articulo_global;
      axios.delete(URL).then((response) => {
        this.dialog = false;
        window.location.reload();
      });
    },
  },
};
</script>