Autor: Luis Angel Larios Castillo
Descripción: Este archivo funciona como Dialog (modal) que muestra toda la información de un articulo global 
<template>
  <v-container grid-list-xs>
    <v-dialog max-width="400">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{ element.zaag_nombre_arti }}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline"> </v-card-title>
        <v-card-text>
          <v-alert color="#2A3B4D" dark dense>
            DETALLES DE ARTICULO GLOBAL
          </v-alert>

          <v-alert color="#f5f5f5" dense>
            <h2>{{ element.zaag_nombre_arti }}</h2>
          </v-alert>
          <div class="black--text">
          <strong>Código de barras: </strong> <br />
          {{ element.zaag_codigo_bar }}
          <br />
          <strong>Clave: </strong> <br />{{ element.zaag_clave }}
          </div>
          <v-alert color="#f5f5f5" dense>
            <h3>DETALLES GENERALES</h3>
          </v-alert>
          <div class="black--text">
                <strong>Subdepartamento</strong> <br />
               {{busqsubdpto.zsude_etiqueta}}
          <br>
                <strong>Catalogo</strong> <br />
                {{busqcatalogos.zca_nombre_ca}}
          </div> 
             <br>
          <v-simple-table dense>
            <tr>
              <td class="text-center"></td>
            </tr>
            <tr>
              <td class="text-center">
                <strong>Modelo :</strong> <br />
                {{ element.zaag_modelo }}
              </td>
              <td class="text-center">
                <strong>Marca :</strong> <br />
                {{ element.zaag_marca }}
              </td>
              <td class="text-center">
                <strong>Categoria :</strong> <br />{{ element.zaag_categoria }}
              </td>
            </tr>
            
          </v-simple-table>
          <br>
          <v-alert color="#f5f5f5" dense>
            <h3>PRECIOS</h3>
          </v-alert>

          <v-simple-table dense>
            <tr>
              <td class="text-center"><strong>Contado :</strong></td>
              <td class="text-center"><strong>Pagos :</strong></td>
              <td class="text-center"><strong>Mayoreo :</strong></td>
              <td class="text-center"><strong>Menudeo :</strong></td>
            </tr>
            <tr>
              <td class="text-center">$ {{ element.zaag_prec_cont }}</td>
              <td class="text-center">$ {{ element.zaag_prec_pag }}</td>
              <td class="text-center">$ {{ element.zaag_prect_mayo }}</td>
              <td class="text-center">$ {{ element.zaag_prect_menud }}</td>
            </tr>
          </v-simple-table>

          <br />
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>
<script>
const axios = require("axios");
export default {
  props: ["element"],
  data() {
    return {
        busqsubdpto:[],
        busqcatalogos:[]
    };
  },
  created() {
       this.findsubdpto()
       this.findcatalogos()
  },
  methods: {
       findsubdpto(){
        axios.get('http://127.0.0.1:8000/departamentos/subdep/'+this.element.zaag_id_subdep+ '/')
          .then(res => this.busqsubdpto = res.data)
      },
      findcatalogos(){
        axios.get('http://127.0.0.1:8000/catalogo/'+this.element.zaag_id_catalogo+'/')
        .then(res => this.busqcatalogos = res.data)
      },
  },
};
</script>