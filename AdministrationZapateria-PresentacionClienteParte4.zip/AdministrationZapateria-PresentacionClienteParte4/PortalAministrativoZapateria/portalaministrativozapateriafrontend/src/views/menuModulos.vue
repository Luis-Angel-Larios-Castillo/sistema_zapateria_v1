Autor: Miguel Angel Zamora Carmona
Descripción: Componente que funciona como menú para la sesión de almacén (conjunto de acciones de registro, modificaciones y destrucción de datos, por parte de trabajadores o administrador)   
<template>
    <div id="menu_lateral">
        <v-list  dark id="menu_lateral">                
               <v-list-item :to="'/articulos/'"> 
                    Articulos
                </v-list-item>    
                <v-list-item :to="'/articulosglobales/'" align="left">
                    Art. Globales
                 </v-list-item>   
                <v-list-item :to="'/catalogos/'">
                    Catálogos
                </v-list-item>    
                <v-list-item :to="'/Clientes/'">
                    Clientes
                </v-list-item>   
                <v-list-item :to="'/clientesnoafi/'" align="left">
                    Clientes no Afiliado
                </v-list-item>     
                <v-list-item :to="'/dep/'">
                    Departamentos
                </v-list-item>
                <v-list-item :to="'/subdep/'">
                    SubDepartamentos
                </v-list-item>
                <v-list-item :to="'/Empleados/'">
                    Empleados
                </v-list-item>    
                <v-list-item :to="'/ListPedSucursal/'" align="left">  
                    Pedidos Sucursal 
                </v-list-item>
                <v-list-item :to="'/ListPedProveedor/'" v-if="IsAdmin == true" align="left">  
                    Pedidos Proveedor 
                </v-list-item>
                <v-list-item :to="'/ListPedCatSucursal/'" align="left">  
                    Ped. Catálogos Sucursal 
                </v-list-item>
                <v-list-item :to="'/ListPedCatalogoPro/'" v-if="IsAdmin == true" align="left">  
                    Ped. Catálogos Proveedor 
                </v-list-item>
                <!--<v-list-item :to="'/slider/'">
                    Galería
                </v-list-item>-->
                <v-list-item :to="'/inventario/'" align="left">
                    Inv. de Articulos
                </v-list-item>
                <v-list-item :to="'/InventarioCatalogos/'" align="left">
                    Inv. de Catálogos
                </v-list-item>
                <v-list-item :to="'/pedidos/'">
                    Pedidos
                </v-list-item>    
                <v-list-item :to="'/Proveedores/'">
                    Proveedores
                </v-list-item>    
                <v-list-item :to="'/sucursal/'">
                    Sucursales
                </v-list-item>
                <v-list-item :to="'/traspaso'">
                   Traspasos
                </v-list-item>
                <v-list-item  :to="'/vales/'">
                    Vales
                </v-list-item>
                <v-list-item :to="'/listUserPermissions/'" v-if="IsAdmin == true">  
                    Usuarios 
                </v-list-item>
                <v-list-item :to="'/ListGroups/'" v-if="IsAdmin == true"> 
                    Grupos 
                </v-list-item>   
        </v-list>
    </div>
</template>
<script>
const axios = require('axios')
import cArticulo from './moduloArticulos/partials/cArticulo'
import cCatalogo from './moduloCatalogos/partials/cCatalogo'
import cDep from './moduloDepartamentos/partials/cDepartamento'
import cSubDep from './moduloDepartamentos/partials/cSubDepartamento'
import cSlider from './moduloSlider/partials/cSlider'
export default {
    components:{
        cArticulo,
        cCatalogo,
        cDep,
        cSubDep,
        cSlider,
    },
    data() {
        return {
            IsAdmin: false
        }
    },
    created() {
        this.getUser()
    },
    methods: {
        getUser(){
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => { 
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/' + res.data[0].user + '/' ) 
                        .then(resUs => { 
                            this.IsAdmin = resUs.data.is_superuser })
                })
                .catch(error => console.log(error)); 
        }
    },
  }
</script>
