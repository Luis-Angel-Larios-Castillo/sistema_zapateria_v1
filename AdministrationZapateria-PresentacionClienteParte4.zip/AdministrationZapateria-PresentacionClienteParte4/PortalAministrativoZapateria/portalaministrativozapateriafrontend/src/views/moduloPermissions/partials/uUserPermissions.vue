Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo permite modificar los permisos de un usuario
<template>
    <v-container fluid> 
         <app-header style="z-index: 135"/> 
         <br>
         <div class="col-8">
        <v-card> 
            <v-toolbar dark id="table_cabecera_color_formulario">
                <h3>Usuario: {{dataUser.nombre}}</h3>
            </v-toolbar> 
             <v-container id="tabla_datos_dos"  class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation m>
                <v-text-field v-model="element.zdus_correo" label="Correo" readonly/>
                <v-select v-model="element.groups" item-text="name" item-value="id"  :items="groups" attach label="Grupo" multiple/>   
                <br> 
                <v-row align="center" justify="space-around">
                    <v-col>
                    <v-btn :disabled="!valid" class="col-8" @click="validate" id="btn_agrega_otro_formulario">
                        Actualizar
                        <v-icon right dark>
                            mdi-update
                        </v-icon>
                    </v-btn>
                    </v-col>
                    <v-col>
                    <v-btn class="col-8" @click="cancelar" id="btn_guardar_formulario">
                        Regresar
                    </v-btn> 
                    </v-col>
                </v-row>
            </v-form>
            <br> 
            </v-container>
        </v-card>
        </div>
    </v-container>
</template>
<script> 
import Header from '../../../components/Header';
const axios = require('axios')
  export default {  
      name: 'Header', 
       components:{
      "app-header": Header,
  },
    created() {
        this.find()
        this.getGroups()
        this.getData()
    },
    data () {
      return { 
        element: [], 
        valid: true,
        groups: [],
        dataUser: []
      }
    },
    methods:{
        update(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.put('http://127.0.0.1:8000/usuario/group-add/' + this.$route.params.id + '/', this.element, config) 
                .then(res => { this.$router.push({ name: 'ListUsuariosPermissions' }) })
                .catch(error => console.log(error)); 
        },
        validate () { 
            if(this.$refs.form.validate()){
                this.update()
            }
        },
        cancelar () {
            this.$router.push({ name: 'ListUsuariosPermissions' });
        },
        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/group-add/' +  this.$route.params.id + '/', config )
                .then(res => this.element = res.data)              
        },
        getData(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get( 'http://127.0.0.1:8000/empleado/?search=' + this.$route.params.id, config )
                .then(res => this.dataUser = res.data[0])              
        },
        getGroups(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/group/', config)
                .then(res => this.groups = res.data)              
        },
    },
  }
</script>