Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra el nombre de usuario
<template>
    <div>
        {{dataUser.nombre}}
    </div>
</template>
<script> 
const axios = require('axios')
  export default { 
    props:[
        'element'
    ], 
    created() {
        this.find()
    },
    data () {
      return { 
          dataUser: []
      }
    },
    methods:{
        find(){ 
            axios.get( 'http://127.0.0.1:8000/empleado/?search=' + this.element.zdus_id_usuario )
                .then(res => this.dataUser = res.data[0])              
        },
        
    },
  }
</script>