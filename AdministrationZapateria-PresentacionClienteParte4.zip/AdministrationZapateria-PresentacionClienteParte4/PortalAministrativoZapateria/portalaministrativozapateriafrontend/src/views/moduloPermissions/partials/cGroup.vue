Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo  permite crear un group
<template>
    <v-container fluid> 
         <app-header style="z-index: 135"/> 
         <br>
         <div class="col-11">
            <v-toolbar dark id="table_cabecera_color_formulario">
                <h3>Agregar nuevo grupo</h3>
            </v-toolbar>
            <v-form ref="form" v-model="valid" lazy-validation m id="tabla_datos_dos"  class="col-12"> 
                <v-text-field v-model="nombre" :rules="nombreRules" label="Nombre" required/> 
                <v-card elevation="0" id="tabla_datos_dos">
                    <v-card-title primary-title>
                        Seleccionar permisos 
                        <v-spacer></v-spacer>
                        <v-text-field outlined rounded v-model="search" append-icon="mdi-magnify" label="Buscar" dense single-line hide-details/>
                    </v-card-title> 
                    <v-card-text>
                        <v-data-table  
                            id="tabla_datos_dos"
                            :headers="headers" 
                            :items="elements" 
                            :items-per-page="5"
                            :search="search"
                            no-results-text="No hay resultados."
                            no-data-text="No se tienen permisos registrados." 
                            :footer-props="{
                                showFirstLastPage: true,
                                itemsPerPageText: 'Elementos por página ',
                            }"
                            :header-props="{ sortByText: 'Ordenar por' }"
                        >
                            <template v-slot:item.id="{ item }">
                                <v-checkbox v-model="selected" :value="item.id"/>
                            </template>     
                        </v-data-table>
                    </v-card-text> 
                </v-card> 
                <br> 
                <v-row align="center" justify="space-around">
                    <v-col>
                    <v-btn :disabled="!valid" color="green" class="col-8" @click="validate" id="btn_agrega_otro_formulario">
                        Guardar
                        <v-icon right dark>
                            mdi-cloud-upload
                        </v-icon>
                    </v-btn>
                    </v-col>
                    <v-col>
                    <v-btn color="error" class="col-8" @click="cancelar" id="btn_guardar_formulario">
                        Regresar
                    </v-btn> 
                    </v-col>
                </v-row>
            </v-form>
            <br> 
         </div>
    </v-container>
</template>

<script> 
import Header from '../../../components/Header';
const axios = require('axios')
  export default { 
      name: 'Header', 
      components:{
      "app-header": Header,
  },
    created() {
        this.find()
        setTimeout(() => {
            this.alert = false
        }, 8000)
    },
    watch: {
        "selected" : function(){
        this.itemsDelete = this.selected.length
        }
    },
    data () {
      return {
        alert: true,
        alertText:'Si no se muestra ningún permiso o se muestran en inglés, regrese a la sección anterior y presione el botón de traducir.',
        element: Object,
        selected: [],
        search: '',
        headers: [
          {
            text: '',
            align: 'start',
            filterable: true,
            value: 'id', 
          }, 
          { text: 'Nombre', value: 'name' },  
        ],
        elements: [],
        elements: [],
        nombre: '',
        nombreRules: [
            v => !!v || 'El nombre es obligatorio',
            v => (v && v.length >= 4) || 'El nombre debe tener más de 3 caracteres',
            v => (v && v.length <= 40) || 'El nombre no debe tener más de 40 caracteres',
        ],
        valid: true
      }
    },
    methods:{
        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get( 'http://127.0.0.1:8000/usuario/permissions/', config)
                .then(res => this.elements = res.data)              
        },
        guardar(dataStorage){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.post('http://127.0.0.1:8000/usuario/group/', dataStorage, config) 
                .then( res => this.$router.push({ name: 'ListGroups' }) )
                .catch( error => console.log(error) )
        },
        validate () { 
            let dataStorage = {
                "name": this.nombre,
                "permissions": this.selected
            }
            if(this.$refs.form.validate()){ 
                this.guardar(dataStorage)
            }
        },
        cancelar () {
            this.$router.push({ name: 'ListGroups' });
        },
        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/usuario/permissions/', config )
                .then(res => this.elements = res.data)              
        },
        
    },
  }
</script>