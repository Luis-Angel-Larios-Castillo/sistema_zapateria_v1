Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los Usuarios
<template>
<div cols="full"> 
    <v-row> 
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col>  
        <v-col cols="md-10 xs-12" > 
             <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">USUARIOS</h1>
            </div>
            <v-card :elevation="0"> 
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    </div>
                </v-card-title>   
                <div class="col-12" style="padding-top:0">
                <v-data-table
                    id="tabla_datos" 
                    :headers="headers" 
                    :items="elements" 
                    :search="search"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen usuarios registrados." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.zdus_correo="{ item }">
                        <sUsuario :element="item"/>  
                    </template>  
                    <template v-slot:item.is_active="{ item }">
                        <v-tooltip bottom >
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon :to="'/uUserPermissions/'+ item.zdus_id_usuario+'/'" v-bind="attrs" v-on="on">
                                    <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                </v-btn>
                            </template>
                            <span>Editar</span>
                        </v-tooltip>
                        
                    </template> 
                </v-data-table>
                </div>
            </v-card>
        </v-col>
    </v-row>
    <br>    
</div> 
</template>
<script>
import Header from '../../components/Header';
import sUsuario from './partials/sUsuario.vue'  
import menuModulos from '../menuModulos'  
const axios = require('axios')
  export default {
      name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos, 
        sUsuario
    },    
    created() {
        this.find()
    },
    data () {
      return {
        element: Object,
        search: '',
        headers: [
          {
            text: 'Nombre',
            align: 'start',
            filterable: true,
            value: 'zdus_correo',

          }, 
          { text: 'ID', value: 'zdus_id_usuario' },  
          { text: 'Acciones', value: 'is_active', sortable: false },
        ],
        elements: [],
       
      }
    },
    methods:{
        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get( 'http://127.0.0.1:8000/usuario/user-permissions/', config)
                .then(res => this.elements = res.data)              
        },
        
    },
  }
</script>
