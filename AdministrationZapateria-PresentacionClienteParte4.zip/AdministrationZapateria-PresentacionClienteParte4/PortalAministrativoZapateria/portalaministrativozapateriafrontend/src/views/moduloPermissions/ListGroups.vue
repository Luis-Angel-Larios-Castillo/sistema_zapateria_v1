Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los Groups
<template>
<div cols="full"> 
    <v-row> 
        <v-col cols="md-2 xs-12" >
            <menuModulos/>
        </v-col>  
        <v-col cols="md-10 xs-12" > 
            <app-header style="z-index: 135"/>     
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">GRUPOS</h1>
            </div><br>
            <v-card :elevation="0">
                <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                        <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on, attrs }">
                                <!--
                                <v-btn dark text @click="traducir()" class="btn_add" v-bind="attrs" v-on="on">
                                    Traducir
                                </v-btn>
                                -->
                            </template>
                            <span>Usar en caso de que los permisos aparezcan en inglés o no aparezcan.</span>
                        </v-tooltip>
                        <v-btn dark text :to="'/cGroup/'" class="btn_add">
                            Agregar
                        </v-btn>
                    </div>
                </v-card-title>  
                <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                    :headers="headers" 
                    :items="elements" 
                    :search="search"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen usuarios registrados." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.name="{ item }">
                        {{item.name}}
                    </template>   
                    <template v-slot:item.permissions="{ item }">
                        <v-row align="center">
                            <v-col>
                                <dGroup  :elementD="item"/> 
                            </v-col>
                            <v-col>
                                <v-tooltip bottom >
                                    <template v-slot:activator="{ on, attrs }"> 
                                        <v-btn icon :to="'/uGroup/'+ item.id +'/'" v-bind="attrs" v-on="on">
                                            <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                        </v-btn>
                                    </template>
                                    <span>Editar</span>
                                </v-tooltip>
                            </v-col>
                        </v-row>
                        
                    </template>   
                </v-data-table>
                </div>
            </v-card>
        </v-col>
    </v-row>
    <br>    
    <v-snackbar v-model="snackbar">
      {{ text }} 
      <template v-slot:action="{ attrs }">
        <v-btn
          color="pink"
          text
          v-bind="attrs"
          @click="snackbar = false"
        >
          Cerrar
        </v-btn>
      </template>
    </v-snackbar>
</div> 
</template>
<script>
import Header from '../../components/Header';
import dGroup from './partials/dGroup.vue'  
import menuModulos from '../menuModulos'  
const axios = require('axios')
  export default {
      name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,  
        dGroup
    },    
    created() {
        this.find()
    },
    data () {
      return {
        element: Object,
        search: '',
        headers: [
          {
            text: '#',
            align: 'start',
            filterable: true,
            value: 'id',

          }, 
          { text: 'Nombre', value: 'name' },  
          { text: 'Acciones', value: 'permissions', sortable: false },
        ],
        elements: [],
        snackbar: false,
        text: 'Se han traducido los permisos existentes.',
      }
    },
    methods:{
        traducir(){
            axios.get('http://127.0.0.1:8000/usuario/permissions/traducir/')
                .then(res => { 
                    this.snackbar = true
                    })
        },
        find(){ 
            let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get( 'http://127.0.0.1:8000/usuario/group/', config)
                .then(res => this.elements = res.data)              
        },
        
    },
  }
</script>