Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los pedidos de las sucursales 
<template>
<div cols="full"> 
    <v-row> 
        <v-col cols="md-2 xs-12">
            <menuModulos/>
        </v-col>  
        <v-col cols="md-10 xs-12">  
             <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">PEDIDOS PROVEEDOR</h1>
                    
            </div><br> 
            <v-tabs v-model="tab" centered icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1">Pedidos de sucursales</v-tab> 
                <v-tab href="#tab-2">Pedidos realizados</v-tab> 
                
            </v-tabs>
            
            <v-tabs-items v-model="tab">
                <v-tab-item value="tab-1">
                    <v-card :elevation="0">
                        <v-card-title class="card_title">
                            <div class="col-12" id="table_cabecera_color">
                                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                <v-btn @click="generarPedido()" :disabled="canCReporte == false" text class="btn_gped white--text">Generar pedido</v-btn>
                                
                                <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                            </div> 
                            <div class="col-12" style="background-color:#14213d;" > 
                                <Barrido/> 
                            </div>  
                        </v-card-title>  
                        <div class="col-12" style="padding-top:0">
                            <v-data-table
                                id="tabla_datos"
                                :headers="headers" 
                                :items="pedi" 
                                :search="search"
                                :items-per-page="5"
                                :items-per-page-options="[5, 10, 15]"
                                no-results-text="No hay resultados."
                                no-data-text="No se tienen pedidos registrados." 
                                :footer-props="{
                                    showFirstLastPage: true,
                                    itemsPerPageText: 'Elementos por página ',
                                }"
                                :header-props="{ sortByText: 'Ordenar por' }"
                            >
                                <template v-slot:item.zpedsuc_nombre="{ item }" >  
                                    <strong>{{item.zpedsuc_nombre}}</strong>  
                                </template>      
                                <template v-slot:item.zpedpro_proveedor_nombre="{ item }" >  
                                    <strong>{{item.zpedpro_proveedor_nombre}}</strong>  
                                </template> 
                                <template v-slot:item.zpedsuc_id_ped_sucur="{ item }" >   
                                    <ItemsPed :items="item.items" :pedID="item.zpedsuc_id_ped_sucur"/>
                                </template>  
                            </v-data-table>
                        </div>
                    </v-card> 
                </v-tab-item>
                <v-tab-item value="tab-2">   
                    <PedidosRealizados/>
                </v-tab-item>
            </v-tabs-items> 
        </v-col>
    </v-row> 
    <v-overlay :value="overlay">
        <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
    </v-overlay>  
    <br>   
</div> 
</template>
<script> 
import Header from '../../components/Header';
import menuModulos from '../menuModulos'   
import Barrido from './partials/_Barrido.vue'
import ItemsPed from './partials/_ItemsPed.vue'
import PedidosRealizados from './partials/_PedidosRealizados.vue'
const moment = require('moment') 
const axios = require('axios')
  export default {
      name: 'Header', 
    components:{ 
        "app-header": Header,
        menuModulos, 
        ItemsPed,
        Barrido,
        PedidosRealizados
    },     
    data() {
        return { 
            overlay: false,
            canCReporte: true,
            IdEmpleado: '',
            status: 'Pedido centro de distribución',
            statusItems: [
                'Pedido centro de distribución', 
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor',
                'Regreso chofer a centro de distribución',
                'En tránsito sucursal',
                'Llego sucursal',
                'Activo'
            ],
            tab: null,
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedsuc_nombre', 
            }, 
            { text: 'Sucursal', value: 'zpedsuc_sucursal'}, 
            { text: 'Proveedor', value: 'zpedpro_proveedor_nombre'}, 
            { text: 'Estatus', value: 'zpedsuc_status_ped'}, 
            { text: 'Acciones', value: 'zpedsuc_id_ped_sucur', sortable: false },
            ],
            pedi: [],
            reportes: [],
        }
    },
    created() { 
        this.find()
    },
    methods: {
        sumarItems(ITEMS){ 
            let pedidoSinDuplicados = ITEMS.reduce((acumulado, itemActual) => { 
            let ItemSimilar = acumulado.find(elemento => elemento.zpedproit_color === itemActual.zpedproit_color && elemento.zpedproit_talla === itemActual.zpedproit_talla );
            if (ItemSimilar) {
                return acumulado.map((elemento) => {
                    if (elemento.zpedproit_id_art === itemActual.zpedproit_id_art && elemento.zpedproit_color === itemActual.zpedproit_color && elemento.zpedproit_talla === itemActual.zpedproit_talla ) {
                        return {
                            ...elemento,
                            zpedproit_cant_ped: elemento.zpedproit_cant_ped + itemActual.zpedproit_cant_ped
                        }
                    } 
                    return elemento;
                });
                } 
                return [...acumulado, itemActual];
            }, []); 
            return pedidoSinDuplicados 
        }, 
        async generarPedido(){
            this.overlay = true    
            axios.get('http://127.0.0.1:8000/proveedor/proveedor/')
                .then(resP => {
                    resP.data.forEach(prov => {
                        this.reportes.push({
                            idProveedor: prov.zp_id_proveedor,
                            nombre: prov.zp_identify_mark,
                            items: []
                        });
                    }); 
                    axios.get('http://127.0.0.1:8000/pedsuc/item/')
                    .then(resItem =>{
                        this.reportes.forEach(rep => { 
                            resItem.data.forEach(item => {
                                if(item.zpedsuca_status == 'Pedido centro de distribución'){
                                    if(item.zpedsuca_marca == rep.nombre){
                                        rep.items.push({
                                            "zpedproit_id_ped_provee": '',
                                            "zpedproit_id_art": item.zpedsuca_id_art,
                                            "zpedproit_color": item.zpedsuca_color,
                                            "zpedproit_talla": item.zpedsuca_talla,
                                            "zpedproit_cant_ped": item.zpedsuca_cant_ped,
                                            "zpedproit_cant_ped_llego": 0,
                                            "zpedproit_notas": []
                                        })
                                    }
                                }
                            }); 
                        });  
                        function callbackFin () { 
                            console.log('Fin'); 
                            setTimeout(function(){
                                console.log('Recargar')  
                                window.location.reload()
                            }, 3000);
                        } 
                        let pedidosSuc = 0
                        function callbackPedidoSucursal (IdEmpleado) { 
                            setTimeout(function(){
                                console.log('Funcion para cambiar el estatus de los pedido de sucursal')  
                                axios.get('http://127.0.0.1:8000/pedsuc/cab/')
                                .then(resPedSuc => {   
                                    resPedSuc.data.forEach(pedido => {
                                        if(pedido.zpedsuc_status_ped == 'Pedido centro de distribución'){ 
                                            pedido.zpedsuc_id_emple_mod = IdEmpleado,
                                            pedido.zpedsuc_status_ped = 'Pedido a Proveedor' 
                                            console.log('Pedido Sucursal')
                                            axios.put('http://127.0.0.1:8000/pedsuc/cab/' + pedido.zpedsuc_id_ped_sucur + '/', pedido)
                                        }  
                                        pedidosSuc++;
                                        if(pedidosSuc === resPedSuc.data.length) {
                                            callbackFin();
                                        }
                                    }); 
                                }) 
                            }, 3000); 
                        } 
                        let itemsPed = 0
                        function callbackItemPedido (IdEmpleado) { 
                            setTimeout(function(){
                                console.log('Funcion para cambiar el estatus de los items de pedido del cliente')  
                                axios.get('http://127.0.0.1:8000/pedido/itemped/')
                                .then(resItOri => {  

                                    resItOri.data.forEach(item => {
                                        if(item.zipe_status == 'Centro de distribución'){ 
                                            item.zipe_status = 'Pedido a Proveedor' 
                                            console.log('Item Original')
                                            axios.put('http://127.0.0.1:8000/pedido/itemped/' + item.zipe_id_item_ped + '/', item)
                                        }  
                                        itemsPed++;
                                        if(itemsPed === resItOri.data.length) {
                                            callbackPedidoSucursal(IdEmpleado);
                                        }
                                    }); 
                                }) 
                            }, 3000); 
                        } 
                        let pedNuevo = 0;
                        this.reportes.forEach(repPed => {  
                            if(repPed.items.length != 0){ 
                                console.log('Nuevo pedido a Proveedor') 
                                let cab = {
                                    zpedpro_nombre: repPed.nombre + '-' + moment().locale('MX').format('YYMMDDHHmmSS'),
                                    zpedpro_id_provee: repPed.idProveedor,
                                    zpedpro_id_emple: this.IdEmpleado, 
                                    zpedpro_status_ped: 'Pedido a Proveedor'
                                }  
                                console.log(cab)
                                axios.post('http://127.0.0.1:8000/pedprov/cab/', cab)
                                .then(resPedCab =>{ 
                                    console.log('Items para pedido proveedor')
                                    this.sumarItems(repPed.items).forEach(item => {
                                        item.zpedproit_id_ped_provee = resPedCab.data.zpedpro_id_ped_provee
                                        console.log('Item Nuevo') 
                                        axios.post('http://127.0.0.1:8000/pedprov/item/', item)
                                    });
                                })
                                
                            }
                            pedNuevo++;
                            if(pedNuevo === this.reportes.length) {
                                callbackItemPedido(this.IdEmpleado);
                            }
                        }); 
                    });                     
                })   
        },   
        find(){ 
            this.pedi = []
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            axios.get('http://127.0.0.1:8000/pedsuc/cab/')
                .then(resCabSuc => {
                    let CabSuc = []
                    resCabSuc.data.forEach(pedCab => {
                        if(pedCab.zpedsuc_status_ped == 'Pedido centro de distribución'){
                            CabSuc.push(pedCab)
                        }
                    });
                    if(CabSuc.length == 0){
                        this.canCReporte = false
                    }  

                })
            axios.get('http://127.0.0.1:8000/pedsuc/cab/')
                .then(res => {
                    res.data.forEach(element => { 
                        if(element.zpedsuc_status_ped ==  this.status){
                            axios.get('http://127.0.0.1:8000/pedsuc/item/?search=' + element.zpedsuc_id_ped_sucur)
                            .then(resItem =>{
                                this.pedi.push({
                                    zpedsuc_fech_creat: element.zpedsuc_fech_creat, 
                                    zpedsuc_fech_mod: element.zpedsuc_fech_mod, 
                                    zpedsuc_id_emple: element.zpedsuc_id_emple, 
                                    zpedsuc_id_emple_mod: element.zpedsuc_id_emple_mod, 
                                    zpedsuc_id_ped_sucur: element.zpedsuc_id_ped_sucur, 
                                    zpedsuc_id_provee: element.zpedsuc_id_provee, 
                                    zpedsuc_id_sucursal: element.zpedsuc_id_sucursal, 
                                    zpedsuc_nombre: element.zpedsuc_nombre, 
                                    zpedsuc_status_ped: element.zpedsuc_status_ped, 
                                    zpedsuc_sucursal: element.zpedsuc_sucursal,
                                    zpedpro_proveedor_nombre: element.zpedpro_proveedor_nombre,
                                    items: resItem.data
                                })
                            })                             
                        }
                    }); 
                })
        }
    },
}
</script>