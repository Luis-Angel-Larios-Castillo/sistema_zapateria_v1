Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra los pedidos realizados a proveedores
<template>
    <v-container fluid> 
        <v-card :elevation="0"> 
            <v-card-title class="card_title">
                <div class="col-12" id="table_cabecera_color">
                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                </div> 
            </v-card-title>  
            <div class="col-12" style="padding-top:0">
                <v-data-table
                    id="tabla_datos"
                    :headers="headers" 
                    :items="pedi" 
                    :search="search"
                    :items-per-page="5"
                    :items-per-page-options="[5, 10, 15]"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen pedidos registrados." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.zpedsuc_nombre="{ item }" >  
                        <strong>{{item.zpedsuc_nombre}}</strong> 
                    </template>      
                    <template v-slot:item.zpedpro_id_ped_provee="{ item }" >  
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon :to="'/DetailPedidoPro/'+ item.zpedpro_id_ped_provee+'/'" v-bind="attrs" v-on="on">
                                    <v-icon color="blue" >mdi-file-document-multiple-outline</v-icon>
                                </v-btn>
                            </template>
                            <span>Ver pedido</span>
                        </v-tooltip>
                        <v-tooltip bottom v-if="item.zpedpro_status_ped != 'Regreso chofer a centro de distribución'">
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon @click="cambiarEstatus(item)" v-bind="attrs" v-on="on">
                                    <v-icon color="blue" >mdi-redo</v-icon>
                                </v-btn>
                            </template>
                            <span>Cambiar estatus</span>
                        </v-tooltip>
                    </template>  
                </v-data-table>
            </div>
        </v-card> 
        <v-overlay :value="overlay">
            <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
        </v-overlay>  
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'empleado'
    ],
    data() {
        return { 
            overlay: false,
            IdEmpleado: '',
            status: 'Pedido a Proveedor',
            statusItems: [ 
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor',
                'Regreso chofer a centro de distribución', 
                'Finalizado '
            ],
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedpro_nombre', 
            }, 
            { text: 'Proveedor', value: 'zpedpro_proveedor'}, 
            { text: 'Estatus', value: 'zpedpro_status_ped'},  
            { text: 'Acciones', value: 'zpedpro_id_ped_provee', sortable: false },
            ],
            pedi: [],

        }
    },
    created() { 
        this.find()
    },
    methods: {
        find(){ 
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            this.pedi = []
            axios.get('http://127.0.0.1:8000/pedprov/cab/')
                .then(res => {
                    res.data.forEach(element => { 
                        if(element.zpedpro_status_ped ==  this.status){
                            this.pedi.push(element)
                        }
                    }); 
                })
        },
        cambiarEstatus(item){
            //console.log(IdEmpleado)   
            this.overlay = true
            let itemsPed = 0
            function callbackItemPedido (newStatus, marca, empleado, pedido, status) {  
                console.log(status)  
                axios.get('http://127.0.0.1:8000/pedido/itemped/')
                .then(resItem => {
                    resItem.data.forEach(item => {
                        if(item.zipe_marca == marca){
                            item.zipe_status = newStatus
                            console.log('item')
                            axios.put('http://127.0.0.1:8000/pedido/itemped/' + item.zipe_id_item_ped + '/', item)
                        }
                        itemsPed++;
                        if(itemsPed === resItem.data.length) {
                            setTimeout(function(){ 
                                pedido.zpedpro_status_ped = newStatus 
                                pedido.zpedpro_id_emple_mod = empleado 
                                axios.put('http://127.0.0.1:8000/pedprov/cab/' + pedido.zpedpro_id_ped_provee + '/', pedido)
                                .then(resPedP =>{
                                    axios.get('http://127.0.0.1:8000/pedsuc/cab/')
                                    .then(resPedSuc =>{
                                        let pedArray = 0
                                        resPedSuc.data.forEach(ped => { 
                                            if(ped.zpedpro_proveedor_nombre == marca){
                                                if(ped.zpedsuc_status_ped == status){
                                                    ped.zpedsuc_status_ped = newStatus
                                                    ped.zpedsuc_id_emple_mod = empleado
                                                    axios.put('http://127.0.0.1:8000/pedsuc/cab/' + ped.zpedsuc_id_ped_sucur + '/', ped )
                                                    console.log(ped)
                                                }
                                            }
                                            pedArray++;
                                            if(pedArray === resPedSuc.data.length) {
                                                setTimeout(function(){ 
                                                    console.log('Recargar')
                                                    window.location.reload()
                                                }, 3000);  
                                            }
                                        });
                                    })
                                })
                            }, 3000);  
                        }
                    });
                })
            } 
            switch (item.zpedpro_status_ped) { 
            case 'Pedido a Proveedor':   
                return  callbackItemPedido ('En tránsito chofer a proveedor', item.zpedpro_proveedor, this.IdEmpleado, item, 'Pedido a Proveedor')
            case 'En tránsito chofer a proveedor': 
                return  callbackItemPedido ('Regreso chofer a centro de distribución', item.zpedpro_proveedor, this.IdEmpleado, item, 'En tránsito chofer a proveedor')
            //case 'Regreso chofer a centro de distribución': 
              //  return  callbackItemPedido ('En tránsito sucursal', item.zpedpro_proveedor, this.IdEmpleado, item, 'Regreso chofer a centro de distribución')
            default:
                console.log('Algo salio mal');
            }
        }
    },
}
</script>