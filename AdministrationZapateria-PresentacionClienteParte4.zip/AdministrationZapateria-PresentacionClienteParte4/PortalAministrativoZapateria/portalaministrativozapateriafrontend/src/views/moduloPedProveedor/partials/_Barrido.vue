<template>
    <v-container> 
        <v-btn text style="border:2px solid white; border-radius:20px; float:right;" @click.stop="dialog = true" class="white--text">
            Barrer pedidos ya caducados
        </v-btn>
        <v-dialog transition="dialog-top-transition" v-model="dialog" max-width="500">  
            <v-card>
                <v-toolbar style="background-color:#14213d;" dark>
                    <h3>Asignar un número para realizar el barrido</h3> 
                </v-toolbar>
                <v-card-text> 
                    <v-container>
                        <v-text-field v-model="num" label="Número:"/>  
                    </v-container>
                </v-card-text>
                <v-card-actions class="justify-end">
                <v-btn outlined @click="consultarItems()" color="green" >
                    Aceptar
                </v-btn>
                <v-btn outlined color="orange" @click="dialog = false">
                    Cancelar
                </v-btn> 
                </v-card-actions>
            </v-card> 
        </v-dialog>
        <v-overlay :value="overlay"> 
            <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
        </v-overlay>  
    </v-container> 
</template>
<script>
const moment = require('moment') 
const axios = require('axios')  
export default {
    data() {
        return {
            dialog: false,
            fechaActual: moment(),
            overlay: false, 
            num: 60,
            idEmpleado: '',
        }
    },
    created() {
        axios.get('http://127.0.0.1:8000/usuario/getusuario/')
        .then(res => {
        let zdus_correo = 'zapateria@denys.com'
        res.data.forEach(user => { 
            if(user.zdus_correo.toLowerCase() == zdus_correo.toLowerCase()){
            this.idEmpleado = user.zdus_id_usuario
            }
        }); 
        })
    },
    methods: { 
        functionCiclica(items, counter, idEmpleado, functionCiclica){ 
        console.log('-------------------------')
        if(counter == items.length){
            window.setTimeout( function() { 
            console.log('Termino') 
                window.location.reload()
            }, 5000) 
        }
        let fecha_vale = new Date().toISOString().slice(0,10)
        if (counter < items.length) {  
            axios.get( 'http://127.0.0.1:8000/pedido/pedcab/'+ items[counter].zipe_id_pedido_cab + '/' )
            .then(resCab => {
            axios.get('http://127.0.0.1:8000/vale/')
            .then(resVale =>{
                resCab.data.zped_pagado += resCab.data.zped_vale
                if(resCab.data.zped_pagado  == 0){
                    console.log('Solo se cancela')
                    resCab.data.zipe_total -= items[counter].zipe_sub_tot
                    items[counter].zipe_status = 'Cancelado'  
                    resCab.data.zped_vale = 0
                    axios.put( 'http://127.0.0.1:8000/pedido/pedcab/'+ resCab.data.zped_id_pedcab + '/', resCab.data )
                    //axios.get( 'http://127.0.0.1:8000/pedido/pedcab/'+ resCab.data.zped_id_pedcab + '/')
                    .then(resPCab =>{
                        axios.put('http://127.0.0.1:8000/pedido/Itembyuser/' + items[counter].zipe_id_item_ped + '/', items[counter])
                        //axios.get('http://127.0.0.1:8000/pedido/Itembyuser/' + items[counter].zipe_id_item_ped + '/')
                        .then(resPItem =>{
                        window.setTimeout( function() { 
                            console.log(items[counter])
                            console.log(resCab.data)   
                            counter++;
                            functionCiclica(items, counter, idEmpleado, functionCiclica);
                        }, 3000);
                        })
                    })   
                }else{
                // Condicion cuando el anticipo es menor al monto del articulo 
                    let num_random = Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))
                    let vale = {
                        "zdv_folio_vale": 'Vale-'+ fecha_vale + '-' + num_random + '-' + (resVale.data.length + 1),
                        "zdv_id_user_autori": 'No autorizado aún',
                        "zdv_id_user_qcobra_vale": 'No cobrado aún',
                        "zdv_fecha_cobro": null,
                        "zdv_importe": resCab.data.zped_pagado,
                        "zdv_id_sucursal": items[counter].zipe_sucursal,
                        "zdv_id_item_ped": items[counter].zipe_id_item_ped,
                        "zdv_estat_vale": false,
                        "zdv_id_cliente": items[counter].zipe_id_cliente,
                        "zdv_id_empleado": idEmpleado 
                    }  
                    items[counter].zipe_status = 'Cancelado'
                    resCab.data.zipe_total -= items[counter].zipe_sub_tot 
                    console.log('Tiene mas de la fecha establecida - el monto mayor a lo pagado')
                    resCab.data.zped_pagado = 0
                    resCab.data.zped_vale = 0
                    //axios.get( 'http://127.0.0.1:8000/pedido/pedcab/'+ resCab.data.zped_id_pedcab + '/')
                    axios.put( 'http://127.0.0.1:8000/pedido/pedcab/'+ resCab.data.zped_id_pedcab + '/', resCab.data )
                    .then(resPCab =>{
                    //axios.get('http://127.0.0.1:8000/vale/')
                    axios.post('http://127.0.0.1:8000/vale/', vale)
                    .then(resPVale =>{
                        //axios.get('http://127.0.0.1:8000/pedido/Itembyuser/' + items[counter].zipe_id_item_ped + '/')
                        axios.put('http://127.0.0.1:8000/pedido/Itembyuser/' + items[counter].zipe_id_item_ped + '/',items[counter])
                        .then(resPItem => {
                        window.setTimeout( function() { 
                            console.log(items[counter])
                            console.log(resCab.data) 
                            console.log(vale)  
                            counter++;
                            functionCiclica(items, counter, idEmpleado, functionCiclica);
                        }, 3000);
                        })
                    }) 
                    })  
                }   
                
            }) 
            })
        }  
        //console.log(idEmpleado)
        },
        consultarItems(){
        this.overlay = true   
        this.dialog = false
        let arr = []
        axios.get('http://127.0.0.1:8000/pedido/Itembyuser/')
        .then(res => {
            res.data.forEach(item => {
            if(item.zipe_status == 'Pendiente'){
                if(this.fechaActual.diff(moment(item.zipe_fecha), 'days') >= this.num){
                arr.push(item)
                }
            }
            });
            this.articulos = arr
            this.functionCiclica(arr, 0, this.idEmpleado, this.functionCiclica)
        })
        },
    },
}
</script>