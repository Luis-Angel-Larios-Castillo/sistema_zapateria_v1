<!--Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el logeo para los usuarios.-->
<template>

  <v-container fluid>
    <app-header style="z-index: 135"/> 
     
      <v-col cols="md-7 xs-12">
        <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">INFORMACIÓN DEL USUARIO</h1>
        </div><br>

      <v-card :elevation="0">
    
    <v-form  style="max-width: 800px" class="mt-4" ref="form" v-model="valid" lazy-validation m>
      <v-text-field

        v-model="correo"
        outlined
        solo
        rounded
        append-icon="mdi-at"
        background-color="#E5E7E9"
        :rules="correoRules"
        label="Correo electrónico:"
        required
        counter
        maxlength="40"
        placeholder="Ejem. example@gmail.com">
      </v-text-field>
      
      <v-text-field
        v-model="password"
        solo
        background-color="#E5E7E9"
        outlined
        rounded
        :append-icon="show ? 'mdi-eye-off' : 'mdi-eye'"
        :rules="passRules"
        :type="show ? 'text' : 'password'"
        label="Contraseña:"
        counter
        @click:append="show = !show"
        maxlength="30"
        placeholder="Ejem. $Contraseña99">
      </v-text-field>
      
      <v-text-field
        solo
        background-color="#E5E7E9"
        v-model="password_confirmation"
        outlined
        rounded
        append-icon="mdi-lock"
        :rules="passConRules"
        :type="show ? 'text' : 'password'"
        label="Confirmación de contraseña:"
        counter
        maxlength="30"
        placeholder="Ejem. $Contraseña99"></v-text-field>
      <br>
      
      <v-btn id="btn_borrar_formulario" x-large class="mr-4"  @click="reset">
        Borrar
        <v-icon right dark>
          mdi-eraser
        </v-icon>
      </v-btn>
      
      <v-btn v-show="correo"  :disabled="!valid" x-large id="btn_guardar_formulario" class="mr-4" @click="validate">
        Guardar
        <v-icon right dark>
          mdi-cloud-upload
        </v-icon>
      </v-btn>

      <v-btn id="btn_cancelar_formulario" x-large class="mr-4" rounded @click="cancelar">
        Cancelar
        <v-icon right dark>
          mdi-close-circle
        </v-icon>
      </v-btn><br><br>
    </v-form>
  
    <v-snackbar
      v-model="snackbar"
      :bottom="y === 'bottom'"
      :left="x === 'left'"
      :multi-line="mode === 'multi-line'"
      :right="x === 'right'"
      :top="y === 'top'"
      :vertical="mode === 'vertical'"
    >
            {{text}}
            <template v-slot:action="{ attrs }">
              <v-btn color="red"  text v-bind="attrs" @click="snackbar = false">
                Cerrar
              </v-btn>
            </template>
          </v-snackbar>
</v-card>
 </v-col>


      
</v-container>
</template>

<script>
import Header from '../../components/Header';
  import axios from "axios";
  
  export default {
    name: 'Header', 
    components:{
    "app-header": Header,
   
  }, 
    data: () => ({
      snackbar: false,
      y: 'top',
      x: null,
      mode: '',
      text: 'La contraseña no coincide o el correo ya este registrado.',
      usuarios:[],                     
      valid: true,
      show: false,
      correo: '',
      correoRules: [
        v => !!v || 'Se requiere ingresar un Correo Electrónico.',
        v => /.+@.+\..+/.test(v) || 'El campo "Correo Electrónico" tine que ser valido',
        v => (v && v.length <= 40) || 'El campo "Correo Electrónico" no debe tener más de 40 caracteres.',
      ],
      password: '',
      passRules: [
        v => !!v || 'El campo "Contraseña" es obligatorio.',
        v => (v && v.length >= 8) || 'El campo "Contraseña" debe tener más de 8 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'El campo "Contraseña" debe tener al menos una mayúscula.',
        v => /(?=.*\d)/.test(v) || 'El campo "Contraseña" debe tener al menos un número.',
        v => /([!@$%])/.test(v) || 'El campo "Contraseña" debe tener al menos un carácter especial "!@$%"',
      ],
      password_confirmation: '',
      passConRules: [
        v => !!v || 'El campo "Contraseña" es obligatorio.',
        v => (v && v.length >= 8) || 'El campo "Contraseña" debe tener más de 8 caracteres.',
        v => /(?=.*[A-Z])/.test(v) || 'El campo "Contraseña" debe tener al menos una mayúscula.', 
        v => /(?=.*\d)/.test(v) || 'El campo "Contraseña" debe tener al menos un número.', 
        v => /([!@$%])/.test(v) || 'El campo "Contraseña" debe tener al menos un carácter especial "!@$%"',
      ],  
       
   }),
     created(){
      
    },
    methods: {
      
      validate(){
        if(this.$refs.form.validate()){
          this.usuarios = {
            zdus_correo:this.correo,
            password:this.password,
            password_confirmation:this.password_confirmation,
          }
        }
        if(this.password === this.password_confirmation) {
          this.submit()
        }
        else{
          this.snackbar = true
        }
      },
      reset(){
        this.$refs.form.reset()
      },

      submit () {
        axios.post('http://127.0.0.1:8000/usuario/signup/',this.usuarios)
        .then(res =>{ this.$router.replace({ path: '/RegistroClientes/' + res.data.zdus_id_usuario })
        })
        .catch(error => this.snackbar = true)
      },
      cancelar () {
        //this.$router.push({ name: 'Home' });
        this.$router.go(-1);
      },
    },
  }
</script>