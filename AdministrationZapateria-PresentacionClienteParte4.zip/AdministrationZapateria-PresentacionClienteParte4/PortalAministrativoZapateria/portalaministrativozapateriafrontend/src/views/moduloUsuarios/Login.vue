<template>
    <v-container fluid>
         <app-header style="z-index: 135"/> 
         <br>
         <br><br>
         <v-container  class="col-8">
    <v-row>
        <v-col class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style=" background:#fca311;  border-top-left-radius: 10px; border-bottom-left-radius: 10px;">
            <br>
            <h2 class="white--text"> 
               <i> Bienvenido a la
                <br>
                Zapateria</i>
            </h2>
            <br>
            <br>
            <v-img :src="require('@/assets/logov2.png')"/>
        </v-col>
        <v-col class="col-lg-9 col-md-9 col-sm-12 col-xs-12 d-flex justify-center" style="background:#f5f5f5; border-top-right-radius: 10px; border-bottom-right-radius: 10px;">
        <div>               
                    <br>
                        <v-icon>mdi-account-circle mdi-48px</v-icon>
                    <br>
                       <h2>Iniciar sesión</h2>
                       <br>
                <v-form ref="form" v-model="valid" lazy-validation m>
                    <v-text-field
                    
                        prepend-inner-icon="mdi-at"
                        v-model="email"  
                        :rules="emailRules"
                        label="Correo"
                         filled
                        rounded
                        dense
                    ></v-text-field>
                    <v-text-field
                         filled
                        rounded
                        dense
                        v-model="pass"  
                        :rules="passRules"
                        :append-icon="show ? 'mdi-eye' : 'mdi-eye-off'"
                        prepend-inner-icon="mdi-lock"
                        label="Contraseña"
                        :type="show ? 'text' : 'password'"
                        @click:append="show = !show"
                    ></v-text-field>
                </v-form>
              <v-row>
                  <v-col class="col-6">
                       <v-btn to="/Usuario" block id="btn_guardar_formulario">Registro</v-btn>
                  </v-col>
                  <v-col class="col-6">
                         <v-btn  block :disabled="!valid" id="btn_agrega_otro_formulario" @click="validate">Inicar </v-btn>
                  </v-col>
              </v-row>
                      <br>  
                       <br><br> 
        </div>
           </v-col>
            </v-row>
            </v-container>
   
    <v-snackbar shaped color="red" outlined v-model="snackbar" :timeout="timeout">
      {{ text }}

      <template v-slot:action="{ attrs }">
        <v-btn color="blue" text v-bind="attrs" @click="snackbar = false">
          Cerrar
        </v-btn>
      </template>
    </v-snackbar>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
    "app-header": Header,
  },
    data() {
        return {
            show: false,
            snackbar: false,
            text: 'El usuario o la contraseña son incorrectos.',
            timeout: 3000,
            element: [],
            valid: true,
            email: '',
            emailRules: [
                v => !!v || 'El correo es obligatorio',
                v => /.+@.+\..+/.test(v) || 'El correo tine que ser valido',
            ],
            pass: 'Hola@1234',
            passRules: [
                v => !!v || 'La contraseña es obligatorio.',    
                v => /(?=.*[A-Z])/.test(v) || 'Debe tener una mayúscula.', 
                v => /(?=.*\d)/.test(v) || 'Debe tener al menos un número.', 
                v => /([!@$%])/.test(v) || 'Debe tener un carácter especial "!@$%"',       
            ],
        }
    },
    created() {
        
    },
    methods:{
        validate () {
            if (this.$refs.form.validate()){
                this.element = {
                    zdus_correo: this.email,
                    password: this.pass
                }
            this.login()
            }  
      },
        async login(){
            await axios.post('http://127.0.0.1:8000/usuario/login/', this.element)
                .then(res=> this.elementRes = res.data)
                .then(res=> {
                    localStorage.token = res.access_token,
                    axios.get('http://127.0.0.1:8000/usuario/token/'+res.access_token+'/')
                        .then(res=> 
                        {
                            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+res.data.user+'/')
                                .then(res=> { 
                                    if(res.data.is_staff == true){
                                        localStorage.type = res.data.is_staff 
                                        this.$router.push({name: 'Articulos'}) 
                                    }else{
                                        localStorage.type = res.data.is_staff 
                                        this.$router.push({name: 'Home'})
                                    }
                                })
                        })
                    })
                .catch(error => { this.snackbar = true, localStorage.token = '' })
    }
    }
}
</script>