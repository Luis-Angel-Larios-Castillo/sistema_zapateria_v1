Autor: Miguel Angel Zamora Carmona
Descripción: Muestra la información del usuario logueado 
<template>
    <v-container fluid> 
      <app-header style="z-index: 135"/>  
      <br>
      <div class="col-10">
      <v-card id="table_cabecera_color_camb_pass" dark>
        <v-card-title> 
          Perfil<div v-if="type == true">: {{UserInfo.zdem_nombre}} {{UserInfo.zdem_apell_pat}} {{UserInfo.zdem_apell_mat}}</div><div v-else>: {{UserInfo.zc_nombre}} {{UserInfo.zc_apell_pat}} {{UserInfo.zc_apell_mat}}</div> 
          <v-spacer/>
          <CambiarContra/>
        </v-card-title> 
      </v-card>
      <br>
      <FormAdminRegis :id="userId" v-if="registarAdmin == true"/>
      <div v-if="typeAdmin == true">
        <h2>Administrador</h2>
        <h3>Correo: {{correo}}</h3>
      </div>
      <div v-else>
        <div v-if="registarAdmin == false">
          <TrabajadorInfo :elementInfo="{UserInfo, correo}" v-if="type == true"/> 
        </div> 
        <ClienteINfo :elementInfo="{UserInfo, correo}" v-if="type == false"/> 
      </div> 
      </div>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import FormAdminRegis from './partials/FormAdminRegis.vue'
import TrabajadorInfo from './partials/TrabajadorInfo.vue'
import ClienteINfo from './partials/ClienteInfo.vue'
import CambiarContra from './partials/CambiarContra.vue'
const axios = require('axios')
export default {
   name: 'Header', 
    components:{ 
       "app-header": Header,
        TrabajadorInfo, 
        CambiarContra,
        ClienteINfo,
        FormAdminRegis
    },
    data() {
        return {
          registarAdmin: false,
          typeAdmin: Boolean,
          userId: '',
          type: Boolean,
          UserInfo: [],
          correo: ''
        }
    },
    created() {
        axios.get('http://127.0.0.1:8000/usuario/token/' + localStorage.token + '/')
        .then( resToken=> {
            this.userId = resToken.data.user
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + resToken.data.user + '/')
                .then( res=> {  
                    if(res.data.is_staff == true){
                      axios.get("http://127.0.0.1:8000/empleado/?search=" + this.userId)
                        .then( res =>  { 
                          if(res.data.length == 0){
                            this.registarAdmin = true 
                          }else{
                            this.UserInfo = res.data[0]
                          }
                          })
                    } else {
                      axios.get("http://127.0.0.1:8000/cliente/clientes/?search=" + this.userId )
                        .then( res => this.UserInfo = res.data[0] )
                    } 
                  this.correo = res.data.zdus_correo
                  this.type = res.data.is_staff
                })
        })
    },
    methods: { 
    },
}
</script>