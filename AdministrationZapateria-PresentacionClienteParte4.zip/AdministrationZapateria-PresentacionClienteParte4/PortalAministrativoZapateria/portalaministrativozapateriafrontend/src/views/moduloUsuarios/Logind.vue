Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el logeo para los usuarios.


<template>
 <v-container fluid>
      <div v-if="permissions.can_manage_empleados == true">
         <app-header style="z-index: 135"/> 
         
              <v-col cols="md-7 xs-12">
                <div flat align="center" justify="space-around">
                  <hr class="line_superior">
                  <h1 id="title">INFORMACIÓN DEL USUARIO</h1>
                </div><br>
                

              <v-card :elevation="0">

                  <v-form  style="max-width: 800px" class="mt-4" ref="form" v-model="valid" lazy-validation m>

                    <v-text-field v-model="correo"
                    outlined
                    rounded
                    solo
                    background-color="#E5E7E9"
                    append-icon="mdi-at" 
                    :rules="correoRules" 
                    label="Correo electrónico:"  
                    placeholder="Ejem. example@gmail.com"
                    counter
                    maxlength="40"
                    required/>
                    <v-text-field 
                      solo
                      background-color="#E5E7E9"
                      v-model="password"  
                      outlined
                      rounded :append-icon="show ? 'mdi-eye' : 'mdi-eye-off'"
                      :rules="passRules"
                      :type="show ? 'text' : 'password'"
                      label="Contraseña:"
                      hint="Al menos 8 carácteres"
                      counter
                      maxlength="30"
                      placeholder="Ejem. $Contraseña99"
                      @click:append="show = !show"
                    />
                    <v-text-field 
                      v-model="password_confirmation" 
                      outlined
                      solo
                      background-color="#E5E7E9"
                      rounded 
                      :rules="passconRules"  
                      append-icon="mdi-lock" 
                      :type="show ? 'text' : 'password'" 
                      label="Confirmación de Contraseña:" 
                      counter
                      maxlength="30"
                      placeholder="Ejem. $Contraseña99"

                    />
                    <br>
                    <v-btn id="btn_borrar_formulario" x-large class="mr-4" @click="reset">
                        Borrar todo
                        <v-icon right dark>
                          mdi-eraser
                        </v-icon>
                      </v-btn> 
                  <v-btn  v-show="correo"  class="mr-4" @click="validate" x-large  :disabled="!valid" id="btn_guardar_formulario">
                      Guardar
                      <v-icon right dark>
                        mdi-cloud-upload
                      </v-icon>
                    </v-btn>

                    <v-btn x-large class="mr-4"  id="btn_cancelar_formulario" @click="cancelar">
                        Cancelar
                        <v-icon right dark>
                          mdi-close-circle
                        </v-icon>
                    </v-btn> 
                  </v-form>
                  <v-snackbar v-model="snackbar"
        
                    :bottom="y === 'bottom'"
                    :left="x === 'left'"
                    :multi-line="mode === 'multi-line'"
                    :right="x === 'right'"
                    :top="y === 'top'"
                    :vertical="mode === 'vertical'"
                  >
                    {{text}}
                    <template v-slot:action="{ attrs }">
                      <v-btn color="red" text v-bind="attrs" @click="snackbar = false">
                        Cerrar
                      </v-btn>
                    </template>
                  </v-snackbar>
              </v-card>
              </v-col>
           
      </div>
      <div v-else>
        <ErrorPage403/>
      </div>
   
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
import axios from "axios";
export default {
  name: 'Header', 
  components:{
     "app-header": Header,
    ErrorPage403
  }, 
  data: () => ({
    snackbar: false,
    y: 'top',
    x: null,
    mode: '',
    text: 'La contraseña no coincide o el correo ya este registrado.',
    usuarios:[],                     
    valid: true,
    show: false,
    password: '',
    passRules: [
      v => !!v || 'La contraseña es obligatorio.',
      v => (v && v.length >= 8) || 'El campo "Contraseña" debe tener más de 8 caracteres.',    
      v => /(?=.*[A-Z])/.test(v) || 'Debe tener una mayúscula.', 
      v => /(?=.*\d)/.test(v) || 'Debe tener al menos un número.', 
      v => /([!@$%])/.test(v) || 'Debe tener un carácter especial "!@$%"',            
    ],
    password_confirmation: '',
    passconRules: [
      v => !!v || 'La contraseña es obligatorio.',
      v => (v && v.length >= 8) || 'El campo "Contraseña" debe tener más de 8 caracteres.',    
      v => /(?=.*[A-Z])/.test(v) || 'Debe tener una mayúscula.', 
      v => /(?=.*\d)/.test(v) || 'Debe tener al menos un número.', 
      v => /([!@$%])/.test(v) || 'Debe tener un carácter especial "!@$%"',  
    ],    
    correo: '',
    correoRules: [
      v => !!v || 'Se requiere el correo.',
      v => /.+@.+\..+/.test(v) || 'El correo tiene que ser valido',
      v => (v && v.length <= 40) || 'El campo "Correo Electrónico" no debe tener más de 40 caracteres.',
    ],
    permissions: {
            can_manage_empleados: false,
        },
  }),
  created(){
      this.findpermsisos()
    },
  methods: {
     findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_empleados: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_empleados') { this.permissions.can_manage_empleados = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
    validate(){ 
      if (this.$refs.form.validate()){
        this.usuarios = {
          zdus_correo:this.correo,
          password:this.password,
          password_confirmation:this.password_confirmation, 
        }
        if (this.password === this.password_confirmation) {
          this.submit()
        }else{ 
          this.snackbar = true
        }
      }
    },
    reset () {
      this.$refs.form.reset()
    },
    submit () {
      axios.post('http://127.0.0.1:8000/usuario/signupstaff/',this.usuarios)
        .then(res =>{ this.$router.replace({ path: '/RegistroEmpleados/' + res.data.zdus_id_usuario }) }) 
        .catch(error => {
          if (error.response.data.zdus_correo == "This field must be unique.") {
          }
          else{
            this.snackbar = true  
          } 
          })
    },
    cancelar () {
        //this.$router.push({ name: 'Home' });
        this.$router.go(-1);
      },
  },
}
</script>