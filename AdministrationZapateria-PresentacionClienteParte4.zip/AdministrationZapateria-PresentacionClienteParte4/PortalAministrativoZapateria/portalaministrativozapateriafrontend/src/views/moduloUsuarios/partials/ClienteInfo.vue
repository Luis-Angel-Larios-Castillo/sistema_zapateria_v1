<template>
    <v-card id="tabla_datos_dos"> 
        <v-row no-gutters>

             <v-col cols="12" md="12" > 
             <v-toolbar dark id="table_cabecera_color_formulario">
                   
                   <v-icon color="white">mdi-card-account-details-outline</v-icon>
                        <v-spacer/>
                        <h3 class="white--text"> Datos Personales</h3> 
                        <v-spacer/>  


                        <v-icon color="white">mdi-file-phone-outline</v-icon>
                        <v-spacer/>
                        <h3 class="white--text">Información de Contacto</h3> 
                        <v-spacer/>  
                   
              
               

                        
                  
                </v-toolbar>
             </v-col>
            <v-col cols="12" md="6"> 
               
                <v-card-text> 
                    <v-row>
                        <v-col cols="6">
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_nombre" label="Nombre"/>
                        </v-col> 
                        <v-col cols="6">
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_apell_pat" label="Apellido Paterno"/>
                        </v-col>  
                    </v-row> 
                    <v-row> 
                        <v-col cols="6">
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_apell_mat" label="Apellido Materno"/>
                        </v-col>  
                        <v-col cols="6">
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_fech_nacim" label="Fecha de nacimiento"/>
                        </v-col> 
                    </v-row>
                    <v-row> 
                        <v-col cols="8">
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_rfc" label="RFC"/>  
                        </v-col> 
                        <v-col cols="4"> 
                            <v-text-field readonly v-model="elementInfo.UserInfo.zc_saldo" label="Saldo"/>
                        </v-col> 
                    </v-row>
                    
                </v-card-text>
            </v-col>
            <v-col cols="12" md="6"> 
                <v-card-text>  
                    <v-text-field readonly v-model="elementInfo.UserInfo.zc_num_telefono"  v-mask="'###-###-##-##'" max="13" label="Tel. casa"/> <br>
                    <v-text-field readonly v-model="elementInfo.UserInfo.zc_num_cell"  v-mask="'###-###-##-##'" max="13" label="Tel. móvil"/> <br>
                    <v-text-field readonly v-model="elementInfo.correo" label="Correo"/>
                </v-card-text>
            </v-col>
        </v-row>
        
        
        <v-toolbar dark id="table_cabecera_color_formulario">
            <v-row justify="center" no-gutters>
                <v-icon color="white">mdi-map-marker-radius-outline</v-icon>
                <v-spacer/>
                <h3 class="white--text">Dirección - Lugar de Residencia</h3> 
                <v-spacer/>  
            </v-row> 
        </v-toolbar>
        <v-card-text>  
        <v-row>
            <v-col cols="3">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_pais" label="País"/>
            </v-col> 
            <v-col cols="4">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_estado" label="Estado"/>
            </v-col> 
            <v-col cols="5">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_municipio" label="Municipio"/>
            </v-col> 
        </v-row>
        <v-row>
            <v-col cols="3">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_colonia" label="Colonia"/>
            </v-col> 
            <v-col cols="3">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_cod_postal" label="Código postal"/>
            </v-col> 
            <v-col cols="6">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_calle_1" label="Calle principal"/>
            </v-col>  
        </v-row>
        <v-row>
            <v-col cols="6">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_calle_2" label="Calle Interconexión"/>
            </v-col>
            <v-col cols="3">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_num_int" label="Número Interior"/>
            </v-col>  
            <v-col cols="3">
                <v-text-field readonly v-model="elementInfo.UserInfo.zc_dir_num_ext" label="Número Exterior"/> 
            </v-col> 
        </v-row>
        </v-card-text>
    </v-card>     
</template>
<script> 
export default {
    props:[
        'elementInfo'
    ],
    data(){
        return {
        };
    },
}
</script>