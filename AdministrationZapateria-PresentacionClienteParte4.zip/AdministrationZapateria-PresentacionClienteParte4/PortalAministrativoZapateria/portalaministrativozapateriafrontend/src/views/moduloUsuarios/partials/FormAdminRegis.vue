<!--Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el formulario para el registro de los datos del administrador.-->
<template>
    <v-container> 
       <v-card :elevation="0">
        <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario" dark>
          <h2>REGISTRO DE DATOS DEL ADMINISTRADOR</h2>
        </v-toolbar> 
        <v-container id="tabla_datos_dos" class="col-12"> 
          <v-form ref="form"  v-model="valid" lazy-validation>
             <v-card-text>
              <v-alert id="title_formulario" dense icon="mdi-account-check">
                <strong>Datos Personales</strong>
              </v-alert>

              <v-row>
                <v-col cols="4">
                  <v-text-field v-model="name" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="apep" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="apem" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="13">
                <v-menu
                  ref="menu"
                  v-model="menu"
                  :close-on-content-click="false"
                  :return-value.sync="date"
                  transition="scale-transition"
                  offset-y
                  min-width="auto">
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field
                      v-model="date"
                      label="Fecha de Nacimiento"
                      prepend-icon="mdi-calendar"
                      readonly
                      v-bind="attrs"
                      v-on="on">
                    </v-text-field>
                  </template>
                  <v-date-picker
                    v-model="date"
                    no-title
                    locale="es-mx"
                    scrollable>
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                      Cancelar
                    </v-btn>
                    <v-btn
                      text
                      color="primary"
                      @click="$refs.menu.save(date)">
                      Guardar
                    </v-btn>
                  </v-date-picker>
                </v-menu>
                </v-col>
               </v-row>
              <v-alert id="title_formulario" dense icon="mdi-home">
                <strong>Dirección - Lugar de Residencia</strong>
              </v-alert>
              <v-row>
               <v-col>
                  <v-text-field v-model="pais" :rules="paisRules" label="País:" required :counter="20" readonly></v-text-field>
                </v-col>
               <v-col>
                  <v-select v-model="edo" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="[v => !!v || 'Se requiere seleccionar un Estado.']" label="Estado:" required/>
                </v-col>
                 <v-col>
                  <v-select v-model="municipio" :items="municipios" item-text="name" :rules="[v => !!v || 'Se requiere seleccionar un Municipio.']" label="Municipio:" required/>
                </v-col>
                
                </v-row>
                 <v-row>
                 <v-col cols="4">
                  <v-text-field v-model="col" :rules="colRules" label="Barrio/Colonia:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. El Bosque" maxlength="20"></v-text-field>
                </v-col>
                <v-col cols="3">
                  <v-text-field v-model="callp" :rules="callpRules" label="Calle Principal:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos" maxlength="50"></v-text-field>
                </v-col>
                <v-col cols="5">
                  <v-text-field v-model="calli" :rules="calliRules" label="Calle/s de Interconexión:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita" maxlength="50"></v-text-field>
                </v-col>
                 </v-row>
                  <v-row>
                <v-col cols="4">
                  <v-text-field v-model="nume" :rules="numeRules" label="N. Exterior:" required :counter="25" maxlength="25" type="text" title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="num" :rules="numRules" label="N. Interior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N" type="text"></v-text-field>
                </v-col>
    
                <v-col>
                  <v-text-field v-model="codigo" :rules="codigoRules" label="Código Postal:" oninput="this.value=this.value.replace(/[^0-9]/g,'');" required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                </v-col>
              </v-row>
          
              <v-alert id="title_formulario" dense icon="mdi-card-account-phone">
                <strong>Información de Contacto</strong>
              </v-alert>
               <br>
              <v-row>
                <v-col cols="4">
                  <v-text-field v-model="tel" :rules="telRules" v-mask="'###-###-##-##'" max="13" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Teléfono Domiciliar:" required>
                  <v-tooltip slot="append" bottom>
                    <template v-slot:activator="{ on, attrs }"> 
                        <v-icon  color="blue" v-bind="attrs" v-on="on">
                          mdi-help-circle-outline
                        </v-icon> 
                    </template>
                    <div>
                      Escribir el número telefónico con lada: <br>
                      Ejemplo: 241-000-00-00
                      <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p>
                    </div>
                  </v-tooltip> 
                  </v-text-field>
                </v-col>
                <v-col cols="4">
                  <v-text-field v-model="telc" :rules="telcRules" v-mask="'###-###-##-##'" max="13" oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" label="Número de Celular:" required>
                    <v-tooltip slot="append" bottom>
                      <template v-slot:activator="{ on, attrs }"> 
                          <v-icon  color="blue" v-bind="attrs" v-on="on">
                            mdi-help-circle-outline
                          </v-icon> 
                      </template>
                      <div>
                        Escribir el número telefónico con lada: <br>
                        Ejemplo: 241-000-00-00
                        <p class="blue  --text">Nota: Los guiones se colocan automaticamente.</p>
                      </div>
                    </v-tooltip> 
                  </v-text-field>
                </v-col> 
                <v-col cols="4">
                  <v-select v-model="sucur" :items="sucursal" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una sucursal']"  label="Sucursal" required/>
                </v-col>
              </v-row>
             <br><br> 
              <v-row align="center" justify="space-around">
                <v-btn :disabled="!valid" x-large color="success" rounded class="mr-4" @click="validate" outlined>
                  Guardar 
                  <v-icon right dark>
                      mdi-cloud-upload
                  </v-icon>
                </v-btn>
                <v-btn color="orange" x-large class="mr-4" rounded @click="reset" outlined>
                  Borrar todo
                  <v-icon right dark>
                      mdi-eraser
                  </v-icon>
                </v-btn>
                <v-btn x-large color="red" rounded class="mr-4" @click="cancelar()" outlined>
                  Cancelar 
                  <v-icon right dark>
                      mdi-delete-outline
                  </v-icon>
                </v-btn>
            </v-row>
        </v-card-text>
        </v-form>
      </v-container>
       </v-card>
      
     
    </v-container>
</template>
<script>
const axios = require('axios')
import esta from "../../../assets/json/muni.json"; 
  export default {
    props:[
        'id'
    ],
    created() { 
      this.filtar()
      this.getSucursal()
    }, 
    data: () => ({
      empleado:[],
      usuarios:[],
      menu: false,
      date: new Date().toISOString().substr(0, 10),
      valid: true, 
      name:'',
      nameRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
        v => !!v || 'Se requiere el nombre.',
        v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
      ],
      apep:'',
      apepRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
        v => !!v || 'Se requiere el apellido paterno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.', 
      ],
      apem:'',
      apemRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',    
        v => !!v || 'Se requiere el apellido materno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.', 
      ], 
      callp:'',
      callpRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',    
        v => !!v || 'Se requiere la calle principal.',
        v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El campo "Calle Principal" no debe tener más de 30 caracteres.',
      ],
      calli: '',
      calliRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
        v => !!v || 'Se requiere la calle interconexión.',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El registro no debe tener más de 30 caracteres.',
      ],
      nume:'',
      numeRules: [
        v => !!v || 'Se requiere el número exterior.',
        v => (v && v.length >= 1) || 'El campo "N. Exterior" debe tener más de 1 caracteres.',
        v => (v && v.length <= 5) || 'El campo "N. Exterior" no debe tener más de 5 caracteres.',
      ], 
      num: '',
      numRules: [
        v => !!v || 'Se requiere el número interior.',
        v => (v && v.length >= 1) || 'El campo "N. Interior" debe tener más de 1 caracteres.',
        v => (v && v.length <= 5) || 'El campo "N. Interior" no debe tener más de 5 caracteres.',
      ],
      col:'',
      colRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Colonia" debe ser mayúscula',
        v => !!v || 'Se requiere la colonia.',
        v => (v && v.length >= 5) || 'El campo "Colonia" debe tener más de 5 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Colonia" no debe tener más de 20 caracteres.',
      ],
      codigo:'',
      codigoRules: [
        v => !!v || 'Se requiere el código postal.',
        v => (v && v.length >= 4) || 'El campo "Código Postal" debe tener más de 4 caracteres.',
        v => (v && v.length <= 5) || 'El campo "Código Postal" no debe tener más de 5 caracteres.',
      ],
      municipio: '',
      municipios: [],
      muniRules: [
        v => !!v || 'Se requiere el municipio.',
        v => (v && v.length >= 5) || 'El campo "Municipio" debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El campo "Municipio" no debe tener más de 30 caracteres.',
      ],
      edo: 'Tlaxcala',
      estado: esta, 
      edoRules: [
        v => !!v || 'Se requiere el estado.',
        v => (v && v.length >= 3) || 'El campo "Estado" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Estado" no debe tener más de 20 caracteres.',
      ],
      pais: 'México',
      paisRules: [
        v => !!v || 'Se requiere el país.',
        v => (v && v.length >= 3) || 'El campo "País" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "País" no debe tener más de 20 caracteres.',
      ],
      tel: '',
      telRules: [
        v => !!v || 'Se requiere el número de teléfono.',
        v => (v && v.length == 13) || 'El campo "Teléfono Domiciliar" debe ser valido.',
      ],
      telc: '',
      telcRules: [
        v => !!v || 'Se requiere el número de celular.',
        v => (v && v.length == 13) || 'El campo "Número de Celular" debe ser valido.',
      ],
      sucursal: [], 
      sucur: null,
      elements: [],
    }), 
    methods: {
      cancelar(){
        this.$router.go(-1) 
      },
      filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.edo )
            this.municipios = this.estado[i].municipios
          } 
        },
      validate () {
        if (this.$refs.form.validate()){
          this.empleado = {
            zdem_id_usuario:this.id,
            zdem_nombre:this.name,
            zdem_apell_pat:this.apep,
            zdem_apell_mat:this.apem,
            zdem_num_tel:this.tel,
            zdem_num_cel:this.telc,
            zdem_id_sucursal: this.sucur,
            zdem_fech_nacim:this.date,
            zdem_dir_pais:this.pais,
            zdem_dir_estado:this.edo,
            zdem_dir_municipio:this.municipio,
            zdem_dir_colonia:this.col,
            zdem_dir_cod_postal:this.codigo,
            zdem_dir_calle_1:this.callp,
            zdem_dir_calle_2:this.calli,
            zdem_dir_num_int:this.num,
            zdem_dir_num_ext:this.nume,
          }
          this.$refs.form.validate()
          this.submit()

        }
        }, 
        getSucursal(){
            axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
            .then(res => this.sucursal = res.data)
        }, 
        submit () {
            axios.post('http://127.0.0.1:8000/empleado/',this.empleado) 
            .then(res => window.location.reload() )
            .catch(error => console.log(error)); 
        },
        reset () {
            this.$refs.form.reset()
        },
    },
  }
</script>