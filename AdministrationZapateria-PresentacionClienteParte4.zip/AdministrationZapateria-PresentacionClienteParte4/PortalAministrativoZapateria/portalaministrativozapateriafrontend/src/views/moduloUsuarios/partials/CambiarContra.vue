<template>
  <div>
        <v-dialog  max-width="600">
        <template v-slot:activator="{ on, attrs }"> 
            <v-btn id="btn_inic" text v-bind="attrs" v-on="on">Cambiar cantraseña</v-btn> 
        </template>
        <v-card>
            <v-card-title class="headline"> 
                Cambiar cantraseña
            </v-card-title>
            <v-card-text> 
                <v-form ref="form" v-model="valid" lazy-validation m>
                    <v-text-field v-model="oldPass" :rules="passRules" 
                    @click:append="showOldPass = !showOldPass" :type="showOldPass ? 'text' : 'password'"
                     :append-icon="showOldPass ? 'mdi-eye-off' : 'mdi-eye'" label="Contraseña antigua"  
                      prepend-inner-icon="mdi-lock"
                     filled
                     rounded
                     dense
                     />
                    <v-text-field v-model="newPass" :rules="passRules" 
                    @click:append="showNewPass = !showNewPass" 
                    :type="showNewPass ? 'text' : 'password'" 
                    :append-icon="showNewPass ? 'mdi-eye-off' : 'mdi-eye'" 
                    label="Contraseña nueva"
                     prepend-inner-icon="mdi-lock"
                     filled
                     rounded
                     dense
                    />
                    <v-text-field v-model="newPassConfir"
                     :rules="passRules"
                      @click:append="showNewPass = !showNewPass" 
                      :type="showNewPass ? 'text' : 'password'" 
                      :append-icon="showNewPass ? 'mdi-eye-off' : 'mdi-eye'" 
                      label="Confirmación de contraseña nueva"
                      prepend-inner-icon="mdi-lock"
                     filled
                     rounded
                     dense
                      />
                    <v-btn id="btn_guardar_formulario" class="col-12" @click="validate()" :disabled="!valid">Guardar</v-btn>
                </v-form>
            </v-card-text>
        </v-card>
        </v-dialog>
        <v-snackbar shaped :color="color"  v-model="snackbar">
            <h3>{{ text }}</h3>      
            <template v-slot:action="{ attrs }">
                <v-btn color="red" text v-bind="attrs" @click="snackbar = false">
                Cerrar
                </v-btn>
            </template>
        </v-snackbar>
    </div>
</template>
<script>
import axios from 'axios'
export default { 
  data() {
    return {
        dialog: false,
        color: 'green',
        snackbar: false,
        text: '',
        valid: true,
        oldPass: '',
        newPass: '',
        newPassConfir: '',
        passRules: [
            v => !!v || 'La contraseña es obligatorio.',    
            v => /(?=.*[A-Z])/.test(v) || 'Debe tener una mayúscula.', 
            v => /(?=.*\d)/.test(v) || 'Debe tener al menos un número.', 
            v => /([!@$%])/.test(v) || 'Debe tener un carácter especial "!@$%"',       
        ],
        showOldPass: false,
        showNewPass: false,
    }
  },
  methods: {
    validate() {
      if (this.$refs.form.validate()){
          this.element = {
              zdus_correo: this.email,
              password: this.pass
          }
          if (this.newPass === this.newPassConfir) {
            this.cambiar() 
          }
          else{
            this.text =  'Las contraseñas nuevas no coinciden.'
            this.color = 'orange'
            this.snackbar = true 
          } 
      }  
    },
    cambiar(){
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        }
      }
      let data = {
        old_password: this.oldPass,
        new_password: this.newPass
      } 
      axios.put('http://127.0.0.1:8000/usuario/change-password/', data, config)
        .then(res => { 
          this.text =  'La contraseña ha sido actualizada.'
          this.color = 'green'
          this.snackbar = true 
          setTimeout(function(){
                window.location.reload()
            }, 1000);
          
        })
        .catch(res => {
          this.text =  'La contraseña anterior no es correcta. '
          this.color = 'orange'
          this.snackbar = true 
        })
    }
  },
}
</script>