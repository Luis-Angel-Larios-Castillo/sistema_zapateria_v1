<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo permite llevar a cabo la edición de un registro a traves de un formulario
el cual recupera los datos previamente registrados-->
<template>
    <v-container fluid>
      <div v-if="permissions.can_manage_galeria == true">
         <app-header style="z-index: 135"/> 
         <br>
      <div class="col-8">

        <v-toolbar style="max-width: 1300px" class="" flat align="center" justify="space-around" id="table_cabecera_color_formulario">
          <v-toolbar-title>
            <v-icon right dark>
              mdi-image-edit
            </v-icon> 
          <strong id="title_editar">Edición del registro: {{elementU.zs_titulo_slider}}</strong>
          </v-toolbar-title>
          <v-spacer/>
          <v-btn to="/slider/" outlined  class="btn_add" color="#F7F9F9">
              Regresar
          </v-btn>
        </v-toolbar>
          <v-container id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>
              <v-text-field v-model="elementU.zs_titulo_slider" filled :rules="tituloRules" label="Título" required :counter="50" placeholder="Ejem. Inspira a tu espíritu de vacaciones" maxlength="50"/>
              <v-text-field v-model="elementU.zs_descrip_slider" filled :rules="descripcionRules" label="Descripción" required :counter="100" placeholder="Ejem. Las vacaciones empiezan aquí mismo" maxlength="100"/>
              <v-text-field v-model="elementU.zs_id_usuario" readonly label="Id de usuario" required v-if="ocultar"></v-text-field>
              <br>
              <v-row align="center" justify="space-around">
                  <v-btn :disabled="!valid"  id="btn_actualizar_formulario" class="mr-4" @click="validate" >
                      Actualizar
                      <v-icon right dark>mdi-update</v-icon>
                 </v-btn>
                <v-btn  id="btn_borrar_formulario" class="mr-4" @click="reset">Borrar Formulario
                <v-icon right dark>
                        mdi-eraser
                    </v-icon>
                </v-btn> 
              </v-row>
            </v-form>
            <br>
          </v-container>
      </div>
       </div>
        <div v-else>
          <ErrorPage403/>
        </div>
    </v-container>
</template>

<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
const axios = require('axios')

export default {
   name: 'Header', 
    components:{
      "app-header": Header,
    ErrorPage403
  }, 
    data: () => ({
      elementU: [],
      valid: true,
      ocultar: false,
      search: null,
      tituloRules: [
        v => !!v || 'El campo título es obligatorio',
        v => (v && v.length >= 4) || 'El título debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El título no debe tener más de 50 caracteres',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo título debe ser mayúscula',
      ],
     descripcionRules: [
        v => !!v || 'El campo descripción es obligatorio',
        v => (v && v.length >= 10) || 'La descripción debe tener más de 10 caracteres',
        v => (v && v.length <= 100) || 'La descripción no debe tener más de 100 caracteres',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo descripción debe ser mayúscula',
      ],
      permissions: {
            can_manage_galeria: false,
                  
        },
    }),

    created() {
        this.findpermsisos()
        this.find()
    },

    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_galeria: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_catalogos') { this.permissions.can_manage_galeria = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      find(){
        axios.get('http://127.0.0.1:8000/slider/'+ this.$route.params.id +'/').
        then(res => {
          this.elementU = res.data
        })
      },
      validate () {
        this.$refs.form.validate()
        this.update()
      },
      async update(){
        await axios.put('http://127.0.0.1:8000/slider/'+ this.$route.params.id +'/',this.elementU)
        .catch(error => console.log(error));
        this.$router.push({ name: 'Slider' });
      },
      reset () {
        this.$refs.form.reset()
      },
      cancelar () {
        this.$router.push({ name: 'Slider' });
      },
    },
  }
</script>