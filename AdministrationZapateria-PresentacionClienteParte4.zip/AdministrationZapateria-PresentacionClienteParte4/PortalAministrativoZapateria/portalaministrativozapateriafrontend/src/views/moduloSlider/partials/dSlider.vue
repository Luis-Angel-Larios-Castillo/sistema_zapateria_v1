<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Archivo que contiene la ventana emergente al momento de querer eliminar un registro y la cual le permite al usuario confirmar la acción solicitada-->

<template>
  <v-row justify="center">
    <v-tooltip bottom >
      <template v-slot:activator="{ on, attrs }">
        <v-btn icon color="red" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_galeria == false">
          <v-icon color="red">mdi-delete</v-icon>
        </v-btn>
      </template>
      <span>Eliminar</span>
    </v-tooltip>
    <v-dialog v-model="dialog" max-width="331">
      <v-card><br>
        <v-alert dense text color="red" type="info">
          <strong>Se va a eliminar el registro:<br>{{elementD.item.zs_titulo_slider}}</strong>
        </v-alert>
        <v-card-text class="black--text">
          <h4>¿Está de acuerdo en eliminarlo?</h4>
        </v-card-text>
        <v-btn outlined color="red" @click="dialog = false">
          Cancelar
          <v-icon right dark>mdi-close-circle</v-icon>
        </v-btn>
        <v-btn outlined color="success" @click="aceptar()">
          Aceptar
          <v-icon right dark>mdi-check-all</v-icon>
        </v-btn><br><br>
      </v-card>
    </v-dialog>
    
  </v-row>
</template>

<script>
  const axios = require('axios')
  
  export default {
    props:[
      'elementD'
    ],
    data () {
      return {
        dialog: false,
      }
    },
    methods:{
      aceptar(){
        let URL = 'http://127.0.0.1:8000/slider/'+ this.elementD.item.zs_id_slider
        axios.delete(URL)
        .then(response => {
          this.dialog = false
          window.location.reload()
        })
      },
    },
  }
</script>