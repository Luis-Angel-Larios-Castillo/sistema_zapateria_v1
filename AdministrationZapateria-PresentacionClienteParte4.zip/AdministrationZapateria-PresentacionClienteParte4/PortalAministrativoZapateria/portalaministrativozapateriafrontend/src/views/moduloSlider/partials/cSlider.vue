<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo contiene el formulario el cual permite hacer el registro de nuevas promociones para el slider principal-->
<template>
    <v-container fluid> 
      <div v-if="permissions.can_manage_galeria == true">
        <app-header style="z-index: 135"/> 
    <v-col cols="md-10 xs-12">
        <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE GALERÍA</h1>
        </div><br>
        <v-card :elevation="0">
          <v-toolbar  flat align="center" justify="space-around" id="table_cabecera_color_formulario">
            <v-spacer/>
            <v-btn to="/slider/" outlined class="btn_add" color="#F7F9F9">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>
         </v-card>
        
         
          <v-container  id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>

              <v-text-field v-model="titulo" filled :rules="tituloRules" label="Título" required :counter="50" placeholder="Ejem. Inspira a tu espíritu de vacaciones" maxlength="50"></v-text-field>
              <v-text-field v-model="descripcion" filled :rules="descripcionRules" label="Descripción" :counter="100" placeholder="Ejem. Las vacaciones empiezan aquí mismo" maxlength="100"></v-text-field>
              <v-text-field v-model="idUser" label="Id Usuario" readonly required v-if="ocultar"></v-text-field>
              <br>
                <v-row align="center" justify="space-around">
                    <v-btn :disabled="!valid" id="btn_agrega_otro_formulario" class="mr-4" @click="validate">
                        Guardar y agregar otro 
                        <v-icon right dark>
                            mdi-reload
                        </v-icon>
                    </v-btn>
                    <v-btn :disabled="!valid" id="btn_guardar_formulario" class="mr-4" @click="validate02">
                        Guardar 
                        <v-icon right dark>
                            mdi-cloud-upload
                        </v-icon>
                    </v-btn>
                    <v-btn id="btn_borrar_formulario" class="mr-4" @click="reset">
                        Borrar Formulario
                      <v-icon right dark>mdi-eraser</v-icon>
                    </v-btn>
                </v-row>
            </v-form>
          </v-container>
          </v-col>
        </div>
        <div v-else>
          <ErrorPage403/>
        </div>
    </v-container>
</template>

<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
      "app-header": Header,
    ErrorPage403
  }, 
    created() {
      this.findpermsisos()
      this.findIdUser()
    },

    data () {
      return {
      element: [],
      valid: true,
      ocultar: false,
      search: null,
      idUser: '',
      titulo: '',
      tituloRules: [
        v => !!v || 'El campo título es obligatorio',
        v => (v && v.length >= 4) || 'El título debe tener más de 3 caracteres',
        v => (v && v.length <= 50) || 'El título no debe tener más de 50 caracteres',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo título debe ser mayúscula',
      ],
      descripcion: '',
      descripcionRules: [
        v => !!v || 'El campo descripción es obligatorio',
        v => (v && v.length >= 10) || 'La descripción debe tener más de 10 caracteres',
        v => (v && v.length <= 100) || 'La descripción no debe tener más de 100 caracteres',
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo descripción debe ser mayúscula',
      ],
      elements: [],
      permissions: {
            can_manage_galeria: false,
                  
        },
      }
    },

    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_galeria: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_catalogos') { this.permissions.can_manage_galeria = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            zs_titulo_slider: this.titulo,
            zs_descrip_slider: this.descripcion,
            zs_id_usuario: this.idUser,
            zaa_existen: true
          }
        this.createAndNew()
        }        
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            zs_titulo_slider: this.titulo,
            zs_descrip_slider: this.descripcion,
            zs_id_usuario: this.idUser,
            zaa_existen: true
          }
        this.create() 
        }        
      },
      createAndNew(){
        axios.post('http://127.0.0.1:8000/slider/', this.element)
          .then(res => {
            window.location.reload()
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      create(){
        axios.post('http://127.0.0.1:8000/slider/', this.element)
          .then(res => {
            this.$router.replace({ path: '/slider/' })
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
          .then(res => this.idUser = res.data.user)
          //.then(res=> console.log(res.data))
      },
      reset () {
        //this.$refs.form.reset()
        this.titulo=''
        this.descripcion=''
      },
    },
  }
</script>