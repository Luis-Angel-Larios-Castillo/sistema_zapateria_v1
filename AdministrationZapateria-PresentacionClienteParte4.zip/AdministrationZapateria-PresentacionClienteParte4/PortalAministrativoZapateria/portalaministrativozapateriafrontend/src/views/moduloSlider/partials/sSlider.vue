<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zs_titulo_slider}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
        </v-card-title>
        <v-card-text>
          <v-alert dense text type="success">
            Título: <strong>{{element.zs_titulo_slider}}</strong>
          </v-alert>
           <v-alert color="grey lighten-4" dense align="center">
                  <h3>INFORMACIÓN GENERAL</h3>
          </v-alert>
          <div class="black--text"> 
            <p><strong>Clave:</strong><br>{{element.zs_id_slider}}</p>
            <p><strong>Descripción:</strong><br>{{element.zs_descrip_slider}}</p>
            <!--<p class="black--text">
              {{findEmpleado(element.zs_id_usuario)}}
              <div v-for="empleado in empleado" :key="empleado.id"><strong>Autor: </strong><br>
                {{empleado.zdem_nombre}} {{empleado.zdem_apell_pat}} {{empleado.zdem_apell_mat}}<br>
              </div></p>
              <p><strong>Correo electrónico del autor: </strong><br>{{usuario.zdus_correo}}</p>-->
            
            <p class="black--text" v-if="this.usuario.is_superuser==false">
              <strong>Autor: </strong><br>
                {{empleado.nombre}}<br>
            </p>
            <p v-else><strong>Correo electrónico del autor: </strong><br>{{usuario.zdus_correo}}</p>

            <p class="red--text"><strong>Fecha de creación: </strong>{{fecha(element.zs_fech_creat_slider)}}</p>
            <p class="red--text"><strong>Última modificación: </strong>{{fecha(element.zs_fech_mod_slider)}}</p>
          </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')
  export default {
    props:[
      'element'
    ],

    created() {
      this.findUsuario()
      //this.findEmpleado()
    },

    data () {
      return {
        usuario: [],
        empleado: [],
      }
    },

    methods:{
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      findUsuario(){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ this.element.zs_id_usuario +'/')
        .then(res => {this.usuario = res.data
        axios.get('http://127.0.0.1:8000/empleado/?search='+ this.element.zs_id_usuario)
        .then(res => this.empleado = res.data[0])
        })
      },
      /*findEmpleado(id_usuario){
        axios.get('http://127.0.0.1:8000/empleado/?search='+ id_usuario)
        .then(res => this.empleado = res.data)
      },*/
    },
  }
</script>