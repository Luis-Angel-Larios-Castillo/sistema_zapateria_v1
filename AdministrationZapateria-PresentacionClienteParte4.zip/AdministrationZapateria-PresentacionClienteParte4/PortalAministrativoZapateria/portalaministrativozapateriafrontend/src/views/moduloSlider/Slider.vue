<!--Autor: Mario Alberto Alonso Alvarado
Descripción: Este archivo muestra un listado de todos los registros asignados a la galeria/slider-->
<template>
    <div cols="full">
        <v-row>
            <v-col cols="md-2 xs-12" >
                <menuModulos/>
            </v-col>
            <v-col cols="md-10 xs-12" > 
                 <app-header style="z-index: 135"/> 
                <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">GALERÍA</h1>
            </div><br>
                 
                <v-card :elevation="0">
                     <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                         <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text :to="'/cSlider/'" class="btn_add" v-show="permissions.can_manage_galeria == true">
                            Agregar
                        </v-btn>
                        </div>
                    </v-card-title>
                     <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                        class="col-10"
                        :headers="headers" 
                        :items="elements"
                        :search="search"
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen registros de ofertas." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }">
                        <template v-slot:item.zs_titulo_slider="{ item }">
                            <sSlider :element="item"/>
                        </template>
                        

                        <template v-slot:item.zs_fech_creat_slider="{ item }">
                                {{fecha(item.zs_fech_creat_slider)}}
                        </template>

                        <template v-slot:item.zs_fech_mod_slider="{ item }">
                                {{fecha(item.zs_fech_mod_slider)}}
                        </template>
                        
                        <template v-slot:item.zs_id_slider="{ item }">
                            <v-row align="center">
                                <v-col><dSlider :elementD="{item, permissions}"/> </v-col>
                                <v-col>
                                    <v-tooltip bottom >
                                        <template v-slot:activator="{ on, attrs }">
                                            <v-btn icon :to="'/uslider/'+ item.zs_id_slider+'/'" v-bind="attrs" v-on="on" v-if="permissions.can_manage_galeria == true">
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                            <v-btn icon v-bind="attrs" v-on="on" v-else disabled>
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Editar</span>
                                    </v-tooltip>
                                </v-col>
                            </v-row>
                        </template>
                    </v-data-table>
                    </div>
                </v-card>
            </v-col>
        </v-row><br>
    </div>
</template>

<script>
import Header from '../../components/Header';
import menuModulos from '../menuModulos'
import dSlider from './partials/dSlider'
import sSlider from './partials/sSlider'

    const moment = require('moment')
    const axios = require('axios')
    export default {
        name: 'Header', 
        components:{
             "app-header": Header,
            menuModulos,
            dSlider,
            sSlider,
        },
        created() {
            this.find()
        },
        data () {
            return {
                element: Object,
                search: '',
                headers: [
                    { text: 'Título', align: 'start', filterable: true, value: 'zs_titulo_slider', sortable: true},
                    { text: 'Descripción', value: 'zs_descrip_slider', sortable: false },
                    { text: 'Fecha de creación', value: 'zs_fech_creat_slider', sortable: true },
                    { text: 'Fecha de modificación', value: 'zs_fech_mod_slider', sortable: true },
                    { text: 'Acciones', value: 'zs_id_slider', align:'center' },
                ],
                elements: [],
                permissions: {
                    can_manage_galeria: false,
                  
                },
            }
        },
        methods:{
            find(){

                axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_galeria: true,
                                    
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_slider') { this.permissions.can_manage_galeria = true}
                                                        
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })


                axios.get('http://127.0.0.1:8000/slider/')
                .then(res => this.elements = res.data)
            },
            fecha(date){
                return moment(date).locale('MX').format('DD-MM-YYYY LT')
            },
        },
    }
</script>