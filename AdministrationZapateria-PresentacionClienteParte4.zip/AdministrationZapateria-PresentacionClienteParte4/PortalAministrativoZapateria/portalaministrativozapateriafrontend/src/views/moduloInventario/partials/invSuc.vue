<template>
    <div cols="full">
        <v-row>
            <v-col cols="md-2 xs-12" >
                <menuModulos/>
            </v-col>
                <v-col cols="md-10 xs-12" >
                    <app-header style="z-index: 135"/> 
                <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">INVENTARIO - ARTICULOS</h1>
                    <!--<br> {{sucursalId}}-->
            </div><br>
                <v-card>
                    <v-tabs>
                        <v-menu offset-y  v-for="sucursal in sucursales" :key="sucursal.zdsu_id_sucursal" open-on-hover>
                            <template v-slot:activator="{ on, attrs }">
                                <v-btn  text v-bind="attrs" v-on="on" :to="'/invSuc/'+ sucursal.zdsu_id_sucursal" v-on:click="findArti">
                                    {{sucursal.zdsu_nombre}}
                                </v-btn>
                            </template>
                        </v-menu>
                        <v-spacer></v-spacer>
                        <v-btn color="black" class="ma-2 white--text" rounded to="/inventario/">
                            General
                            <v-icon right dark>mdi-storefront</v-icon>
                        </v-btn>
                    </v-tabs>
                </v-card>
                
                <v-data-iterator :items="articulos" :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" hide-default-footer no-results-text="Sin registros" no-data-text="No se tienen registros de articulos.">
                    
                    <template v-slot:header>
                        <v-toolbar class="mb-2" color="#e4e6eb" flat>
                            <v-toolbar-title>Articulos - Sucursal {{sucursalId}}</v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Búscar..."></v-text-field>
                        </v-toolbar>
                    </template>
                    
                    <template v-slot:default="props">
                        <v-row>
                            <v-col v-for="item in props.items" :key="item.name" cols="12" sm="6" md="4" lg="3">
                                <v-card>
                                    <v-card-title class=" subheading font-weight-bold" >
                                        <v-img v-if="item.zaa_cantidad>=1" class="imgColor white--text align-center" dark height="200px">
                                            <h4>{{ item.zaa_nombre_arti }}</h4>
                                        </v-img>
                                        <v-img v-else dark class="imgColor white--text align-center" height="200px">

                                            <h2 class="text-center">Agotado</h2>
                                            <h4>{{ item.zaa_nombre_arti }}</h4>
                                        </v-img>
                                        
                                    </v-card-title>
                                    
                                    <v-divider></v-divider>
                                    
                                    <v-list dense>
                                        <v-list-item>
                                            <v-list-item-content>Clave:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zaa_clave }}
                                            </v-list-item-content>
                                        </v-list-item>
                                        
                                        <v-list-item>
                                            <v-list-item-content>Cantidad:</v-list-item-content>
                                                <v-list-item-content>
                                                    <v-chip :color="getColor(item.zaa_cantidad)" class="white--text"> 
                                                        {{ item.zaa_cantidad }}
                                                    </v-chip>
                                                </v-list-item-content>
                                        </v-list-item>
                                        <v-list-item>
                                            <v-list-item-content>Estatus:</v-list-item-content>
                                                 <v-list-item-content>
                                                <v-chip
                                                
                                                    :color="colortipo(item.zaa_existen)"
                                                    class="white--text"
                                                >
                                                {{status(item.zaa_existen)}}
                                                </v-chip>
                                             </v-list-item-content>

                                        </v-list-item>
                                    

                                        <v-list-item>
                                            <v-list-item-content>Marca:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zaa_marca }}
                                            </v-list-item-content>
                                        </v-list-item>
                                
                                        <v-list-item>
                                            <v-list-item-content>Módelo:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zaa_modelo }}
                                            </v-list-item-content>
                                        </v-list-item>

                                        <v-list-item>
                                            <v-list-item-content>Categoría:</v-list-item-content>
                                            <v-list-item-content class="align-end">
                                                {{ item.zaa_categoria }}
                                            </v-list-item-content>
                                        </v-list-item>
                                    </v-list>
                                </v-card>
                            </v-col>
                        </v-row>
                    </template>
                    
                    <template v-slot:footer>
                        <v-row class="mt-2" align="center" justify="center">
                            <span class="grey--text" style="margin-left:12px;">Elementos por página</span>
                            <v-menu offset-y>
                                <template v-slot:activator="{ on, attrs }">
                                    <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                                        {{ itemsPerPage }}
                                        <v-icon>mdi-chevron-down</v-icon>
                                    </v-btn>
                                </template>
                                <v-list>
                                    <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                                        <v-list-item-title>{{ number }}</v-list-item-title>
                                    </v-list-item>
                                </v-list>
                            </v-menu>
                            <v-spacer></v-spacer>
                            <span class="mr-4 grey--text">
                                    Página {{ page }} de {{ numberOfPages }}
                                <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
                                <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
                            </span>
                        </v-row>
                    </template>

                </v-data-iterator>
            </v-col>
        </v-row>
    </div>
</template>

<script>
    const axios = require('axios')
    import Header from '../../../components/Header';
    import menuModulos from '../../menuModulos'
    
    export default {
        name: 'Header', 
        components:{
            "app-header": Header,
            menuModulos,
        },
        
        created() {
            this.findSucursales()
            this.findArti()
        },
        
        data() {
            return {
                sucursales: [],
                articulos: [],
                sucursalId:'',
                itemsPerPageArray: [4, 12, 24],
                search: '',
                page: 1,
                itemsPerPage: 12,
                sortBy: 'zaa_nombre_arti',
                keys: [
                    'zaa_nombre_arti',
                    'zaa_clave',
                    'zaa_cantidad',
                    'zaa_marca',
                    'zaa_modelo',
                    'zaa_categoria',
                    'zaa_existen'
                ],
            }
        },

        computed: {
            numberOfPages () {
                return Math.ceil(this.articulos.length / this.itemsPerPage)
            },
        },

        methods:{


              status(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activó."
          }
          else{
              cam_estatus="Inactivo."
          }
          return cam_estatus
      },
      colortipo(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="green accent-4"
          }
          else{
              color_estatus="red accent-3"
          }
          return color_estatus
      },
            findSucursales(){
                axios.get("http://127.0.0.1:8000/sucursal/sucursales/activas/")
                .then(res=> this.sucursales = res.data)
            },
            findArti: function (event) {
                axios.get("http://127.0.0.1:8000/articulo/invSuc/?search=" + this.$route.params.id)
                .then(res => this.articulos = res.data)

                axios.get('http://127.0.0.1:8000/sucursal/'+ this.$route.params.id +'/')
                .then(res => { 
                    this.sucursalId = res.data.zdsu_nombre
                })
            },
            getColor (zaa_cantidad) {
                if (zaa_cantidad < 2) return 'red accent-3'
                else if (zaa_cantidad < 5) return 'orange accent-3'
                else return 'green accent-4'
            },
            nextPage () {
                if (this.page + 1 <= this.numberOfPages) this.page += 1
            },
            formerPage () {
                if (this.page - 1 >= 1) this.page -= 1
            },
            updateItemsPerPage (number) {
                this.itemsPerPage = number
            },
        },
    }
</script>