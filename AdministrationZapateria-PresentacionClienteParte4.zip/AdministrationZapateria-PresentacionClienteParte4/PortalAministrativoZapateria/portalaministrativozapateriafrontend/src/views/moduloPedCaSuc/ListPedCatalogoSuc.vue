Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra un listado de todos los pedidos catalogos de las sucursales 
<template>
<div cols="full"> 
    <v-row> 
        <v-col cols="md-2 xs-12">
            <menuModulos/>
        </v-col>  
        <v-col cols="md-10 xs-12">  
             <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">PEDIDOS CATÁLOGOS SUCURSAL</h1> 
            </div><br> 
            <v-tabs v-model="tab" centered icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1">Pedidos de sucursales</v-tab> 
                <v-tab href="#tab-2">Pedidos realizados</v-tab> 
            </v-tabs>
            <v-tabs-items v-model="tab">
                <v-tab-item value="tab-1">
                    <v-card :elevation="0">
                        <v-card-title class="card_title">
                            <div class="col-12" id="table_cabecera_color">
                                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                                <v-btn dark text class="btn_add" :disabled="canCReporte == false" @click="generarReporte()" v-if="permissions.can_manage_ped_cat_suc == true">
                                    Pedido matriz
                                </v-btn>
                            </div>  
                        </v-card-title>  
                        <div class="col-12" style="padding-top:0">
                            <v-data-table
                                id="tabla_datos"
                                :headers="headers" 
                                :items="clientes" 
                                :search="search"
                                :items-per-page="5"
                                :items-per-page-options="[5, 10, 15]"
                                no-results-text="No hay resultados."
                                no-data-text="No se tienen pedidos registrados." 
                                :footer-props="{
                                    showFirstLastPage: true,
                                    itemsPerPageText: 'Elementos por página ',
                                }"
                                :header-props="{ sortByText: 'Ordenar por' }"
                            >
                                <template v-slot:item.nombre="{ item }" >  
                                    <strong>{{item.nombre}}</strong>  
                                </template>      
                                <template v-slot:item.type="{ item }" >  
                                    <strong class="purple--text">{{item.type}}</strong>  
                                </template> 
                                <template v-slot:item.id="{ item }" >   
                                    <ItemsByUser :clienteID="item.id"/>
                                </template>  
                            </v-data-table>
                        </div>
                    </v-card> 
                </v-tab-item>
                <v-tab-item value="tab-2"> 
                    <PedidosR :empleado="empleado"/>   
                </v-tab-item>
            </v-tabs-items> 
        </v-col>
    </v-row> 
    <v-overlay :value="overlay">
        <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
    </v-overlay>  
    <br>   
</div> 
</template>
<script>
import Header from '../../components/Header';
import menuModulos from '../menuModulos' 
import ItemsByUser from './partials/_itemsByUser.vue'  
import PedidosR from './partials/_PedidosRealizados.vue' 
const moment = require('moment') 
const axios = require('axios')
export default {
     name: 'Header', 
    components:{ 
        "app-header": Header,
        menuModulos,  
        ItemsByUser,
        PedidosR
    }, 
    data() {
        return {
            canCReporte: true,
            empleado: [],
            IdSucursal: '',
            overlay: false,
            tab: null,
            search: '',
            headers: [
                {
                    text: 'Cliente',
                    align: 'start',
                    filterable: true,
                    value: 'nombre', 
                }, 
                { text: 'Tipo', value: 'type', sortable: false }, 
                { text: 'Catalogos', value: 'id', sortable: false },
            ], 
            clientes: [], 
            reporte: [],
            permissions: {
            can_manage_ped_cat_suc: false,
        },
        }
    },
    created() {
        this.find()
    },
    methods: {
        generarReporte(){
            this.overlay = true
            function callbackFin () { 
                console.log('Fin'); 
                setTimeout(function(){
                    console.log('Recargar')  
                    window.location.reload()
                }, 3000);
            } 
            let itemsOriginales = 0
            function callbackItems (items) { 
                setTimeout(function(){ 
                    items.forEach(item => {
                        item.zipcat_estatus_cat = 'Pedido centro de distribución'
                        axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + item.zipcat_id_itemped_cat + '/', item)
                        //console.log(item);
                        itemsOriginales++;
                        if(itemsOriginales === items.length) {
                            callbackFin();
                        }
                    }); 
                }, 3000); 
            }   
            let ItemsOri = [] 
            axios.get('http://127.0.0.1:8000/proveedor/proveedor/')
                .then(resPro => {
                    resPro.data.forEach(proveedor => {
                        this.reporte.push({
                            nombre: proveedor.zp_identify_mark,
                            proveedorId: proveedor.zp_id_proveedor,
                            items: []
                        })
                    });
                    axios.get('http://127.0.0.1:8000/pedido/itempedcat/')
                        .then(resItems => { 
                            this.reporte.forEach(reporte => {
                                resItems.data.forEach(item => {
                                    if(reporte.nombre == item.zipcat_marca){
                                        if(item.zipcat_id_sucursal == this.IdSucursal){ 
                                            if(item.zipcat_estatus_cat == 'Pendiente'){
                                                ItemsOri.push(item)
                                                reporte.items.push({
                                                    zpedsucat_id_cat: item.zipcat_id_catalogo,
                                                    zpedsucat_cant_ped: item.zipcat_cant, 
                                                    zpedsucat_id_ped_cat_sucur: ''
                                                })
                                            }  
                                        }
                                    } 
                                });
                            });   
                            let itemsNuevos = 0
                            this.reporte.forEach(repNew => {
                                if(repNew.items.length != 0){
                                    //console.log(repNew.nombre  + '-' + moment().locale('MX').format('YYMMDDHHmmSS'))
                                    let cab = {
                                        "zpedcsuc_nombre": repNew.nombre  + '-' + moment().locale('MX').format('YYMMDDHHmmSS'),  
                                        "zpedcsuc_status_ped": "Pedido centro de distribución",
                                        "zpedcsuc_id_sucursal": this.IdSucursal,
                                        "zpedcsuc_id_emple": this.empleado.zdem_id_usuario,
                                        "zpedcsuc_id_provee": repNew.proveedorId
                                    }
                                    axios.post('http://127.0.0.1:8000/pedcatsuc/cab/', cab)
                                    .then(resPedCab => {
                                        this.sumarItems(repNew.items).forEach(item => {
                                            item.zpedsucat_id_ped_cat_sucur = resPedCab.data.zpedcsuc_id_ped_cat_sucur
                                            //console.log(item)
                                            axios.post('http://127.0.0.1:8000/pedcatsuc/item/', item)
                                        });
                                    })
                                } 
                                itemsNuevos++;
                                if(itemsNuevos === this.reporte.length) {
                                    callbackItems(ItemsOri);
                                }
                            }); 
                        })
                })
            
        },
        find(){   


             axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_ped_cat_suc: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_pedidos_articulos_sucursales') { this.permissions.can_manage_ped_cat_suc = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                }) 


            let Items = []
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
            .then(res => {  
                axios.get('http://127.0.0.1:8000/empleado/?search=' + res.data[0].user)
                .then(resEmp => {  
                    this.empleado = resEmp.data[0]
                    this.IdSucursal = resEmp.data[0].zdem_id_sucursal
                    axios.get('http://127.0.0.1:8000/pedido/itempedcat/')
                        .then(resItems =>{
                            resItems.data.forEach(item => {
                            if(item.zipcat_id_sucursal == resEmp.data[0].zdem_id_sucursal){ 
                                    if(item.zipcat_estatus_cat == 'Pendiente'){
                                        Items.push(item)
                                    }  
                                }
                            });
                            if(Items.length == 0){
                                this.canCReporte = false
                            }  
                        })
                    let clie = []
                    axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + resEmp.data[0].zdem_id_sucursal)
                        .then(res => {
                            res.data.forEach(cliente => {
                                clie.push({
                                    nombre: cliente.nombre,
                                    id: cliente.zc_id_usuario,
                                    type: 'Afiliado' 
                                })
                            });
                        })  
                    this.clientes = clie  
                    }) 
            })         
        },  
        sumarItems(ITEMS){ 
            let pedidoSinDuplicados = ITEMS.reduce((acumulado, itemActual) => { 
            let ItemSimilar = acumulado.find(elemento => elemento.zpedsucat_id_cat === itemActual.zpedsucat_id_cat);
            if (ItemSimilar) {
                return acumulado.map((elemento) => {
                    if (elemento.zpedsucat_id_cat === itemActual.zpedsucat_id_cat ) {
                        return {
                            ...elemento,
                            zpedsucat_cant_ped: elemento.zpedsucat_cant_ped + itemActual.zpedsucat_cant_ped
                        }
                    } 
                    return elemento;
                });
                } 
                return [...acumulado, itemActual];
            }, []); 
            return pedidoSinDuplicados 
        }, 
    },
}
</script>
