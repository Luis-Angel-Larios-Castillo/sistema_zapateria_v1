Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo obtiene los datos del cliente
<template> 
        <strong>{{cliente.nombre}}</strong>  
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'idCliente'
    ],
    data() { 
        return { 
            cliente: '', 
        }
    },
    created() { 
        this.find()
    },
    methods: {  
        find(){  
            axios.get('http://127.0.0.1:8000/cliente/clientes/?search=' + this.idCliente)
            .then(res => { 
                this.cliente = res.data[0]
            })
        }
    },
}
</script>