Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra los pedidos realizados
<template>
    <v-container fluid> 
        <v-card :elevation="0"> 
            <v-card-title class="card_title">
                <div class="col-12" id="table_cabecera_color">
                    <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-select v-model="status" v-on:change="find()" class="select_status" :items="statusItems" dense rounded solo :rules="[v => !!v || 'Debe seleccionar una Estatus']"  label="Estatus" required/>
                </div> 
            </v-card-title>  
            <div class="col-12" style="padding-top:0">
                <v-data-table
                    id="tabla_datos"
                    :headers="headers" 
                    :items="pedi" 
                    :search="search"
                    :items-per-page="5"
                    :items-per-page-options="[5, 10, 15]"
                    no-results-text="No hay resultados."
                    no-data-text="No se tienen pedidos registrados." 
                    :footer-props="{
                        showFirstLastPage: true,
                        itemsPerPageText: 'Elementos por página ',
                    }"
                    :header-props="{ sortByText: 'Ordenar por' }"
                >
                    <template v-slot:item.zpedcsuc_nombre="{ item }" >  
                        <strong>{{item.zpedcsuc_nombre}}</strong> 
                    </template>      
                    <template v-slot:item.zpedcsuc_id_ped_cat_sucur="{ item }" >  
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn icon :to="'/DetailPedCatSucursal/'+ item.zpedcsuc_id_ped_cat_sucur+'/'" v-bind="attrs" v-on="on">
                                    <v-icon color="blue" >mdi-file-document-multiple-outline</v-icon>
                                </v-btn>
                            </template>
                            <span>Ver pedido</span>
                        </v-tooltip>
                        <v-tooltip bottom >
                            <template v-slot:activator="{ on, attrs }"> 
                                <v-btn v-if="item.zpedcsuc_status_ped == 'En tránsito sucursal'" icon @click="marcarLlego(item)" v-bind="attrs" v-on="on">
                                    <v-icon color="green" >mdi-package-variant</v-icon>
                                </v-btn>
                            </template>
                            <span>Cambiar estatus</span>
                        </v-tooltip>
                    </template>  
                </v-data-table>
            </div>
        </v-card> 
        <v-overlay :value="overlay">
            <v-progress-circular :size="70" :width="7" color="cyan" indeterminate/>    
        </v-overlay>
        <v-snackbar shaped color="green" outlined v-model="snackbar" :timeout="timeout">
            <h2 class="black--text" >{{ text }}</h2> 
            <template v-slot:action="{ attrs }">
                <v-btn color="blue" text v-bind="attrs" @click="snackbar = false">
                Cerrar
                </v-btn>
            </template>
        </v-snackbar> 
    </v-container>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'empleado'
    ],
    data() { 
        return { 
            overlay: false,
            IdEmpleado: '',
            snackbar: false,
            text: '',
            timeout: 3000,
            status: 'Pedido centro de distribución',
            statusItems: [
                'Pedido centro de distribución', 
                'Pedido a Proveedor',
                'En tránsito chofer a proveedor', 
                'Regreso chofer a centro de distribución',
                'En tránsito sucursal',
                'Llego sucursal' 
            ],
            search: '',
            headers: [
            {
                text: 'Pedido',
                align: 'start',
                filterable: true,
                value: 'zpedcsuc_nombre', 
            }, 
            { text: 'Sucursal', value: 'zpedcsuc_sucursal'}, 
            { text: 'Estatus', value: 'zpedcsuc_status_ped'}, 
            { text: 'Acciones', value: 'zpedcsuc_id_ped_cat_sucur', sortable: false },
            ],
            pedi: [], 
        }
    },
    created() { 
        this.find()
    },
    methods: { 
        marcarLlego(pedSuc){
            this.overlay = true 
            this.pedi = []
            pedSuc.zpedsuc_id_emple_mod = this.empleado
            pedSuc.zpedcsuc_status_ped = 'Llego sucursal'
            
            //'En tránsito sucursal'
            let itemsPed = 0
            axios.get('http://127.0.0.1:8000/pedido/itempedcat/')
                .then(resItem =>{
                    resItem.data.forEach(itemPed => { 
                        if(itemPed.zipcat_estatus_cat == 'En tránsito sucursal'){
                            if(pedSuc.zpedcsuc_proveedor_nombre == itemPed.zipcat_marca){
                                if(pedSuc.zpedcsuc_id_sucursal == itemPed.zipcat_id_sucursal){
                                    itemPed.zipcat_estatus_cat = 'Llego sucursal'
                                    //console.log(itemPed)  
                                    axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + itemPed.zipcat_id_itemped_cat + '/', itemPed)  
                                } 
                            } 
                        }
                        itemsPed++; 
                        if(itemsPed === resItem.data.length) {
                            setTimeout(function(){   
                                axios.put('http://127.0.0.1:8000/pedcatsuc/cab/' + pedSuc.zpedcsuc_id_ped_cat_sucur + '/', pedSuc)
                                    .then(res =>{ 
                                        window.location.reload()
                                    })
                            }, 3000);
                        }
                    });
                }) 
        },
        find(){ 
            this.pedi = [] 
            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/')
            .then(res => {
                res.data.forEach(element => { 
                    if(this.empleado.zdem_id_sucursal == element.zpedcsuc_id_sucursal){
                        if(element.zpedcsuc_status_ped ==  this.status){
                            this.pedi.push(element)
                        }
                    }
                    
                }); 
            }) 
        }
    },
}
</script>