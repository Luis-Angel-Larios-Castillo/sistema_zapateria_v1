Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo muestra toda la informacion del pedido
<template>
    <v-container fluid>  
        <app-header style="z-index: 135"/> 
        <br>
        <div class="col-10">
        <v-toolbar  id="table_cabecera_color_formulario" dark>
            <v-tabs v-model="tab"  icons-and-text>
                <v-tabs-slider/>
                <v-tab href="#tab-1">Pedido</v-tab> 
                <v-tab href="#tab-2">Items relacionados</v-tab> 
            </v-tabs>
            <PDF :id="pedCab.zpedcsuc_id_ped_cat_sucur"/>
            <v-btn dark text class="btn_add" :to="'/ListPedCatSucursal/'">
                regresar
            </v-btn> 
        </v-toolbar> 
            <v-tabs-items v-model="tab">
                <v-tab-item value="tab-1">
                    <v-card>    
                        <v-card-title>
                            <h3>Pedido de Sucursal: {{pedCab.zpedcsuc_nombre}}</h3>
                            <v-spacer/>
                            <h3>{{fecha(pedCab.zpedcsuc_fech_creat)}}</h3>
                            <v-spacer/>
                            
                        </v-card-title>
                        <v-card-title> 
                            <h4>Creado por: {{emplCrea.nombre}}</h4>
                            <v-spacer/> 
                            <h4>Estatus: {{pedCab.zpedcsuc_status_ped}}</h4> 
                        </v-card-title>
                        <v-card-title> 
                            <h4>Proveedor: {{proveedor.zp_nombre}} {{proveedor.zp_apell_pat}} {{proveedor.zp_apell_mat}}</h4>
                            <v-spacer/>
                            <h4>Identificador: {{proveedor.zp_identify_mark}}</h4> 
                        </v-card-title>
                        <v-card-title v-if="modif == true"> 
                            <h5>Modificado por: {{emplMod.nombre}}</h5>
                            <v-spacer/> 
                            <h5>Fecha de mod: {{fecha(pedCab.zpedsuc_fech_mod)}}</h5> 
                        </v-card-title> 
                        <v-toolbar dense dark v-if="pedCab.zpedcsuc_status_ped == 'Llego sucursal'">
                            <v-spacer></v-spacer>
                            <v-btn v-if="pedCab.zpedcsuc_puede_editar == true" @click="editar()" text class="btn_gped white--text">dejar de editar</v-btn>
                            <v-btn v-else @click="editar()" text class="btn_gped white--text">Editar</v-btn>
                        </v-toolbar> 
                        <v-card-text>  
                            <v-simple-table dense fixed-header>
                                <template v-slot:default>
                                    <thead>
                                        <tr>  
                                            <th class="text-center font-weight-black black--text">Nombre</th>
                                            <th class="text-center font-weight-black black--text">Marca</th> 
                                            <th class="text-center font-weight-black black--text">Cantidad solicitada</th>
                                            <th class="text-center font-weight-black black--text">Cantidad recibida</th>
                                        </tr>
                                    </thead>
                                    <tbody> 
                                        <tr v-for="item in reportes" :key="item.zpedsucat_id_item_ped_cat">   
                                            <td class="text-center">{{item.zpedsucat_nombre}}</td>
                                            <td class="text-center">{{item.zpedsucat_marca}}</td>  
                                            <td class="text-center">{{item.zpedsucat_cant_ped}}</td>   
                                            <td class="text-center" >                                  
                                                <v-text-field  v-if="pedCab.zpedcsuc_status_ped == 'Llego sucursal'"  class="fieldCant" :disabled="pedCab.zpedcsuc_puede_editar == false" v-model="item.zpedsucat_cant_ped_llego" v-on:change="ingresarCantidad(item)"  label="Cantidad"/>
                                                <p v-else>
                                                    {{item.zpedsucat_cant_ped_llego}}
                                                </p>
                                            </td> 
                                        </tr>
                                    </tbody>
                                </template>
                            </v-simple-table>  
                        </v-card-text>
                    </v-card>   
                </v-tab-item>
                <v-tab-item value="tab-2">  
                    <v-card :elevation="0">
                        <v-card-title class="card_title">
                            <div class="col-12" id="table_cabecera_color">
                                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                            </div>  
                        </v-card-title>  
                        <div class="col-12" style="padding-top:0">
                            <v-data-table
                                id="tabla_datos"
                                :headers="headers" 
                                :items="items" 
                                :search="search"
                                :items-per-page="5"
                                :items-per-page-options="[5, 10, 15]"
                                no-results-text="No hay resultados."
                                no-data-text="No se tienen pedidos registrados." 
                                :footer-props="{
                                    showFirstLastPage: true,
                                    itemsPerPageText: 'Elementos por página ',
                                }"
                                :header-props="{ sortByText: 'Ordenar por' }"
                            >
                                <template v-slot:item.zipcat_id_cliente="{ item }" > 
                                    <GetCliente :idCliente="item.zipcat_id_cliente"/>  
                                </template>   
                                <template v-slot:item.zipcat_id_itemped_cat="{ item }" v-if="pedCab.zpedcsuc_status_ped == 'Llego sucursal'">  
                                    <v-tooltip bottom>
                                        <template v-slot:activator="{ on, attrs }"> 
                                            
                                            <v-btn v-if="item.zipcat_estatus_cat == 'Llego sucursal'" icon @click="cambiarEstatus(item, 'Pendiente')" v-bind="attrs" v-on="on">
                                                <v-icon color="blue" >mdi-timetable</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Marcar como pendiente</span>
                                    </v-tooltip>
                                    <v-tooltip bottom>
                                        <template v-slot:activator="{ on, attrs }">  
                                            <v-btn v-if="item.zipcat_estatus_cat == 'Llego sucursal'" icon @click="cambiarEstatus(item, 'Listo para entregar')" v-bind="attrs" v-on="on">
                                                <v-icon color="green" >mdi-account-arrow-left-outline</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Marcar como listo para entregar</span>
                                    </v-tooltip>
                                    <!--
                                    <v-tooltip bottom>
                                        <template v-slot:activator="{ on, attrs }"> 
                                            <v-btn v-if="item.zipcat_estatus_cat == 'Llego sucursal'" icon @click="cambiarEstatus(item, 'Cancelado')" v-bind="attrs" v-on="on">
                                                <v-icon color="red" >mdi-file-cancel-outline</v-icon>
                                            </v-btn>
                                        </template>
                                        <span>Cancelar</span>
                                    </v-tooltip>
                                    -->
                                </template>  
                                <template v-slot:item.zipcat_id_itemped_cat="{ item }" v-else>   
                                </template>  
                            </v-data-table>
                        </div>
                    </v-card>  
                </v-tab-item>
            </v-tabs-items>     
        </div>
    </v-container>
</template>
<script>
import Header from '../../../components/Header';
const moment = require('moment')
import PDF from '../../../components/PDFPedSucCat.vue'
import GetCliente from './_GetCliente.vue' 
const axios = require('axios')
export default { 
    name: 'Header', 
    components:{ 
        PDF,
        "app-header": Header,
        GetCliente
    }, 
    data(){
        return {
            search: '',
            tab: null,
            headers: [
                {
                    text: 'Catalogo',
                    align: 'start',
                    filterable: true,
                    value: 'nombre_cat', 
                }, 
                { text: 'Cliente', value: 'zipcat_id_cliente'}, 
                { text: 'Marca', value: 'zipcat_marca'}, 
                { text: 'Estatus', value: 'zipcat_estatus_cat'}, 
                { text: 'Cantidad', value: 'zipcat_cant', align: 'center', sortable: false },
                { text: 'Acciones', value: 'zipcat_id_itemped_cat', align: 'center', sortable: false },
            ],  
            items: [],
            IdEmpleado: '',
            proveedor: [],
            tab: null,
            pedCab: [], 
            reportes: [], 
            emplCrea: [],
            emplMod: [],
            modif: false
        }
    },
    created(){ 
        this.find()
    }, 
    methods:{ 
        cambiarEstatus(item, status){
            item.zipcat_estatus_cat = status 
            if(item.zipcat_estatus_cat = 'Listo para entregar'){
                axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + item.zipcat_id_itemped_cat + '/', item)
                .then(resItem=>{
                    axios.get('http://127.0.0.1:8000/catalogo/' + item.zipcat_id_catalogo + '/')
                    .then(resCatalogo=>{
                        resCatalogo.data.zac_cantidad += item.zipcat_cant
                        axios.put('http://127.0.0.1:8000/catalogo/' + item.zipcat_id_catalogo + '/', resCatalogo.data)
                    })
                })
            }else{
                axios.put('http://127.0.0.1:8000/pedido/itempedcat/' + item.zipcat_id_itemped_cat + '/', item)
            } 
            
        },
        ingresarCantidad(item){  
            this.pedCab.zpedcsuc_id_emple_mod = this.IdEmpleado
            axios.put('http://127.0.0.1:8000/pedcatsuc/item/' + item.zpedsucat_id_item_ped_cat + '/', item)
                .then(resItem => {
                    axios.put('http://127.0.0.1:8000/pedcatsuc/cab/' + this.$route.params.id + '/', this.pedCab)
                    .then(res =>{
                        this.find()
                    })
                })
        },
        editar(item){
            this.pedCab.zpedcsuc_id_emple_mod = this.IdEmpleado
            this.pedCab.zpedcsuc_puede_editar = !this.pedCab.zpedcsuc_puede_editar
            axios.put('http://127.0.0.1:8000/pedcatsuc/cab/' + this.$route.params.id + '/', this.pedCab)
            .then(res =>{
                this.find()
            })
        },
        getEmpleadoCrea(cab){ 
            axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token )
                .then(resToken => {  
                    this.IdEmpleado = resToken.data[0].user 
                })
            axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedcsuc_id_emple)
                .then(resEmp => {
                    this.emplCrea = resEmp.data[0]
                })
            if(cab.zpedcsuc_id_emple_mod != null){
                axios.get('http://127.0.0.1:8000/empleado/?search=' + cab.zpedcsuc_id_emple_mod)
                .then(resEmp =>{
                    this.emplMod = resEmp.data[0]
                    this.modif = true
                })
            } 
        },
        fecha(date){
            return moment(date).locale('MX').format('DD-MM-YYYY LT')
        },    
        find(){
            this.items = []
            let repostesBruto = [] 
            axios.get('http://127.0.0.1:8000/pedcatsuc/cab/' + this.$route.params.id + '/')
            .then(resCab=> { 
                axios.get('http://127.0.0.1:8000/pedido/itempedcat/?search=' + resCab.data.zpedcsuc_id_sucursal)
                .then(resItems => {
                    resItems.data.forEach(item => {
                        if(resCab.data.zpedcsuc_id_sucursal == item.zipcat_id_sucursal){
                            if(item.zipcat_marca == resCab.data.zpedcsuc_proveedor_nombre){
                                this.items.push(item)
                            }
                        }    
                    }); 
                })
                axios.get('http://127.0.0.1:8000/proveedor/proveedor/' + resCab.data.zpedcsuc_id_provee + '/')
                    .then(resProvee =>{
                        this.proveedor = resProvee.data
                    })
                this.pedCab = resCab.data 
                this.getEmpleadoCrea(resCab.data)
                axios.get('http://127.0.0.1:8000/pedcatsuc/item/?search=' +this.$route.params.id )
                    .then(resItem => {  
                        resItem.data.forEach(item => { 
                            repostesBruto.push(item) 
                        }); 
                        this.reportes = repostesBruto 
                    })
                }) 
        }
    }
}
</script>
