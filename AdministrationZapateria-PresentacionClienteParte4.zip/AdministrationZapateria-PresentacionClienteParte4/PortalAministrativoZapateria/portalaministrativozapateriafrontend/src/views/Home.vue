Modifico: Miguel Angel Zamora Carmona
Descripción: Se agrego el componente _List que muestra los artículos registrados y el carrusel 
<template>
  <div cols="full">
    <div class="circulo">
      </div>
    <div class="slidersurb">
      <List/>
    </div>
  </div>
</template>
<script>
import List from './Home/_List.vue'
export default {
    components:{
        List
    },
    data: () => ({
    }),
  }
</script>
<style scoped>
.circulo {
     width: 900px;
     height: 850px;
     -moz-border-radius: 50%;
     -webkit-border-radius: 50%;
     border-radius: 50%;
     background: #fca311;
     top: -225px;
    z-index: 100;
    margin-left:-500px;
    position: absolute;
    
}

  .slidersurb{
    width: 100%;
    z-index: 101;
    position: absolute;

  }

</style>