Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra los detalles de los datos del empleado.

<template>
    <v-container grid-list-xs>
        <v-dialog  max-width="600">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{elements.zdem_nombre}} {{elements.zdem_apell_pat}} {{elements.zdem_apell_mat}} </strong>
        </p>
      </template>
      <v-card>
        
        <v-card-title class="headline">

        </v-card-title>
        <v-card-text>
            <v-alert dense text type="success" v-if="elements.zdem_existen == true" >
                El Empleado: <strong>{{elements.zdem_nombre}} {{elements.zdem_apell_pat}} {{elements.zdem_apell_mat}} </strong> Esta habilitado. 
            </v-alert>
            <v-alert dense text type="warning" color="red" v-if="elements.zdem_existen == false" >
                El Empleado: <strong>{{elements.zdem_nombre}} {{elements.zdem_apell_pat}} {{elements.zdem_apell_mat}}</strong> Esta deshabilitado.
            </v-alert>
            <div class="black--text"> 
                <p><strong>Sucursal </strong>
                <p>{{elements.zdem_sucursal_nombre}}</p>
                
                <p><strong>Numeros de Contacto: </strong> <br>{{elements.zdem_num_tel}}  ---- {{elements.zdem_num_cel}}</p>
                <p><strong>Fecha de Nacimiento: </strong> <br>{{elements.zdem_fech_nacim}}</p>
                <p><strong>Dirección </strong><br>
                <p><strong>Calle Principal: </strong> <br>{{elements.zdem_dir_calle_1}}</p>
                <p><strong>Calle Interconexión: </strong> <br>{{elements.zdem_dir_calle_2}}</p>
                <p><strong>No.Interior: </strong>{{elements.zdem_dir_num_int}} --- <strong>No.Exterior:</strong> {{elements.zdem_dir_num_ext}} </p>
                <p><strong>Colonia: </strong> {{elements.zdem_dir_colonia}} <strong>C.P.</strong>{{elements.zdem_dir_cod_postal}} </p>
                <p><strong>Lugar de Residencia </strong>
                <p>{{elements.zdem_dir_municipio}} {{elements.zdem_dir_estado}}, {{elements.zdem_dir_pais}}</p>
                <p class="red--text"><strong>Fecha de creación: </strong>{{fecha(elements.zdem_fech_crea)}}</p>
                <p class="red--text"><strong>Fecha de ultima modificación: </strong>{{fecha(elements.zdem_fech_mod)}}</p>
                
               
          
                
          
            </div>
        </v-card-text>
      </v-card>
    </v-dialog>
    </v-container>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
export default {
    props:[
        'elements'
    ], 
    data(){
        return { 
        }
    },
    methods:{ 
      fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
}}
</script>