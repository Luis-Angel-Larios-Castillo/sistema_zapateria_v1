Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra el registro de los datos del empleado.

<template>
<div cols="full">
    <v-row>
      <v-col cols="md-2 xs-12" >
          <menuModulos/>
      </v-col> 
      <v-col cols="md-10 xs-12" >
         <app-header style="z-index: 135"/> 
        <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">EMPLEADOS</h1>
            </div><br>

                   <v-card :elevation="0">
                     <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                      <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text to="/EmpleadosHist/" class="btn_csv" v-show="permissions.can_manage_empleados == true">
                Historial
              </v-btn>
                    <v-btn dark text :to="'/Usuarios'" class="btn_add" v-show="permissions.can_manage_empleados == true">
                            Agregar
                        </v-btn>
                        </div>
                    </v-card-title>
        <div class="col-12" style="padding-top:0">
        <v-data-table
          id="tabla_datos"
          :headers="headers"
          :search="search"
          :items="elementsa"
          :footer-props="{
            showFirstLastPage: true,
            itemsPerPageText: 'Elementos por página ',
            }"
          :header-props="{ sortByText: 'Ordenar por' }">
         
        
        <template v-slot:item.zdem_nombre="{ item }">
          <dempleado :elements="item" />
        </template>

        <template v-slot:item.zdem_dir_municipio="{ item }">
            {{item.zdem_dir_municipio}} {{item.zdem_dir_estado}}, {{item.zdem_dir_pais}}
        </template>

        <template v-slot:item.actions="{ item }">
           <v-row align="center">
             <v-col>
                <v-btn icon :to="'/aempleado/'+ item.zdem_id_empleado+'/'" v-if="permissions.can_manage_empleados == true">
                  <v-icon color="blue" >mdi-pencil-outline</v-icon>
                </v-btn>
                 <v-btn icon v-else disabled>
                  <v-icon color="blue" >mdi-pencil-outline</v-icon>
                </v-btn>
             </v-col>
             <v-col>
            <eempleado :elementD="{item, permissions}"/> 
            </v-col>


             <v-col>
            <v-tooltip bottom v-if="item.zdem_existen == true">
                  <template v-slot:activator="{ on, attrs }">
                      <v-icon  color="success" @click="desactivar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_empleados == false">
                          mdi-eye
                      </v-icon>
                  </template>
                  <span>Desactivar</span>
              </v-tooltip>

               
                
              <v-tooltip bottom v-if="item.zdem_existen == false">
                  <template v-slot:activator="{ on, attrs }">
                      <v-icon  color="red" @click="activar (item)" v-bind="attrs" v-on="on" :disabled="permissions.can_manage_empleados == false">
                          mdi-eye-off-outline
                      </v-icon>
                  </template>
                  <span>Activar</span>  
              </v-tooltip>
            </v-col>
            </v-row>
          </template>
        </v-data-table> 
         </div>
        </v-card>
      </v-col>
      
    </v-row> 
</div>
  
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import Header from '../../components/Header';
import menuModulos from '../menuModulos' 
import dempleado from './DetalleEmpleado'
import eempleado from './DeleteEmpleado'
import styles from '../../../public/Styles'
  export default {
     name: 'Header', 
    components:{
      "app-header": Header,
      menuModulos,
      dempleado,
      eempleado
   
    },

    created(){
      this.find()
    },
    data () {
      return{
     
      elements:Object,
      search: '',
      headers: [
        {
          text: 'Nombre',
          align: 'start',
          sortable: false,
          value: 'zdem_nombre',
        },
          { text: 'Sucursal', value: 'zdem_sucursal_nombre' },
          { text: 'Número de Celular', value: 'zdem_num_cel' },
          { text: 'Lugar de residencia', value: 'zdem_dir_municipio' },
          { text: 'Colonia', value: 'zdem_dir_colonia' },
          { text: 'Acciones', value: 'actions', sortable: false, align:'center'},
           
      ],
      isAdmin: false,
      elementsa:[],
      permissions: {
            can_manage_empleados: false,
            //can_manage_empleados_hist: false,
        },
      
      }

          },
  
    methods: {
        find(){


          axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_empleados: true,
                                    //can_manage_empleados_hist: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_empleados') { this.permissions.can_manage_empleados = true}
                                                        //if(resPer.data.codename == 'manage_empleados_historico') { this.permissions.can_manage_empleados_hist = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })

        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
        .then(resUser => { 
          
          axios.get('http://127.0.0.1:8000/empleado/?search=' + resUser.data[0].user)
          .then(resEmp => { 
            axios.get('http://127.0.0.1:8000/usuario/getusuario/' + resUser.data[0].user + '/')
            .then(resGetData=> { 
              if (resGetData.data.is_superuser == true){
                this.isAdmin = true 
                axios.get('http://127.0.0.1:8000/empleado/' )
                .then(res => this.elementsa = res.data)
              } else{
                axios.get('http://127.0.0.1:8000/empleado/?search=' + resEmp.data[0].zdem_id_sucursal )
                .then(res => this.elementsa = res.data)
              }
            })  
          })
        }) 
       //console.log(this.elementsa );
       
      },

       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
    activar (m) {
            const URL = 'http://127.0.0.1:8000/empleado/'+m.zdem_id_empleado+'/'
            axios.put(URL, {
                zdem_id_usuario:m.zdem_id_usuario,
                zdem_nombre:m.zdem_nombre,
                zdem_apell_pat:m.zdem_apell_pat,
                zdem_apell_mat:m.zdem_apell_mat,
                zdem_num_tel:m.zdem_num_tel,
                zdem_num_cel:m.zdem_num_cel,
                zdem_fech_nacim:m.zdem_fech_nacim,
                zdem_dir_pais:m.zdem_dir_pais,
                zdem_correo:m.zdem_correo,
                zdem_dir_estado:m.zdem_dir_estado,
                zdem_dir_municipio:m.zdem_dir_municipio,
                zdem_dir_colonia:m.zdem_dir_colonia,
                zdem_dir_cod_postal:m.zdem_dir_cod_postal,
                zdem_dir_calle_1:m.zdem_dir_calle_1,
                zdem_dir_calle_2:m.zdem_dir_calle_2,
                zdem_dir_num_int:m.zdem_dir_num_int,
                zdem_dir_num_ext:m.zdem_dir_num_ext,
                zdem_fech_crea:m.zdem_fech_crea,
                zdem_fech_mod:m.zdem_fech_mod,
                zdem_id_sucursal:m.zdem_id_sucursal,
                zdem_existen : true, 
            }).catch(error => console.log(error))

           const URLUpdate = 'http://127.0.0.1:8000/usuario/getusuario/'+m.zdem_id_usuario+'/'
        axios.put(URLUpdate,{
          zdus_correo:m.zdem_correo,
          is_active: true,
        }).catch(error => console.log(error))
        window.location.reload()
      },
        
        desactivar (m) {
            const URL = 'http://127.0.0.1:8000/empleado/'+m.zdem_id_empleado+'/'
            axios.put(URL, {
                zdem_id_usuario:m.zdem_id_usuario,
                zdem_nombre:m.zdem_nombre,
                zdem_apell_pat:m.zdem_apell_pat,
                zdem_apell_mat:m.zdem_apell_mat,
                zdem_num_tel:m.zdem_num_tel,
                zdem_num_cel:m.zdem_num_cel,
                zdem_fech_nacim:m.zdem_fech_nacim,
                zdem_dir_pais:m.zdem_dir_pais,
                zdem_dir_estado:m.zdem_dir_estado,
                zdem_dir_municipio:m.zdem_dir_municipio,
                zdem_dir_colonia:m.zdem_dir_colonia,
                zdem_dir_cod_postal:m.zdem_dir_cod_postal,
                zdem_dir_calle_1:m.zdem_dir_calle_1,
                zdem_dir_calle_2:m.zdem_dir_calle_2,
                zdem_dir_num_int:m.zdem_dir_num_int,
                zdem_dir_num_ext:m.zdem_dir_num_ext,
                zdem_correo:m.zdem_correo,
                zdem_fech_crea:m.zdem_fech_crea,
                zdem_fech_mod:m.zdem_fech_mod,
                zdem_id_sucursal:m.zdem_id_sucursal,
                zdem_existen : false, 
            }).catch(error => console.log(error))
         
      const URLUpdate = 'http://127.0.0.1:8000/usuario/getusuario/'+m.zdem_id_usuario+'/'
        axios.put(URLUpdate,{
          zdus_correo:m.zdem_correo,
          is_active: false,
        
        }).catch(error => console.log(error))
        window.location.reload()
      },
    },
  }
</script>
