Autor: Elisa Huerta Corona.
Descripción: En el presente archivo se muestra la actualización de los datos del empleado.
<template>
    <v-container fluid>
      <div v-if="permissions.can_manage_empleados == true">
        <app-header style="z-index: 135"/> 
        <div class="col-9">
            <v-toolbar class="" flat align="center" justify="space-around" id="table_cabecera_color_formulario">
                <v-toolbar-title>
                    <v-icon right dark>
                    mdi-account-convert
                    </v-icon>
                    <strong id="title_editar"> Edición del cliente:  {{actualizar.zdem_nombre}} {{actualizar.zdem_apell_pat}} {{actualizar.zdem_apell_mat}}</strong>
                </v-toolbar-title>
                <v-spacer/>
                <v-btn to="/Empleados/" outlined class="btn_add" color="#F7F9F9">
                    Regresar
                </v-btn>
            </v-toolbar>
            <div>
                    <v-container  id="tabla_datos_dos" class="col-12">
                        <v-form ref="form" v-model="valid" lazy-validation>
                          <v-alert id="title_formulario" dense icon="mdi-account-check">
                            <strong>DATOS PERSONALES</strong>
                          </v-alert>
                            <v-row>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_nombre" :rules="nameRules" label="Nombre:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. José Arturo" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_apell_pat" :rules="apepRules" label="Apellido Paterno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Fernández" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_apell_mat" :rules="apemRules" label="Apellido Materno:" required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ ]/g,'');" placeholder="Ejem. Jiménez" maxlength="20" title="Sólo se permiten letras"></v-text-field>
                                </v-col>
                            </v-row>
                             <v-row>
                                    <v-col cols="13">
                                        <v-menu
                                            ref="menu"
                                            v-model="menu"
                                            :close-on-content-click="false"
                                            :return-value.sync="date"
                                            transition="scale-transition"
                                            offset-y
                                            min-width="auto">
                                            
                                            <template v-slot:activator="{ on, attrs }">
                                                <v-text-field
                                                    v-model="actualizar.zdem_fech_nacim"
                                                    label="Fecha de Nacimiento"
                                                    prepend-icon="mdi-calendar"
                                                    readonly
                                                    v-bind="attrs"
                                                    v-on="on">
                                                </v-text-field>
                                            </template>
                                            <v-date-picker
                                                v-model="actualizar.zdem_fech_nacim"
                                                no-title
                                                locale="es-mx"
                                                scrollable>
                                            <v-spacer></v-spacer>
                                            <v-btn text color="primary" @click="menu = false">
                                                Cancelar
                                            </v-btn>
                                            <v-btn
                                                text
                                                color="primary"
                                                @click="$refs.menu.save(date)">
                                                Guardar
                                            </v-btn>
                                            </v-date-picker>
                                        </v-menu>
                                    </v-col>
                                </v-row>
                            <v-alert id="title_formulario" dense icon="mdi-home">
                              <strong>DIRECCIÓN - LUGAR DE RECIDENCIA</strong>
                            </v-alert>
                            <v-row>
                                <v-col>
                                    <v-text-field v-model="actualizar.zdem_dir_pais" :rules="paisRules" label="País:" required :counter="20" readonly></v-text-field>
                                </v-col>
                                <v-col>
                                    <!--<v-select v-model="actualizar.zdem_dir_estado" v-on:change="filtar()"  :rules="edoRules" label="Estado:" required :counter="20"></v-select>-->
                                    <v-select v-model="actualizar.zdem_dir_estado" v-on:change="filtar()" :items="estado" item-text="estado_nombre" :rules="[v => !!v || 'Se requiere seleccionar un Estado.']" label="Estado:" required/>
                                </v-col>
                                 <v-col>
                                    <!--<v-select v-model="actualizar.zdem_dir_municipio" :rules="muniRules" label="Municipio:" required :counter="30"></v-select>-->
                                    <v-select v-model="actualizar.zdem_dir_municipio" :items="municipio" item-text="name" :rules="[v => !!v || 'Se requiere seleccionar un Municipio.']" label="Municipio:" required/>
                                </v-col>
                              </v-row>
                              <v-row>
                                 <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_dir_colonia" :rules="colRules" label="Barrio/Colonia:"  required :counter="20" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ.,-:/0-9 ]/g,'');" placeholder="Ejem. El Bosque" maxlength="20"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_dir_calle_1" :rules="callpRules" label="Calle Principal:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Calle López Mateos" maxlength="50"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_dir_calle_2" :rules="calliRules" label="Calle/s de Interconexión:" required :counter="50" oninput="this.value=this.value.replace(/[^A-Za-zñÑáÁéÉíÍóÓúÚ().,-:/0-9 ]/g,'');" placeholder="Ejem. Entre Calle las Rosas y Calle Loma Bonita" maxlength="50"></v-text-field>
                                </v-col>

                               </v-row>
                                <v-row>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_dir_num_ext" :rules="numeRules" label="N. Exterior:" required :counter="25" maxlength="25" type="text" title="Si no cuentas con un N. Exterior ingresar: N/A o S/N"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_dir_num_int" :rules="numRules" label="N. Interior:" required :counter="25" maxlength="25" title="Si no cuentas con un N. Interior ingresar: N/A o S/N" type="text"></v-text-field>
                                </v-col>
                               
                                <v-col>
                                    <v-text-field v-model="actualizar.zdem_dir_cod_postal" :rules="codigoRules" label="Código Postal:" oninput="this.value=this.value.replace(/[^0-9]/g,'');" required :counter="5" placeholder="Ejem. 90684" maxlength="5"></v-text-field>
                                </v-col>
                            </v-row>
                                
                            
                            <v-alert id="title_formulario" dense icon="mdi-card-account-phone">
                            <strong>Información de Contacto</strong>
                          </v-alert>
                            <v-row>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_num_tel" v-mask="'###-###-##-##'" max="13" :rules="telRules" label="Teléfono Domiciliar:" required oninput="this.value=this.value.replace(/[^0-9^-]/g,'');" counter placeholder="Ejem. 245-154-24-21" title="Sólo se permiten datos númericos"></v-text-field>
                                </v-col>
                                <v-col cols="4">
                                    <v-text-field v-model="actualizar.zdem_num_cel" v-mask="'###-###-##-##'" max="13" :rules="celRules" label="Número de Celular:" required oninput="this.value=this.value.replace(/[^0-9^-]/g,'');"  counter placeholder="Ejem. 245-875-35-20" title="Sólo se permiten datos númericos"></v-text-field>
                                </v-col><br>
                              
                                  <v-col cols="4" >
                                    <v-select v-model="actualizar.zdem_id_sucursal" :items="sucursal" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una sucursal']"  label="Sucursal" required/>
                                  </v-col>
                                </v-row>
                                  <br><br>
                            <v-row align="center" justify="space-around">
                                <v-btn :disabled="!valid" id="btn_actualizar_formulario" x-large class="mr-4" @click="validate">
                                    Actualizar 
                                    <v-icon right dark>
                                        mdi-update
                                    </v-icon>
                                </v-btn>
                                <v-btn x-large id="btn_cancelar_formulario" class="mr-4" @click="cancelar">
                                    Cancelar
                                    <v-icon right dark>
                                        mdi-close-circle
                                    </v-icon>
                                </v-btn>
                            </v-row>
                        </v-form>
                        <br>
                    </v-container>
                </div>
            </div>
       
        </div>
      <div v-else>
         <ErrorPage403/>
      </div>
    </v-container>
</template>

<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue'
import esta from "../../assets/json/muni.json";
import axios from "axios";
  export default {
     name: 'Header', 
    components:{
    "app-header": Header,
    ErrorPage403
  },
    created() {
      this.busqpermisos()
      this.buscar()
      this.getSucursal()
    },
    data: () => ({
      actualizar:[],
      sucursal: [], 
      empleado:[],
      date: new Date().toISOString().substr(0, 10),
      menu: false,
      valid: true,
      
      nameRules: [
       v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Nombre" debe ser mayúscula',
       v => !!v || 'Se requiere el nombre.',
       v => (v && v.length >= 2) || 'El campo "Nombre" debe tener más de 2 caracteres.',
       v => (v && v.length <= 20) || 'El campo "Nombre" no debe tener más de 20 caracteres.',
      ],

      apepRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Paterno" debe ser mayúscula',
        v => !!v || 'Se requiere el apellido paterno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Paterno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Paterno" no debe tener más de 20 caracteres.',
      ],
    
      apemRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Apellido Materno" debe ser mayúscula',    
        v => !!v || 'Se requiere el apellido materno.',
        v => (v && v.length >= 3) || 'El campo "Apellido Materno" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Apellido Materno" no debe tener más de 20 caracteres.',
        
      ],
     
      callpRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle Principal" debe ser mayúscula',    
        v => !!v || 'Se requiere la calle principal.',
        v => (v && v.length >= 5) || 'El campo "Calle Principal" debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El campo "Calle Principal" no debe tener más de 30 caracteres.',
      ],
  
      calliRules: [
        v => /(?=.*[A-Z])/.test(v) || 'La primera letra del campo "Calle/s de Interconexión" debe ser mayúscula',
        v => !!v || 'Se requiere la calle interconexión.',
        v => (v && v.length >= 5) || 'El registro debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El registro no debe tener más de 30 caracteres.',
      ],

      numeRules: [
        v => !!v || 'Se requiere el número exterior.',
        //v => (v && v.length >= 1) || 'El campo "N. Exterior" debe tener más de 1 caracteres.',
        //v => (v && v.length <= 5) || 'El campo "N. Exterior" no debe tener más de 5 caracteres.',
      ], 
      
      numRules: [
        v => !!v || 'Se requiere el número interior.',
        //v => (v && v.length >= 1) || 'El campo "N. Interior" debe tener más de 1 caracteres.',
        //v => (v && v.length <= 5) || 'El campo "N. Interior" no debe tener más de 5 caracteres.',
      ],
     
      colRules: [
        v => !!v || 'Se requiere ingresar una Colonia.',
        v => (v && v.length >= 5) || 'El campo "Colonia" debe tener más de 5 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Colonia" no debe tener más de 20 caracteres.',
      ],
     
      codigoRules: [
        v => !!v || 'Se requiere el código postal.',
        //v => (v && v.length >= 4) || 'El campo "Código Postal" debe tener más de 4 caracteres.',
       // v => (v && v.length <= 5) || 'El campo "Código Postal" no debe tener más de 5 caracteres.',
      ],
      
      municipio: [],
      /*muniRules: [
        v => !!v || 'Se requiere ingresar un Municipio.',
        v => (v && v.length >= 5) || 'El campo "Municipio" debe tener más de 5 caracteres.',
        v => (v && v.length <= 30) || 'El campo "Municipio" no debe tener más de 30 caracteres.',
      ],*/
      estado: esta, 
      /*edoRules: [
        v => !!v || 'Se requiere ingresar un Estado.',
        v => (v && v.length >= 3) || 'El campo "Estado" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "Estado" no debe tener más de 20 caracteres.',
      ],*/
      pais: 'México',
      paisRules: [
        v => !!v || 'Se requiere el país.',
        v => (v && v.length >= 3) || 'El campo "País" debe tener más de 3 caracteres.',
        v => (v && v.length <= 20) || 'El campo "País" no debe tener más de 20 caracteres.',
      ],
      celRules: [
        v => !!v || 'Se requiere el número de celular.',
        v => (v && v.length == 13) || 'El campo "Número de Celular" debe tener al menos 10 caracteres.',
      ],
      telRules: [
        v => !!v || 'Se requiere el número de teléfono.',
        v => (v && v.length == 13) || 'El campo "Teléfono Domiciliar" debe tener al menos 10 caracteres.',
      ],
      sucur: null,

      permissions: {
            can_manage_empleados: false,
           
        },

   
    }),
     methods: {
       busqpermisos(){

         axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_empleados: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_empleados') { this.permissions.can_manage_empleados = true}
                                                                                                               
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })
      },

        filtar: function (event){ 
        for(let i = 0; i < this.estado.length; i++){
          if(this.estado[i].estado_nombre == this.actualizar.zdem_dir_estado )
            this.municipio = this.estado[i].municipios
          } 
        },

      buscar(){
          axios.get('http://127.0.0.1:8000/empleado/'+ this.$route.params.id +'/')
          .then(res => {
           this.actualizar = res.data
           this.filtar()
          })
      },
      validate(){
        this.empleado={
          zdem_id_usuario:this.actualizar.zdem_id_usuario,
          zdem_nombre:this.actualizar.zdem_nombre,
          zdem_apell_pat:this.actualizar.zdem_apell_pat,
          zdem_apell_mat:this.actualizar.zdem_apell_mat,
          zdem_id_sucursal:this.actualizar.zdem_id_sucursal,
          zdem_num_tel:this.actualizar.zdem_num_tel,
          zdem_num_cel:this.actualizar.zdem_num_cel,
          zdem_fech_nacim:this.actualizar.zdem_fech_nacim,
          zdem_dir_pais:this.actualizar.zdem_dir_pais,
          zdem_dir_estado:this.actualizar.zdem_dir_estado,
          zdem_dir_municipio:this.actualizar.zdem_dir_municipio,
          zdem_dir_colonia:this.actualizar.zdem_dir_colonia,
          zdem_dir_cod_postal:this.actualizar.zdem_dir_cod_postal,
          zdem_dir_calle_1:this.actualizar.zdem_dir_calle_1,
          zdem_dir_calle_2:this.actualizar.zdem_dir_calle_2,
          zdem_dir_num_int:this.actualizar.zdem_dir_num_int,
          zdem_dir_num_ext:this.actualizar.zdem_dir_num_ext,
          zdem_existen :this.actualizar.zdem_existen, 
        }
        this.$refs.form.validate()
        this.submit()
      },

       getSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
        .then(res => this.sucursal = res.data)
      },
       cancelar () {
        this.$router.push({ name: 'Empleados' });
      },
      reset () {
        this.$refs.form.reset()
      },
        submit () {
          axios.put('http://127.0.0.1:8000/empleado/'+ this.$route.params.id +'/',this.empleado)
          .then(res =>{   this.$router.push({ name: 'Empleados' });})
         .catch(error => console.log(error));
      
        
          
      }
    
    }
  }

</script>