Autor: Elisa Huerta Corona.
Descripción: El presente archivo es para eliminar el empleado.

<template>
  <v-container>
    <v-tooltip bottom >
        <template v-slot:activator="{ on, attrs }">
           <v-btn icon color="#5B5B5B" @click.stop="dialog = true" v-bind="attrs" v-on="on" :disabled="elementD.permissions.can_manage_empleados == false">
          <v-icon color="red">mdi-delete</v-icon>
        </v-btn>
        </template>
        <span>Eliminar</span>
    </v-tooltip> 
    <v-dialog v-model="dialog" max-width="500">
      <v-card> 
        <v-container> 
          <v-alert dense text color="red" type="info" border="top">
            <strong>Se va a eliminar el Empleado:<br>{{elementD.item.zdem_nombre}} {{elementD.item.zdem_apell_pat}} {{elementD.item.zdem_apell_mat}}</strong>
          </v-alert>
          <v-card-text class="black--text">
            <h4>¿Está de acuerdo en eliminarlo?</h4>
          </v-card-text>
          <v-form ref="form" v-model="valid" lazy-validation m>
            <v-text-field v-model="motivo"  :rules="motivoRules" label="Motivo" required/>
              <br>
              <v-row align="center" justify="space-around">
                <v-btn @click="dialog = false" outlined color="red">
                  Cancelar
                  <v-icon right dark>mdi-close-circle</v-icon>
                </v-btn> 
                <v-btn :disabled="!valid" color="success" class="mr-4" @click="validate" outlined>
                    Guardar 
                    <v-icon right dark>mdi-check-all</v-icon>
                </v-btn>  
              </v-row>
            </v-form> 
            <br> 
        </v-container>
      </v-card> 
    </v-dialog>    
  </v-container> 
</template>

<script> 
const axios = require('axios')
export default {
    props:[
        'elementD'
    ],
    data () {
      return {
        valid: true, 
        motivo: '',
        motivoRules: [
          v => !!v || 'El motivo es obligatorio',
          v => (v && v.length >= 5) || 'El motivo debe tener 5 o más caracteres',
          v => (v && v.length <= 150) || 'El nombre no debe tener más de 150 caracteres',
        ],
        dialog: false, 
        User: '',  
    }
    },
    created() {
      this.getUser()
    },
    methods:{
      validate(){
        if (this.$refs.form.validate()){ 
          this.aceptar()
        }  
      },
      getUser(){ 
        axios.get("http://127.0.0.1:8000/usuario/token/?search=" + localStorage.token )
          .then(res => this.User = res.data[0].user ) 
      }, 
      aceptar(){  
        let empHist = {
          zdemh_nombre: this.elementD.item.zdem_nombre,
          zdemh_apell_pat: this.elementD.item.zdem_apell_pat,
          zdemh_apell_mat: this.elementD.item.zdem_apell_mat,
          zdemh_num_tel: this.elementD.item.zdem_num_tel,
          zdemh_num_cel: this.elementD.item.zdem_num_cel,
          zdemh_fech_nacim: this.elementD.item.zdem_fech_nacim,
          zdemh_dir_pais: this.elementD.item.zdem_dir_pais,
          zdemh_dir_estado: this.elementD.item.zdem_dir_estado,
          zdemh_dir_municipio: this.elementD.item.zdem_dir_municipio,
          zdemh_dir_colonia: this.elementD.item.zdem_dir_colonia,
          zdemh_dir_cod_postal: this.elementD.item.zdem_dir_cod_postal,
          zdemh_dir_calle_1: this.elementD.item.zdem_dir_calle_1,
          zdemh_dir_calle_2: this.elementD.item.zdem_dir_calle_2,
          zdemh_dir_num_int: this.elementD.item.zdem_dir_num_int,
          zdemh_dir_num_ext: this.elementD.item.zdem_dir_num_ext,
          zdemh_correo: this.elementD.item.zdem_correo,
          zdemh_motivo: this.motivo,
          zdemh_fech_cre: this.elementD.item.zdem_fech_crea,
          zdemh_id_usuario: this.elementD.item.zdem_id_usuario,
          zdemh_id_sucursal: this.elementD.item.zdem_id_sucursal,
          zdemh_usua_delet: this.User
        }  
        let URL = 'http://127.0.0.1:8000/empleado/'+ this.elementD.item.zdem_id_empleado
        axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.elementD.item.zdem_id_usuario + "/" )
          .then(res => {
            axios.put("http://127.0.0.1:8000/usuario/getusuario/" + this.elementD.item.zdem_id_usuario + "/", { 
              zdus_correo: res.data.zdus_correo,
              is_active: false,
              is_staff: res.data.is_staff,
              is_superuser: res.data.is_superuser,
              is_eliminated: true
            } )
            .then(resU => {
              axios.post("http://127.0.0.1:8000/empleado/empleados/historico/", empHist)
                .then(rNew => {
                  axios.delete(URL)
                    .then(rDelete=>{
                      this.dialog = false
                      window.location.reload()
                    })
                }) 
            })
          } )           
      }
    },
  }
</script>