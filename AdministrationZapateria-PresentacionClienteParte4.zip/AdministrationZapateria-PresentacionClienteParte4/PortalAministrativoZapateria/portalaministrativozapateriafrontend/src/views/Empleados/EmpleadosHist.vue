Autor: Miguel Angel Zamora Carmona
Descripción: En el presente archivo se muestra el registro de los datos de los empleados eliminados.
<template>
  <div cols="full">
    <v-row>
      <v-col cols="md-2 xs-12" >
          <menuModulos/>
      </v-col> 
      <v-col cols="md-10 xs-12" >
      <div align="center" justify="space-around">
                    <hr class="line_superior">
                    <h1 id="title"> HISTÓRICO DE EMPLEADOS</h1>
                 </div><br>
          <v-card :elevation="0">
           <v-card-title class="card_title">
             <div class="col-12" id="table_cabecera_color">
                <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                <v-spacer/>
                <v-btn  :to="'/Empleados/'" outlined class="btn_add" color="#F7F9F9">
                 <v-icon>
                mdi-arrow-left-circle
                 </v-icon>
                Regresar
              </v-btn>
             </div>
           </v-card-title>
      <div class="col-12" style="padding-top:0">
        <v-data-table
          id="tabla_datos"
          :headers="headers"
          :search="search"
          :items="elements"
          no-results-text="No hay resultados."
          no-data-text="No se han eliminado empleados" 
          :footer-props="{
            showFirstLastPage: true,
            itemsPerPageText: 'Elementos por página ',
            }"
          :header-props="{ sortByText: 'Ordenar por' }"
        >  
        <template v-slot:item.zdemh_nombre="{ item }"> 
            <sEmpleado  :element="item" /> 
        </template>  
        <template v-slot:item.zdemh_fech_dele="{ item }">
              {{fecha(item.zdemh_fech_dele)}}
        </template> 
        </v-data-table>
      </div> 
        </v-card>
      </v-col>
    </v-row> 
</div>
</template>
<script>
const moment = require('moment')
const axios = require('axios')
import menuModulos from '../menuModulos'  
import sEmpleado from './sEmpleadoHist.vue'
  export default {
    components:{
      menuModulos, 
      sEmpleado,
    }, 
    created(){
      this.find()
    },
    data () {
      return{ 
        elements:Object,
        search: '',
        headers: [
            {
            text: 'Nombre',
            align: 'start',
            sortable: false,
            value: 'zdemh_nombre',
            }, 
            { text: 'Tel. de Casa', value: 'zdemh_num_tel' }, 
            { text: 'Tel. celular', value: 'zdemh_num_cel' }, 
            { text: 'Correo', value: 'zdemh_correo' }, 
            { text: 'Fecha de eliminación', value: 'zdemh_fech_dele' }, 
        ],
        elements:[], 
      }

    },
    methods: {
        find(){
            axios.get('http://127.0.0.1:8000/empleado/empleados/historico/')
                .then(res => this.elements = res.data)
                .catch(error => console.log(error)) 
        }, 
        fecha(date){
            return moment(date).locale('MX').format('DD-MM-YYYY LT')
        },
    },
  }
</script>
