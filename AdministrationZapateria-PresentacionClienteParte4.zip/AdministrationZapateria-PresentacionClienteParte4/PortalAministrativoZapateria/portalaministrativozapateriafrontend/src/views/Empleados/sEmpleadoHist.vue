Autor: Miguel Angel Zamora Carmona
Descripción: En el presente archivo se muestra el detalle de un empleado eliminado.
<template>
    <v-container>
        <v-dialog  max-width="800">
            <template v-slot:activator="{ on, attrs }">
                <p v-bind="attrs" v-on="on" class="blue--text">
                <strong>{{element.nombre}}</strong>
                </p>
            </template>
            <v-card> 
                <v-card-title class="headline"> 
                    <strong>{{element.nombre}}</strong>
                </v-card-title>
                <v-card-text>
                    <v-toolbar dark dense>
                        <v-row justify="center" no-gutters>
                            <v-icon color="white">mdi-file-phone-outline</v-icon>
                            <v-spacer/>
                            <h3 class="white--text">Información de Contacto</h3>  
                            <v-spacer/>
                        </v-row> 
                    </v-toolbar>
                    <v-simple-table dense>
                        <template v-slot:default>
                            <tbody> 
                                <tr>
                                    <td><strong>Tel. de casa: </strong> {{element.zdemh_num_tel}} </td> 
                                    <td><strong>Tel. celular: </strong> {{element.zdemh_num_cel}}</td> 
                                    <td><strong>Correo: </strong> {{element.zdemh_correo}} </td>
                                </tr>
                            </tbody>
                        </template> 
                    </v-simple-table>
                    <v-toolbar dark dense>
                        <v-row justify="center" no-gutters>
                            <v-icon color="white">mdi-map-marker-radius-outline</v-icon>
                            <v-spacer/>
                            <h3 class="white--text">Dirección - Lugar de Residencia</h3>  
                            <v-spacer/>
                        </v-row> 
                    </v-toolbar>
                    <v-simple-table dense>
                        <template v-slot:default>
                            <tbody> 
                                <tr>
                                    <td> 
                                        <p>
                                            <strong>Dirección: </strong>
                                            <strong>Calle principal: </strong>{{element.zdemh_dir_calle_1}}
                                            <strong>Calle Interconexión: </strong>{{element.zdemh_dir_calle_2}} 
                                            <strong>Núm. Int: </strong>{{element.zdemh_dir_num_int}} 
                                            <strong>Núm. Ext: </strong>{{element.zdemh_dir_num_ext}} 
                                            <strong>Cp. </strong>{{element.zdemh_dir_cod_postal}} 
                                            <strong>Colonia: </strong>{{element.zdemh_dir_colonia}} 
                                            <strong>Municipio: </strong>{{element.zdemh_dir_municipio}} 
                                            <strong>Estado: </strong>{{element.zdemh_dir_estado}} 
                                            <strong>País: </strong>{{element.zdemh_dir_pais}} 
                                        </p>
                                        
                                    </td> 
                                </tr> 
                            </tbody> 
                        </template>
                    </v-simple-table>
                    <v-toolbar dark dense>
                        <v-row justify="center" no-gutters>
                            <v-icon color="white">mdi-file-document-multiple-outline</v-icon>
                            <v-spacer/>
                            <h3 class="white--text">Información Extra</h3>  
                            <v-spacer/>
                        </v-row> 
                    </v-toolbar> 
                    <v-simple-table dense>
                        <template v-slot:default>
                            <tbody> 
                                <tr>
                                    <td><strong>Sucursal: </strong> {{element.zdemh_sucursal_nombre}} </td>   
                                    <td><strong>Creado: </strong> {{fecha(element.zdemh_fech_cre)}} </td> 
                                </tr>
                            </tbody> 
                        </template>
                    </v-simple-table>  
                    <v-toolbar dark dense>
                        <v-row justify="center" no-gutters>
                            <v-icon color="white">mdi-delete-sweep-outline</v-icon>
                            <v-spacer/>
                            <h3 class="white--text">Información de eliminación</h3>  
                            <v-spacer/>
                        </v-row> 
                    </v-toolbar> 
                    {{getUser(element.zdemh_usua_delet)}}  
                    <v-simple-table dense>
                        <template v-slot:default>
                            <tbody> 
                                <tr v-if="type == true">
                                    <td><strong>Eliminado por el administrador: </strong></td>   
                                    <td>{{element.zdemh_correo_elim}}</td> 
                                </tr>
                                <tr v-else>
                                    <td><strong>Eliminado por:</strong></td>   
                                    <td>
                                        <v-tooltip bottom v-if="isDelete == true">
                                            <template v-slot:activator="{ on, attrs }">
                                                <h3 v-bind="attrs" v-on="on" class="red--text">
                                                    {{userData.nombre}}
                                                </h3>
                                            </template>
                                            <span>El usuario que elimino este registro esta eliminado y se encuentra en la vista de empleados histórico.</span>
                                        </v-tooltip> 
                                        <v-tooltip bottom v-else>
                                            <template v-slot:activator="{ on, attrs }">
                                                <h3 v-bind="attrs" v-on="on" class="green--text">
                                                    {{userData.nombre}}
                                                </h3>
                                            </template>
                                            <span>El usuario se encuentra en la vista de empleados</span>
                                        </v-tooltip> 
                                    </td> 
                                </tr>
                                <tr>
                                    <td><strong>Fecha de eliminación: </strong></td>
                                    <td class="red--text">{{fecha(element.zdemh_fech_dele)}}</td>
                                </tr>
                                <tr>
                                    <td><strong>Motivo: </strong></td>
                                    <td class="red--text">{{element.zdemh_motivo}} </td>
                                </tr>
                            </tbody> 
                        </template>
                    </v-simple-table>  
                </v-card-text>
            </v-card>
        </v-dialog>
    </v-container>
</template>
<script>
const axios = require('axios')
const moment = require('moment') 
export default { 
    props:[
        'element'
    ],
    data() {
        return { 
            type: false,
            isDelete: false,
            userData: []
        }
    },
    methods: { 
        getUser(id){
            axios.get("http://127.0.0.1:8000/usuario/getusuario/" + id + "/")
                .then(res => {
                    if(res.data.is_superuser == true){
                        this.type = true
                    } else {
                        if(res.data.is_eliminated == true){
                            this.isDelete = true
                            axios.get("http://127.0.0.1:8000/empleado/empleados/historico/?search=" + id )
                            .then(resU => this.userData = resU.data[0])
                        } else {
                            this.isDelete = false
                            axios.get("http://127.0.0.1:8000/empleado/?search=" + id )
                            .then(resU => this.userData = resU.data[0])
                        } 
                    }
                })
        },
        fecha(date){
            return moment(date).locale('MX').format('DD-MM-YYYY LT')
        },
    },
}
</script>