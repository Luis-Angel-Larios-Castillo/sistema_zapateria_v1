<!--
♣ Autor: Luis Angel Larios Castillo
♣ Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro
-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="500">
      <template v-slot:activator="{ on, attrs }">
        <v-btn
        v-bind="attrs"
        v-on="on"
        text
        color="teal darken-1"
        >
      Ver Detalles
    </v-btn>
      </template>
      <v-card>
        <v-card-title class="headline">
        
        </v-card-title>
        <v-card-text>
          <v-alert color="info" dark dense align="left">
            <h3>
            {{element.zaa_clave}}
           </h3>
          </v-alert>
           
           
          <div class="black--text">                
            <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DEL ARTICULO</h3>
                </v-alert>
                <div align="center">
                  <p><strong>CLAVE: </strong> {{element.zaa_clave}}</p>
                   <p><strong>ARTICULO: </strong> {{element.zaa_nombre_arti}}</p>
                  <p><strong>MARCA: </strong> {{element.zaa_marca}}</p>
                  <p><strong>CANTIDAD EN EXISTENCIA: </strong> {{element.zaa_cantidad}}</p>
                  <p><strong>MODELO: </strong> {{element.zaa_modelo}}</p>
                              
                </div>
                   
        </div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
  export default {
    props:[
      'element'
    ],
     data () {
            return {
               
                
            }
        },
    created() {
        
    },
    methods:{
     
           
    },
  }
</script>