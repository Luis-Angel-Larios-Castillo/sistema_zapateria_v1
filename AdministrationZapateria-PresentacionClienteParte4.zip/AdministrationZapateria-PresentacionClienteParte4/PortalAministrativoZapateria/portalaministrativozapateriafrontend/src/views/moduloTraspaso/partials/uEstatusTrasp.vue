<!--
 ♣ Autor: Luis Angel Larios Castillo
Descripción: Este archivo muestra un listado de todos los registros de los traspasos

-->
<template>
    <div>
          <v-row>
               <v-col
                class="mt-5 col-10" 
                >
                    <v-select
                    :items="['En proceso', 'Entregado', 'Entregado con daños','Finalizado','No entregado']"
                    v-model="element.item.zdtr_estatus_trasp"
                    dense
                    outlined
                    v-on:change="update()"
                    :disabled="element.permissions.can_manage_art_trasp == false" 
                    ></v-select>
                </v-col>
          
          </v-row>
    </div>
</template>
<script>

const axios = require('axios')
export default {
    props:[
      'element'
    ],
    created() {
           
           this.findIdUser()
        },
        data () {
            return {
               idUser:[]
            }
        },
        methods:{

            findIdUser(){
                const userToken = localStorage.token
                axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
                .then(res => this.idUser = res.data.user)
            },
           
             update() {
              axios
                .put(
                  "http://127.0.0.1:8000/articulo/traspaso/" + this.element.item.zdtr_id_traspaso+ "/",{
                        zdtr_id_user_modifico:this.idUser,
                        zdtr_id_sucursal_de_salida:this.element.item.zdtr_id_sucursal_de_salida,
                        zdtr_id_sucursal_de_entrada:this.element.item.zdtr_id_sucursal_de_entrada,
                        zdtr_cantidad:this.element.item.zdtr_cantidad,
                        zdtr_folio_arti_trasp:this.element.item.zdtr_folio_arti_trasp,
                        zdtr_id_empleado_qgenero_trasp:this.element.item.zdtr_id_empleado_qgenero_trasp,
                        zdtr_id_artic_trasp:this.element.item.zdtr_id_artic_trasp,
                        zdtr_estatus_trasp:this.element.item.zdtr_estatus_trasp,
                  })
               
              
            },
           
    
        },
        
}
</script>