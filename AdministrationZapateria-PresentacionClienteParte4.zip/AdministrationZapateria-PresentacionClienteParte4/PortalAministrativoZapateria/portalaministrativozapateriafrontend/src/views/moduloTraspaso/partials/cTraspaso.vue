/*
        ♣ Autor: Luis Angel Larios Castillo.
        ♣ Descripción:  Este modulo se centra en realizar crear el traspaso de articulos
 */

<template>  
    <v-container fluid>
        <div v-if="permissions.can_manage_art_trasp == true">
             <app-header style="z-index: 135"/> 
        <br>
        <v-row id="cabecera_color_azul">
         
            <v-col>
                <div style="color:white; float:left;">
                    <v-btn
                elevation="2"
                icon
                dark
                :to="'/traspaso/'"
                >
                <v-icon>mdi-arrow-left-circle-outline</v-icon>
                </v-btn>
                </div>
              <h2 class="white--text">
                TRASPASOS DE ARTICULOS ENTRE SUCURSALES
            </h2> 
            </v-col>
           
        </v-row>
           <v-row>
               <v-col  cols="md-3 xs-12">
                    <div id="cabecera_color_azul">
                        <h2 class="white--text">
                            ARTICULOS</h2> 
                    </div>
                    <v-responsive
                        class="overflow-y-auto"
                        max-height="470"
                    >
                        <v-responsive
                        class="text-center"
                        >

                <v-data-iterator :items="findarticulos" no-data-text="No hay resultados." no-results-text="No hay resultados." :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" :sort-by="sortBy.toLowerCase()" :sort-desc="sortDesc" hide-default-footer>
                    
                    <template v-slot:header>
                        <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar artículos"/><br>
                    </template>
                    <!-- Items inicio -->
                    <template v-slot:default="props">
                        <v-row>
                        <v-col v-for="d in props.items" :key="d.zpd_id_pedid_devol" cols="12">
                                    <v-hover
                                        v-slot="{ hover }"
                                    >
                                <v-card
                                        class="mx-auto cardcolor"
                                        max-width="300"
                                        outlined
                                        :elevation="hover ? 16 : 2"
                                        :class="{ 'on-hover': hover }"
                                        
                                    >                              
                                        
                                        
                                        <v-list-item-content>
                                            <div class="text-overline mb-4">
                                            <v-chip outlined color="primary"> 
                                                {{d.zaa_nombre_arti}}
                                            </v-chip>
                                            </div>                                   
                                            <div >
                                            <strong>{{d.zaa_clave}}</strong>                                           
                                            </div>
                                        </v-list-item-content>
                                        </v-list-item>
                                        <v-card-actions>
                                             <sArtiTrasp :element="d"/>
                                             <v-spacer></v-spacer>
                                            <v-btn  @click="select = d.zaa_id_articulo"
                                                small
                                                depressed
                                               color="#000"
                                                rounded
                                                dark
                                            > 
                                            Traspasar
                                            </v-btn>   
                                        </v-card-actions>
                                       
                                         </v-card>
                                    </v-hover>
                                   
                            </v-col>
                          </v-row>
                         <div>
                     </div>
                </template>
                <!-- Items fin -->
               
                </v-data-iterator>
                            </v-responsive>
                        </v-responsive>
                    </v-col>
                    <v-col cols="md-9 xs-12">
                            <v-card height="100%" v-if="select == ''" color="#ECECEC">
                                <v-container fill-height  justify-center>
                                    <h3>No se ha seleccionado ningún artículo</h3>
                                </v-container>
                            </v-card>

                        <div v-for="prin in findarticulos" v-bind:key="prin.zaa_id_articulo">
                            <div v-if="select==prin.zaa_id_articulo">
                                   
                            <v-card height="100%">
                                <v-alert
                                dense
                                color="#14213d"
                                dark
                                >
                                <h2 class="white--text">DETALLES DE TRASPASO</h2>
                                
                                </v-alert> 
                               <v-card-text>
                                    <div align="left">


                                    <v-card
                                        class="mx-auto"
                                        outlined
                                    >
                                        <v-list-item three-line>
                                            <v-list-item-avatar
                                            tile
                                            size="150"
                                            color="grey"
                                        >
                                        <v-img dark class="imgColor" />
                                        </v-list-item-avatar>
                                        <v-list-item-content>
                                            <v-row>
                                            <v-col class="text-center" >
                                                    
                                                      <div class="text-h4 mb-2">
                                                       {{prin.zaa_nombre_arti}} 
                                                    </div>
                                                   
                                                   
                                                    <h3>CLAVE:</h3> 
                                                   
                                                    <v-chip
                                                    class="ma-2"
                                                    >
                                                    <strong>{{prin.zaa_clave}}</strong>
                                                    </v-chip>                          
                                                    
                                                   
                                                    <h3>CANTIDAD</h3> 
                                                    <v-chip
                                                    class="ma-2"
                                                    >
                                                    <strong v-if="catidad_artic == 0">{{prin.zaa_cantidad}}</strong>
                                                    <strong v-else>{{prin.zaa_cantidad - catidad_artic}}</strong>
                                                    </v-chip>   
                                                         
                                            </v-col>
                                            <div v-show="false">
                                            {{arti_global = prin.zaa_id_arti_global}}
                                            <strong>{{arti_color = prin.zaa_color}}</strong>
                                            <br>
                                             <strong>{{tallaModel = prin.zaa_talla}}</strong>
                                             <v-text-field v-model="arti_global" label="articulo global"  required ></v-text-field>
                                             <br>
                                             {{id_arti_for_traspaso = prin.zaa_id_articulo}}
                                                <br>
                                            {{cant_arti_for_traspaso = prin.zaa_cantidad}}
                                            </div>
                                            
                                            

                                            


                                            <v-col
                                            cols="12"
                                            sm="6"
                                            md="8"
                                            >
                                              <v-form ref="form" v-model="valid" lazy-validation>
                                                
                                                   <div hidden>{{id_articulo_tras=prin.zaa_id_articulo}}</div>
                                                   
                                                <v-autocomplete
                                                    v-model="sucur_salida_Select"
                                                    :items="sucursales"
                                                    dense
                                                    label="Sucursal de salida"
                                                    item-text="zdsu_etiqueta" item-value="zdsu_id_sucursal"
                                                    :rules="[v => !!v || 'Debe seleccionar una sucursal']"   required
                                                ></v-autocomplete>
                                                <div v-if="sucur_salida_Select != null">
                                                {{ findsucusali(sucur_salida_Select)}}
                                                </div>
                                                 <v-autocomplete
                                                    v-model="sucur_entrada_Select"
                                                    :items="sucursales"
                                                    dense
                                                    label="Sucursal de entrada"
                                                    item-text="zdsu_etiqueta" item-value="zdsu_id_sucursal"
                                                    :rules="[v => !!v || 'Debe seleccionar una sucursal']"   required
                                                 ></v-autocomplete>
                                                 <div v-if="sucur_entrada_Select != null">
                                                {{ findsucuentr(sucur_entrada_Select)}}
                                                </div>
                                                 <v-text-field v-model="catidad_artic" label="Cantidad de articulos" oninput="this.value=this.value.replace(/[^0-9]/g,'');"  required  maxlength="6"></v-text-field>
                                                 <div hidden>
                                                    {{id_articulo_tras}}

                                                    {{sucur_entrada_Select}}

                                                    {{sucur_salida_Select}}
                                                </div>                                              
                                                <p v-if="catidad_artic > prin.zaa_cantidad " style="color:red;"> Cantidad insuficiente de articulos en inventario</p>
                                                 <v-btn v-show="sucur_entrada_Select != null && sucur_salida_Select != null && catidad_artic > 0 && catidad_artic <= prin.zaa_cantidad" color="blue" @click="validar" outlined block>
                                                    Traspar
                                                </v-btn>
                                                </v-form>
                                            </v-col>
                                            </v-row>
                                             
                                        </v-list-item-content>
                                        </v-list-item>                                   
                                    </v-card>

                                    <br>
                               <v-card>
                                    <v-tabs  background-color="#14213d" dark>
                                       <v-tab>Detalles de articulo</v-tab>
                                        <v-tab>Sucursal de salida</v-tab>
                                        <v-tab>Sucursal de entrada</v-tab>
                                        <v-tab-item>
                                 <v-simple-table>
                                    <template v-slot:default >
                                    <thead>
                                        <tr>
                                        <th class="text-center">
                                        Clave
                                        </th>
                                        <th class="text-center">
                                            Nombre
                                        </th>
                                        <th class="text-center">
                                            Cantidad
                                        </th>
                                        <th class="text-center">
                                            Marca
                                        </th>
                                        <th class="text-center">
                                            Prec. de contado
                                        </th>
                                        <th class="text-center">
                                            Prec. en pagos
                                        </th>
                                        <th class="text-center">
                                            Prec. de mayoreo
                                        </th>
                                        <th class="text-center">
                                            Prec. de menudeo
                                        </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td class="text-center">{{prin.zaa_clave}}</td>
                                        <td class="text-center">{{prin.zaa_nombre_arti}}</td>
                                        <td class="text-center">{{prin.zaa_cantidad}}</td>
                                        <td class="text-center">{{prin.zaa_marca}}</td>
                                        <td class="text-center">${{prin.zaa_prec_cont}}</td>
                                        <td class="text-center">${{prin.zaa_prec_pag}}</td>
                                        <td class="text-center">${{prin.zaa_prect_mayo}}</td>
                                        <td class="text-center">${{prin.zaa_prect_menud}}</td>
                                        </tr>
                                    </tbody>
                                    </template>
                                </v-simple-table>

                                        </v-tab-item>
                                        <v-tab-item>
                                            <v-simple-table>
                                            <template v-slot:default >
                                            <thead>
                                                <tr>
                                                   <th class="text-center">
                                                    Folio de sucursal
                                                    </th>
                                                    <th class="text-center">
                                                        Nombre
                                                    </th>
                                                    <th class="text-center">
                                                        Numero de telefono
                                                    </th>
                                                    <th class="text-center">
                                                        Pais
                                                    </th>
                                                    <th class="text-center">
                                                        Estado
                                                    </th>
                                                    <th class="text-center">
                                                        Municipio
                                                    </th>
                                                    <th class="text-center">
                                                       Colonia
                                                    </th>
                                                    <th class="text-center">
                                                       Estatus
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <td class="text-left">{{busqsucsali.zdsu_folio_surcur}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_nombre}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_num_tel}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_pais}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_estado}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_municipio}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_colonia}}</td>
                                                <td class="text-center">
                                                    <div v-if="busqsucsali.zdsu_estat_sucur != null">
                                                    <v-chip
                                                    class="ma-2"
                                                    :color="colorestatussucsali(busqsucsali.zdsu_estat_sucur)"
                                                    outlined
                                                    >{{funestatussucsali(busqsucsali.zdsu_estat_sucur)}}
                                                    </v-chip>
                                                    </div>
                                                </td>
                                                </tr>
                                            </tbody>
                                            </template>
                                        </v-simple-table>
                                        </v-tab-item>
                                        <v-tab-item>
                                             <v-simple-table>
                                            <template v-slot:default >
                                            <thead>
                                                <tr>
                                                   <th class="text-center">
                                                    Folio de sucursal
                                                    </th>
                                                    <th class="text-center">
                                                        Nombre
                                                    </th>
                                                    <th class="text-center">
                                                        Numero de telefono
                                                    </th>
                                                    <th class="text-center">
                                                        Pais
                                                    </th>
                                                    <th class="text-center">
                                                        Estado
                                                    </th>
                                                    <th class="text-center">
                                                        Municipio
                                                    </th>
                                                    <th class="text-center">
                                                       Colonia
                                                    </th>
                                                    <th class="text-center">
                                                       Estatus
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <td class="text-left">{{busqsucentre.zdsu_folio_surcur}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_nombre}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_num_tel}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_pais}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_estado}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_municipio}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_colonia}}</td>
                                                <td class="text-center">
                                                    <div v-if="busqsucentre.zdsu_estat_sucur != null">
                                                    <v-chip
                                                    class="ma-2"
                                                    :color="colorestatussucentri(busqsucentre.zdsu_estat_sucur)"
                                                    outlined
                                                    >{{funestatussucentri(busqsucentre.zdsu_estat_sucur)}}
                                                    </v-chip>
                                                    </div>
                                                </td>
                                               
                                                </tr>
                                            </tbody>
                                            </template>
                                        </v-simple-table>
                                        </v-tab-item>
                                    </v-tabs>
                                </v-card>                           
                                    </div>
                                </v-card-text>
                                 </v-card>
                             </div>
                                <div v-else>
                                </div>
                            </div> 
            </v-col>
        </v-row>
        </div>
        <div v-else>
            <ErrorPage403/>
        </div>
    </v-container>
</template>
<script>
import Header from '../../../components/Header';
let fecha_trasp =  new Date().toISOString().slice(0,10)
const axios = require('axios')
import sArtiTrasp from './sArtiTrasp';
import ErrorPage403 from '../../../components/ErrorPage403.vue';
export default {
     name: 'Header', 
   components:{
        "app-header": Header,
        sArtiTrasp,
        ErrorPage403
    },
    data() {
        return {
            select: '',
            tab: null,
            itemsPerPageArray: [ 9, 18, 27],
            search: '',
            filter: {},
            sortDesc: false,
            page: 1,
            itemsPerPage: 999999,
            sortBy: 'zaa_nombre_arti',
            keys: [
            'zaa_nombre_arti',
            'zaa_id_articulo',
            'zaa_clave',
            'zaa_marca'
           
            ],
            findarticulos:[],
            valid: true,
            sucursales:[],
            sucur_salida_Select: null,
            sucur_entrada_Select: null,
            id_articulo_tras:null,
            idUser: '',
            noti:false,
            num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
            catidad_artic:0,
            busqsucsali:[],
            busqsucentre:[],
            id_arti_for_traspaso:'',
            cant_arti_for_traspaso:'',
            arti_color:[],
            tallaModel:[],
            arti_global:'',
            empleadoResult:[],
            idUser:[],
            permissions: {
                    can_manage_art_trasp: false,
                  
                },
            
        }
    },
    created() {
        this.findpermsisos()
        this.find()
        this.findSucursal()
        this.findIdUser()    
    },
computed: {
      numberOfPages () {
        return Math.ceil(this.findarticulos.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Name')
      },
      
    },

    methods: {    
        findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_art_trasp: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos_traspaso') { this.permissions.can_manage_art_trasp = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },

        validar () {
       
            if (this.sucur_salida_Select != null && this.sucur_entrada_Select != null){
                    this.element = {
                        zdtr_id_user_modifico:'No modificado aun' ,
                        zdtr_id_sucursal_de_salida:this.sucur_salida_Select,
                        zdtr_id_sucursal_de_entrada:this.sucur_entrada_Select,
                        zdtr_id_empleado_qgenero_trasp:this.idUser,
                        zdtr_id_artic_trasp:this.id_articulo_tras,
                        zdtr_folio_arti_trasp:"Trasp" + " - "+ fecha_trasp +" - "+ this.num_random,
                        zdtr_cantidad:this.catidad_artic,
                        zdtr_estatus_trasp:'En proceso'
                    }
                    this.actualizarstockarti()
                    this.create() 
                    this.createarticulonew()
                    }        
            else{
                this.noti=true
            }
                    
        } ,     
    

      create(){
        axios.post('http://127.0.0.1:8000/articulo/traspaso/', this.element)
          .then(res => {
            this.$router.replace({ path: '/traspaso/' })
            this.dialog = false
          })
          .catch(error => console.log(error));
      },

      createarticulonew() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .post("http://127.0.0.1:8000/articulo/admin/", {

          zaa_id_sucursal: this.sucur_entrada_Select,
          zaa_color: this.arti_color,
          zaa_cantidad: this.catidad_artic,
          zaa_talla: this.tallaModel,
          zaa_existen: true,
          zaa_id_arti_global: this.arti_global,

        }, config)
        .then((res) => {
          //window.location.reload();
        })
        .catch((error) => console.log(error));
    },

    actualizarstockarti() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .put("http://127.0.0.1:8000/articulo/admin/"+this.id_arti_for_traspaso+'/', {
          zaa_id_articulo:this.id_arti_for_traspaso,
          zaa_id_sucursal: this.sucur_salida_Select,
          zaa_color: this.arti_color,
          zaa_cantidad: this.cant_arti_for_traspaso - this.catidad_artic,
          zaa_talla: this.tallaModel,
          zaa_existen: true,
          zaa_id_arti_global: this.arti_global,

        }, config)
        .then((res) => {
          //window.location.reload();
        })
        .catch((error) => console.log(error));
    },



        findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
          .then(res => this.sucursales = res.data)
      },

      findsucusali(id){
        axios.get('http://127.0.0.1:8000/sucursal/'+id+'/')
          .then(res => this.busqsucsali = res.data)
      },
    findsucuentr(id){
        axios.get('http://127.0.0.1:8000/sucursal/'+id+'/')
          .then(res => this.busqsucentre = res.data)
      },
      
      
         find(){
                

             let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }

            const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            
            axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
            .then(res => { this.empleadoResult = res.data[0]

                //console.log(this.empleadoResult)

            axios.get('http://127.0.0.1:8000/articulo/admin/?search=' + this.empleadoResult.zdem_id_sucursal,config)
                .then(res => {this.findarticulos = res.data

                //console.log(this.elements)
                     })
                 })
            })


        },




        findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
          .then(res => this.idUser = res.data.user)
      },
        
      
         nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
        },
        formerPage () {
         if (this.page - 1 >= 1) this.page -= 1
        },
        updateItemsPerPage (number) {
        this.itemsPerPage = number
        },

    funestatussucsali(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activa"
          }
          else{
              cam_estatus="Inactiva"
          }
          return cam_estatus
      },
    colorestatussucsali(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },

      funestatussucentri(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activa"
          }
          else{
              cam_estatus="Inactiva"
          }
          return cam_estatus
      },
    colorestatussucentri(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },

                 
              },  
            }
</script>
<style scoped>
   
</style>