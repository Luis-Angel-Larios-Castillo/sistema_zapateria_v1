<!--
♣ Autor: Luis Angel Larios Castillo
♣ Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro
-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="500">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zdtr_folio_arti_trasp}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
        
        </v-card-title>
        <v-card-text>
          <v-alert color="info" dark dense align="left">
            <h3>
            DETALLES DE TRASPASO
           </h3>
          </v-alert>
           
           <strong>Fecha de creacion de traspaso: </strong><br> {{fecha(element.zdtr_fecha_creacion)}}
           <br>
           <strong>Estatus: </strong><br>
           <v-chip
            :color="colorestatustrasp(element.zdtr_estatus_trasp)"
            outlined
          >{{element.zdtr_estatus_trasp}}</v-chip>
           
            
          <div class="black--text mt-3">                
            <div align="left" style="font-size:15px;">
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DEL ARTICULO</h3>
                </v-alert>
                <div align="center">
                    <p><strong>CLAVE: </strong> {{artisinfo.zaa_clave}}</p>
                    <p><strong>Nombre: </strong> {{artisinfo.zaa_nombre_arti}}</p>
                    <p><strong>Cantidad: </strong> {{element.zdtr_cantidad}}</p>
                    <p><strong>Marca: </strong> {{artisinfo.zaa_marca}}</p>
                    <p><strong>Precio de Contado: </strong> ${{artisinfo.zaa_prec_cont}}</p>
                    <p><strong>Precio en Pagos: </strong> ${{artisinfo.zaa_prec_pag}}</p>
                    <p><strong>Precio de Mayoreo: </strong> ${{artisinfo.zaa_prect_mayo}}</p>
                    <p><strong>Precio de Menudeo: </strong> ${{artisinfo.zaa_prect_menud}}</p>
                </div>
                
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DE LA SUCURSAL DE SALIDA</h3>
                </v-alert>
                <div align="center">
                  <p><strong>NOMBRE DE LA SUCURSAL: </strong> {{sucsali.zdsu_nombre}}</p>
                  <p><strong>FOLIO: </strong> {{sucsali.zdsu_folio_surcur}}</p>
                  <p><strong>TELEFONO: </strong> {{sucsali.zdsu_num_tel}}</p>
                  <p><strong>ESTADO: </strong> {{sucsali.zdsu_dir_estado}}</p>
                  <p><strong>MUNICIPIO: </strong> {{sucsali.zdsu_dir_municipio}}</p>
                              
                </div>

                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DE LA SUCURSAL DE ENTRADA</h3>
                </v-alert>
                <div align="center">
                  <p><strong>NOMBRE DE LA SUCURSAL: </strong> {{sucentrad.zdsu_nombre}}</p>
                  <p><strong>FOLIO: </strong> {{sucentrad.zdsu_folio_surcur}}</p>
                  <p><strong>TELEFONO: </strong> {{sucentrad.zdsu_num_tel}}</p>
                  <p><strong>ESTADO: </strong> {{sucentrad.zdsu_dir_estado}}</p>
                  <p><strong>MUNICIPIO: </strong> {{sucentrad.zdsu_dir_municipio}}</p>
                </div>

                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DEL EMPLEADO QUE REALIZO EL TRASPASO</h3>
                </v-alert>
                <div align="center">
                

                {{empleado_user_empleado}}
                 
                </div>

                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DETALLES DE MODIFICACIÓN</h3>
                </v-alert>
                <div align="center" v-if="element.zdtr_id_user_modifico != 'No modificado aun'">
                {{empleado_user_empleado_modifico}}<br>
                 {{fecha(element.zdtr_fecha_modificacion)}}
                </div>
                <div v-else align="center">
                  {{element.zdtr_id_user_modifico}}
                </div>

                

               
               
                   
        </div></div>
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
const moment = require('moment')
const axios = require('axios')
  export default {
    props:[
      'element'
    ],
     data () {
            return {
                artisinfo:[],
                sucsali:[],
                sucentrad:[],
                empleado_user:[],
                empleado_user_empleado:[],
                empleado_user_modifico:[],
                empleado_user_empleado_modifico:[]
                
            }
        },
    created() {
        this.findart()
        this.findsucsali()
        this.findsucentr()
        this.finduser()
        this.findusermodifico()
    },
    methods:{
      findart(){
                let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/articulo/admin/'+this.element.zdtr_id_artic_trasp+'/', config)
                .then(res => this.artisinfo = res.data)   
            },
          findsucsali(){
             axios.get('http://127.0.0.1:8000/sucursal/'+this.element.zdtr_id_sucursal_de_salida+'/')
                .then(res => this.sucsali = res.data)   
          },
           findsucentr(){
             axios.get('http://127.0.0.1:8000/sucursal/'+this.element.zdtr_id_sucursal_de_entrada+'/')
                .then(res => this.sucentrad = res.data)   
          },
           finduser(){
        axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.element.zdtr_id_empleado_qgenero_trasp+"/")
                .then(resc_s =>  {this.empleado_user = resc_s.data
                
                    if(this.empleado_user.is_superuser == true){
                    this.empleado_user_empleado=this.empleado_user.zdus_correo
                    }
                    else{
                      axios.get("http://127.0.0.1:8000/empleado/?search=" + this.element.zdtr_id_empleado_qgenero_trasp)
                    .then(res =>  {this.empleado_user_empleado = res.data[0].nombre
                    })
                    }
                })
      },
      findusermodifico(){
        if(this.element.zdtr_id_user_modifico != 'No modificado aun'){
        axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.element.zdtr_id_user_modifico+"/")
                .then(resc_s =>  {this.empleado_user_modifico = resc_s.data
                
                    if(this.empleado_user_modifico.is_superuser == true){
                    this.empleado_user_empleado_modifico=this.empleado_user_modifico.zdus_correo
                    }
                    else{
                      axios.get("http://127.0.0.1:8000/empleado/?search=" + this.element.zdtr_id_user_modifico)
                    .then(res =>  {this.empleado_user_empleado_modifico = res.data[0].nombre
                    })
                    }
                })}
                else{
                  
                }
      },
       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
      colorestatustrasp(estatus){
        let colorfinal=""
        if(estatus == 'En proceso'){
          colorfinal = 'blue'
        }
        else if(estatus == 'Entregado'){
          colorfinal = '#1E88E5'
        }
        else if(estatus == 'Entregado con daños'){
          colorfinal = '#D81B60'
        }
        else if(estatus == 'Finalizado'){
          colorfinal = 'green'
        }
        else{
          colorfinal = '#A51C30'
        }
        return colorfinal
      }
    },
  }
</script>