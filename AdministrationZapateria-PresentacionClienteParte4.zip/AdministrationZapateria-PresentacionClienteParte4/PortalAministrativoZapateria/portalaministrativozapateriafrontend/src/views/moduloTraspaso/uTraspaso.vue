<template>
    <div fluid>
         <div v-if="permissions.can_manage_art_trasp == true">
              <app-header style="z-index: 135"/> 
        <br>
       <v-card
            class="mx-auto"
            max-width="95%"
            outlined
        >
        <div id="cabecera_color_azul" style="color:#fff;">
            <v-btn
                elevation="2"
                icon
                dark
                :to="'/traspaso/'"
                style="float:left;"
                >
                <v-icon>mdi-arrow-left-circle-outline</v-icon>
                </v-btn>
            <h2>{{elementU.zdtr_folio_arti_trasp}}</h2>
        </div>
            
                <v-row>
                    <v-col cols="3">
                        <v-list-item-avatar
                            tile
                            size="150"
                            color="grey"
                        >
                        <v-img dark class="imgColor align-center"  />
                        </v-list-item-avatar>
                    </v-col>
                    <v-col cols="4">
                        
                         <h3>CLAVE:</h3>            
                         <v-chip
                            class="ma-2"
                         >
                        <strong>{{findarticulo.zaa_clave}}</strong>
                        </v-chip>                          
                        <h3>ARTICULO:</h3>  
                        <div class="text-h4 mb-2">
                            {{findarticulo.zaa_nombre_arti}}
                        </div>
                    </v-col>
                    <v-col cols="5">
                        <br>
                        <v-form ref="form" v-model="valid" lazy-validation m>    
                       <v-autocomplete
                        v-model="elementU.zdtr_id_sucursal_de_salida"
                        :items="sucursales"
                        dense
                        label="Sucursal de salida"
                        item-text="zdsu_etiqueta" item-value="zdsu_id_sucursal"
                        :rules="[v => !!v || 'Debe seleccionar una sucursal']"   required
                        ></v-autocomplete>
                        <v-autocomplete
                        v-model="elementU.zdtr_id_sucursal_de_entrada"
                        :items="sucursales"
                        dense
                        label="Sucursal de entrada"
                        item-text="zdsu_etiqueta" item-value="zdsu_id_sucursal"
                        :rules="[v => !!v || 'Debe seleccionar una sucursal']"   required
                        ></v-autocomplete>
                        <v-text-field v-model="elementU.zdtr_cantidad" label="Cantidad de articulos" oninput="this.value=this.value.replace(/[^0-9]/g,'');"  required  maxlength="6"></v-text-field>
                        <v-select
                            :items="['En proceso', 'Entregado', 'Entregado con daños','Finalizado','No entregado']"
                            label="Estatus"
                            v-model="elementU.zdtr_estatus_trasp"
                        ></v-select>
                        <v-btn
                            :disabled="!valid"
                            color="blue"
                            class="mr-4"
                            @click="validate"
                            outlined
                            v-show="elementU.zdtr_id_sucursal_de_entrada != null && elementU.zdtr_id_sucursal_de_salida != null && elementU.zdtr_cantidad > 0"
                        >
                            Actualizar
                            <v-icon right dark>mdi-update</v-icon>
                        </v-btn>
                        <v-btn
                            color="error"
                            class="mr-4"
                            @click="cancelar"
                            outlined
                            >Cancelar<v-icon right dark>mdi-close-circle</v-icon></v-btn
                        >
                        </v-form>
                    </v-col>
                </v-row>
                <div v-if="elementU.zdtr_id_sucursal_de_salida != null">
                    {{ findsucusali(elementU.zdtr_id_sucursal_de_salida)}}
                </div>
                <div v-if="elementU.zdtr_id_sucursal_de_entrada != null">
                     {{ findsucuentr(elementU.zdtr_id_sucursal_de_entrada)}}
                </div>
                <br>
            <v-card>
                 
                                    <v-tabs  background-color="#14213d" dark>
                                       <v-tab>Detalles de articulo GUARDADO</v-tab>
                                        <v-tab>Sucursal de salida GUARDADA</v-tab>
                                        <v-tab>Sucursal de entrada GUARDADA</v-tab>
                                        <v-tab-item>
                                 <v-simple-table>
                                    <template v-slot:default >
                                    <thead>
                                        <tr>
                                        <th class="text-center">
                                        Clave
                                        </th>
                                        <th class="text-center">
                                            Nombre
                                        </th>
                                        <th class="text-center">
                                            Cantidad
                                        </th>
                                        <th class="text-center">
                                            Marca
                                        </th>
                                        <th class="text-center">
                                            Prec. de contado
                                        </th>
                                        <th class="text-center">
                                            Prec. en pagos
                                        </th>
                                        <th class="text-center">
                                            Prec. de mayoreo
                                        </th>
                                        <th class="text-center">
                                            Prec. de menudeo
                                        </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <td class="text-center">{{findarticulo.zaa_clave}}</td>
                                        <td class="text-center">{{findarticulo.zaa_nombre_arti}}</td>
                                        <td class="text-center">{{findarticulo.zaa_cantidad}}</td>
                                        <td class="text-center">{{findarticulo.zaa_marca}}</td>
                                        <td class="text-center">${{findarticulo.zaa_prec_cont}}</td>
                                        <td class="text-center">${{findarticulo.zaa_prec_pag}}</td>
                                        <td class="text-center">${{findarticulo.zaa_prect_mayo}}</td>
                                        <td class="text-center">${{findarticulo.zaa_prect_menud}}</td>
                                        </tr>
                                    </tbody>
                                    </template>
                                </v-simple-table>

                                        </v-tab-item>
                                        <v-tab-item>
                                            <v-simple-table>
                                            <template v-slot:default >
                                            <thead>
                                                <tr>
                                                   <th class="text-center">
                                                    Folio de sucursal
                                                    </th>
                                                    <th class="text-center">
                                                        Nombre
                                                    </th>
                                                    <th class="text-center">
                                                        Numero de telefono
                                                    </th>
                                                    <th class="text-center">
                                                        Pais
                                                    </th>
                                                    <th class="text-center">
                                                        Estado
                                                    </th>
                                                    <th class="text-center">
                                                        Municipio
                                                    </th>
                                                    <th class="text-center">
                                                       Colonia
                                                    </th>
                                                    <th class="text-center">
                                                       Estatus
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <td class="text-left">{{busqsucsali.zdsu_folio_surcur}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_nombre}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_num_tel}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_pais}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_estado}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_municipio}}</td>
                                                <td class="text-center">{{busqsucsali.zdsu_dir_colonia}}</td>
                                                <td class="text-center">
                                                    <v-chip
                                                    class="ma-2"
                                                    :color="colorestatussucsali(busqsucsali.zdsu_estat_sucur)"
                                                    outlined
                                                    >{{funestatussucsali(busqsucsali.zdsu_estat_sucur)}}
                                                    </v-chip>
                                                </td>
                                                </tr>
                                            </tbody>
                                            </template>
                                        </v-simple-table>
                                        </v-tab-item>
                                        <v-tab-item>
                                             <v-simple-table>
                                            <template v-slot:default >
                                            <thead>
                                                <tr>
                                                   <th class="text-center">
                                                    Folio de sucursal
                                                    </th>
                                                    <th class="text-center">
                                                        Nombre
                                                    </th>
                                                    <th class="text-center">
                                                        Numero de telefono
                                                    </th>
                                                    <th class="text-center">
                                                        Pais
                                                    </th>
                                                    <th class="text-center">
                                                        Estado
                                                    </th>
                                                    <th class="text-center">
                                                        Municipio
                                                    </th>
                                                    <th class="text-center">
                                                       Colonia
                                                    </th>
                                                    <th class="text-center">
                                                       Estatus
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                <td class="text-left">{{busqsucentre.zdsu_folio_surcur}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_nombre}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_num_tel}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_pais}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_estado}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_municipio}}</td>
                                                <td class="text-center">{{busqsucentre.zdsu_dir_colonia}}</td>
                                                 <td class="text-center">
                                                    <v-chip
                                                    class="ma-2"
                                                    :color="colorestatussucentri(busqsucentre.zdsu_estat_sucur)"
                                                    outlined
                                                    >{{funestatussucentri(busqsucentre.zdsu_estat_sucur)}}
                                                    </v-chip>
                                                </td>
                                                </tr>
                                            </tbody>
                                            </template>
                                        </v-simple-table>
                                        </v-tab-item>
                                    </v-tabs>
                                </v-card>  


            <v-card-actions>
            
            </v-card-actions>
        </v-card>
        </div>
        <div v-else>
            <ErrorPage403/>
        </div>
    </div>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue';
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
         "app-header": Header,
        ErrorPage403
    },
    created() {
        this.findpermsisos()
        this.find()
        this.findSucursal()
        this.findIdUser()
       
    },
    data () {
      return {
          elementU: [],
          findarticulo:[],
          sucursales:[],
          valid: true,
          idUser: '',
          permissions: {
                    can_manage_art_trasp: false,
                  
                },
      }
    },
     methods: {
         findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_art_trasp: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos_traspaso') { this.permissions.can_manage_art_trasp = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
        findSucursal(){
            axios.get('http://127.0.0.1:8000/sucursal/')
            .then(res => this.sucursales = res.data)
        },
        findsucusali(id){
            axios.get('http://127.0.0.1:8000/sucursal/'+id+'/')
            .then(res => this.busqsucsali = res.data)
        },
        findsucuentr(id){
            axios.get('http://127.0.0.1:8000/sucursal/'+id+'/')
            .then(res => this.busqsucentre = res.data)
        },
        find(){
            axios.get('http://127.0.0.1:8000/articulo/traspaso/'+ this.$route.params.id +'/').
                then(res => {
                  this.elementU = res.data

                    let config = {
                headers: {
                Authorization: "Token " + localStorage.token,
                }
            }
            axios.get('http://127.0.0.1:8000/articulo/admin/'+this.elementU.zdtr_id_artic_trasp+'/', config)
                .then(res => this.findarticulo = res.data)  


                })
        },

        validate() {
              
                if (this.$refs.form.validate()) {
                  this.elementU = {
                        zdtr_id_user_modifico:this.idUser,
                        zdtr_id_sucursal_de_salida:this.elementU.zdtr_id_sucursal_de_salida,
                        zdtr_id_sucursal_de_entrada:this.elementU.zdtr_id_sucursal_de_entrada,
                        zdtr_cantidad:this.elementU.zdtr_cantidad,
                        zdtr_folio_arti_trasp:this.elementU.zdtr_folio_arti_trasp,
                        zdtr_id_empleado_qgenero_trasp:this.elementU.zdtr_id_empleado_qgenero_trasp,
                        zdtr_id_artic_trasp:this.elementU.zdtr_id_artic_trasp,
                        zdtr_estatus_trasp:this.elementU.zdtr_estatus_trasp,
                  };
                  this.update();
                }
              
            },
            async update() {
              await axios
                .put(
                  "http://127.0.0.1:8000/articulo/traspaso/" + this.$route.params.id + "/",
                  this.elementU
                )
                .catch((error) => console.log(error));
              this.$router.push({ name: "Traspaso" });
            },
            cancelar() {
          this.$router.push({ name: "Traspaso" });
        },
        findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
          .then(res => this.idUser = res.data.user)
      },
    funestatussucsali(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activa"
          }
          else{
              cam_estatus="Inactiva"
          }
          return cam_estatus
      },
    colorestatussucsali(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },

      funestatussucentri(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Activa"
          }
          else{
              cam_estatus="Inactiva"
          }
          return cam_estatus
      },
    colorestatussucentri(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },
     },
}
</script>
