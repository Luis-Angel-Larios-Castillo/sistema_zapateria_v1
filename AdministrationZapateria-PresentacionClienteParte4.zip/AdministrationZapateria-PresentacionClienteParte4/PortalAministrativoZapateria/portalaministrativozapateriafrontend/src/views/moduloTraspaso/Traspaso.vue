<!--
 ♣ Autor: Luis Angel Larios Castillo
Descripción: Este archivo muestra un listado de todos los registros de los traspasos

-->
<template>
    <div cols="full">
          <v-row>
            <v-col cols="md-2 xs-12" >
                <menuModulos/>
            </v-col>

             <v-col cols="md-10 xs-12">
                 <app-header style="z-index: 135"/> 
            <div align="center" justify="space-around">
                <hr class="line_superior">
                    <h1 id="title">TRASPASOS</h1>
            </div><br>

                   <v-card :elevation="0">
                     <v-card-title class="card_title">
                    <div class="col-12" id="table_cabecera_color">
                      <v-text-field v-model="search" class="btn_search" dark dense rounded solo-inverted append-icon="mdi-magnify" label="Buscar" single-line hide-details/>
                    <v-btn dark text :to="'/ctraspaso/'" class="btn_add" v-show="permissions.can_manage_art_trasp == true">
                            Agregar
                        </v-btn>
                        </div>
                    </v-card-title>
                     <div class="col-12" style="padding-top:0">
                    <v-data-table
                        id="tabla_datos"
                        class="col-10"
                        :headers="headers" 
                        :items="elements"
                        :search="search"
                        no-results-text="No hay resultados."
                        no-data-text="No se tienen registros de ofertas." 
                        :footer-props="{
                            showFirstLastPage: true,
                            itemsPerPageText: 'Elementos por página ',
                        }">
                         <template v-slot:item.zaa_folio_arti_trasp="{ item }">
                            <sTraspaso :element="item"/>
                        </template>
                               
                        <template v-slot:item.zdtr_estatus_trasp="{ item }">
                            
                            <uEstaTras :element="{item, permissions}"/>
                            
                        </template>

                        <template v-slot:item.zdtr_id_traspaso="{ item }">
                            <v-row align="center">
                                <v-col> <dTraspaso :elementD="{item, permissions}"/> </v-col>
                                <v-col>
                                    <v-tooltip bottom >
                                        <template v-slot:activator="{ on, attrs }">                                            
                                            <v-btn icon :to="'/utraspaso/'+ item.zdtr_id_traspaso+'/'" v-bind="attrs" v-on="on" v-if="permissions.can_manage_art_trasp == true">
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                            <v-btn icon v-bind="attrs" v-on="on" v-else disabled>
                                                <v-icon color="blue" >mdi-pencil-outline</v-icon>
                                            </v-btn>
                                        </template>
                                        
                                        <span>Editar</span>
                                    </v-tooltip>
                                </v-col>
                            </v-row>
                        </template>
                        
                            
                    </v-data-table>
                    </div>
                </v-card>
            </v-col>

          </v-row>
    </div>
</template>
<script>
import Header from '../../components/Header';
import menuModulos from '../menuModulos'
import sTraspaso from './partials/sTraspaso'
import dTraspaso from './partials/dTraspaso'
import uEstaTras from './partials/uEstatusTrasp'
const axios = require('axios')
export default {
    name: 'Header', 
    components:{
        "app-header": Header,
        menuModulos,
        sTraspaso,
        dTraspaso,
        uEstaTras,
    },
    created() {
            this.find()
        },
        data () {
            return {
                element: Object,
                search: '',
                headers: [
                    { text: 'Ver detalles', align: 'start', filterable: true, value: 'zaa_folio_arti_trasp', sortable: true, align:'center'},
                    { text: 'Clave de articulo', value: 'zdtr_clave_art_trasp', sortable: true,  filterable: true, align:'center' },
                    { text: 'Sucursal de salida', value: 'zdtr_suc_salida', sortable: true, filterable: true, align:'center'},
                    { text: 'Sucursal de entrada', value: 'zdtr_suc_entrada', sortable: true, filterable: true, align:'center' },
                    { text: 'Estatus', value: 'zdtr_estatus_trasp', sortable: true, filterable: true, align:'center' },
                    
                    { text: 'Acciones', value: 'zdtr_id_traspaso', sortable: false },
                    
                ],
                elements: [],
                empleadoResult:[],
                idUser:[],
                permissions: {
                    can_manage_art_trasp: false,
                  
                },
            }
        },
        methods:{
            find(){


                 axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_art_trasp: true,
                                    
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_articulos_traspaso') { this.permissions.can_manage_art_trasp = true}
                                                        
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        })
                    
                })

                const userToken = localStorage.token
            axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
            .then(res => {this.idUser = res.data.user
            
            axios.get('http://127.0.0.1:8000/empleado/?search=' + this.idUser)
            .then(res => { this.empleadoResult = res.data[0]

                axios.get('http://127.0.0.1:8000/articulo/traspaso/?search='+this.empleadoResult.zdem_id_sucursal)
                .then(res => {this.elements = res.data})
                 })
                 })
            },
               
           
    
        },
        
}
</script>