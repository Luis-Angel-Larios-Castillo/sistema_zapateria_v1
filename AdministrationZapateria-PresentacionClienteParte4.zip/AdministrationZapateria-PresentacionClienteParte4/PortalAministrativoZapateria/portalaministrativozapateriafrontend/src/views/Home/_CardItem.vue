Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo cuenta con un Card que contiene los datos del articulo y la redirección al _Detail
<template >
    <v-hover v-slot="{ hover }">
        <v-card :to="'/detailarti/'+ CardData.zaag_id_articulo_global+'/'" :class="{ 'on-hover': hover }" :elevation="hover ? 20 : 5">
          
            <v-img dark class="white--text imgColor align-end"  height="200px">
                <h2  class="text-center" style="font-size:50px;">{{CardData.zaag_marca}}</h2>
                <v-card-title >{{CardData.zaag_nombre_arti}}</v-card-title>
            </v-img>  
            <v-card-text class=" black--text">
            <p class="text-center"><strong>Catalogo: </strong>{{CardData.zaag_catalogo}}</p>
            <p class="text-center"><strong>Depto: </strong>{{CardData.zaag_dep_etiqueta}}</p>
            <p class="text-center"><strong>Temporada: </strong>{{CardData.zaag_temp}}</p>
            <!--
            <v-row class="text-center">
                <v-col><p><strong>Modelo: </strong>{{CardData.zaa_modelo}}</p></v-col>  
                <v-col><p><strong>Marca: </strong>{{CardData.zaa_marca}}</p></v-col>                  
            </v-row>
            -->
            <p class="headline"><strong>$</strong>{{CardData.zaag_prec_cont}}</p>
            </v-card-text>        
        </v-card>
    </v-hover>
</template>
<script>
const axios = require('axios')
export default {
    props:[
        'CardData'
    ],
    data () {
      return {
        dialog: false,
    }
    },
  }
</script>
<style lang="sass" scoped>
.v-card.on-hover.theme--dark
  background-color: rgba(#FFF, 0.8)
  >.v-card__text
    color: #000
</style>