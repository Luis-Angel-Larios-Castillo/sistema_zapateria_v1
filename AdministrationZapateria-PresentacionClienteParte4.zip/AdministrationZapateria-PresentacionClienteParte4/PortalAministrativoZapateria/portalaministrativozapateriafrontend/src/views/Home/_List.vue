Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo tiene la sección del carrusel y la lista de artículos que llama a el componente _CardItem   
<template>
  <div cols="full">
     <app-header style="z-index: 135"/> 
    <!--<v-carousel hide-delimiters height="600px" cycle show-arrows-on-hover class="subheading pt-4">
      <v-carousel-item
      v-for="i in citems"
      :key="i.id"
      :src="i.src"
      :lazy-src="i.src"
      width="100%"
    >
    <div class="div_content_slider">
      <br><br><br><br>
      <br><br>
      <v-row>
        <v-col>
          <span class="title_slider_home">MARCA</span><br>
          <span class="title2_slider_home">ADIDAS</span>
        </v-col>
      </v-row>
      <v-row>
        <v-col>
          <a class="btn_inicio_slider">Comprar</a>
        </v-col>
      </v-row>
    
    </div>
    
    </v-carousel-item>
    </v-carousel>-->


     <v-img :src="require('@/assets/logov1.png')" width="80%" heighti="80%"/>

    <v-container>
    <div class="hr-sect"><h2>Productos</h2></div>
      <v-data-iterator :items="items" no-data-text="No hay resultados." no-results-text="No hay resultados." :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" :sort-by="sortBy.toLowerCase()" :sort-desc="sortDesc" hide-default-footer>
    
      <template v-slot:header>
          <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
      </template>
      <!-- Items inicio -->
      <template v-slot:default="props">
        <v-row>
          <v-col v-for="item in props.items" :key="item.zaag_id_articulo_global" cols="12" sm="6" md="4" lg="4" >
            <CardItem :CardData="item"/> 
          </v-col>
        </v-row>
      </template>
      <!-- Items fin -->
      <!-- Paginación inicio -->
      <template v-slot:footer>
        <v-row class="mt-2" align="center" justify="center" >
          <span class="grey--text">Elementos por página</span>
          <v-menu offset-y>
            <template v-slot:activator="{ on, attrs }">
              <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                {{ itemsPerPage }}
                <v-icon>mdi-chevron-down</v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                <v-list-item-title>{{ number }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
          <v-spacer></v-spacer>
          <span class="mr-4 grey--text">
            Página {{ page }} de {{ numberOfPages }}
          </span>
            <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
            <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
          <!-- Paginación fin -->
        </v-row>
      </template>
    </v-data-iterator>
    </v-container>
    <br>
  </div>
</template>

<script>
import Header from '../../components/Header';
import CardItem from './_CardItem'
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
       "app-header": Header,
        CardItem
    },
    data () {
      return {
        itemsPerPageArray: [ 9, 18, 27],
        search: '',
        filter: {},
        sortDesc: false,
        page: 1,
        itemsPerPage: 9,
        sortBy: 'zaa_nombre_arti',
        keys: [
          'zaa_color',
          'zaa_marca',
          'zaa_clave',
          'zaa_talla',
          'zaa_cantidad',
          'zaa_prec_cont',
          'zaa_modelo' 
        ],
        items: [],
        citems: [
          { id: 1, src: 'https://cdnv2.moovin.com.br/belinhacalcados/imagens/produtos/det/tenis-nike-bq3207-002-revolution-5-278b1b6b12429d8ce7a3ec6925c654c3.png' },
          { id: 2, src: 'https://images.tcdn.com.br/img/img_prod/651359/tenis_nike_adulto_air_max_alpha_at1237_005_8547_1_20201027103233.png' },
          { id: 3, src: 'https://cdnv2.moovin.com.br/belinhacalcados/imagens/produtos/det/tenis-nike-bq3207-002-revolution-5-278b1b6b12429d8ce7a3ec6925c654c3.png' },
          { id: 4, src: 'https://images.unsplash.com/photo-1529339944280-1a37d3d6fa8c?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=750&q=80' },
          { id: 5, src: 'https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1400&q=80' },
        ],
      }
    },
    created() {
      this.find()
    },
    computed: {
      numberOfPages () {
        return Math.ceil(this.items.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Name')
      },
      
    },
    methods: {
      find(){
      axios.get('http://127.0.0.1:8000/articuloglobal/')
        .then(res => {this.items = res.data })     
      },
      nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
      },
      formerPage () {
        if (this.page - 1 >= 1) this.page -= 1
      },
      updateItemsPerPage (number) {
        this.itemsPerPage = number
      },
    },
  }
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0, 0.35);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0, 0.35);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
    
}
.btn_inicio_slider{
  background:none;
  border-radius:50px;
  border:3px solid #14213d;
  padding: 8px;
  text-decoration:none;
  padding-left:30px;
  padding-right:30px;
  color:#14213d;
}
.btn_inicio_slider:hover{
  background:none;
  border-radius:50px;
  border:3px solid #fca311;
  padding: 8px;
  text-decoration:none;
  padding-left:30px;
  padding-right:30px;
  color:#fca311;
}
.div_content_slider{
  /*border:3px solid red;*/
  float:right;
  height:100%;
  width: 40%;
}
.title_slider_home{
  color:#14213d;
  font-size:40px;
  font-family: 'roboto';
  font-weight: bold;
}
.title2_slider_home{
  color:#fca311;
  font-size:80px;
  font-family: 'Bodoni MT Condensed';
  font-weight: bold;
}

</style>