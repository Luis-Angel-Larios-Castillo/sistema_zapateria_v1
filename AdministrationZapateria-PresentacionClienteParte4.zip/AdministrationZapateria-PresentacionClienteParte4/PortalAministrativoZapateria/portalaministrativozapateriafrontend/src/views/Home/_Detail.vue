Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo se muestra toda la información del articulo
<template>
    <v-container fluid>
        
          <app-header style="z-index: 135"/> 
              <br>
        <v-row>
            <v-col class="mx-auto md-6 xs-12">
                <v-img dark class="imgColor align-center" height="400px" width="600px">
                    <h2 class="white--text text-center" style="font-size:60px;">{{element.zaag_marca}}</h2> 
                </v-img>  
            </v-col>  
            <v-col class="text-center black--text align-center md-6 xs-12"> 
            <h1 style="font-size:60px;">{{element.zaag_nombre_arti}}</h1><br>
            <p>
                <strong>Catalogo: </strong>
                <v-chip class="ma-2" color="blue" label outlined >
                    {{element.zaag_catalogo}} 
                </v-chip>    
                <strong>Temporada: </strong>
                <v-chip class="ma-2" color="blue" label outlined >
                    {{element.zaag_temp}}
                </v-chip> 
            </p> 
                <strong>Departamento: </strong>
                <v-btn :to="'/departamento/'+ element.zaag_id_depart" color="green" outlined>
                    {{element.zaag_dep}}
                </v-btn><br><br>
                <strong>Subdepartamento: </strong>
                <v-btn :to="'/departamento/'+ element.zaag_id_subdep" color="green" outlined>
                    {{element.zaag_dep_etiqueta}}
                </v-btn> <br><br>
            <strong>Categoría: </strong>
                <v-chip class="ma-2" color="blue" label outlined >
                    {{element.zaag_categoria}} 
                </v-chip>
            <h2><strong>Precio: </strong>${{element.zaag_prec_cont}}</h2><br>
            <!--
            <p><strong>Sucursal: </strong>{{element.zaa_sucursal}}</p>
            <p><strong>Colores: </strong>{{colores}}</p>   
            <p><strong>Cantidad: </strong>{{element.zaa_cantidad}}</p>
            <p><strong>Tallas: </strong>{{sizes}}</p>   
            -->
            <p><strong>Modelo: </strong>{{element.zaag_modelo}}</p>  
            <p><strong>Marca: </strong>{{element.zaag_marca}}</p>
            <!--
            <v-form ref="form" v-model="valid" lazy-validation m>
                <v-row>
                    <v-col cols="6">
                        <v-select v-model="colorSel" :items="colores" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un color']"  label="Color" required/>
                    </v-col>
                    <v-col cols="6">
                        <v-select v-model="sizeSel" :items="sizes" item-text="text" item-value="text" :rules="[v => !!v || 'Debe seleccionar un talla']"  label="Talla" required/>
                    </v-col>
                </v-row>
                <v-row align="center">
                    <v-col cols="2"/>
                    <v-col cols="4" >
                        <v-select v-model="cant" :items="cantidad02" :rules="[v => !!v || 'Debe seleccionar una cantidad']"  label="Cantidad" required/>
                    </v-col>
                    <v-col cols="4" >
                        <v-btn text  color="primary" v-if="cantidad != 0" :disabled="!valid" @click="validate">
                            Agregar
                            <v-icon>mdi-eye</v-icon>   
                        </v-btn>
                    </v-col>
                    <v-col cols="2"/>
                </v-row>
                
            </v-form>
            <v-snackbar shaped color="green" outlined v-model="snackbar" :timeout="timeout">
            <h2 class="black--text" >{{ text }}</h2>
            

            <template v-slot:action="{ attrs }">
                <v-btn
                color="blue"
                text
                v-bind="attrs"
                @click="snackbar = false"
                >
                Cerrar
                </v-btn>
            </template>
            </v-snackbar>
            -->
        </v-col>
        </v-row>  
    </v-container>
</template>
<script>
import Header from '../../components/Header';
const axios = require('axios')
export default {  
    name: 'Header', 
    components: {
    "app-header": Header,
  },  
    created() {
        this.find() 
        
    },
    data() {
        return {
            idUser:'',
            snackbar: false,
            text: 'El articulo se agrego al carrito',
            timeout: 3000,
            element: [],
            elementG:[],
            colores: '',
            colorSel: '',
            sizes: '',
            sizeSel: '',
            cabeceraPedido:[],
            catalogo:[],
            cantidad: 0,
            cantidad02: [],
            valid: true,
            cant: 1,
            cantRules: [
                v => !!v || 'Cantidad inválida.',
                v => (v && v > 0) || 'No se puede seleccionar esta cantidad.',
                v => (v && v < this.cantidad+1) || 'No se puede seleccionar esta cantidad +',
            ],
        }
    },
    methods: {
        getColors(){
            let extn = this.element.zaa_color.length
            let colo = ''
            for (let i = 0; i < extn; i++) {
            if (i == extn -1) {
                colo = colo + this.element.zaa_color[i].text
                this.colores = colo
            }else{
                colo = colo + this.element.zaa_color[i].text + " - "
            }
            }
        },
        getSizes(){
            let extn = this.element.zaa_talla.length
            let size = '' 
            for (let i = 0; i < extn; i++) {
            if (i == extn -1) {
                size = size + this.element.zaa_talla[i].text
                this.sizes = size
            }else{
                size = size + this.element.zaa_talla[i].text + " - "
            }
            }
        },
        /*
        getCabecera(){
            if(localStorage.token){
                axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                .then((res) => {
                    this.idUser = res.data.user
                     axios.get('http://127.0.0.1:8000/pedido/pcuactiv/?search='+res.data.user)
                        .then((res) => { 
                            if(res.data.length == 0){ 
                                axios.post('http://127.0.0.1:8000/pedido/pedcab/',{
                                    "zped_status": "Activo",
                                    "zped_fecha":  new Date().toISOString().slice(0,10),
                                    "zipe_total": 0,
                                    "zped_id_usuario": this.idUser
                                }).then(res=> window.location.reload())
                             }
                            this.cabeceraPedido = res.data[0]})
                })
            }
        },
        validate () {
            if(localStorage.token == ''){
                this.$router.replace({name: 'Login'})
            }else{
                axios.get('http://127.0.0.1:8000/usuario/token/'+localStorage.token+'/' )
                    
                    .catch(error=> { localStorage.token = '', this.$router.replace({name: 'Login'})})
                
                if (this.$refs.form.validate()){
                    this.elementG = {
                        zipe_color: this.colorSel,
                        zipe_talla: this.sizeSel,
                        zipe_cant: this.cant,
                        zipe_sub_tot: this.cant * this.element.zaa_prec_cont,
                        zipe_status: 'Espera',
                        zipe_id_arti: this.element.zaa_id_articulo,
                        zipe_id_pedido_cab: this.cabeceraPedido.zped_id_pedcab
                }
                this.create()
            }
            }

        },
        async create(){
            this.getCabecera()
            await axios.post('http://127.0.0.1:8000/pedido/itemped/', this.elementG)
            .then(res=> {
                this.snackbar = true
                window.location.reload()
            })
            .catch(error => console.log(error));
        },
        */
        find(){
            axios.get('http://127.0.0.1:8000/articuloglobal/'+ this.$route.params.id +'/').
                then(res => { 
                    this.element = res.data
                    /*
                    this.cantidad = res.data.zaa_cantidad
                    let cant = []
                    for (let i = 1; i <= res.data.zaa_cantidad; i++) {               
                        cant.push(i)
                    }
                    this.cantidad02 = cant
                    
                    this.getColors()
                    this.getSizes()
                    */
                })
        },

        
    },
    
}
</script>