Autor: Miguel Angel Zamora Carmona
Descripción: Este archivo cuenta con un listado de los artículos pertenecientes a un departamento o subdepartamento, la lista de artículos que llama a el componente _CardItem
<template>
    <v-container fluid>
        <app-header style="z-index: 135"/> 
        <div class="col-11">
      <div class="hr-sect"><h2>Productos</h2></div>
        <v-data-iterator :items="items" no-data-text="No hay resultados." no-results-text="No hay resultados." :items-per-page.sync="itemsPerPage" :page.sync="page" :search="search" :sort-by="sortBy.toLowerCase()" :sort-desc="sortDesc" hide-default-footer>
    
      <template v-slot:header>
          <v-text-field v-model="search" clearable flat solo-inverted hide-details prepend-inner-icon="mdi-magnify" label="Buscar..."/><br>
      </template>
      <!-- Items inicio -->
      <template v-slot:default="props">
        <v-row>
          <v-col v-for="item in props.items" :key="item.zaag_id_articulo_global" cols="12" sm="6" md="4" lg="4" >
            <CardItem :CardData="item"/> 
          </v-col>
        </v-row>
      </template>
      <!-- Items fin -->
      <!-- Paginación inicio -->
      <template v-slot:footer>
        <v-row class="mt-2" align="center" justify="center" >
          <span class="grey--text">Elementos por página</span>
          <v-menu offset-y>
            <template v-slot:activator="{ on, attrs }">
              <v-btn dark text color="primary" class="ml-2" v-bind="attrs" v-on="on">
                {{ itemsPerPage }}
                <v-icon>mdi-chevron-down</v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item v-for="(number, index) in itemsPerPageArray" :key="index" @click="updateItemsPerPage(number)">
                <v-list-item-title>{{ number }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
          <v-spacer></v-spacer>
          <span class="mr-4 grey--text">
            Página {{ page }} de {{ numberOfPages }}
          </span>
            <v-icon color="" @click="formerPage">mdi-chevron-left</v-icon>
            <v-icon color="blue darken-3" class="ml-1" @click="nextPage">mdi-chevron-right</v-icon>
          <!-- Paginación fin -->
        </v-row>
      </template>
    </v-data-iterator>
    <br>
        </div>
    </v-container>
</template>
<script>
import Header from '../../components/Header';
import CardItem from './_CardItem'
const axios = require('axios')
export default {
  name: 'Header', 
    components:{
      "app-header": Header,
        CardItem
    },
    data() {
        return {
            itemsPerPageArray: [ 9, 18, 27],
            search: '',
            filter: {},
            sortDesc: false,
            page: 1,
            itemsPerPage: 9,
            sortBy: 'zaa_nombre_arti',
            keys: [
            'zaa_color',
            'zaa_marca',
            'zaa_clave',
            'zaa_talla',
            'zaa_cantidad',
            'zaa_prec_cont',
            'zaa_modelo'

            ],
            items: [],
        }
    },
    created() {
        axios.get("http://127.0.0.1:8000/articuloglobal/?search=" + this.$route.params.id)
          .then(res => this.items = res.data)
    },
    computed: {
      numberOfPages () {
        return Math.ceil(this.items.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== 'Name')
      },
      
    },
    methods: {
        nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
      },
      formerPage () {
        if (this.page - 1 >= 1) this.page -= 1
      },
      updateItemsPerPage (number) {
        this.itemsPerPage = number
      },
    },
    watch: {
        "$route.params.id" : function(){
            axios.get("http://127.0.0.1:8000/articuloglobal/?search=" + this.$route.params.id)
              .then(res => this.items = res.data)
            
        }
    },
}
</script>
<style>
.hr-sect {
    display: flex;
    flex-basis: 100%;
    align-items: center;
    color: rgba(0, 0, 0, 0.35);
    margin: 8px 0px;
}
.hr-sect:before,
.hr-sect:after {
    content: "";
    flex-grow: 1;
    background: rgba(0, 0, 0, 0.35);
    height: 1px;
    font-size: 0px;
    line-height: 0px;
    margin: 0px 8px;
}
</style>