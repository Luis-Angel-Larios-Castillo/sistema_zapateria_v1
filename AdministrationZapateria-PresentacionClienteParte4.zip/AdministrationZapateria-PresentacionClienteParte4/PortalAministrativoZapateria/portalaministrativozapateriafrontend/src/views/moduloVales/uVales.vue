<template>
  <v-container fluid>
    <div v-if="permissions.can_manage_vales == true">
       <app-header style="z-index: 135"/> 
    <div class="col-8">
       <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
        <v-toolbar-title>
        <v-icon right dark>
              mdi-rotate-3d-variant
            </v-icon>
           <strong id="title_editar"> Actualizar: {{ elementU.zdv_folio_vale }}</strong>
        </v-toolbar-title>

      </v-toolbar>
        <v-container id="tabla_datos_dos" class="col-12">
        <v-form ref="form" v-model="valid" lazy-validation>     
 
    <v-row>
      <v-col>
        <v-text-field
          v-model="cliente_user_cliente.nom_and_folio"
          label="Nombre del cliente"
          filled
          readonly
        ></v-text-field>
      </v-col>
      <v-col>
       <div v-if="man_reali_su == false">
         <v-text-field
          v-model="empleado_user_empleado.nombre"
          label="Empleado que realizo el vale"
          filled
          readonly
        ></v-text-field>
        </div>
        <div v-else>
          <v-text-field
          v-model="man_reali_correo"
          label="Empleado que realizo el vale"
          filled
          readonly
        ></v-text-field>
        </div>
      </v-col>
    </v-row>

     <v-row>
              <v-col>
                <v-autocomplete
                  v-model="elementU.zdv_id_item_ped"
                  :items="pedidos"
                  filled
                  label="Buscar Pedido"
                  item-text="nomped_nomarti"
                  item-value="zipe_id_item_ped"
                  readonly
                  required
                ></v-autocomplete>
              </v-col>
              <v-col>
                 <v-text-field
                  v-model="elementU.zdv_importe"
                  label="Importe"
                  prefix="$"
                  counter
                  filled
                  oninput="this.value=this.value.replace(/[^0-9]/g,'');"
                  required
                  maxlength="6"
                ></v-text-field>
              </v-col>
            </v-row>

    <div v-if="man_aut_su == true">
        <v-text-field
          v-model="man_aut_correo"
          label="Empleado que autorizo el vale"
          filled
          readonly
        
        ></v-text-field>
      </div>
       <div v-else>
           <v-text-field
          v-model="empleado_autori_empleado.nombre"
          label="Empleado que autorizo el vale"
          filled
          readonly
         
        ></v-text-field>
       </div>
          {{fecha(elementU.zdv_fech_crea)}}

          <div hidden>{{difetencia_fechas_vali}}</div>
         
          
            <v-row v-show="difetencia_fechas_vali >= 3 && elementU.zdv_id_user_autori == 'No autorizado aún'">
              <v-col>
                <v-switch
                  v-model="ver_vali_check"
                  inset
                  label="Autorizar vale con credenciales"
                  readonly
                >
                </v-switch>
            </v-col>
            <v-col>
              <v-btn
                  color="primary"
                  dark
                  @click="dialog2 = true"
                  block
                  outlined
                >
                  Autorizar Vale
                </v-btn>
            </v-col>
          </v-row>
      <v-row>
        <v-col>
                  <v-switch
                        v-show="elementU.zdv_id_user_autori == 'No autorizado aún' && difetencia_fechas_vali < 3"
                        v-model="ver_vali_check2"
                        inset
                        label="Autorizar Vale"
                        :readonly="permissions.canAutorizar == false"
                  >
                  </v-switch>
        </v-col>
        <v-col>
          <p v-show="elementU.zdv_id_user_autori == 'No autorizado aún' && permissions.canAutorizar == false" style="color:red;">No cuentas con los permisos para autorizar este vale</p>
        </v-col>
      </v-row>
            <hr>
            <br>
             <v-dialog v-model="dialog2" max-width="500px">
                  <v-card>
                    <v-card-title> Autorizar Vale </v-card-title>
                    <v-card-text>
                      <div v-if="User_Auten == null">
                        <v-text-field
                          v-model="correo"
                          label="Correo"
                          :rules="emailRules"
                        />
                        <v-text-field
                          v-model="pass"
                          label="Contraseña"
                          :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                          :type="show1 ? 'text' : 'password'"
                          counter
                          @click:append="show1 = !show1"
                        />
                        <v-btn
                          depressed
                          color="primary"
                          @click="autenticar()"
                          block
                          >Verificar</v-btn
                        >
                      </div>
                      <div v-else>
                        <h2>Se autorizado el vale</h2>
                        <div hidden>
                          {{ User_Auten }}
                          {{ (permissions.canAutorizar = true) }}
                          {{ (ver_vali_check = true) }}
                        </div>
                      </div>
                    </v-card-text>
                    <v-card-actions>
                      <v-btn color="red" text @click="dialog2 = false">
                        Cerrar
                      </v-btn>
                    </v-card-actions>
                  </v-card>
                </v-dialog>

                <v-snackbar color="red" v-model="snackbar">
                El correo o contraseña son incorrectos
              </v-snackbar>
              <v-snackbar color="red" v-model="snackbar2">
                Las credenciales son invalidas
              </v-snackbar>
              <v-snackbar color="red" v-model="snackbar3">
                El usuario no cuenta con los permisos
              </v-snackbar>
                <!--FIND LOGIN-->



          <v-row align="center" justify="space-around">
              <v-btn
                :disabled="!valid"
                x-large
                id="btn_actualizar_formulario"
                class="mr-4"
                @click="validate"
                
              >
                Actualizar
                <v-icon right dark>mdi-update</v-icon>
              </v-btn>
              <v-btn
               
                x-large
                class="mr-4"
                @click="cancelar"
                id="btn_cancelar_formulario"
                >Cancelar<v-icon right dark>mdi-close-circle</v-icon></v-btn
              >
            </v-row>

        </v-form>
       </v-container>
    </div>
    </div>
      <div v-else>
        <ErrorPage403/>
      </div>
  </v-container>
</template>
<script>
import Header from '../../components/Header';
import ErrorPage403 from '../../components/ErrorPage403.vue';
const axios = require("axios");
const moment = require('moment');
export default {
   name: 'Header', 
        components:{
           "app-header": Header,
            ErrorPage403
          }, 
        created() {
            this.findpermsisos()
            this.find();
            this.findpedidos();
            this.finduserpermission();
            this.findIdUser();
        },
        data () {
            return {   
              ocultar: true,            
               elementU: [],
               pedidos: [],
               valid: true,
               ver_vali_check: false,
               ver_vali_check2: false,
               conalert: null,
               show1: false,
               snackbar3: false,
               snackbar2: false,
               snackbar: false,
               dialog2: false,
               cliente_user:[],
               cliente_user_cliente:[],
               empleado_user:[],
               empleado_user_empleado:[],
               empleado_autori:[],
               empleado_autori_empleado:[],
               difetencia_fechas_vali:null,
               man_aut_su:'',
               man_aut_correo:'',
               man_reali_su:'',
               man_reali_correo:'',

               //permissions para autorizar 
               
              permissions: {
                canAutorizar: false,
                can_manage_vales: false,
              },
              correo: "",
              emailRules: [
                (v) => !!v || "El campo correo es obligatorio",
                (v) => /.+@.+\..+/.test(v) || "Introduce una dirección de correo valida",
              ],
              pass: "Hola@1234",
              User_Auten: null,
              idUser:[],
               
               
            }
        },
        methods:{
          findpermsisos(){
                axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                        .then(res => {    
                            axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                                .then(resGet =>{
                                    if(resGet.data.is_superuser == true){
                                        this.permissions = {
                                            can_manage_vales: true,
                                        }
                                    } else {
                                        axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                            .then(resUs => {   
                                                    resUs.data.groups.forEach(group => {
                                                        group.permissions.forEach(permission => {  

                                                            axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                            .then(resPer => {
                                                                if(resPer.data.codename == 'manage_vales') { this.permissions.can_manage_vales = true}
                                                                
                                                            })
                                                            
                                                        });
                                                    });  
                                            })
                                    }
                                }) 
                        }) 
              },
            findpedidos() {
                axios.get("http://127.0.0.1:8000/pedido/itembpc/")
                .then((res) => (this.pedidos = res.data));
            },
            findIdUser(){
              const userToken = localStorage.token
              axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
                .then(res => this.idUser = res.data.user)
            },
            find(){
                axios.get("http://127.0.0.1:8000/vale/" + this.$route.params.id + "/")
                .then(res =>  {this.elementU = res.data
               
                //Cliente
                axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.elementU.zdv_id_cliente+"/")
                .then(resc_s =>  {this.cliente_user = resc_s.data
                
                    if(this.cliente_user.is_superuser == true){
                      console.log("es otro cliente")
                    }
                    else{
                      axios.get("http://127.0.0.1:8000/cliente/clientes/?search=" + this.elementU.zdv_id_cliente)
                    .then(res =>  {this.cliente_user_cliente = res.data[0]})
                    }
                })


                //Empleado que creo vale
                 axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.elementU.zdv_id_empleado+"/")
                .then(resE_s =>  {this.empleado_user = resE_s.data

                  this.man_reali_su=resE_s.data.is_superuser
                  this.man_reali_correo=resE_s.data.zdus_correo

                    if(this.empleado_user.is_superuser == true){
                      //console.log("El que creo el vale es super usuario")
                    }
                    else{
                    axios.get("http://127.0.0.1:8000/empleado/?search=" + this.elementU.zdv_id_empleado)
                    .then(res =>  {this.empleado_user_empleado = res.data[0]})
                    }
                })

                 //Empleado que autorizo vale
               if(this.elementU.zdv_id_user_autori != 'No autorizado aún'){
                 axios.get("http://127.0.0.1:8000/usuario/getusuario/" + this.elementU.zdv_id_user_autori+"/")
                .then(resE_suto =>  {this.empleado_autori = resE_suto.data

                this.man_aut_su = resE_suto.data.is_superuser
                this.man_aut_correo = resE_suto.data.zdus_correo

                    if(this.empleado_user.is_superuser == true){
                      //console.log("El que autorizo es super usuario")
                    }
                    else{
                    axios.get("http://127.0.0.1:8000/empleado/?search=" + this.elementU.zdv_id_user_autori)
                    .then(res =>  {this.empleado_autori_empleado = res.data[0]})
                    }
                })}
                else{
                  //console.log("vale no autorizado aun")
                }

                
                })
            },

            validate() {
              if (this.ver_vali_check == true) {
                if (this.$refs.form.validate()) {
                  this.elementU = {
                    zdv_folio_vale: this.elementU.zdv_folio_vale,
                    zdv_id_user_autori: this.User_Auten,
                    zdv_fecha_cobro: this.elementU.zdv_fecha_cobro,
                    zdv_importe: this.elementU.zdv_importe,
                    zdv_id_user_qcobra_vale: this.elementU.zdv_id_user_qcobra_vale,
                    zdv_id_sucursal: this.elementU.zdv_id_sucursal,
                    zdv_id_usuario: this.elementU.zdv_id_usuario,
                    zdv_estat_vale: this.elementU.zdv_estat_vale,
                    zdv_id_pedcab: this.elementU.id_ped_cab,
                    zdv_id_item_ped: this.elementU.zdv_id_item_ped,
                    zdv_id_empleado: this.elementU.zdv_id_empleado,
                  };
                  this.update();
                }
              }
            else if (this.ver_vali_check2 == true) {
                if (this.$refs.form.validate()) {
                  this.elementU = {
                    zdv_auto_increment: this.elementU.zdv_auto_increment,
                    zdv_folio_vale: this.elementU.zdv_folio_vale,
                    zdv_id_user_autori: this.idUser,
                    zdv_fecha_cobro: this.elementU.zdv_fecha_cobro,
                    zdv_importe: this.elementU.zdv_importe,
                    zdv_id_user_qcobra_vale: this.elementU.zdv_id_user_qcobra_vale,
                    zdv_id_sucursal: this.elementU.zdv_id_sucursal,
                    zdv_id_usuario: this.elementU.zdv_id_usuario,
                    zdv_estat_vale: this.elementU.zdv_estat_vale,
                    zdv_id_pedcab: this.elementU.id_ped_cab,
                    zdv_id_item_ped: this.elementU.zdv_id_item_ped,
                    zdv_id_empleado: this.elementU.zdv_id_empleado,
                  };
                  this.update();
                }
              } 
              else {
                if (this.$refs.form.validate()) {
                  this.elementU = {
                    zdv_auto_increment: this.elementU.zdv_auto_increment,
                    zdv_folio_vale: this.elementU.zdv_folio_vale,
                    zdv_id_user_autori: this.elementU.zdv_id_user_autori,
                    zdv_fecha_cobro: this.elementU.zdv_fecha_cobro,
                    zdv_importe: this.elementU.zdv_importe,
                    zdv_id_user_qcobra_vale: this.elementU.zdv_id_user_qcobra_vale,
                    zdv_id_sucursal: this.elementU.zdv_id_sucursal,
                    zdv_id_usuario: this.elementU.zdv_id_usuario,
                    zdv_estat_vale: this.elementU.zdv_estat_vale,
                    zdv_id_pedcab: this.elementU.id_ped_cab,
                    zdv_id_item_ped: this.elementU.zdv_id_item_ped,
                    zdv_id_empleado: this.elementU.zdv_id_empleado,
                  };
                  this.update();
                }
              }
            },

        async update() {
              await axios
                .put(
                  "http://127.0.0.1:8000/vale/" + this.$route.params.id + "/",
                  this.elementU
                )
                .catch((error) => console.log(error));
              this.$router.push({ name: "Vale" });
            },
        reset() {
          this.$refs.form.reset();
        },
        cancelar() {
          this.$router.push({ name: "Vale" });
        },
         fecha(date_creacion){
          var fecha_de_hoy = moment();
          var fecha1 = moment(date_creacion);
          var fecha2 = moment(fecha_de_hoy);
          this.difetencia_fechas_vali= fecha2.diff(fecha1, 'months');
        },
        autenticar() {
          let datos = {
            zdus_correo: this.correo,
            password: this.pass,
          };
            axios
              .post("http://127.0.0.1:8000/usuario/compuser/", datos)
              .then(res => {
                if (res.data.user.is_superuser == true) {
                  this.permissions.canAutorizar = true;
                  this.User_Auten = res.data.user.zdus_id_usuario;
                } else if (
                  res.data.user.is_superuser == false &&
                  res.data.user.is_staff == false
                ) {
                  this.snackbar2 = true;
                } else {
                  res.data.user.groups.forEach((group) => {
                    group.permissions.forEach((permission) => {
                      axios
                        .get(
                          "http://127.0.0.1:8000/usuario/permissions/" +
                            permission +
                            "/"
                        )
                        .then((resPer) => {
                          if(resPer.data.codename == 'manage_vales') { this.permissions.can_manage_vales = true}
                          if (resPer.data.codename == "authorize_vale") {
                            this.permissions.canAutorizar = true;
                            if (
                              res.data.user.zdus_id_usuario != null &&
                              res.data.user.is_staff == true
                            ) {
                              //console.log(res.data.user)
                              this.User_Auten = res.data.user.zdus_id_usuario;
                              this.conalert = 1;
                            } else {
                              //console.log('El usuario no cuenta con los permisos')
                              this.conalert = 0;
                            }
                          } else {
                            this.conalert = 0;
                          }
                        });
                    });
                  });
                  if (this.conalert == 0) {
                    this.snackbar3 = true;
                  }
                }
              }) .catch(res => {
          this.snackbar = true;
        });
    },


        finduserpermission() {
      let config = {
        headers: {
          Authorization: "Token " + localStorage.token,
        },
      };
      axios
        .get(
          "http://127.0.0.1:8000/usuario/token/?search=" + localStorage.token
        )
        .then((res) => {
          axios
            .get(
              "http://127.0.0.1:8000/usuario/getusuario/" +
                res.data[0].user +
                "/"
            )
            .then((resGet) => {
              if (resGet.data.is_superuser == true) {
                this.permissions = {
                  canAutorizar: true,
                  can_manage_vales: true,
                };
              } else {
                axios
                  .get(
                    "http://127.0.0.1:8000/usuario/user-permissions/" +
                      res.data[0].user +
                      "/"
                  )
                  .then((resUs) => {
                    resUs.data.groups.forEach((group) => {
                      group.permissions.forEach((permission) => {
                        axios
                          .get(
                            "http://127.0.0.1:8000/usuario/permissions/" +
                              permission +
                              "/",
                            config
                          )
                          .then((resPer) => {
                            if (resPer.data.codename == "authorize_vale") {
                              this.permissions.canAutorizar = true;
                            }
                            if(resPer.data.codename == 'manage_vales') { this.permissions.can_manage_vales = true}
                          });
                      });
                    });
                  });
              }
            });
        });
    },
           
        },
    }
</script>