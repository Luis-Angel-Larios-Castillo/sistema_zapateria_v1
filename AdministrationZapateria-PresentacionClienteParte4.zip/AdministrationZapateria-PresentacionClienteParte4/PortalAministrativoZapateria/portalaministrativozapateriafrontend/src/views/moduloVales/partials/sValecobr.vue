<!--Autor: Luis Angel Larios Castillo
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro-->
<template>
  <v-container grid-list-xs>
      <div v-if="element.zdv_id_user_qcobra_vale=='No cobrado aún'">
         <span style="color:red;"> No cobrado aún</span>
        </div> 
        <div v-else>
       <div v-for="user in user_cobra" :key="user.id">
           
            <div v-if="user.is_superuser">
                {{user.zdus_correo}}
            </div>
            <div v-else v-for="userxobra in empleado_cobra" :key="userxobra.id">
            {{userxobra.nombre}}
            
            </div>
        </div>
          
            </div> 
            
  </v-container>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')
  export default {
    props:[
      'element'
    ],

    created() {
      this.findUserCobra()
      this.findEmpleadoCobra()
     
    },

    data () {
      return {
        empleado_cobra:[],
        user_cobra:[],
        nombre:''

      }
    },

    methods:{
      
      findEmpleadoCobra(){
        axios.get('http://127.0.0.1:8000/empleado/?search='+this.element.zdv_id_user_qcobra_vale)
        .then(resE => this.empleado_cobra = resE.data)
      },
      
      
      findUserCobra(){
        if(this.element.zdv_id_user_qcobra_vale != "No cobrado aún"){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+this.element.zdv_id_user_qcobra_vale)
        .then(resE => this.user_cobra = resE.data)
        }
        else{
          this.mostr_msj2="Este vale no se ha cobrado";
        }
      },
   
     
       
    },
  }
</script>