<!--Autor: Luis Angel Larios Castillo
Descripción: Este archivo contiene el formulario el cual permite hacer el registro de nuevas promociones para el slider principal-->
<template>
    <v-container fluid> 
      <div v-if="permissions.can_manage_vales == true">
         <app-header style="z-index: 135"/> 
    
    <v-col cols="md-8 xs-12">
         <div flat align="center" justify="space-around">
          <hr class="line_superior">
          <h1 id="title">REGISTRO DE VALES</h1>
        </div><br>
        <v-card :elevation="0">
             <v-toolbar flat align="center" justify="space-around" id="table_cabecera_color_formulario">
            
            <v-col>
              <v-chip
              class="ma-2"
              color="#F7F9F9"
              outlined
                    >
                       {{obtvale()}}
                     
                    </v-chip>
                </v-col>
            <v-spacer/>  
            <v-btn to="/Catalogos/" outlined class="btn_add" color="#F7F9F9">
            <v-icon>
              mdi-arrow-left-circle
            </v-icon>
              Regresar
            </v-btn>
          </v-toolbar>
          
        
          <v-container id="tabla_datos_dos" class="col-12">
            <v-form ref="form" v-model="valid" lazy-validation>
              <v-row>
                 
                <v-col v-if="ocultar">
                   <v-text-field filled v-model="zdv_id_user_autori" label="Quien autoriza"></v-text-field>
                </v-col>
                
              </v-row>
              <v-row>
                <v-col>
                <v-autocomplete
            v-model="clientSelect"
            :items="clientes_users"
            dense
            filled
            label="Selecciona un cliente"
            item-text="nom_and_folio" item-value="zc_id_usuario"
            :rules="[v => !!v || 'Debe seleccionar un cliente']"   required
          ></v-autocomplete>
                </v-col>
              </v-row>
               <v-row>
                 <v-col v-if="ocultar">
                    <v-text-field  v-model="zdv_id_user_qcobra_vale" label="Id del usuario que cobra" v-if="ocultar"></v-text-field>
                </v-col>
                <v-col v-if="ocultar">
                   <v-text-field v-model="zdv_fecha_cobro" label="Fecha de cobro" v-if="ocultar"></v-text-field>
                </v-col>
                <v-col>
                   <v-text-field filled v-model="zdv_importe"  prefix="$" label="Importe" oninput="this.value=this.value.replace(/[^0-9]/g,'');" counter  required  maxlength="6"></v-text-field>
                </v-col>
             
              </v-row>

               <v-row>
                 <v-col>
                   <v-select  filled v-model="sucSelect" :items="sucursales" item-text="zdsu_nombre" item-value="zdsu_id_sucursal" :rules="[v => !!v || 'Debe seleccionar una Sucursal']"  label="Sucursal de entrega" required/>
                </v-col>
               
                <v-col v-if="ocultar">
                  <v-switch
                        v-if="ocultar"
                        v-model="zdv_estat_vale"
                        inset
                        label="Estatus"
                      ></v-switch>
                </v-col>
               
              </v-row>
  <v-row>
    <v-col>
      <v-autocomplete
            v-model="pedSelect"
            :items="pedidos"
            filled
            dense
            label="Buscar Pedido"
            item-text="nomped_nomarti" item-value="zipe_id_item_ped"
            :rules="[v => !!v || 'Debe seleccionar un pedido']"   required
          ></v-autocomplete>
          
      </v-col>
     
  </v-row>

              <br>
                <v-row align="center" justify="space-around">
                    <v-btn :disabled="!valid" id="btn_agrega_otro_formulario"  class="mr-1" @click="validate">
                        Guardar y agregar otro 
                        <v-icon right dark>
                            mdi-reload
                        </v-icon>
                    </v-btn>
                    <v-btn :disabled="!valid" id="btn_guardar_formulario" class="mr-1" @click="validate02">
                        Guardar 
                        <v-icon right dark>
                            mdi-cloud-upload
                        </v-icon>
                    </v-btn>
                    <v-btn id="btn_borrar_formulario" class="mr-1" @click="reset">
                        Borrar formulario
                      <v-icon right dark>mdi-eraser</v-icon>
                    </v-btn>
                </v-row>
            </v-form>
          </v-container>
          </v-card>
       </v-col>
      </div>
      <div v-else>
        <ErrorPage403/>
      </div>
    </v-container>
</template>

<script>
import Header from '../../../components/Header';
import ErrorPage403 from '../../../components/ErrorPage403.vue'
let fecha_vale =  new Date().toISOString().slice(0,10)
const axios = require('axios')
  export default {
    name: 'Header', 
    components:{
       "app-header": Header,
    ErrorPage403
  }, 
    
    data () {
      return {
      element: [],
      valid: true,
      ocultar: false,
      search: null,
      idUser: '',
      sucursales: [],
      sucSelect: null,
      pedidos:[],
      pedSelect: '',
      zdv_id_user_autori:'No autorizado aún',
      zdv_id_user_qcobra_vale:'No cobrado aún',
      zdv_fecha_cobro:null,
      zdv_importe:'',
      zdv_id_sucursal:'',
      zdv_id_item_ped:'',
      zdv_estat_vale:false,
      zdv_id_usuario:'',
      num_random: Math.floor(Math.random() * (10 - 1 + 1)) +''+ Math.floor(Math.random() * (10 - 1 + 1))+''+ Math.floor(Math.random() * (10 - 1 + 1))  ,
      idpedcab:'',

      busqvalest:[],
      elements: [],
      clientes_users:[],
      clientSelect: null,
      pedcabSelect:'',
      permissions: {
                    can_manage_vales: false,
                  
                },
     
      
     
      }
    },
    created() {
      this.findpermsisos()
      this.findSucursal()
      this.findIdUser()
      this.findpedidos()
      this.findvalest()
      this.findclienteuser()
      
     
    },

    methods: {
      findpermsisos(){
        axios.get('http://127.0.0.1:8000/usuario/token/?search=' + localStorage.token ) 
                .then(res => {    
                    axios.get('http://127.0.0.1:8000/usuario/getusuario/'+ res.data[0].user + '/')
                        .then(resGet =>{
                            if(resGet.data.is_superuser == true){
                                this.permissions = {
                                    can_manage_vales: true,
                                }
                            } else {
                                axios.get('http://127.0.0.1:8000/usuario/user-permissions/' + res.data[0].user + '/' ) 
                                    .then(resUs => {   
                                            resUs.data.groups.forEach(group => {
                                                group.permissions.forEach(permission => {  

                                                    axios.get('http://127.0.0.1:8000/usuario/permissions/' + permission + '/')
                                                    .then(resPer => {
                                                        if(resPer.data.codename == 'manage_vales') { this.permissions.can_manage_vales = true}
                                                        
                                                    })
                                                    
                                                });
                                            });  
                                    })
                            }
                        }) 
                }) 
      },
      findvalest(){
                axios.get('http://127.0.0.1:8000/vale/')
                .then(res => this.busqvalest = res.data)
            },
      findIdUser(){
        const userToken = localStorage.token
        axios.get('http://127.0.0.1:8000/usuario/token/'+userToken+'/' )
          .then(res => this.idUser = res.data.user)
      },
      findpedidos(){
                axios.get('http://127.0.0.1:8000/pedido/itembpc/')
                .then(res => this.pedidos = res.data)                            
        },
        
       
        
        findclienteuser(){
            axios.get('http://127.0.0.1:8000/cliente/clientes/')
                .then(res => this.clientes_users = res.data)                
        },
      findSucursal(){
        axios.get('http://127.0.0.1:8000/sucursal/sucursales/activas/')
          .then(res => this.sucursales = res.data)
      },
      validate () {
        if (this.$refs.form.validate()){
          this.element = {
            //zdv_auto_increment:(this.busqvalest.length+1),
            zdv_folio_vale: 'Vale-'+fecha_vale + '-'+this.num_random+'-'+(this.busqvalest.length+1),
            zdv_id_user_autori:this.zdv_id_user_autori,
            zdv_id_user_qcobra_vale:this.zdv_id_user_qcobra_vale,
            zdv_fecha_cobro:this.zdv_fecha_cobro,
            zdv_importe:this.zdv_importe,
            zdv_id_sucursal:this.sucSelect,
            zdv_id_item_ped:this.pedSelect,
            zdv_id_cliente:this.clientSelect,
            zdv_estat_vale:this.zdv_estat_vale,
            zdv_id_empleado:this.idUser,
           
          }
        this.createAndNew()
        }        
      },
      validate02 () {
        if (this.$refs.form.validate()){
          this.element = {
            zdv_folio_vale: 'Vale-'+fecha_vale + '-'+this.num_random+'-'+(this.busqvalest.length+1),
            zdv_id_user_autori:this.zdv_id_user_autori,
            zdv_id_user_qcobra_vale:this.zdv_id_user_qcobra_vale,
            zdv_fecha_cobro:this.zdv_fecha_cobro,
            zdv_importe:this.zdv_importe,
            zdv_id_sucursal:this.sucSelect,
            zdv_id_item_ped:this.pedSelect,
            zdv_id_cliente:this.clientSelect,
            zdv_estat_vale:this.zdv_estat_vale,
            zdv_id_empleado:this.idUser
          }
        this.create() 
        }        
      },
      createAndNew(){
        axios.post('http://127.0.0.1:8000/vale/', this.element)
          .then(res => {
            window.location.reload()
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      create(){
        axios.post('http://127.0.0.1:8000/vale/', this.element)
          .then(res => {
            this.$router.replace({ path: '/vales/' })
            this.dialog = false
          })
          .catch(error => console.log(error));
      },
      reset () {
       this.zdv_importe="";
       this.sucSelect="";
       this.pedSelect="";
      },
      obtvale(){
        let obtval=""
        obtval=  'Vale-'+fecha_vale + '-'+this.num_random+'-'+(this.busqvalest.length+1);
        return obtval
      }
    },
  }
</script>