<!--Autor: Luis Angel Larios Castillo
Descripción: Este archivo funciona como una ventana emergente (modal) que permite observar los detalles pertenecientes a un registro-->
<template>
  <v-container grid-list-xs>
    <v-dialog  max-width="500">
      <template v-slot:activator="{ on, attrs }">
        <p v-bind="attrs" v-on="on" class="blue--text">
          <strong>{{element.zdv_folio_vale}}</strong>
        </p>
      </template>
      <v-card>
        <v-card-title class="headline">
        
        </v-card-title>
        <v-card-text>
          <v-alert color="info" dark dense align="left">
            <h3> <v-icon>mdi-card-bulleted-outline</v-icon> 
            {{element.zdv_folio_vale}}</h3>
          </v-alert>
          <div class="black--text">                
 
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DEL VALE</h3>
                </v-alert>

                <p hidden><strong>ID de Vale: </strong><br> {{element.zdv_id_vale}}</p>
                <h3>Folio</h3>{{element.zdv_folio_vale}}<br>
                 <h3>Sucursal</h3>{{element.surcur_nombre}}<br>
                <h3>Importe</h3>$ {{element.zdv_importe}}<br>                
                <h3>Estatus</h3>
                <v-chip
                class="ma-2"
                :color="colorestatus(element.zdv_estat_vale)"
                outlined
                >
                {{funestatus(element.zdv_estat_vale)}}
                </v-chip>
                <h3>Fecha de creación de vale</h3>{{fecha(element.zdv_fech_crea)}}<br>
                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DEL CLIENTE</h3>
                </v-alert>

                 <div v-for="emp_pe in empleado_cli" :key="emp_pe.id">
                   <h3>Folio del cliente</h3>
                   <v-chip
                    class="ma-2"
                    color="primary"
                    outlined
                    >{{emp_pe.zc_folio_client}}</v-chip>
                   <h3>Nombre</h3>{{emp_pe.nombre}}<br>
                   <h3>Estado</h3>{{emp_pe.zc_dir_estado}}<br>
                   <h3>Telefono</h3>{{emp_pe.zc_num_telefono}}         
                  </div>
                
                        


                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DEL USUARIO QUE AUTORIZA EL VALE</h3>
                </v-alert>

                 <div v-for="emp_autori in empleado_autori" :key="emp_autori.id">
                   <h3>Nombre</h3>{{emp_autori.nombre}}<br>
                   <h3>Sucursal a la que pertenece</h3>{{emp_autori.zdem_sucursal_nombre}}<br>
                   <h3>Telefono</h3>{{emp_autori.zdem_num_cel}}         
                  </div>
                  <div v-if="mostr_msj==null">
                    <h3>Correo</h3>{{user_autori.zdus_correo}}
                  </div>
                  <div v-else>
                    <v-chip
                    class="ma-2"
                    color="red"
                    outlined
                    >
                     {{mostr_msj}}
                    </v-chip>
                  </div> 


                <v-alert color="grey lighten-4" dense align="center">
                  <h3>DATOS DEL USUARIO QUE COBRA EL VALE</h3>
                </v-alert>

                <div v-for="emp_cobra in empleado_cobra" :key="emp_cobra.id">
                   <h3>Nombre</h3>{{emp_cobra.nombre}}<br>
                   <h3>Sucursal a la que pertenece</h3>{{emp_cobra.zdem_sucursal_nombre}}<br>
                   <h3>Telefono</h3>{{emp_cobra.zdem_num_cel}}         
                  </div>
                <div v-if="mostr_msj2==null">
                    <h3>Correo</h3>{{user_cobra.zdus_correo}}
                  </div>
                  <div v-else>
                    <v-chip
                    class="ma-2"
                    color="red"
                    outlined
                    >
                     {{mostr_msj2}}
                    </v-chip>
                  </div> 
                
               <br>
                <strong><i>Fecha en la que se cobro el vale :</i></strong>{{element.zdv_fecha_cobro}} <br>
                

                <v-alert color="grey lighten-4" dense align="center">
                    <h3>DATOS DEL PEDIDO</h3>
                </v-alert>
              
               
                  
                  <h3>Folio del pedido</h3>{{element.nom_item_ped}}<br>
                  <h3>Fecha de pedido</h3>{{pedido_item.zipe_fecha}}<br>
                  <h3>Articulo</h3>{{pedido_item.zipe_art_nom}}<br>
                  <h3>Cantidad</h3>{{pedido_item.zipe_cant}}<br>
                  <h3>Subtotal</h3>{{pedido_item.zipe_sub_tot}}<br>
                  <h3>Se devolvio</h3>{{pedido_item.zipe_devo}}<br>

            </div>
        </v-card-text>
      </v-card>
    </v-dialog>  
  </v-container>
</template>

<script>
  const moment = require('moment')
  const axios = require('axios')
  export default {
    props:[
      'element'
    ],

    created() {
      this.findEmpleado()
      this.findPedido()
      this.findEmpleadoAutori()
      this.findUserAutori()
      this.findEmpleadoCobra()
      this.findUserCobra()
    },

    data () {
      return {
        usuario: [],
        empleado_cli:[],
        otroid:'',
        pedido_item:[],
        empleado_autori:[],
        user_autori:[],
        mostr_msj:null,
        mostr_msj2:null,
        empleado_cobra:[],
        user_cobra:[],
       

      }
    },

    methods:{
       
      findEmpleado(){
        axios.get('http://127.0.0.1:8000/cliente/clientes/?search='+this.element.zdv_id_cliente)
        .then(resE => this.empleado_cli = resE.data)
      },
      findEmpleadoAutori(){
        axios.get('http://127.0.0.1:8000/empleado/?search='+this.element.zdv_id_user_autori)
        .then(resE => this.empleado_autori = resE.data)
      },
      findEmpleadoCobra(){
        axios.get('http://127.0.0.1:8000/empleado/?search='+this.element.zdv_id_user_qcobra_vale)
        .then(resE => this.empleado_cobra = resE.data)
      },
      findPedido(){
        axios.get('http://127.0.0.1:8000/pedido/itembpc/'+this.element.zdv_id_item_ped+'/')
        .then(resE => this.pedido_item = resE.data)
      },
      findUserAutori(){
        if(this.element.zdv_id_user_autori != "No autorizado aún"){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+this.element.zdv_id_user_autori)
        .then(resE => this.user_autori = resE.data[0])
        }
        else{
          this.mostr_msj="Este vale no se ha autorizado";
        }
      },
      findUserCobra(){
        if(this.element.zdv_id_user_qcobra_vale != "No cobrado aún"){
        axios.get('http://127.0.0.1:8000/usuario/getusuario/?search='+this.element.zdv_id_user_qcobra_vale)
        .then(resE => this.user_cobra = resE.data[0])
        }
        else{
          this.mostr_msj2="Este vale no se ha cobrado";
        }
      },
     funestatus(estatus){
          let cam_estatus=""
          if(estatus==true){
              cam_estatus="Cobrado"
          }
          else{
              cam_estatus="No Cobrado"
          }
          return cam_estatus
      },
      colorestatus(estatus){
          let color_estatus=""
          if(estatus==true){
              color_estatus="success"
          }
          else{
              color_estatus="red"
          }
          return color_estatus
      },
       fecha(date){
        return moment(date).locale('MX').format('DD-MM-YYYY LT')
      },
    },
  }
</script>