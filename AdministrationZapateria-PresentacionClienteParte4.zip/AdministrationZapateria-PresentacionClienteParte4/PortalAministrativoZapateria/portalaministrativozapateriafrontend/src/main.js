import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify';
import moment from 'moment'
import '@babel/polyfill'
import 'roboto-fontface/css/roboto/roboto-fontface.css'
import '@mdi/font/css/materialdesignicons.css'
import Vuelidate from 'vuelidate'
import VueApexCharts from 'vue-apexcharts'
import Datepicker from 'vuejs-datepicker'
import { es } from 'vuejs-datepicker/dist/locale'
import { VueMaskDirective } from 'v-mask'  

Vue.config.devtools=false
Vue.config.productionTip = false
Vue.directive('mask', VueMaskDirective);

Vue.use(Vuelidate)

new Vue({
  router,
  store,
  es,
  vuetify,
  moment,
  //Graficas VueApexCharts
  VueApexCharts,
  Datepicker,

  render: h => h(App)
}).$mount('#app')
