# Autor: Elisa Huerta Corona.
# Descripción: En el presente archivo se muestra la tabla de la base de datos para el registro de los clientes afiliados.

from django.db import models
from modulos.moduloUsuarios.models import Usuario
from modulos.moduloSucursales.models import Sucursal
import uuid 

class ClientesAfiliados(models.Model):
    zc_id_cliente = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, null=False, blank=False)
    zc_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, null=False, blank=False, related_name='Relacion4')
    zc_nombre = models.CharField(max_length=30, null=False, blank=False)
    zc_apell_pat = models.CharField(max_length=30, null=False, blank=False)
    zc_apell_mat = models.CharField(max_length=30, null=False, blank=False)
    zc_fech_nacim = models.DateField()
    zc_num_telefono = models.CharField(max_length=15, null=False, blank=False)
    zc_num_cell = models.CharField(max_length=15, null=False, blank=False)
    zc_rfc = models.CharField(max_length=20, null=False, blank=False)
    zc_correo = models.CharField(max_length=40, null=False, blank=False)
    zc_dir_pais = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_estado = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_municipio = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_colonia = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_cod_postal = models.CharField(max_length=10,null=False, blank=False)
    zc_dir_calle_1 = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_calle_2 = models.CharField(max_length=100, null=False, blank=False)
    zc_dir_num_int = models.CharField(max_length=30, null=True, blank=True)
    zc_dir_num_ext = models.CharField(max_length=30, null=True, blank=True)
    zc_saldo = models.FloatField(default=0)
    zc_enter_client = models.CharField(max_length=150, null=True, blank=True)
    zc_tipo_cliente = models.BooleanField(default=True)
    zc_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, null=False, blank=False, related_name='Relacion5')
    zc_folio_client = models.CharField(max_length=80, null=False, blank=False)
    zc_fech_crea = models.DateTimeField(auto_now_add=True)
    zc_fech_mod = models.DateTimeField(auto_now=True)
    zc_existen = models.BooleanField(default=True) 
    class Meta:
        permissions = [('manage_clientes_afiliados', 'Puede Gestionar Clientes Afiliados')]
        db_table ="zc_clientes_afi" 

class ClientesAfiliadosHistorico(models.Model):
    zdc_id_cliente = models.CharField(primary_key=True, default='', max_length=100)
    zdc_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='Relacion1')
    zdc_nombre = models.CharField(null=False, blank=False, max_length=30, default='')
    zdc_apell_pat = models.CharField(null=False, blank=False, max_length=30, default='')
    zdc_apell_mat = models.CharField(null=False, blank=False, max_length=30, default='')
    zdc_num_telefono = models.CharField(default='', null=False, blank=False, max_length=15)
    zdc_num_cell = models.CharField(default='', null=False, blank=False, max_length=15)
    zdc_rfc = models.CharField(null=True, blank=True, max_length=20, default='')
    zdc_correo = models.CharField(null=False, blank=False, max_length=40, default='')
    zdc_dir_calle_1 = models.CharField(null=False, blank=False, max_length=100, default='')
    zdc_dir_calle_2 = models.CharField(null=True, blank=True, max_length=100, default='')
    zdc_dir_cod_postal = models.CharField(default='', null=False, blank=False, max_length=10)
    zdc_dir_colonia = models.CharField(null=False, blank=False, max_length=50, default='')
    zdc_dir_municipio = models.CharField(null=False, blank=False, max_length=100, default='')
    zdc_dir_estado = models.CharField(null=False, blank=False, max_length=100, default='')
    zdc_dir_pais = models.CharField(null=False, blank=False, max_length=100, default='')
    zdc_dir_num_ext = models.CharField(default='', null=True, blank=True, max_length=30)
    zdc_dir_num_int = models.CharField(default='', null=True, blank=True, max_length=30)
    zdc_fech_nacim = models.DateField (null=False, blank=False, default='')
    zdc_saldo = models.FloatField(default=0)
    zdc_enter_client = models.CharField(max_length=150, null=True, blank=True)
    zdc_tipo_cliente = models.BooleanField(default=True)
    zdc_folio_client = models.CharField(max_length=80, null=False, blank=False)
    zdc_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, null=False, blank=False, related_name='Relacion3')
    zdc_fech_crea = models.DateTimeField(blank=False, null=False, default='')
    zdc_fech_mod = models.DateTimeField(blank=False, null=False, default='')
    zdc_fech_delet = models.DateTimeField(auto_now=True, null=False, blank=False)
    zdc_usua_delet = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='Relacion2')
    zdc_motivo = models.CharField(max_length=150, null=False, blank=False, default='')

    class Meta:
        #permissions = [('manage_clientes_afiliados_histotico', 'Puede Gestionar Clientes Afiliados Histotico')]
        db_table = "zdc_clientes_afi_hist" 