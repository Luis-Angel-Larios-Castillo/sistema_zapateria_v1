from django.contrib import admin
from .models import ClientesAfiliados
# Register your models here.
class ClientesAfiliadosAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'id',)

# Register your models here.
