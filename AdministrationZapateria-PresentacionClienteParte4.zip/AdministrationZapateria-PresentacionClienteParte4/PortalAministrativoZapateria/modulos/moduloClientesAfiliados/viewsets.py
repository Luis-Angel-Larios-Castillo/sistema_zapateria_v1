from rest_framework import viewsets
from .models import ClientesAfiliados, ClientesAfiliadosHistorico
from .serializer import ClientesAfiliadosSerializer, ClientesAfiliadosHistoricoSerializer
from rest_framework import filters
from django.shortcuts import get_object_or_404

class ClientesAfiliadosViewSet(viewsets.ModelViewSet):
    search_fields = ['=zc_id_usuario__zdus_id_usuario', '=zc_id_sucursal__zdsu_id_sucursal', '=zc_existen', 'zc_nombre', 'zc_apell_pat', 'zc_apell_mat']
    filter_backends = (filters.SearchFilter,) 

    queryset = ClientesAfiliados.objects.all()
    serializer_class = ClientesAfiliadosSerializer

class ClientesAfiliadosHistoricoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zdc_nombre']
    queryset = ClientesAfiliadosHistorico.objects.all()
    serializer_class = ClientesAfiliadosHistoricoSerializer

# Api para empleados asocidos a un id de una sucursal

class BusqClienAfiSucViewSet(viewsets.ModelViewSet):
    search_fields = ['=zc_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,) 
    queryset = ClientesAfiliados.objects.all()
    serializer_class = ClientesAfiliadosSerializer