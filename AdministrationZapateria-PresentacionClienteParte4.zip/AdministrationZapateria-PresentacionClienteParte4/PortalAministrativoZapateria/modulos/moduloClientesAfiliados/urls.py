from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ClientesAfiliadosViewSet, ClientesAfiliadosHistoricoViewSet, BusqClienAfiSucViewSet

route =  routers.SimpleRouter()
route.register('clientes' , ClientesAfiliadosViewSet)
route.register('historicoClientes', ClientesAfiliadosHistoricoViewSet)
route.register('suc' , BusqClienAfiSucViewSet)
urlpatterns = route.urls