from django.apps import AppConfig


class ModuloclienteafiliadoConfig(AppConfig):
    name = 'moduloClientesAfiliados'
