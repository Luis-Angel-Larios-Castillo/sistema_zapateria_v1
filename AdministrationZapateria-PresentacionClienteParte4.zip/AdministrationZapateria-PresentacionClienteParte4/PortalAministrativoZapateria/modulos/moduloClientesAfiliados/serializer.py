from rest_framework import serializers
from .models import ClientesAfiliados, ClientesAfiliadosHistorico

class ClientesAfiliadosSerializer(serializers.ModelSerializer): 
    nombre = serializers.SerializerMethodField('get_nombre_comp')
    nom_and_folio = serializers.SerializerMethodField('get_nom_and_folio')
    class Meta:
        model = ClientesAfiliados
        fields = '__all__' 
    def get_nombre_comp(self, item):
        nombre = item.zc_nombre + " " + item.zc_apell_pat + " " + item.zc_apell_mat  
        return nombre
    def get_nom_and_folio(self, item):
        nom_and_folio = item.zc_folio_client + "  " +  item.zc_nombre + " " + item.zc_apell_pat + " " + item.zc_apell_mat
        return nom_and_folio
         
class ClientesAfiliadosHistoricoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClientesAfiliadosHistorico 
        fields = '__all__'
