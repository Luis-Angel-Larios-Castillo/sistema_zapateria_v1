from django.apps import AppConfig


class ModuloproveedoresConfig(AppConfig):
    name = 'moduloProveedores'
