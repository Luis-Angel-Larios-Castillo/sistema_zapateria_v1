from rest_framework import serializers
from .models import Proveedores, ProveedoresHistorico

class ProveedoresSerializer(serializers.ModelSerializer):
    class Meta:
        model = Proveedores 
        fields = '__all__'
"""""
class ProveedoresHistoricoSerializer(serializers.ModelSerializer):
    zdp_correo = serializers.SerializerMethodField('get_correo')
    zdp_correo_elim = serializers.SerializerMethodField('get_correo_elim')
    
    class Meta:
        model = ProveedoresHistorico 
        fields = '__all__'
    
    def get_correo(self, item):
        zdp_correo = item.zdp_id_usuario.zdus_correo  
        return zdp_correo
    def get_correo_elim(self, item):
        zdp_correo_elim = item.zdp_usua_delet.zdus_correo  
        return zdp_correo_elim
    """""
class ProveedoresHistoricoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProveedoresHistorico 
        fields = '__all__'