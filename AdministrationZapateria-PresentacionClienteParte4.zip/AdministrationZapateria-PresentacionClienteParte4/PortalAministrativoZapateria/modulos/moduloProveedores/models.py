# Autor: Elisa Huerta Corona.
# Descripción: En el presente archivo se muestra la tabla de la base de datos para el registro de los proveedores.

from django.db import models
from modulos.moduloUsuarios.models import Usuario 
# Create your models here.
import uuid

class Proveedores(models.Model):
    zp_id_proveedor = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zp_nombre = models.CharField(max_length=45)
    zp_apell_pat = models.CharField(max_length=45)
    zp_apell_mat = models.CharField(max_length=45)
    zp_num_telefono = models.CharField(max_length=13)
    zp_num_cell = models.CharField(max_length=13)
    zp_rfc = models.CharField(max_length=45)
    zp_correo = models.CharField(max_length=45)
    zp_dir_pais = models.CharField(max_length=30)
    zp_dir_estado = models.CharField(max_length=100)
    zp_dir_municipio = models.CharField(max_length=100)
    zp_dir_colonia = models.CharField(max_length=30)
    zp_dir_cod_postal = models.CharField(default='', null=False, blank=False, max_length=10)
    zp_dir_calle_prin = models.CharField(max_length=30)
    zp_dir_calle_inter = models.CharField(max_length=45)
    zp_dir_num_int = models.CharField(max_length=45)
    zp_dir_num_ext = models.CharField(max_length=45)
    zp_existen = models.BooleanField(default=True)
    zp_fech_crea = models.DateTimeField(auto_now_add=True)
    zp_fech_mod = models.DateTimeField(auto_now=True)
    zp_identify_mark = models.CharField(max_length=30)
    
    class Meta:
        permissions = [('manage_proveedores', 'Puede Gestionar Proveedores')]
        db_table ="zdp_proveedores" 

class ProveedoresHistorico(models.Model):

    zdp_id_proveedor = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdp_nombre = models.CharField(max_length=45)
    zdp_apell_pat = models.CharField(max_length=45)
    zdp_apell_mat = models.CharField(max_length=45)
    zdp_num_telefono = models.CharField(max_length=13)
    zdp_num_cell = models.CharField(max_length=13)
    zdp_rfc = models.CharField(max_length=45)
    zdp_correo = models.CharField(max_length=45)
    zdp_dir_pais = models.CharField(max_length=100)
    zdp_dir_estado = models.CharField(max_length=100)
    zdp_dir_municipio = models.CharField(max_length=30)
    zdp_dir_colonia = models.CharField(max_length=30)
    zdp_dir_cod_postal = models.CharField(default='', null=False, blank=False, max_length=10)
    zdp_dir_calle_prin = models.CharField(max_length=30)
    zdp_dir_calle_inter = models.CharField(max_length=45)
    zdp_dir_num_int = models.CharField(max_length=45)
    zdp_dir_num_ext = models.CharField(max_length=45)
    zdp_fech_crea = models.DateTimeField(blank=False, null=False, default='')
    zdp_fech_delet = models.DateTimeField(auto_now=True, null=False, blank=False)
    zdp_fech_mod = models.DateTimeField(auto_now=True)
    zdp_usua_delet = models.ForeignKey(Usuario, on_delete=models.CASCADE, default='')
    zdp_motivo = models.CharField(max_length=150, null=False, blank=False, default='')
    zdp_identify_mark = models.CharField(max_length=30)


    class Meta:
        #permissions = [('manage_proveedores_historico', 'Puede Gestionar Proveedores Historico')]
        db_table ="zdp_proveedores_hist" 


    

    
