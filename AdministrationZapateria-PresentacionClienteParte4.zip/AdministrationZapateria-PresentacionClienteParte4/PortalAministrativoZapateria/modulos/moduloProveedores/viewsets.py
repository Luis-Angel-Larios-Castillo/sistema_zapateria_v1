from rest_framework import viewsets
from .models import Proveedores, ProveedoresHistorico
from .serializer import ProveedoresSerializer, ProveedoresHistoricoSerializer
from rest_framework import filters
from django.shortcuts import get_object_or_404

class ProveedoresViewSet(viewsets.ModelViewSet):
    queryset = Proveedores.objects.all()
    serializer_class = ProveedoresSerializer

class ProveedoresHistoricoViewSet(viewsets.ModelViewSet):
    #search_fields = ['=zdp_id_usuario__zdus_id_usuario']
    #filter_backends = (filters.SearchFilter,)  
    queryset = ProveedoresHistorico.objects.all()
    serializer_class = ProveedoresHistoricoSerializer 

class ProveedoresactViewSet(viewsets.ModelViewSet):
    search_fields = ['=zp_nombre']
    queryset = Proveedores.objects.filter(zp_existen=1)
    serializer_class = ProveedoresSerializer
