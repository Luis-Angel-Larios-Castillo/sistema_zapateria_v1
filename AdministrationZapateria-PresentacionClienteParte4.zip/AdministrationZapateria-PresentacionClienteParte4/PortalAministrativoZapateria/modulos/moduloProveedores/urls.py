from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ProveedoresViewSet, ProveedoresHistoricoViewSet, ProveedoresactViewSet

route =  routers.SimpleRouter()
route.register('proveedor' , ProveedoresViewSet)
route.register('histo' , ProveedoresHistoricoViewSet)
route.register('proveedores/activos' , ProveedoresactViewSet)
urlpatterns = route.urls