from django.contrib import admin
from .models import Catalogo
# Register your models here.

class CatalogoAdmin(admin.ModelAdmin):
    list_display = ('zca_id_catalogo', 'zca_nombre_ca')


admin.site.register(Catalogo, CatalogoAdmin) 
