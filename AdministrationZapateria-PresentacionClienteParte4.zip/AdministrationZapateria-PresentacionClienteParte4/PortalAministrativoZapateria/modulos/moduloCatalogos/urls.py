"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloCatalogos
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import CatalogoViewSet, InventarioCat, CatalogoactViewSet

route =  routers.SimpleRouter()
route.register('' , CatalogoViewSet)
route.register('invCat/Cat' , InventarioCat)
route.register('catalogos/activos' , CatalogoactViewSet)
urlpatterns = route.urls