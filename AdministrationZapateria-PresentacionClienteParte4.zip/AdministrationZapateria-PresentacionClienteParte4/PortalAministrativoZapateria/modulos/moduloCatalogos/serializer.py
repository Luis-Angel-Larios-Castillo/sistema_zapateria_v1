"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloCatalogos
"""
from rest_framework import serializers
from .models import Catalogo

class CatalogoSerializer(serializers.ModelSerializer):
    zca_proveedor_nombre = serializers.SerializerMethodField('get_proveedor_nombre')
    zca_sucursal_nombre = serializers.SerializerMethodField('get_sucursal_nombre')
    class Meta:
        model = Catalogo 
        fields = '__all__'
    def get_proveedor_nombre(self, item):
        zca_proveedor_nombre = item.zca_id_proveedores.zp_nombre + ' ' +  item.zca_id_proveedores.zp_apell_pat + ' ' +  item.zca_id_proveedores.zp_apell_mat
        return zca_proveedor_nombre
    
    def get_sucursal_nombre(self, item):
        zca_sucursal_nombre = item.zac_sucursal.zdsu_nombre + ' - ' + item.zac_sucursal.zdsu_dir_municipio + ' ' + item.zac_sucursal.zdsu_dir_estado
        return zca_sucursal_nombre
