"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloCatalogos
"""
from rest_framework import viewsets
from .models import Catalogo
from .serializer import CatalogoSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters

class CatalogoViewSet(viewsets.ModelViewSet):
    queryset = Catalogo.objects.all()
    search_fields = ['zca_id_proveedores__zp_id_proveedor', '=zac_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    serializer_class = CatalogoSerializer 

class InventarioCat(viewsets.ModelViewSet):
    search_fields = ['=zac_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    queryset = Catalogo.objects.all()
    serializer_class = CatalogoSerializer

class CatalogoactViewSet(viewsets.ModelViewSet):
    search_fields = ['=zac_sucursal__zdsu_id_sucursal', '=zca_nombre_ca']
    filter_backends = (filters.SearchFilter,)
    queryset = Catalogo.objects.filter(zac_existen=1)
    serializer_class = CatalogoSerializer