"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tabla llamada zdca_catalogos 
"""
from django.db import models
import uuid
from modulos.moduloProveedores.models import Proveedores
from modulos.moduloSucursales.models import Sucursal
# Create your models here.

class Catalogo(models.Model):
    zca_id_catalogo = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zca_nombre_ca = models.CharField(max_length=100)
    zca_id_proveedores = models.ForeignKey(Proveedores, on_delete=models.CASCADE , related_name='Proveedor')
    # zca_id_temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE)
    zca_year = models.IntegerField()
    zca_temporada = models.CharField(max_length=30)
    zca_cod_barras = models.CharField(max_length=45)
    zca_prec_prev = models.FloatField()
    zca_prec_regul = models.FloatField()
    zac_prec_comp = models.FloatField()
    zac_existen = models.BooleanField(default=True)
    zac_apart = models.BooleanField(default=True)
    zac_cantidad = models.IntegerField()
    zac_tipo_paquete = models.CharField(max_length=50, null=True, blank=True, default='')
    zac_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, null=False, blank=False, related_name='Sucursal')
    zac_is_deleted = models.BooleanField(default=False)
    zac_fech_delet = models.DateTimeField(auto_now=True, null=False, blank=False)
    zac_usua_delet = models.CharField(max_length=50, null=True)

    def __str__(self):
        return self.zca_nombre_ca
    class Meta:
        permissions = [('manage_catalogos', 'Puede Gestionar Catálogos')]
        db_table = "zdca_catalogos"  