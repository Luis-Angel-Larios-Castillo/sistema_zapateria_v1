from django.apps import AppConfig

class ModulocatalogosConfig(AppConfig):
    name = 'moduloCatalogos'
