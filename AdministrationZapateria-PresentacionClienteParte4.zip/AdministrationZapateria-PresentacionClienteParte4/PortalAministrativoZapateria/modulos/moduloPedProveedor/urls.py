"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloPedProveedor
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ItemPedProvViewSet, PedProvCabeceraViewSet

route =  routers.SimpleRouter()
route.register('cab' , PedProvCabeceraViewSet)
route.register('item' , ItemPedProvViewSet)
urlpatterns = route.urls