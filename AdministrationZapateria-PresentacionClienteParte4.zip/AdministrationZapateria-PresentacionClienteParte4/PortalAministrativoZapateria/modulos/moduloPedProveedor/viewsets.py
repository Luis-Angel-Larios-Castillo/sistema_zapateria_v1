"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloPedProveedor
"""
from rest_framework import viewsets
from .models import PedidoProveedorCabecera, ItemPedidoProveedor
from .serializer import PedidoProveedorCabeceraSerializer, ItemPedidoProveedorSerializer
from rest_framework import filters
from django.db.models import Q  

class PedProvCabeceraViewSet(viewsets.ModelViewSet):
    queryset = PedidoProveedorCabecera.objects.all()
    serializer_class = PedidoProveedorCabeceraSerializer   
    #search_fields = ['']
    #filter_backends = (filters.SearchFilter,)   

class ItemPedProvViewSet(viewsets.ModelViewSet):
    queryset = ItemPedidoProveedor.objects.all()
    serializer_class = ItemPedidoProveedorSerializer  
    search_fields = ['=zpedproit_id_ped_provee__zpedpro_id_ped_provee']
    filter_backends = (filters.SearchFilter,)  