"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zpedpro_pedido_provee y zpedpro_caja_item_provee
"""
from django.db import models
from modulos.moduloArticulos.models import Articulo
from modulos.moduloProveedores.models import Proveedores
from modulos.moduloUsuarios.models import Usuario 
import uuid 

class PedidoProveedorCabecera(models.Model): 
    zpedpro_id_ped_provee = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedpro_nombre = models.CharField(max_length=100, null=True, blank=True)
    zpedpro_id_provee  = models.ForeignKey(Proveedores, on_delete=models.CASCADE, related_name='ProveedorPCP', blank=True)
    zpedpro_id_emple  = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='EmpleadoCPCP', blank=True)
    zpedpro_fech_creat = models.DateTimeField(auto_now_add=True)
    zpedpro_fech_mod = models.DateTimeField(auto_now=True)
    zpedpro_puede_editar = models.BooleanField(default=True)
    zpedpro_id_emple_mod = models.CharField(max_length=100, null=True, blank=True)
    zpedpro_status_ped = models.CharField(max_length=50, null=False, blank=False) 
    
    def __str__(self):
        return self.zpedpro_nombre
    class Meta:
        permissions = [('manage_pedidos_articulos_proveedores', 'Puede Gestionar Pedidos de Artículos a Proveedores')]
        db_table = "zpedpro_pedido_provee"  

class ItemPedidoProveedor(models.Model): 
    zpedproit_id_item_caj = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedproit_id_ped_provee = models.ForeignKey(PedidoProveedorCabecera, on_delete=models.CASCADE, blank=True, related_name='CabeceraPProv')
    zpedproit_id_art = models.ForeignKey(Articulo, on_delete=models.CASCADE, blank=True, related_name='ArticuloPProv') 
    zpedproit_color = models.CharField(max_length=50, null=False, blank=False)
    zpedproit_talla = models.CharField(max_length=50, null=False, blank=False)
    zpedproit_cant_ped = models.IntegerField(default=0)
    zpedproit_cant_ped_llego = models.IntegerField(default=0)
    zpedproit_notas = models.JSONField(blank=True, null=True)   
 
    def __str__(self):
        return self.zpedproit_color
    class Meta:
        #permissions = [('manage_pedidos_proveedores_items', 'Puede Gestionar Artículos de Pedidos de Proveedores')]
        db_table = "zpedpro_pedpro_item_provee" 