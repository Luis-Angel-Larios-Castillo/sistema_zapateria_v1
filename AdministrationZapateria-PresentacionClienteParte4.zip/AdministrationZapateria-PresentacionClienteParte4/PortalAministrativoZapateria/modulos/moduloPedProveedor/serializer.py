"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloPedProveedor
"""
from rest_framework import serializers
from .models import PedidoProveedorCabecera, ItemPedidoProveedor

class ItemPedidoProveedorSerializer(serializers.ModelSerializer): 
    zpedproit_model = serializers.SerializerMethodField('get_model') 
    zpedproit_marca = serializers.SerializerMethodField('get_marca') 
    class Meta: 
        model = ItemPedidoProveedor  
        fields = '__all__'
    def get_model(self, item):
        zpedproit_model = item.zpedproit_id_art.zaa_id_arti_global.zaag_modelo
        return zpedproit_model 
    def get_marca(self, item):
        zpedproit_marca = item.zpedproit_id_art.zaa_id_arti_global.zaag_marca
        return zpedproit_marca 

class PedidoProveedorCabeceraSerializer(serializers.ModelSerializer): 
    zpedpro_proveedor = serializers.SerializerMethodField('get_proveedor') 
    class Meta:
        model = PedidoProveedorCabecera 
        fields = '__all__'
        #depth = 1 
    def get_proveedor(self, item):
        zpedpro_proveedor = item.zpedpro_id_provee.zp_identify_mark
        return zpedpro_proveedor 

