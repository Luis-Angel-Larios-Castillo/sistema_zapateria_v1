from django.apps import AppConfig


class ModulopedproveedorConfig(AppConfig):
    name = 'moduloPedProveedor'
