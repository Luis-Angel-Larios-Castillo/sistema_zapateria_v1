"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloPedCaSuc
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import PedCabCatProvViewSet, ItemCatPedProvViewSet

route =  routers.SimpleRouter()
route.register('cab' , PedCabCatProvViewSet)
route.register('item' , ItemCatPedProvViewSet)
urlpatterns = route.urls