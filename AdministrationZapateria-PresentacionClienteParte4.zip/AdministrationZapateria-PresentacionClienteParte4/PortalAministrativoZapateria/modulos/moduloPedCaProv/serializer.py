"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloPedCaSuc
"""
from rest_framework import serializers
from .models import PedidoCatalogoProveedorCabecera, ItemPedidoCatalogoProveedor

class PedidoCataProveedorCabeceraSerializer(serializers.ModelSerializer):  
    zpedpr_proveedor_nombre = serializers.SerializerMethodField('get_proveedor_nombre') 
    class Meta:
        model = PedidoCatalogoProveedorCabecera 
        fields = '__all__'
        #depth = 1  
    def get_proveedor_nombre(self, item):
        zpedpr_proveedor_nombre = item.zpedpr_id_provee.zp_identify_mark
        return zpedpr_proveedor_nombre 

class ItemCataPedidoProveedorSerializer(serializers.ModelSerializer): 
    zpedipr_nombre = serializers.SerializerMethodField('get_nombre') 
    zpedipr_marca = serializers.SerializerMethodField('get_marca') 
    zpedipr_status = serializers.SerializerMethodField('get_status') 
    class Meta:
        model = ItemPedidoCatalogoProveedor 
        fields = '__all__'
        #depth = 1  
    def get_nombre(self, item):
        zpedipr_nombre = item.zpedipr_id_cat.zca_nombre_ca
        return zpedipr_nombre
    def get_status(self, item):
        zpedipr_status = item.zpedipr_id_ped_cat_prov.zpedpr_status_ped
        return zpedipr_status  
    def get_marca(self, item):
        zpedipr_marca = item.zpedipr_id_cat.zca_id_proveedores.zp_identify_mark
        return zpedipr_marca 