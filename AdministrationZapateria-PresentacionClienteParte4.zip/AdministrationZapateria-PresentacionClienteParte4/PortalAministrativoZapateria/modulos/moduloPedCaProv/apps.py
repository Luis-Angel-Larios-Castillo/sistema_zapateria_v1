from django.apps import AppConfig


class ModulopedcaprovConfig(AppConfig):
    name = 'moduloPedCaProv'
