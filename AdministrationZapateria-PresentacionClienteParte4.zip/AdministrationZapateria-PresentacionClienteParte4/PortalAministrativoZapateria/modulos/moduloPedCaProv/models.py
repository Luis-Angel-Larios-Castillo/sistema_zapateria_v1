"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zpedpr_pedido_cata_prov y zpedpr_pedido_cata_item_prov
"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario  
from modulos.moduloProveedores.models import Proveedores 
from modulos.moduloCatalogos.models import Catalogo
import uuid 
# Create your models here.

class PedidoCatalogoProveedorCabecera(models.Model):
    zpedpr_id_ped_cat_prov = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedpr_nombre = models.CharField(max_length=100, null=True, blank=True)
    zpedpr_id_emple = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='EmpleadoCCaPP', blank=True)
    zpedpr_id_provee = models.ForeignKey(Proveedores, on_delete=models.CASCADE, related_name='IDProveedorPCaP', blank=True)
    zpedpr_fech_creat = models.DateTimeField(auto_now_add=True)
    zpedpr_fech_mod = models.DateTimeField(auto_now=True)
    zpedpr_puede_editar = models.BooleanField(default=True)
    zpedpr_id_emple_mod = models.CharField(max_length=100, null=True, blank=True)
    zpedpr_status_ped = models.CharField(max_length=50, null=False, blank=False) 
    
    def __str__(self):
        return self.zpedpr_nombre
    class Meta:
        permissions = [('manage_pedidos_catalogos_proveedor', 'Puede Gestionar Pedidos de Catálogos a Proveedores')]
        db_table = "zpedpr_pedido_cata_prov"  

class ItemPedidoCatalogoProveedor(models.Model):
    zpedipr_id_item_ped_cat = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedipr_id_ped_cat_prov = models.ForeignKey(PedidoCatalogoProveedorCabecera, on_delete=models.CASCADE, related_name='IDCabeceraPS', blank=True)
    zpedipr_id_cat  = models.ForeignKey(Catalogo, on_delete=models.CASCADE, related_name='IDCatalogoPP', blank=True)  
    zpedipr_cant_ped = models.IntegerField(default=0) 
    zpedipr_cant_ped_llego = models.IntegerField(default=0)  
 
    def __str__(self):
        return self.zpedsucat_cant_ped
    class Meta:
        #permissions = [('manage_catalogos_proveedor_items', 'Puede Gestionar Pedidos de Catálogos a Proveedores')]
        db_table = "zpedipr_pedido_cata_item_prov" 
