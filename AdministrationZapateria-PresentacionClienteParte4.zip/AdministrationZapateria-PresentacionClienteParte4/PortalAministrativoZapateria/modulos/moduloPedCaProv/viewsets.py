"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloPedCaSuc
"""
from rest_framework import viewsets
from .models import PedidoCatalogoProveedorCabecera, ItemPedidoCatalogoProveedor
from .serializer import ItemCataPedidoProveedorSerializer, PedidoCataProveedorCabeceraSerializer
from rest_framework import filters
from django.db.models import Q  

class PedCabCatProvViewSet(viewsets.ModelViewSet):
    queryset = PedidoCatalogoProveedorCabecera.objects.all()
    serializer_class = PedidoCataProveedorCabeceraSerializer  
    search_fields = ['=zpedpr_id_provee__zp_id_proveedor']
    filter_backends = (filters.SearchFilter,) 

class ItemCatPedProvViewSet(viewsets.ModelViewSet): 
    queryset = ItemPedidoCatalogoProveedor.objects.all()
    serializer_class = ItemCataPedidoProveedorSerializer  
    search_fields = ['=zpedipr_id_ped_cat_prov__zpedpr_id_ped_cat_prov']
    filter_backends = (filters.SearchFilter,) 
    