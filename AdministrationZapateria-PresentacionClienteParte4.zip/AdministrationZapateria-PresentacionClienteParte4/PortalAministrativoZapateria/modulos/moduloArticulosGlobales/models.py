from django.db import models
import uuid
from modulos.moduloCatalogos.models import Catalogo
from modulos.moduloDepartamentos.models import SubDepartamento

# Articulos Globales
class ArticuloGlobal(models.Model):
    zaag_id_articulo_global = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zaag_nombre_arti = models.CharField(max_length=100)
    zaag_clave = models.CharField(max_length=45)
    zaag_codigo_bar = models.CharField(max_length=45)
    zaag_modelo = models.CharField(max_length=45)
    zaag_categoria = models.CharField(max_length=45)
    zaag_marca = models.CharField(max_length=45)
    zaag_prec_cont = models.FloatField()
    zaag_prec_pag = models.FloatField()
    zaag_prect_mayo = models.FloatField()
    zaag_prect_menud = models.FloatField()
    zaag_id_catalogo = models.ForeignKey(Catalogo, on_delete=models.CASCADE)
    zaag_id_subdep = models.ForeignKey(SubDepartamento, on_delete=models.CASCADE)
    zaag_oferta = models.FloatField(default=0, blank=True, null=True)

    def __str__(self):
        return self.zaag_nombre_arti
    class Meta:
        permissions = [('manage_articulos_globales', 'Puede Gestionar Artículos Globales')]
        db_table = "zdag_articulos_globales"  
