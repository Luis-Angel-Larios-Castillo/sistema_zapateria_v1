from rest_framework import serializers
from .models import ArticuloGlobal


# Serializer para Articulos de globales
class ArticuloGlobalSerializer(serializers.ModelSerializer):
    zaag_id_depart = serializers.SerializerMethodField('get_zaag_id_depart')
    zaag_dep = serializers.SerializerMethodField('get_zaag_dep')
    zaag_catalogo = serializers.SerializerMethodField('get_catalogo')
    zaag_temp = serializers.SerializerMethodField('get_temp')
    zaag_dep_etiqueta = serializers.SerializerMethodField('get_dep_etiqueta')
    class Meta:
        model = ArticuloGlobal 
        fields = '__all__'
        #depth = 2
    def get_zaag_dep(self, item):
        zaag_dep = item.zaag_id_subdep.zsude_id_dep.zde_nombre 
        return zaag_dep
    def get_zaag_id_depart(self, item):
        zaag_id_depart = item.zaag_id_subdep.zsude_id_dep.zde_id_dep 
        return zaag_id_depart
    def get_catalogo(self, item):
        zaag_catalogo = item.zaag_id_catalogo.zca_nombre_ca 
        return zaag_catalogo
    def get_temp(self, item):
        zaag_temp = item.zaag_id_catalogo.zca_temporada 
        return zaag_temp
    def get_dep_etiqueta(self, item):
        zaag_dep_etiqueta = item.zaag_id_subdep.zsude_id_dep.zde_nombre + ' - ' + item.zaag_id_subdep.zsude_categoria
        return zaag_dep_etiqueta
    


