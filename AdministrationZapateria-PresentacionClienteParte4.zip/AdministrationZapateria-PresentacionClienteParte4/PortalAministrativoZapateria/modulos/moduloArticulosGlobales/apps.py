from django.apps import AppConfig


class ModuloarticulosglobalesConfig(AppConfig):
    name = 'moduloArticulosGlobales'
