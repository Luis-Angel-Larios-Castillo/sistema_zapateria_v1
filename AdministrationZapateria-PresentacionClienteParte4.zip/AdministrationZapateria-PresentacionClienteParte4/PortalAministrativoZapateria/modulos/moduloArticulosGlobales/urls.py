"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece las urls concerniente al moduloArticulosGlobales
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ArtiGlobalViewSet

route =  routers.SimpleRouter()
route.register('' , ArtiGlobalViewSet)
urlpatterns = route.urls