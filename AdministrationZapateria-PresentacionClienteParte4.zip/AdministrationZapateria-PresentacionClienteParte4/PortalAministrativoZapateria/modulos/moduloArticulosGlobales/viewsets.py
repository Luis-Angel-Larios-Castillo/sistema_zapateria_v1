"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece el viewsets que pertenece al Módulo de articulos globales
"""
from rest_framework import viewsets
from .models import ArticuloGlobal
from .serializer import ArticuloGlobalSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters

class ArtiGlobalViewSet(viewsets.ModelViewSet):
    search_fields = ['=zaag_id_articulo_global', '=zaag_id_catalogo__zca_id_catalogo', '=zaag_id_subdep__zsude_id_subdep', '=zaag_id_subdep__zsude_id_dep__zde_id_dep']
    filter_backends = (filters.SearchFilter,)
    queryset = ArticuloGlobal.objects.all()
    serializer_class = ArticuloGlobalSerializer
