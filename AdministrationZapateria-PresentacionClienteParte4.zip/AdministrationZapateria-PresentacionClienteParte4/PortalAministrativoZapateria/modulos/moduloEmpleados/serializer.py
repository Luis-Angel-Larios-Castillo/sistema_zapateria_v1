from rest_framework import serializers
from .models import Empleados, EmpleadosHistorico

class EmpleadosSerializer(serializers.ModelSerializer):
    nombre = serializers.SerializerMethodField('get_nombre_comp')
    zdem_sucursal_nombre = serializers.SerializerMethodField('get_sucursal_nombre')

    zdsu_suc_direccionCalle = serializers.SerializerMethodField('get_suc_direccion')
    zdsu_suc_direccionMuni = serializers.SerializerMethodField('get_suc_direc')

    class Meta:
        model = Empleados
        fields = '__all__'
        
    def get_sucursal_nombre(self, item):
        zdem_sucursal_nombre = item.zdem_id_sucursal.zdsu_nombre
        return zdem_sucursal_nombre
    def get_nombre_comp(self, item):
        nombre = item.zdem_nombre + " " + item.zdem_apell_pat + " " + item.zdem_apell_mat  
        return nombre
    def get_suc_direccion(self, item):
        zdsu_suc_direccionCalle = item.zdem_id_sucursal.zdsu_dir_calle_1 + " #" + item.zdem_id_sucursal.zdsu_dir_num_ext + " " + item.zdem_id_sucursal.zdsu_dir_colonia  
        return zdsu_suc_direccionCalle
    def get_suc_direc(self, item):
        zdsu_suc_direccionMuni = item.zdem_id_sucursal.zdsu_dir_municipio + ", " + item.zdem_id_sucursal.zdsu_dir_estado  
        return zdsu_suc_direccionMuni

class EmpleadosHistoricoSerializer(serializers.ModelSerializer):
    zdemh_sucursal_nombre = serializers.SerializerMethodField('get_sucursal_nombre')
    nombre = serializers.SerializerMethodField('get_nombre_comp')
    zdemh_correo = serializers.SerializerMethodField('get_correo')
    zdemh_correo_elim = serializers.SerializerMethodField('get_correo_elim')
    class Meta:
        model = EmpleadosHistorico
        fields = '__all__'
        
    def get_sucursal_nombre(self, item):
        zdemh_sucursal_nombre = item.zdemh_id_sucursal.zdsu_nombre + " - " + item.zdemh_id_sucursal.zdsu_dir_municipio
        return zdemh_sucursal_nombre
    def get_nombre_comp(self, item):
        nombre = item.zdemh_nombre + " " + item.zdemh_apell_pat + " " + item.zdemh_apell_mat  
        return nombre
    def get_correo(self, item):
        zdemh_correo = item.zdemh_id_usuario.zdus_correo  
        return zdemh_correo
    def get_correo_elim(self, item):
        zdemh_correo_elim = item.zdemh_usua_delet.zdus_correo  
        return zdemh_correo_elim
