from django.contrib import admin
from .models import Empleados
# Register your models here.
class EmpleadosAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'id',)

# Register your models here.
