from django.apps import AppConfig


class ModuloempleadosConfig(AppConfig):
    name = 'moduloEmpleados'
