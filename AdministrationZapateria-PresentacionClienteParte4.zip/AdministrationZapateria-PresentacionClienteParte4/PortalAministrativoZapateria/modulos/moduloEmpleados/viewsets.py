from rest_framework import viewsets
from .models import Empleados, EmpleadosHistorico
from .serializer import EmpleadosSerializer, EmpleadosHistoricoSerializer
from rest_framework import filters
from django.shortcuts import get_object_or_404

class EmpleadosViewSet(viewsets.ModelViewSet):
    search_fields = ['=zdem_id_usuario__zdus_id_usuario', '=zdem_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)  
    queryset = Empleados.objects.all()
    serializer_class = EmpleadosSerializer

# Api para empleados asocidos a un id de una sucursal

class BusqEmplSucViewSet(viewsets.ModelViewSet):
    search_fields = ['=zdem_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,) 
    queryset = Empleados.objects.all()
    serializer_class = EmpleadosSerializer

class EmpleadosHistoricoViewSet(viewsets.ModelViewSet): 
    search_fields = ['=zdemh_id_usuario__zdus_id_usuario']
    filter_backends = (filters.SearchFilter,)  
    queryset = EmpleadosHistorico.objects.all()
    serializer_class = EmpleadosHistoricoSerializer