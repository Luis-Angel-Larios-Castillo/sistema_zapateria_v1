# Autor: Elisa Huerta Corona.
# Descripción: En el presente archivo se muestra la tabla de la base de datos para el registro de los empleados.
from django.db import models
# Create your models here.
from modulos.moduloUsuarios.models import Usuario
from modulos.moduloSucursales.models import Sucursal 
import uuid


class Empleados(models.Model):
    zdem_id_empleado = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdem_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    zdem_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    zdem_nombre = models.CharField(max_length=45)
    zdem_apell_pat = models.CharField(max_length=45)
    zdem_apell_mat = models.CharField(max_length=45)
    zdem_num_tel = models.CharField(max_length=13)
    zdem_num_cel = models.CharField(max_length=13)
    zdem_correo = models.CharField(null=False, blank=False, max_length=40, default='')
    zdem_fech_nacim = models.DateField()
    zdem_dir_pais = models.CharField(max_length=45)
    zdem_dir_estado = models.CharField(max_length=45)
    zdem_dir_municipio = models.CharField(max_length=45)
    zdem_dir_colonia = models.CharField(max_length=45)
    zdem_dir_cod_postal = models.IntegerField()
    zdem_dir_calle_1 = models.CharField(max_length=45)
    zdem_dir_calle_2 = models.CharField(max_length=45)
    zdem_dir_num_int = models.CharField(max_length=45)
    zdem_dir_num_ext = models.CharField(max_length=45)
    zdem_existen = models.BooleanField(default=True)
    zdem_fech_crea = models.DateTimeField(auto_now_add=True)
    zdem_fech_mod = models.DateTimeField(auto_now=True) 
    class Meta:
        permissions = [('manage_empleados', 'Puede Gestionar Empleados')]
        db_table ="zdem_empleados" 

class EmpleadosHistorico(models.Model):
    zdemh_id_empleado = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdemh_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='UsuarioCliente')
    zdemh_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    zdemh_nombre = models.CharField(max_length=45)
    zdemh_apell_pat = models.CharField(max_length=45)
    zdemh_apell_mat = models.CharField(max_length=45)
    zdemh_num_tel = models.CharField(max_length=13)
    zdemh_num_cel = models.CharField(max_length=13)
    zdemh_fech_nacim = models.DateField()
    zdemh_correo = models.CharField(null=False, blank=False, max_length=40, default='')
    zdemh_dir_pais = models.CharField(max_length=45)
    zdemh_dir_estado = models.CharField(max_length=45)
    zdemh_dir_municipio = models.CharField(max_length=45)
    zdemh_dir_colonia = models.CharField(max_length=45)
    zdemh_dir_cod_postal = models.IntegerField()
    zdemh_dir_calle_1 = models.CharField(max_length=45)
    zdemh_dir_calle_2 = models.CharField(max_length=45)
    zdemh_dir_num_int = models.CharField(max_length=45)
    zdemh_dir_num_ext = models.CharField(max_length=45)
    zdemh_usua_delet = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='UsuarioElimino')
    zdemh_motivo = models.CharField(max_length=150, null=False, blank=False, default='')
    zdemh_fech_dele = models.DateTimeField(auto_now_add=True)
    zdemh_fech_cre = models.DateTimeField()
    
    class Meta:
        #permissions = [('manage_empleados_historico', 'Puede Gestionar Empleados Histotico')]
        db_table ="zdemh_empleados_hist" 