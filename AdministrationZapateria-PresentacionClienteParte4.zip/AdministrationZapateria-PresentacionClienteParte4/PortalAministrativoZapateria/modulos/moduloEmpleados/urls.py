from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import EmpleadosViewSet, BusqEmplSucViewSet, EmpleadosHistoricoViewSet

route =  routers.SimpleRouter()
route.register('' , EmpleadosViewSet)
route.register('empleados/sucursal' , BusqEmplSucViewSet)
route.register('empleados/historico' , EmpleadosHistoricoViewSet)
urlpatterns = route.urls