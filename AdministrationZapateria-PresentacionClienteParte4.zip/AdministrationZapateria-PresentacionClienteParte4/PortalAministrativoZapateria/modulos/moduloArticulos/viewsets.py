"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloArticulos
"""
from rest_framework import viewsets
from .models import Articulo, ArticuloTraspaso 
from .serializer import ArticuloSerializer, TraspasoArtiSerializer
from django.shortcuts import get_object_or_404, render
from rest_framework import filters
from django.db.models import Q 
from rest_framework.permissions import IsAuthenticated, DjangoModelPermissions, IsAuthenticatedOrReadOnly

class PruebasViewSet(viewsets.ModelViewSet): 
    #permission_classes = [DjangoModelPermissions]
    queryset = Articulo.objects.all()
    serializer_class = ArticuloSerializer 

class ArticuloViewSet(viewsets.ModelViewSet): 
    #permission_classes = [DjangoModelPermissions]
    #search_fields = ['=zaa_id_subdep__zsude_id_subdep', '=zaa_id_catalogo__zca_id_catalogo', '=zaa_categoria']
    search_fields = ['=zaa_id_sucursal__zdsu_id_sucursal', '=zaa_id_arti_global__zaag_id_articulo_global' ]
    filter_backends = (filters.SearchFilter,) 
    queryset = Articulo.objects.all()
    serializer_class = ArticuloSerializer  
    
class ArtActCajaViewSet(viewsets.ModelViewSet):    
    serializer_class = ArticuloSerializer
    queryset = Articulo.objects.all().filter(zaa_existen=1)
    search_fields = ['zaa_nombre_arti', 'zaa_color', 'zaa_codigo_bar', 'zaa_modelo', 'zaa_clave', 'zaa_marca']
    filter_backends = (filters.SearchFilter,)

class ArticulosActivosViewSet(viewsets.ModelViewSet):
    #search_fields = ['=zaa_id_subdep__zsude_id_subdep', '=zaa_id_subdep__zsude_id_dep__zde_id_dep']
    search_fields = ['=zaa_id_sucursal__zdsu_id_sucursal', '=zaa_id_arti_global__zaag_id_articulo_global', '=zaa_id_arti_global__zaag_id_subdep__zsude_id_dep__zde_id_dep' , '=zaa_id_arti_global__zaag_id_subdep__zsude_id_subdep' ]
    filter_backends = (filters.SearchFilter,) 
    queryset = Articulo.objects.all().filter(zaa_existen=1)
    serializer_class = ArticuloSerializer

class InventarioSuc(viewsets.ModelViewSet):
    search_fields = ['=zaa_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    queryset = Articulo.objects.all()
    serializer_class = ArticuloSerializer

class TraspArticulos(viewsets.ModelViewSet):
    search_fields = ['=zdtr_id_sucursal_de_salida__zdsu_id_sucursal', '=zdtr_id_sucursal_de_entrada__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    queryset = ArticuloTraspaso.objects.order_by('zdtr_fecha_creacion').reverse()
    serializer_class = TraspasoArtiSerializer

"""Vistas para el módulo de almacen, Sucursal Tlaxcala

class InventarioSucTlaxcalaAccesorios(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Accesorios', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaBotas(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Botas', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaGorras(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Gorras', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaChamarras(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Chamarras', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaZapatos(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Zapatos', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaPlayeras(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Playeras', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer

class InventarioSucTlaxcalaTennis(viewsets.ModelViewSet):
    queryset = Articulo.objects.filter(zaa_categoria='Tenis', zaa_sucursal='Tlaxcala')
    serializer_class = ArticuloSerializer"""