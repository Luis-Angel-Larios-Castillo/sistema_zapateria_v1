"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloArticulos
"""
from rest_framework import serializers
from .models import Articulo, ArticuloTraspaso

class ArticuloSerializer(serializers.ModelSerializer):
    zaa_dpto_etiqueta = serializers.SerializerMethodField('get_etiqueta')
    zaa_dpto = serializers.SerializerMethodField('get_dpto')
    zaa_subdpto_name = serializers.SerializerMethodField('get_subdpto_name')
    zaa_dpto_name = serializers.SerializerMethodField('get_dpto_name')
    zaa_cata_name = serializers.SerializerMethodField('get_cata_name')
    zaa__temporada = serializers.SerializerMethodField('get_temporada')
    zaa_sucursal = serializers.SerializerMethodField('get_sucursal')

    #Funciones de datos extra del articulo global
    zaa_nombre_arti = serializers.SerializerMethodField('get_zaag_nombre_arti')
    zaa_modelo = serializers.SerializerMethodField('get_zaag_modelo')
    zaa_clave = serializers.SerializerMethodField('get_zaag_clave')
    zaa_marca = serializers.SerializerMethodField('get_zaag_marca')
    zaa_catalogo = serializers.SerializerMethodField('get_zaag_catalogo')
    zaa_codigo_bar = serializers.SerializerMethodField('get_zaag_codigo_bar')
    zaa_categoria = serializers.SerializerMethodField('get_zaag_categoria')

    zaa_prec_cont = serializers.SerializerMethodField('get_zaag_prec_cont')
    zaa_prec_pag = serializers.SerializerMethodField('get_zaag_prec_pag')
    zaa_prect_mayo = serializers.SerializerMethodField('get_zaag_prect_mayo')
    zaa_prect_menud = serializers.SerializerMethodField('get_zaag_prect_menud')
    zaa_oferta = serializers.SerializerMethodField('get_zaag_oferta')
    zaa_id_catalogo = serializers.SerializerMethodField('get_zaag_id_catalogo')

    class Meta: 
        model = Articulo  
        fields = '__all__'
        #depth = 3
    
    def get_etiqueta(self, item):
        zaa_dpto_etiqueta = item.zaa_id_arti_global.zaag_id_subdep.zsude_id_dep.zde_nombre + ' - ' +  item.zaa_id_arti_global.zaag_id_subdep.zsude_nombre 
        return zaa_dpto_etiqueta
    
    def get_dpto(self, item):
        zaa_dpto = item.zaa_id_arti_global.zaag_id_subdep.zsude_id_dep.zde_id_dep
        return zaa_dpto
        
    def get_subdpto_name(self, item):
        zaa_subdpto_name = item.zaa_id_arti_global.zaag_id_subdep.zsude_nombre
        return zaa_subdpto_name
    
    def get_dpto_name(self, item):
        zaa_dpto_name = item.zaa_id_arti_global.zaag_id_subdep.zsude_id_dep.zde_nombre 
        return zaa_dpto_name
    
    def get_cata_name(self, item):
        zaa_cata_name = item.zaa_id_arti_global.zaag_id_catalogo.zca_nombre_ca
        return zaa_cata_name
    
    def get_temporada(self, item):
        zaa__temporada = item.zaa_id_arti_global.zaag_id_catalogo.zca_temporada
        return zaa__temporada

    def get_sucursal(self, item):
        zaa_sucursal = item.zaa_id_sucursal.zdsu_nombre + ' - ' + item.zaa_id_sucursal.zdsu_dir_municipio
        return zaa_sucursal

    #Funciones de datos extra del articulo global

    def get_zaag_nombre_arti(self, item):
        zaa_nombre_arti = item.zaa_id_arti_global.zaag_nombre_arti
        return zaa_nombre_arti
    
    def get_zaag_modelo(self, item):
        zaa_modelo = item.zaa_id_arti_global.zaag_modelo
        return zaa_modelo
    
    def get_zaag_clave(self, item):
        zaa_clave = item.zaa_id_arti_global.zaag_clave
        return zaa_clave
    
    def get_zaag_marca(self, item):
        zaa_marca = item.zaa_id_arti_global.zaag_marca
        return zaa_marca
    
    def get_zaag_catalogo(self, item):
        zaa_catalogo = item.zaa_id_arti_global.zaag_id_catalogo.zca_nombre_ca + ' - ' + item.zaa_id_arti_global.zaag_id_catalogo.zca_temporada
        return zaa_catalogo
    
    def get_zaag_codigo_bar(self, item):
        zaa_codigo_bar = item.zaa_id_arti_global.zaag_codigo_bar
        return zaa_codigo_bar
    
    def get_zaag_categoria(self, item):
        zaa_categoria = item.zaa_id_arti_global.zaag_categoria
        return zaa_categoria

    def get_zaag_prec_cont(self, item):
        zaa_prec_cont = item.zaa_id_arti_global.zaag_prec_cont
        return zaa_prec_cont
    
    def get_zaag_prec_pag(self, item):
        zaa_prec_pag = item.zaa_id_arti_global.zaag_prec_pag
        return zaa_prec_pag
    
    def get_zaag_prect_mayo(self, item):
        zaa_prect_mayo = item.zaa_id_arti_global.zaag_prect_mayo
        return zaa_prect_mayo
    
    def get_zaag_prect_menud(self, item):
        zaa_prect_menud = item.zaa_id_arti_global.zaag_prect_menud
        return zaa_prect_menud

    def get_zaag_oferta(self, item):
        zaa_oferta = item.zaa_id_arti_global.zaag_oferta
        return zaa_oferta
    
    def get_zaag_id_catalogo(self, item):
        zaa_id_catalogo = item.zaa_id_arti_global.zaag_id_catalogo.zca_id_catalogo
        return zaa_id_catalogo
    





# Serializer para Articulos de traspaso
class TraspasoArtiSerializer(serializers.ModelSerializer):
    zdtr_suc_salida = serializers.SerializerMethodField('get_zdtr_suc_salida')
    zdtr_suc_entrada = serializers.SerializerMethodField('get_zdtr_suc_entrada')
    zdtr_clave_art_trasp = serializers.SerializerMethodField('get_zdtr_clave_art_trasp')
    zdtr_rela_suc_sali_entr = serializers.SerializerMethodField('get_zdtr_rela_suc_sali_entr')

    class Meta:
        model = ArticuloTraspaso 
        fields = '__all__'
        #depth = 2

    def get_zdtr_suc_salida(self, item):
        zdtr_suc_salida = item.zdtr_id_sucursal_de_salida.zdsu_nombre + ' - ' + item.zdtr_id_sucursal_de_salida.zdsu_dir_municipio
        return zdtr_suc_salida
    
    def get_zdtr_suc_entrada(self, item):
        zdtr_suc_entrada = item.zdtr_id_sucursal_de_entrada.zdsu_nombre + ' - ' + item.zdtr_id_sucursal_de_entrada.zdsu_dir_municipio
        return zdtr_suc_entrada
    
    def get_zdtr_clave_art_trasp(self, item):
        zdtr_clave_art_trasp = item.zdtr_id_artic_trasp.zaa_id_arti_global.zaag_clave
        return zdtr_clave_art_trasp
    
    def get_zdtr_rela_suc_sali_entr(self, item):
        zdtr_rela_suc_sali_entr = item.zdtr_id_sucursal_de_salida.zdsu_nombre + ' - ' + item.zdtr_id_sucursal_de_entrada.zdsu_nombre
        return zdtr_rela_suc_sali_entr
    
