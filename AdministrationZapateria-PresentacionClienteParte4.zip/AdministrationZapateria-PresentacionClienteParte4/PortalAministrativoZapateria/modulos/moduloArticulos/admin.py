from django.contrib import admin
#from .models import Articulo, Catalogo
from .models import Articulo
# Register your models here.

class ArticuloAdmin(admin.ModelAdmin):
    #list_display = ('zaa_id_articulo', 'zaa_nombre_arti')
    list_display = ('zaa_id_articulo',)
   
admin.site.register(Articulo, ArticuloAdmin)