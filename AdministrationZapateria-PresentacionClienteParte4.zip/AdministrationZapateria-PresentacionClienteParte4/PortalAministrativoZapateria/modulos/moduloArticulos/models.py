"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tabla llamada zda_articulos
"""
from django.db import models
import uuid
from modulos.moduloArticulosGlobales.models import ArticuloGlobal
from modulos.moduloSucursales.models import Sucursal
from modulos.moduloUsuarios.models import Usuario 


class Articulo(models.Model):
    zaa_id_articulo = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zaa_color = models.JSONField()
    zaa_talla = models.JSONField()
    zaa_cantidad = models.IntegerField()
    zaa_existen = models.BooleanField(default=True)
    zaa_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    zaa_id_arti_global = models.ForeignKey(ArticuloGlobal, on_delete=models.CASCADE)

    class Meta:
        permissions = [('manage_articulos', 'Puede Gestionar Artículos')]
        db_table = "zda_articulos"   

# Traspasos de articulos
class ArticuloTraspaso(models.Model):
    zdtr_id_traspaso = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdtr_id_sucursal_de_salida = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='zdtr_id_sucursal_de_salida')
    zdtr_id_sucursal_de_entrada = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='zdtr_id_sucursal_de_entrada')
    zdtr_id_empleado_qgenero_trasp = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    zdtr_id_artic_trasp = models.ForeignKey(Articulo, on_delete=models.CASCADE)
    zdtr_fecha_creacion = models.DateTimeField(auto_now_add=True, null=False, blank=False)
    zdtr_fecha_modificacion = models.DateTimeField(auto_now=True, null=False, blank=False)
    zdtr_id_user_modifico = models.CharField(max_length=120)
    zdtr_cantidad = models.IntegerField()
    zdtr_folio_arti_trasp = models.CharField(max_length=100)
    zdtr_estatus_trasp = models.CharField(max_length=100)


    def __str__(self):
        return self.zdtr_id_traspaso
    class Meta:
        permissions = [('manage_articulos_traspaso', 'Puede Gestionar Artículos de Traspaso')]
        db_table = "zdtr_traspasos"  