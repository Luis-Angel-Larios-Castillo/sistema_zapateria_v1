"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloArticulos
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ArticuloViewSet, ArticulosActivosViewSet, ArtActCajaViewSet, InventarioSuc, PruebasViewSet, TraspArticulos

route =  routers.SimpleRouter()
route.register('admin' , ArticuloViewSet)
route.register('client' , ArticulosActivosViewSet)
route.register('artcaja' , ArtActCajaViewSet)
route.register('invSuc' , InventarioSuc)
route.register('pruebas' , PruebasViewSet)
route.register('traspaso' , TraspArticulos)

"""Rutas para el módulo de almacen, Sucursal Tlaxcala
route.register('InvSucTlaxcalaAccesorios', InventarioSucTlaxcalaAccesorios)
route.register('InvSucTlaxcalaBotas', InventarioSucTlaxcalaBotas)
route.register('InvSucTlaxcalaGorras', InventarioSucTlaxcalaGorras)
route.register('InvSucTlaxcalaChamarras', InventarioSucTlaxcalaChamarras)
route.register('InvSucTlaxcalaZapatos', InventarioSucTlaxcalaZapatos)
route.register('InvSucTlaxcalaPlayeras', InventarioSucTlaxcalaPlayeras)
route.register('InvSucTlaxcalaTennis', InventarioSucTlaxcalaTennis)"""
urlpatterns = route.urls