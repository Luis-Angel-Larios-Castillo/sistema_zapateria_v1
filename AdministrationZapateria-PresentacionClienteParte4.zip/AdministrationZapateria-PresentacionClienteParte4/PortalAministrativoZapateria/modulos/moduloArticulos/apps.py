from django.apps import AppConfig


class ModuloarticulosConfig(AppConfig):
    name = 'moduloArticulos'
