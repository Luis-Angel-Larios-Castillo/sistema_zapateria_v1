# Autor: Elisa Huerta Corona.
# Descripción: En el presente archivo se muestra la tabla de la base de datos para el registro de los clientes no afiliados.

from django.db import models  
import uuid
# Create your models here.

class ClientesNoAfiliados(models.Model):
    zc_id_cliente = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zc_nombre = models.CharField(max_length=45, null=False, blank=False)
    zc_apell_pat = models.CharField(max_length=45, null=False, blank=False)
    zc_apell_mat = models.CharField(max_length=45, null=False, blank=False)
    zc_num_telefono = models.CharField(max_length=15, null=False, blank=False)
    zc_num_cell = models.CharField(max_length=15, null=False, blank=False)
    zc_direccion = models.CharField(max_length=300, null=False, blank=False)
    zc_existen = models.BooleanField(default=True)
    zc_folio_client = models.CharField(max_length=20, null=False, blank=False, default='')
    
    class Meta:
        permissions = [('manage_clientes_no_afiliados', 'Puede Gestionar Clientes No Afiliados')]
        db_table ="zdc_cliente_NoAfi"