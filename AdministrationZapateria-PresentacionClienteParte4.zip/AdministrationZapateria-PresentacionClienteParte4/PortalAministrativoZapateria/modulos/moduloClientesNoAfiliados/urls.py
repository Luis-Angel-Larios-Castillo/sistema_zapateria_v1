from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ClientesNoAfiliadosViewSet

route =  routers.SimpleRouter()
route.register('' , ClientesNoAfiliadosViewSet)
urlpatterns = route.urls