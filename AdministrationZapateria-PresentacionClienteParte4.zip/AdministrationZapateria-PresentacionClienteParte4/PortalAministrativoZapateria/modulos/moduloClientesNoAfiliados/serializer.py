from rest_framework import serializers
from .models import ClientesNoAfiliados

class ClientesNoAfiliadosSerializer(serializers.ModelSerializer):
    nombre = serializers.SerializerMethodField('get_nombre_comp')
    class Meta:
        model = ClientesNoAfiliados
        fields = '__all__'
        
    def get_nombre_comp(self, item):
        nombre = item.zc_nombre + " " + item.zc_apell_pat + " " + item.zc_apell_mat  
        return nombre