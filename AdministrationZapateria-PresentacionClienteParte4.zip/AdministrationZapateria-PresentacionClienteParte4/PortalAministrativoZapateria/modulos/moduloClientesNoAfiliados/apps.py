from django.apps import AppConfig


class ModuloclientesnoafiliadosConfig(AppConfig):
    name = 'moduloClientesNoAfiliados'
