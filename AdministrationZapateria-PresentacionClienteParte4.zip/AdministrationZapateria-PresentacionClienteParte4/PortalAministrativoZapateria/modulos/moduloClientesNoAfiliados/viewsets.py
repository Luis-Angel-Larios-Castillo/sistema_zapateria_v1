from rest_framework import viewsets
from .models import ClientesNoAfiliados
from .serializer import ClientesNoAfiliadosSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters

class ClientesNoAfiliadosViewSet(viewsets.ModelViewSet):
    queryset = ClientesNoAfiliados.objects.all()
    serializer_class = ClientesNoAfiliadosSerializer
    search_fields = ['=zc_id_cliente']
    filter_backends = (filters.SearchFilter,)