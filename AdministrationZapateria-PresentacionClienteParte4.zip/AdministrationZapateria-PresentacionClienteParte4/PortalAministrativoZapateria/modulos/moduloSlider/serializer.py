"""
Autor: Mario Alberto Alonso Alvarado
Descripción: En este documento se establece el serializer que pertenece al Módulo de Slider
"""
from rest_framework import serializers
from .models import Slider

class SliderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Slider 
        fields = '__all__'