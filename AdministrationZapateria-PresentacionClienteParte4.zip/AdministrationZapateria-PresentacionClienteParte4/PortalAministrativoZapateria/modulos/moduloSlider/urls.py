"""
Autor: Mario Alberto Alonso Alvarado
Descripción: En este documento se establece las urls que pertenecen al moduloSlider
"""
from rest_framework import routers
from .viewsets import SliderViewSet

route =  routers.SimpleRouter()
route.register('' , SliderViewSet)
urlpatterns = route.urls