"""
Autor: Mario ALberto Alonso Alvarado
Descripción: En este documento se establece el viewsets que pertenecen al modulo de Slider
"""
from rest_framework import viewsets
from .models import Slider
from .serializer import SliderSerializer

class SliderViewSet(viewsets.ModelViewSet):
    search_fields = ['=zs_titulo_slider']
    queryset = Slider.objects.all().order_by('zs_titulo_slider')
    serializer_class = SliderSerializer