from django.apps import AppConfig


class ModulosliderConfig(AppConfig):
    name = 'moduloSlider'
