"""
Autor: Mario Alberto Alonso
Descripción: En este documento se establece la estructura de la tabla llamada zds_slider
"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario
import uuid 

class Slider(models.Model):
    zs_id_slider = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zs_titulo_slider = models.CharField(max_length=100, null=False, blank=False)
    zs_descrip_slider = models.CharField(max_length=200, null=False, blank=False)
    zs_fech_creat_slider = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de creación", null=False, blank=False)
    zs_fech_mod_slider = models.DateTimeField(auto_now=True, verbose_name="Fecha de modificación", null=False, blank=False)
    zs_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    class Meta:
        #permissions = [('manage_slider', 'Puede Gestionar Galería')]
        db_table = "zds_slider" 
    def __str__(self):
        return self.zs_titulo_slider 
    