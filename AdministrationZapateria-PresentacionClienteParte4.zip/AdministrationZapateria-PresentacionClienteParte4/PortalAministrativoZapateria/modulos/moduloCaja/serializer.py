"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloCaja
"""
from rest_framework import serializers
from .models import CajaCabecera, ItemCaja

class CajaCabeceraSerializer(serializers.ModelSerializer): 
    class Meta:
        model = CajaCabecera 
        fields = '__all__'
        #depth = 1 

class ListCajaSerializer(serializers.ModelSerializer):
    zca_empleado = serializers.SerializerMethodField('get_user_email')
    class Meta:
        model = CajaCabecera 
        fields = '__all__'
    def get_user_email(self, pedidocab):
        zca_empleado = pedidocab.zca_id_usuario.zdus_correo
        return zca_empleado

class ItemSerializer(serializers.ModelSerializer):
    zca_articulo = serializers.SerializerMethodField('get_articulo')
    class Meta:
        model = ItemCaja 
        fields = '__all__'
    def get_articulo(self, itemcaja):
        zca_articulo = itemcaja.zica_id_arti.zaa_nombre_arti
        return zca_articulo

class ItemAddSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemCaja 
        fields = '__all__'

'''
class PCAdminSerializer(serializers.ModelSerializer):
    zdus_correo = serializers.SerializerMethodField('get_user_email')
    class Meta:
        model = CajaCabecera 
        fields = '__all__'
    def get_user_email(self, cajacab):
        zdus_correo = cajacab.zped_id_usuario.zdus_correo
        return zdus_correo
'''
class ItemPriceSerializer(serializers.ModelSerializer):
    precio = serializers.SerializerMethodField('get_precio')
    class Meta:
        model = ItemCaja 
        fields = '__all__'
    def get_precio(self, itemcaja):
        precio = itemcaja.zipe_id_arti.zaa_prec_cont
        return precio