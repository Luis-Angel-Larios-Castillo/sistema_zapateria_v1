"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloCaja
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import ListOrderByDateViewSet, CabAscViewSet, CabDesViewSet, CajaCabeceraViewSet, ListCajaViewSet, ItemCajaViewSet, ItemByCCViewSet, ListVentasViewSet, ListVentasUsuarioViewSet, ListMoviViewSet, ListMoviByUserViewSet, CajaCabConceptoViewSet

route =  routers.SimpleRouter()
route.register('cabecera' , CajaCabeceraViewSet)
route.register('cabasc' , CabAscViewSet)
route.register('cabdes' , CabDesViewSet)
route.register('list' , ListCajaViewSet)
route.register('listmov' , ListMoviViewSet)
route.register('listbydate' , ListOrderByDateViewSet)
route.register('listmovuser' , ListMoviByUserViewSet)
route.register('listventas' , ListVentasViewSet)
route.register('listventasusuario' , ListVentasUsuarioViewSet)
route.register('item' , ItemCajaViewSet)
route.register('itemsbycab' , ItemByCCViewSet)
route.register('cabconcepto' , CajaCabConceptoViewSet)
urlpatterns = route.urls