"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloCaja
"""
from rest_framework import viewsets
from .models import CajaCabecera, ItemCaja
from .serializer import CajaCabeceraSerializer, ListCajaSerializer, ItemAddSerializer, ItemSerializer
from rest_framework import filters
from django.db.models import Q  

class CajaCabeceraViewSet(viewsets.ModelViewSet):
    queryset = CajaCabecera.objects.all().order_by('zca_fecha')
    serializer_class = CajaCabeceraSerializer    

class CabAscViewSet(viewsets.ModelViewSet): 
    search_fields = ['zca_id_usuario__zdus_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = CajaCabecera.objects.all().order_by('zca_fecha')
    serializer_class = CajaCabeceraSerializer   

class CabDesViewSet(viewsets.ModelViewSet):
    queryset = CajaCabecera.objects.all().order_by('-zca_fecha')
    serializer_class = CajaCabeceraSerializer  

class ListCajaViewSet(viewsets.ModelViewSet):
    queryset = CajaCabecera.objects.all().order_by('zca_fecha')
    serializer_class = ListCajaSerializer    

class ItemCajaViewSet(viewsets.ModelViewSet):
    queryset = ItemCaja.objects.all()
    serializer_class = ItemAddSerializer

class ItemByCCViewSet(viewsets.ModelViewSet):    
    serializer_class = ItemSerializer
    search_fields = ['=zica_id_caja_cab__zca_id_pedcab']
    filter_backends = (filters.SearchFilter,) 
    queryset = ItemCaja.objects.all()

class ListVentasViewSet(viewsets.ModelViewSet):    
    serializer_class = ListCajaSerializer
    queryset = CajaCabecera.objects.all().filter(zca_tipo = 'Venta').order_by('zca_fecha')

class ListMoviViewSet(viewsets.ModelViewSet):    
    serializer_class = ListCajaSerializer
    queryset = CajaCabecera.objects.all().filter(~Q(zca_tipo = 'Venta')).order_by('zca_fecha')

class ListVentasUsuarioViewSet(viewsets.ModelViewSet):    
    serializer_class = ListCajaSerializer
    search_fields = ['=zca_id_usuario__zdus_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = CajaCabecera.objects.all().filter(zca_tipo = 'Venta').order_by('zca_fecha')

class ListMoviByUserViewSet(viewsets.ModelViewSet):    
    serializer_class = ListCajaSerializer
    search_fields = ['=zca_id_usuario__zdus_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = CajaCabecera.objects.all().order_by('zca_hora')

class ListOrderByDateViewSet(viewsets.ModelViewSet):    
    serializer_class = ListCajaSerializer
    queryset = CajaCabecera.objects.all().order_by('zca_fecha')

class CajaCabConceptoViewSet(viewsets.ModelViewSet):
    queryset = CajaCabecera.objects.all()
    search_fields = ['zca_concepto']
    filter_backends = (filters.SearchFilter,)
    serializer_class = CajaCabeceraSerializer
