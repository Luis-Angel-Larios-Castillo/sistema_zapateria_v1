from django.apps import AppConfig


class ModulocajaConfig(AppConfig):
    name = 'moduloCaja'
