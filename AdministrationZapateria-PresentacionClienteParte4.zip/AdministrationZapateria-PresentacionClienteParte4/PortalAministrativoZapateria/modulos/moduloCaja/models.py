"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zca_caja_cab y zica_caja_item

"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario
from modulos.moduloArticulos.models import Articulo
import uuid 

class CajaCabecera(models.Model): 
    zca_id_pedcab = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zca_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    zca_nombre = models.CharField(max_length=100, default='')
    zca_tipo = models.CharField(max_length=40)
    zca_concepto = models.CharField(max_length=255, null=True)
    zca_fecha = models.DateField()
    zca_hora = models.TimeField()
    zca_total = models.FloatField(default=0)
    def __str__(self):
        return self.zca_tipo
    class Meta:
        #permissions = [('manage_caja_cab', 'Puede Gestionar Caja')]
        db_table = "zca_caja_cab"  


class ItemCaja(models.Model):
    zica_id_item_caj= models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zica_id_caja_cab = models.ForeignKey(CajaCabecera, on_delete=models.CASCADE)
    zica_id_arti = models.ForeignKey(Articulo, on_delete=models.CASCADE)
    zica_cant = models.IntegerField()
    zica_sub_tot = models.FloatField()
    zica_tot = models.FloatField()
    zica_des = models.FloatField()
    def __str__(self):
        return self.zica_id_item_caj
    class Meta:
        #permissions = [('manage_caja_item', 'Puede Gestionar Artículos de Caja')]
        db_table = "zica_caja_item" 
    """"""