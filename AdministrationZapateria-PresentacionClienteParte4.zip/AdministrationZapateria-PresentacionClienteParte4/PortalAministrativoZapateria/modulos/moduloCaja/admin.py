from django.contrib import admin
from .models import CajaCabecera, ItemCaja

# Register your models here.

class CajaCabeceraAdmin(admin.ModelAdmin):
    list_display = ('zca_id_pedcab', 'zca_id_usuario')
    
class ItemCajaAdmin(admin.ModelAdmin): 
    list_display = ('zica_id_item_caj', 'zica_cant')

admin.site.register(CajaCabecera, CajaCabeceraAdmin) 
admin.site.register(ItemCaja, ItemCajaAdmin) 
