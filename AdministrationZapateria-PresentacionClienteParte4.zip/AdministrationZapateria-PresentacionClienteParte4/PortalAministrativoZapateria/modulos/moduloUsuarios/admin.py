from django.contrib import admin
from .models import Usuario
# Register your models here.
class UsuarioAdmin(admin.ModelAdmin):
    list_display = ('zdus_correo', 'zdus_id_usuario')

admin.site.register(Usuario, UsuarioAdmin) 