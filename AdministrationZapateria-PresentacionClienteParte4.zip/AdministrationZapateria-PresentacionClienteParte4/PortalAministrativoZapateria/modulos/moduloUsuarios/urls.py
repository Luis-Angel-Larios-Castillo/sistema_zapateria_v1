"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloUsuarios
"""
from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .viewsets import GroupsAddViewSet, UsersViewSet, UserViewSet, TokenViewSet, GetUsuarioViewSet, GroupsViewSet, PermissionsViewSet
from .views import ChangePasswordView
router = DefaultRouter()
router.register('', UserViewSet),
router.register('token', TokenViewSet)
router.register('group', GroupsViewSet)
router.register('permissions', PermissionsViewSet)
router.register('getusuario', GetUsuarioViewSet)  
router.register('user-permissions', UsersViewSet)  
router.register('group-add', GroupsAddViewSet)  
urlpatterns = [
    path('', include(router.urls)),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
]