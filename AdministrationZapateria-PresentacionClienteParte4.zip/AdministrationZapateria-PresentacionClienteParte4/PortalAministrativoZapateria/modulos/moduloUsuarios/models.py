"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tabla llamada zdus_usuarios y los metodos de creación de nuevos usuarios

"""
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
import uuid

from rest_framework.decorators import permission_classes 

class UserProfileMAnager(BaseUserManager):
    def create_user(self, zdus_correo, password=None):
        if not zdus_correo:
            raise ValueError('Email obligatorio') 
        zdus_correo = self.normalize_email(zdus_correo) 
        user = self.model(zdus_correo = zdus_correo) 
        user.set_password(password) 
        user.save(using=self._db) 
        return user

    def create_superuser(self, zdus_correo, password):
        user = self.create_user(zdus_correo, password)
        user.is_superuser = True
        user.is_staff = True
        user.save(using=self._db)
        return user
    
    def create_staffuser(self, zdus_correo, password):
        user = self.create_user(zdus_correo, password)
        user.is_superuser = False
        user.is_staff = True
        user.save(using=self._db)
        return user


class Usuario(AbstractBaseUser, PermissionsMixin):
    zdus_id_usuario = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdus_correo = models.EmailField(unique=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_eliminated = models.BooleanField(default=False)

     
    class Meta:
        # Ejemplo de permiso creado desde el model, pueden crearce para establecer acciones 
                            #codename           #name
        # permissions = [('permiso_prueba', 'Este es un permiso creado con las migraciones.')]
        permissions = [('manage_usuarios', 'Puede Gestionar Usuarios')]
        db_table = "zdus_usuarios" 

    objects = UserProfileMAnager()
    USERNAME_FIELD = 'zdus_correo'

    def get_email(self):
        return self.zdus_correo

    def __str__(self):
        return self.zdus_correo 
        