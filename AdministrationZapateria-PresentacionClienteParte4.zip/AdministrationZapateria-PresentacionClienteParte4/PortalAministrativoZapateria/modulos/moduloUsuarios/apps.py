from django.apps import AppConfig


class ModulousuariosConfig(AppConfig):
    name = 'moduloUsuarios'
