"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloUsuarios
"""
from rest_framework import status, viewsets, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import Group, Permission
from .serializer import GroupAddSerializer, UserDataSerializer, ComprobarUsuarioSerializer, UsersSerializer, GroupSerializer,  PermissionSerializer, LoginSerializer, UsuarioModelSerializer, RegisterSerializer, TokenSerializer, GetUsuarioSerializer, RegisterStaffSerializer, RegisterAdminSerializer
from .models import Usuario
from rest_framework.permissions import IsAdminUser, IsAuthenticated
# Importar serializer para registrar a un administrador
# from .serializer import RegisterAdminSerializer 
class UsersViewSet(viewsets.ModelViewSet):   
    queryset = Usuario.objects.all().filter(is_staff=True, is_superuser=False)
    serializer_class = UsersSerializer 

class GroupsViewSet(viewsets.ModelViewSet):  
    permission_classes = [IsAuthenticated]
    queryset = Group.objects.all()
    serializer_class = GroupSerializer 

class GroupsAddViewSet(viewsets.ModelViewSet):  
    permission_classes = [IsAdminUser]
    queryset = Usuario.objects.all()
    serializer_class = GroupAddSerializer  

class UserViewSet(viewsets.GenericViewSet):
    queryset = Usuario.objects.filter(is_active=True)
    serializer_class = UsuarioModelSerializer

    @action(detail=False, methods=['post'])
    def compuser(self, request):
        serializer = ComprobarUsuarioSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        data = {
            'user': UserDataSerializer(user).data
        }
        return Response(data, status=status.HTTP_201_CREATED)  

    @action(detail=False, methods=['post'])
    def login(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user, token = serializer.save()
        data = {
            'user': UsuarioModelSerializer(user).data,
            'access_token': token
        }
        return Response(data, status=status.HTTP_201_CREATED)  

    @action(detail=False, methods=['post'])
    def signup(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        data = UsuarioModelSerializer(user).data
        return Response(data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['post'])
    def signupstaff(self, request):
        serializer = RegisterStaffSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        data = UsuarioModelSerializer(user).data
        return Response(data, status=status.HTTP_201_CREATED)
# Registro de un administrador 
    @action(detail=False, methods=['post'])
    def signupadmin(self, request):
        serializer = RegisterAdminSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        data = UsuarioModelSerializer(user).data
        return Response(data, status=status.HTTP_201_CREATED) 

class TokenViewSet(viewsets.ModelViewSet):
    queryset = Token.objects.all()
    serializer_class = TokenSerializer

class GetUsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = GetUsuarioSerializer
    #Lineas de búsqueda por Id
    search_fields = ['=zdus_id_usuario']
    filter_backends = (filters.SearchFilter,) 

class PermissionsViewSet(viewsets.ModelViewSet):  
    #permission_classes = [IsAuthenticated]
    queryset = Permission.objects.all().order_by('id').filter(name__contains = 'Puede')
    serializer_class = PermissionSerializer  
    @action(detail=False, methods=['get'])
    def traducir(self, request):
        # Permissions del moduloPedSucursal
        """perm = Permission.objects.get(codename="add_pedidosucursalcabecera") # codename
        perm.name = "Puede agregar Cabecera de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_pedidosucursalcabecera") # codename
        perm.name = "Puede editar Cabecera de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_pedidosucursalcabecera") # codename
        perm.name = "Puede observar Cabecera de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_pedidosucursalcabecera") # codename
        perm.name = "Puede eliminar Cabecera de un pedido de la sucursal" # Nuevo nombre
        perm.save()"""  

        """perm = Permission.objects.get(codename="add_itempedidosucursal") # codename
        perm.name = "Puede agregar Item de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_itempedidosucursal") # codename
        perm.name = "Puede editar Item de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_itempedidosucursal") # codename
        perm.name = "Puede observar Item de un pedido de la sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_itempedidosucursal") # codename
        perm.name = "Puede eliminar Item de un pedido de la sucursal" # Nuevo nombre
        perm.save() """
         # Permissions del moduloVales
        """perm = Permission.objects.get(codename="add_vale") # codename
        perm.name = "Puede agregar Vale" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_vale") # codename
        perm.name = "Puede editar Vale" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_vale") # codename
        perm.name = "Puede observar Vale" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_vale") # codename
        perm.name = "Puede eliminar Vale" # Nuevo nombre
        perm.save()
        """
        # Permissions del moduloSucursal
        """perm = Permission.objects.get(codename="add_sucursal") # codename
        perm.name = "Puede agregar Sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_sucursal") # codename
        perm.name = "Puede editar Sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_sucursal") # codename
        perm.name = "Puede observar Sucursales" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_sucursal") # codename
        perm.name = "Puede eliminar Sucursal" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloUsuario
        """perm = Permission.objects.get(codename="add_usuario") # codename
        perm.name = "Puede agregar Usuario" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_usuario") # codename
        perm.name = "Puede editar Usuario" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_usuario") # codename
        perm.name = "Puede observar Usuarios" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_usuario") # codename
        perm.name = "Puede eliminar Usuario" # Nuevo nombre
        perm.save()
        """

        # Permissions del moduloCarrusel
        """perm = Permission.objects.get(codename="add_slider") # codename
        perm.name = "Puede agregar Imagen del carrusel" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_slider") # codename
        perm.name = "Puede editar Imagen del carrusel" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_slider") # codename
        perm.name = "Puede observar Imágenes del carrusel" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_slider") # codename
        perm.name = "Puede eliminar Imagen del carrusel" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloProveedores
        """perm = Permission.objects.get(codename="add_proveedoreshistorico") # codename
        perm.name = "Puede agregar Histórico de proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_proveedoreshistorico") # codename
        perm.name = "Puede editar Histórico de proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_proveedoreshistorico") # codename
        perm.name = "Puede observar Histórico de proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_proveedoreshistorico") # codename
        perm.name = "Puede eliminar Histórico de proveedores" # Nuevo nombre
        perm.save() 
        perm = Permission.objects.get(codename="add_proveedores") # codename
        perm.name = "Puede agregar proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_proveedores") # codename
        perm.name = "Puede editar proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_proveedores") # codename
        perm.name = "Puede observar proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_proveedores") # codename
        perm.name = "Puede eliminar proveedores" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloPedidos
        """perm = Permission.objects.get(codename="add_itemintercambio") # codename
        perm.name = "Puede agregar Intercambio" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_itemintercambio") # codename
        perm.name = "Puede editar Intercambio" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_itemintercambio") # codename
        perm.name = "Puede observar Intercambios" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_itemintercambio") # codename
        perm.name = "Puede eliminar Intercambio" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_itempedido") # codename
        perm.name = "Puede agregar Ítem de un pedido" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_itempedido") # codename
        perm.name = "Puede editar Ítem de un pedido" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_itempedido") # codename
        perm.name = "Puede observar Ítems de un pedido" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_itempedido") # codename
        perm.name = "Puede eliminar Ítem de un pedido" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_pedidocabecera") # codename
        perm.name = "Puede agregar Cabecera de pedidos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_pedidocabecera") # codename
        perm.name = "Puede editar Cabecera de pedidos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_pedidocabecera") # codename
        perm.name = "Puede observar Cabeceras de pedidos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_pedidocabecera") # codename
        perm.name = "Puede eliminar Cabecera de pedidos" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloEmpleados
        """perm = Permission.objects.get(codename="add_empleados") # codename
        perm.name = "Puede agregar Empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_empleados") # codename
        perm.name = "Puede editar Empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_empleados") # codename
        perm.name = "Puede observar Empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_empleados") # codename
        perm.name = "Puede eliminar Empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_empleadoshistorico") # codename
        perm.name = "Puede agregar Histórico de empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_empleadoshistorico") # codename
        perm.name = "Puede editar Histórico de empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_empleadoshistorico") # codename
        perm.name = "Puede observar Histórico de empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_empleadoshistorico") # codename
        perm.name = "Puede eliminar Histórico de empleados" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloDepartamentos
        """perm = Permission.objects.get(codename="add_subdepartamento") # codename
        perm.name = "Puede agregar subdepartamento" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_subdepartamento") # codename
        perm.name = "Puede editar subdepartamento" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_subdepartamento") # codename
        perm.name = "Puede observar subdepartamentos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_subdepartamento") # codename
        perm.name = "Puede eliminar subdepartamento" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_departamento") # codename
        perm.name = "Puede agregar departamento" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_departamento") # codename
        perm.name = "Puede editar departamento" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_departamento") # codename
        perm.name = "Puede observar departamentos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_departamento") # codename
        perm.name = "Puede eliminar departamento" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloClientesNoAfiliados
        """perm = Permission.objects.get(codename="add_clientesnoafiliados") # codename
        perm.name = "Puede agregar Cliente no afiliado" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_clientesnoafiliados") # codename
        perm.name = "Puede editar Cliente no afiliado" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_clientesnoafiliados") # codename
        perm.name = "Puede observar Clientes no afiliados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_clientesnoafiliados") # codename
        perm.name = "Puede eliminar Cliente no afiliado" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloClientesAfiliados
        """perm = Permission.objects.get(codename="add_clientesafiliadoshistorico") # codename
        perm.name = "Puede agregar Histórico de Cliente afiliado " # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_clientesafiliadoshistorico") # codename
        perm.name = "Puede editar Histórico de Cliente afiliado " # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_clientesafiliadoshistorico") # codename
        perm.name = "Puede observar Histórico de Clientes afiliados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_clientesafiliadoshistorico") # codename
        perm.name = "Puede eliminar Histórico de Cliente afiliado " # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_clientesafiliados") # codename
        perm.name = "Puede agregar Cliente afiliado" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_clientesafiliados") # codename
        perm.name = "Puede editar Cliente afiliado" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_clientesafiliados") # codename
        perm.name = "Puede observar Clientes afiliados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_clientesafiliados") # codename
        perm.name = "Puede eliminar Cliente afiliado" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloCatalogos
        """perm = Permission.objects.get(codename="add_catalogo") # codename
        perm.name = "Puede agregar catálogo" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_catalogo") # codename
        perm.name = "Puede editar catálogo" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_catalogo") # codename
        perm.name = "Puede observar catalogos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_catalogo") # codename
        perm.name = "Puede eliminar catálogo" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloCaja
        """perm = Permission.objects.get(codename="add_itemcaja") # codename
        perm.name = "Puede agregar Ítem de caja" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_itemcaja") # codename
        perm.name = "Puede editar Ítem de caja" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_itemcaja") # codename
        perm.name = "Puede observar Ítems de caja" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_itemcaja") # codename
        perm.name = "Puede eliminar Ítem de caja" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="add_cajacabecera") # codename
        perm.name = "Puede agregar Caja cabecera" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_cajacabecera") # codename
        perm.name = "Puede editar Caja cabecera" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_cajacabecera") # codename
        perm.name = "Puede observar Caja cabeceras" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_cajacabecera") # codename
        perm.name = "Puede eliminar Caja cabecera" # Nuevo nombre
        perm.save()"""
        # Permissions del moduloArticulos
        """perm = Permission.objects.get(codename="add_articulo") # codename
        perm.name = "Puede agregar articulo" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="change_articulo") # codename
        perm.name = "Puede editar articulo" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="view_articulo") # codename
        perm.name = "Puede observar artículos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="delete_articulo") # codename
        perm.name = "Puede eliminar articulo" # Nuevo nombre
        perm.save()"""
        """
        # Permissions del moduloUsuarios
        perm = Permission.objects.get(codename="manage_usuarios") # codename
        perm.name = "Puede Gestionar Usuarios" # Nuevo nombre
        perm.save()

        # Permissions del moduloVales
        perm = Permission.objects.get(codename="authorize_vale") # codename
        perm.name = "Puede autorizar Vale" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_vales") # codename
        perm.name = "Puede Gestionar Vales" # Nuevo nombre
        perm.save()

        # Permissions del moduloArticulos
        perm = Permission.objects.get(codename="manage_articulos") # codename
        perm.name = "Puede Gestionar Artículos" # Nuevo nombre
        perm.save()

        # Permissions del moduloArticulos traspasos
        perm = Permission.objects.get(codename="manage_articulos_traspaso") # codename
        perm.name = "Puede Gestionar Artículos de Traspaso" # Nuevo nombre
        perm.save()

        # Permissions del moduloArticulos globales
        perm = Permission.objects.get(codename="manage_articulos_globales") # codename
        perm.name = "Puede Gestionar Artículos Globales" # Nuevo nombre
        perm.save()

        # Permissions del moduloCaja
        perm = Permission.objects.get(codename="manage_caja_cab") # codename
        perm.name = "Puede Gestionar Cabeceras de Caja" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_caja_item") # codename
        perm.name = "Puede Gestionar Items de Caja" # Nuevo nombre
        perm.save()

        # Permissions del moduloCatalogos
        perm = Permission.objects.get(codename="manage_catalogos") # codename
        perm.name = "Puede Gestionar Catalogos" # Nuevo nombre
        perm.save()

        # Permissions del moduloClientes Afiliados
        perm = Permission.objects.get(codename="manage_clientes_afiliados") # codename
        perm.name = "Puede Gestionar Clientes Afiliados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_clientes_afiliados_histotico") # codename
        perm.name = "Puede Gestionar Clientes Afiliados Histotico" # Nuevo nombre
        perm.save()

        # Permissions del moduloClientes No Afiliados
        perm = Permission.objects.get(codename="manage_clientes_no_afiliados") # codename
        perm.name = "Puede Gestionar Clientes No Afiliados" # Nuevo nombre
        perm.save()

        # Permissions del moduloDepartamentos
        perm = Permission.objects.get(codename="manage_departamentos") # codename
        perm.name = "Puede Gestionar Departamentos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_subdepartamentos") # codename
        perm.name = "Puede Gestionar SubDepartamentos" # Nuevo nombre
        perm.save()

        # Permissions del moduloEmpleados
        perm = Permission.objects.get(codename="manage_empleados") # codename
        perm.name = "Puede Gestionar Empleados" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_empleados_historico") # codename
        perm.name = "Puede Gestionar Empleados Histotico" # Nuevo nombre
        perm.save()

        # Permissions del moduloPedCabProv
        perm = Permission.objects.get(codename="manage_catalogos_proveedor_cabecera") # codename
        perm.name = "Puede Gestionar Cabeceras de Catalogos de proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_catalogos_proveedor_items") # codename
        perm.name = "Puede Gestionar Items de Catalogos de proveedores" # Nuevo nombre
        perm.save()

        # Permissions del moduloPedCabSuc
        perm = Permission.objects.get(codename="manage_ped_catalogos_sucursal_cab") # codename
        perm.name = "Puede Gestionar Cabeceras de Pedidos de Catalogos de Sucursal" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_ped_catalogos_sucursal_items") # codename
        perm.name = "Puede Gestionar Items de Pedidos de Catalogos de Sucursal" # Nuevo nombre
        perm.save()

        # Permissions del moduloPedidos
        perm = Permission.objects.get(codename="manage_pedidos_cabeceras") # codename
        perm.name = "Puede Gestionar Cabeceras de Pedidos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_pedidos_items") # codename
        perm.name = "Puede Gestionar Articulos de Pedidos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_items_intercambio") # codename
        perm.name = "Puede Gestionar Articulos de Intercambio" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_pedidos_catalogos_cabeceras") # codename
        perm.name = "Puede Gestionar Cabeceras de Pedidos de Catalogos" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_pedidos_catalogos_items") # codename
        perm.name = "Puede Gestionar Items de Pedidos de Catalogos" # Nuevo nombre
        perm.save()

        # Permissions del moduloPedProveedor
        perm = Permission.objects.get(codename="manage_pedidos_proveedores_cab") # codename
        perm.name = "Puede Gestionar Cabeceras de Pedidos de Proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_pedidos_proveedores_items") # codename
        perm.name = "Puede Gestionar items de Pedidos de Proveedores" # Nuevo nombre
        perm.save()

        # Permissions del moduloPedSucursal
        perm = Permission.objects.get(codename="manage_pedidos_sucursales_cab") # codename
        perm.name = "Puede Gestionar Cabeceras de Pedidos de Sucursales" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_pedidos_sucursales_items") # codename
        perm.name = "Puede Gestionar Items de Pedidos de Sucursales" # Nuevo nombre
        perm.save()

        # Permissions del moduloProveedores
        perm = Permission.objects.get(codename="manage_proveedores") # codename
        perm.name = "Puede Gestionar Proveedores" # Nuevo nombre
        perm.save()
        perm = Permission.objects.get(codename="manage_proveedores_historico") # codename
        perm.name = "Puede Gestionar Proveedores Historico" # Nuevo nombre
        perm.save()

        # Permissions del moduloSlider
        perm = Permission.objects.get(codename="manage_slider") # codename
        perm.name = "Puede Gestionar Galeria" # Nuevo nombre
        perm.save()

        # Permissions del moduloSucursales
        perm = Permission.objects.get(codename="manage_sucursales") # codename
        perm.name = "Puede Gestionar Sucursales" # Nuevo nombre
        perm.save()
        """
        return Response('Traducido',status=status.HTTP_201_CREATED)