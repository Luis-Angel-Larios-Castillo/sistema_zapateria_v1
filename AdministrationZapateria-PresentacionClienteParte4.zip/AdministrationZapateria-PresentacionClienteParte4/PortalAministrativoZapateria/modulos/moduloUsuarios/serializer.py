"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloUsuarios
"""
from django.contrib.auth.models import Group, Permission, PermissionsMixin
from rest_framework import fields, permissions, serializers 
from django.contrib.auth import password_validation, authenticate
from django.core.validators import RegexValidator, FileExtensionValidator
from rest_framework.validators import UniqueValidator
from rest_framework.authtoken.models import Token
from .models import Usuario 

class PermissionSerializer(serializers.ModelSerializer):    
    class Meta:
        model = Permission
        fields = '__all__' 

class PermissionsNameSerializer(serializers.ModelSerializer):    
    class Meta:
        model = Permission
        fields = '__all__'

class GroupSerializer(serializers.ModelSerializer):   
    class Meta:
        model = Group
        fields = ['id', 'name', 'permissions']
        #fields = ['id', 'name', 'permissions']

class GroupAddSerializer(serializers.ModelSerializer):    
    class Meta:
        model =  Usuario
        fields = ['zdus_id_usuario', 'zdus_correo', 'is_active', 'is_staff', 'is_superuser', 'is_eliminated', 'groups']

class UsersSerializer(serializers.ModelSerializer):  
    groups = GroupSerializer(many=True) 
    class Meta:
        model =  Usuario
        fields = ['zdus_id_usuario', 'zdus_correo', 'is_active', 'is_staff', 'is_superuser', 'is_eliminated', 'groups']
        

class ChangePasswordSerializer(serializers.Serializer):
    model = Usuario 
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)
 
class TokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = Token 
        fields = '__all__'
    
class GetUsuarioSerializer(serializers.ModelSerializer): 
    class Meta:
        model =  Usuario
        fields = ['zdus_id_usuario', 'zdus_correo', 'is_active', 'is_staff', 'is_superuser', 'is_eliminated']

class UsuarioModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = (
            'zdus_correo',
            'zdus_id_usuario',  
        )

class LoginSerializer(serializers.Serializer): 
    zdus_correo = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(username=data['zdus_correo'], password=data['password'])
        if not user:
            raise serializers.ValidationError('Las credenciales no son válidas')
        self.context['user'] = user
        return data

    def create(self, data):
        token, created = Token.objects.get_or_create(user=self.context['user'])
        return self.context['user'], token.key

class ComprobarUsuarioSerializer(serializers.Serializer):
    zdus_correo = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(username=data['zdus_correo'], password=data['password'])
        if not user:
            raise serializers.ValidationError('Las credenciales no son válidas')
        self.context['user'] = user  
        return data

    def create(self, data):  
        return self.context['user'] 

class UserDataSerializer(serializers.ModelSerializer):  
    groups = GroupSerializer(many=True) 
    class Meta:
        model =  Usuario
        fields = ['zdus_id_usuario', 'zdus_correo', 'is_staff', 'is_superuser', 'groups']

class RegisterSerializer(serializers.Serializer):
    zdus_correo = serializers.EmailField(
        validators=[UniqueValidator(queryset=Usuario.objects.all())]
    )
    password = serializers.CharField(min_length=8, max_length=64)
    password_confirmation = serializers.CharField(min_length=8, max_length=64)

    def validate(self, data):
        passwd = data['password'] 
        passwd_conf = data['password_confirmation']
        if passwd != passwd_conf:
            raise serializers.ValidationError("Las contraseñas no coinciden")
        password_validation.validate_password(passwd)

        return data

    def create(self, data):
        data.pop('password_confirmation')
        user = Usuario.objects.create_user(**data)
        return user 

class RegisterStaffSerializer(serializers.Serializer):
    zdus_correo = serializers.EmailField(
        validators=[UniqueValidator(queryset=Usuario.objects.all())]
    )
    password = serializers.CharField(min_length=8, max_length=64)
    password_confirmation = serializers.CharField(min_length=8, max_length=64)

    def validate(self, data):
        passwd = data['password']
        passwd_conf = data['password_confirmation']
        if passwd != passwd_conf:
            raise serializers.ValidationError("Las contraseñas no coinciden")
        password_validation.validate_password(passwd)

        return data

    def create(self, data):
        data.pop('password_confirmation')
        user = Usuario.objects.create_staffuser(**data)
        return user 

# Serializer para registrar a un administrador 
class RegisterAdminSerializer(serializers.Serializer):
    zdus_correo = serializers.EmailField(
        validators=[UniqueValidator(queryset=Usuario.objects.all())]
    )
    password = serializers.CharField(min_length=8, max_length=64)
    password_confirmation = serializers.CharField(min_length=8, max_length=64)
    def validate(self, data):
        passwd = data['password']
        passwd_conf = data['password_confirmation']
        if passwd != passwd_conf:
            raise serializers.ValidationError("Las contraseñas no coinciden")
        password_validation.validate_password(passwd)

        return data 
        
    def create(self, data):
        data.pop('password_confirmation')
        user = Usuario.objects.create_superuser(**data)
        return user  
