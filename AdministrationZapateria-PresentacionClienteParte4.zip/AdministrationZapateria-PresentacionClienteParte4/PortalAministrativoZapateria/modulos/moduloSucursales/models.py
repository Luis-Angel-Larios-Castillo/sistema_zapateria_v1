"""
Autor: Luis Angel Larios Cstillo
Descripción: En este documento se establece la estructura de la tabla llamada zdsu_sucursales
""" 
from django.db import models
import uuid
from django.contrib.auth.models import Permission

class Sucursal(models.Model):
    zdsu_id_sucursal = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdsu_nombre = models.CharField(max_length=70, null=False, blank=False)
    zdsu_dir_calle_1 = models.CharField(max_length=100, null=False, blank=False)
    zdsu_dir_calle_2 = models.CharField(max_length=100, null=False, blank=False)
    zdsu_dir_colonia = models.CharField(max_length=80, null=False, blank=False)
    zdsu_dir_municipio = models.CharField(max_length=80, null=False, blank=False)
    zdsu_dir_estado = models.CharField(max_length=50, null=False, blank=False)
    zdsu_dir_pais = models.CharField(max_length=35, null=False, blank=False)
    zdsu_dir_cod_postal = models.CharField(max_length=6, null=False, blank=False)
    zdsu_dir_num_ext = models.CharField(max_length=10, null=False, blank=False)
    zdsu_dir_num_int = models.CharField(max_length=10, null=False, blank=False)
    zdsu_num_tel = models.CharField(max_length=13)
    zdsu_estat_sucur = models.BooleanField(default=True)
    zdsu_folio_surcur = models.CharField(max_length=80, null=False, blank=False)
    zdsu_fech_crea = models.DateTimeField(auto_now_add=True)
    zdsu_fech_mod = models.DateTimeField(auto_now=True)

    class Meta:
        permissions = [('manage_sucursales', 'Puede Gestionar Sucursales')]
        db_table = "zdsu_sucursales"

    def __str__(self):
        return self.zdsu_nombre 