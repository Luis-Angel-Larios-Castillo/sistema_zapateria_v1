"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece las urls que pertenecen al modulo_sucursales
"""
from rest_framework import routers
from .viewsets import SucursalViewSet, SucursalactViewSet

route =  routers.SimpleRouter()
route.register('' , SucursalViewSet)
route.register('sucursales/activas' , SucursalactViewSet)
urlpatterns = route.urls