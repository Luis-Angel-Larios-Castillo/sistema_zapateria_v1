"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece el serializer que pertenece al Módulo de Sucursales
"""
from rest_framework import serializers
from .models import Sucursal

class SucursalSerializer(serializers.ModelSerializer):
    zdsu_etiqueta = serializers.SerializerMethodField('get_etiqueta')
    class Meta:
        model = Sucursal 
        fields = '__all__'
    def get_etiqueta(self, item):
        zdsu_etiqueta = item.zdsu_nombre + ' - ' + item.zdsu_dir_municipio
        return zdsu_etiqueta