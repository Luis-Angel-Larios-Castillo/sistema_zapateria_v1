"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece el viewsets que pertenece al Módulo de Sucursales
"""
from rest_framework import viewsets
from .models import Sucursal
from .serializer import SucursalSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters

class SucursalViewSet(viewsets.ModelViewSet):
    search_fields = ['=zdsu_nombre', 'zdsu_id_sucursal']
    #queryset = Sucursal.objects.all()
    queryset = Sucursal.objects.order_by('zdsu_fech_crea').reverse()
    serializer_class = SucursalSerializer

class SucursalactViewSet(viewsets.ModelViewSet):
    search_fields = ['=zdsu_nombre']
    queryset = Sucursal.objects.order_by('zdsu_fech_crea').reverse().filter(zdsu_estat_sucur=1)
    serializer_class = SucursalSerializer
