from django.apps import AppConfig


class ModulosucursalesConfig(AppConfig):
    name = 'moduloSucursales'
