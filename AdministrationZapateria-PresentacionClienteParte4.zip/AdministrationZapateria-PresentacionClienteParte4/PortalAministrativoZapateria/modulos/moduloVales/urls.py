"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece las urls que pertenecen al modulo_vales
"""
from rest_framework import routers
from .viewsets import ValeViewSet

route =  routers.SimpleRouter()
route.register('' , ValeViewSet)
urlpatterns = route.urls