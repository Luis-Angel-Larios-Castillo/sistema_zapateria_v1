"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece el viewsets que pertenece al Módulo de Vales
"""
from rest_framework import viewsets
from .models import Vale
from .serializer import ValeSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters

class ValeViewSet(viewsets.ModelViewSet):
    #search_fields = ['=zdv_folio_vale', '=zdv_gen_vale', 'zdv_id_vale', 'zdv_id_usuario__zdus_id_usuario', '=zdv_id_cliente']
    search_fields = ['=zdv_id_cliente', '=zdv_id_pedcab', '=zdv_id_sucursal__zdsu_id_sucursal']
    queryset = Vale.objects.order_by('zdv_fech_crea').reverse()
    serializer_class = ValeSerializer
    filter_backends = (filters.SearchFilter,) 

