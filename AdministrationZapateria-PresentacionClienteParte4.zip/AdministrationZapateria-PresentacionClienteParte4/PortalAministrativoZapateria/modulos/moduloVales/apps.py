from django.apps import AppConfig


class ModulovalesConfig(AppConfig):
    name = 'moduloVales'
