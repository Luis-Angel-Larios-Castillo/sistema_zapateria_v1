"""
Autor: Luis Angel Larios Castillo
Descripción: En este documento se establece el serializer que pertenece al Módulo de vales
"""
from rest_framework import serializers
from .models import Vale

class ValeSerializer(serializers.ModelSerializer):
    ID = serializers.SerializerMethodField('get_id')
    nom_item_ped=serializers.SerializerMethodField('get_zped_nombre')
    surcur_nombre=serializers.SerializerMethodField('get_zdsu_nombre')
    surcur_foli=serializers.SerializerMethodField('get_zdsu_folio_surcur')
    id_ped_cab=serializers.SerializerMethodField('get_zipe_id_pedido_cab')
    correo_empl=serializers.SerializerMethodField('get_zdus_correo')
     
    class Meta:
        model = Vale 
        fields = '__all__'
         
    def get_id(self, item):
        ID = item.zdv_id_vale
        return ID
    
    def get_zped_nombre(self, item):
        nom_item_ped = item.zdv_id_item_ped.zipe_id_pedido_cab.zped_nombre
        return nom_item_ped
    
    def get_zdsu_nombre(self, item):
        surcur_nombre = item.zdv_id_sucursal.zdsu_nombre
        return surcur_nombre
    
    def get_zdsu_folio_surcur(self, item):
        surcur_foli = item.zdv_id_sucursal.zdsu_folio_surcur
        return surcur_foli
    
    def get_zipe_id_pedido_cab(self, item):
        id_ped_cab = item.zdv_id_item_ped.zipe_id_pedido_cab.zped_id_pedcab
        return id_ped_cab
    
    def get_zdus_correo(self, item):
        correo_empl = item.zdv_id_empleado.zdus_correo
        return correo_empl 