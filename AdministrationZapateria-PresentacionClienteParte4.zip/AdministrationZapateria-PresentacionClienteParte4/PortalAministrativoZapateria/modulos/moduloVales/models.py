from django.db import models
import uuid
from modulos.moduloUsuarios.models import Usuario
from modulos.moduloSucursales.models import Sucursal
from modulos.moduloPedidos.models import ItemPedido


class Vale(models.Model):
    zdv_id_vale = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zdv_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE)
    zdv_id_item_ped = models.ForeignKey(ItemPedido, on_delete=models.CASCADE)
    zdv_id_empleado = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    zdv_id_cliente = models.CharField(max_length=100, null=True)
    zdv_id_user_autori = models.CharField(max_length=100, null=True)
    zdv_id_user_qcobra_vale = models.CharField(max_length=100, null=True)
    zdv_folio_vale = models.CharField(max_length=120, null=True)
    zdv_fech_crea = models.DateTimeField(auto_now_add=True)
    zdv_estat_vale = models.BooleanField(default=False)
    zdv_fecha_cobro = models.DateField(null=True)
    zdv_importe = models.FloatField(default=0)
    zdv_id_pedcab = models.CharField(max_length=120, null=True)

    class Meta:
        # Ejemplo de permiso creado desde el model, pueden crearce para establecer acciones 
                            #codename           #name
        # permissions = [('permiso_prueba', 'Este es un permiso creado con las migraciones.')]
        permissions = [('authorize_vale', 'Puede autorizar Vale'), ('manage_vales', 'Puede Gestionar Vales')]
        db_table = "zdv_vales"

    def __str__(self):
        return self.zdv_gen_vale


