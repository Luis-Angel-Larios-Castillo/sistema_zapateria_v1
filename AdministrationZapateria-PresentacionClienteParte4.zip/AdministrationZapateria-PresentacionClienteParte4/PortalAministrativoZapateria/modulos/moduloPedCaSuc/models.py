"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zpedsu_pedido_cata_sucur y zpedsu_pedido_cata_item_sucur
"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario 
from modulos.moduloSucursales.models import Sucursal
from modulos.moduloProveedores.models import Proveedores 
from modulos.moduloCatalogos.models import Catalogo
import uuid 
# Create your models here.

class PedidoCatalogoSucursalCabecera(models.Model):
    zpedcsuc_id_ped_cat_sucur = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedcsuc_nombre = models.CharField(max_length=100, null=True, blank=True)
    zpedcsuc_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='SucursalCatOri', blank=True)
    zpedcsuc_id_emple = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='EmpleadoCCaPS', blank=True)
    zpedcsuc_id_provee = models.ForeignKey(Proveedores, on_delete=models.CASCADE, related_name='IDProveedorPCaS', blank=True)
    zpedcsuc_fech_creat = models.DateTimeField(auto_now_add=True)
    zpedcsuc_fech_mod = models.DateTimeField(auto_now=True)
    zpedcsuc_puede_editar = models.BooleanField(default=True)
    zpedcsuc_id_emple_mod = models.CharField(max_length=100, null=True, blank=True)
    zpedcsuc_status_ped = models.CharField(max_length=50, null=False, blank=False) 
    
    def __str__(self):
        return self.zpedcsuc_nombre
    class Meta:
        permissions = [('manage_pedidos_catalogos_sucursal', 'Puede Gestionar Pedidos de Catálogos a Sucursal')]
        db_table = "zpedsu_pedido_cata_sucur"  

class ItemPedidoCatalogoSucursal(models.Model):
    zpedsucat_id_item_ped_cat = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedsucat_id_ped_cat_sucur = models.ForeignKey(PedidoCatalogoSucursalCabecera, on_delete=models.CASCADE, related_name='IDCabeceraPS', blank=True)
    zpedsucat_id_cat  = models.ForeignKey(Catalogo, on_delete=models.CASCADE, related_name='IDCatalogoPS', blank=True)  
    zpedsucat_cant_ped = models.IntegerField(default=0) 
    zpedsucat_cant_ped_llego = models.IntegerField(default=0)
 
    def __str__(self):
        return self.zpedsucat_cant_ped
    class Meta:
        #permissions = [('manage_ped_catalogos_sucursal_items', 'Puede Gestionar Pedidos de Catálogos a Sucursal')]
        db_table = "zpedsu_pedido_cata_item_sucur" 
