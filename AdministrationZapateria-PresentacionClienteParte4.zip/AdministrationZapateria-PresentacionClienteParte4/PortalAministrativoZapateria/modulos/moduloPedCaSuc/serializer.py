"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloPedCaSuc
"""
from rest_framework import serializers
from .models import PedidoCatalogoSucursalCabecera, ItemPedidoCatalogoSucursal

class PedidoCataSucursalCabeceraSerializer(serializers.ModelSerializer): 
    zpedcsuc_sucursal = serializers.SerializerMethodField('get_sucursal') 
    zpedcsuc_proveedor_nombre = serializers.SerializerMethodField('get_proveedor_nombre') 
    class Meta:
        model = PedidoCatalogoSucursalCabecera 
        fields = '__all__'
        #depth = 1 
    def get_sucursal(self, item):
        zpedcsuc_sucursal = item.zpedcsuc_id_sucursal.zdsu_nombre
        return zpedcsuc_sucursal 
    def get_proveedor_nombre(self, item):
        zpedcsuc_proveedor_nombre = item.zpedcsuc_id_provee.zp_identify_mark
        return zpedcsuc_proveedor_nombre 

class ItemCataPedidoSucursalSerializer(serializers.ModelSerializer): 
    zpedsucat_nombre = serializers.SerializerMethodField('get_nombre') 
    zpedsucat_marca = serializers.SerializerMethodField('get_marca') 
    zpedsucat_status = serializers.SerializerMethodField('get_status') 
    class Meta:
        model = ItemPedidoCatalogoSucursal 
        fields = '__all__'
        #depth = 1  
    def get_nombre(self, item):
        zpedsucat_nombre = item.zpedsucat_id_cat.zca_nombre_ca
        return zpedsucat_nombre
    def get_status(self, item):
        zpedsucat_status = item.zpedsucat_id_ped_cat_sucur.zpedcsuc_status_ped
        return zpedsucat_status  
    def get_marca(self, item):
        zpedsucat_marca = item.zpedsucat_id_cat.zca_id_proveedores.zp_identify_mark
        return zpedsucat_marca 