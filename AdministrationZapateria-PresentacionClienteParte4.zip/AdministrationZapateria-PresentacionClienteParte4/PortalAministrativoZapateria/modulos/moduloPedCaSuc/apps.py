from django.apps import AppConfig


class ModulopedcasucConfig(AppConfig):
    name = 'moduloPedCaSuc'
