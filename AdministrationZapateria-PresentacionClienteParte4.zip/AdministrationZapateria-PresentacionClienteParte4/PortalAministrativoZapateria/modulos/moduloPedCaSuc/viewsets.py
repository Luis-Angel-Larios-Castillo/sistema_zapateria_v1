"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloPedCaSuc
"""
from rest_framework import viewsets
from .models import PedidoCatalogoSucursalCabecera, ItemPedidoCatalogoSucursal
from .serializer import ItemCataPedidoSucursalSerializer, PedidoCataSucursalCabeceraSerializer
from rest_framework import filters
from django.db.models import Q  

class PedCabCatSucViewSet(viewsets.ModelViewSet):
    queryset = PedidoCatalogoSucursalCabecera.objects.all()
    serializer_class = PedidoCataSucursalCabeceraSerializer  
    search_fields = ['=zpedcsuc_id_sucursal__zdsu_id_sucursal', '=zpedcsuc_id_provee__zp_id_proveedor']
    filter_backends = (filters.SearchFilter,) 

class ItemCatPedSucViewSet(viewsets.ModelViewSet): 
    queryset = ItemPedidoCatalogoSucursal.objects.all()
    serializer_class = ItemCataPedidoSucursalSerializer  
    search_fields = ['=zpedsucat_id_ped_cat_sucur__zpedcsuc_id_ped_cat_sucur']
    filter_backends = (filters.SearchFilter,) 
    