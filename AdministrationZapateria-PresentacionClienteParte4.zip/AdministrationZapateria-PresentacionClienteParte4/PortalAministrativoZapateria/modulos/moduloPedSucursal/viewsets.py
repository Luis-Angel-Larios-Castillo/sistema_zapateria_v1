"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloDepartamentos
"""
from rest_framework import viewsets
from .models import PedidoSucursalCabecera, ItemPedidoSucursal
from .serializer import PedidoSucursalCabeceraSerializer, ItemPedidoSucursalSerializer
from rest_framework import filters
from django.db.models import Q  

class PedCabSucViewSet(viewsets.ModelViewSet):
    queryset = PedidoSucursalCabecera.objects.all()
    serializer_class = PedidoSucursalCabeceraSerializer  
    search_fields = ['=zpedsuc_id_sucursal__zdsu_id_sucursal', '=zpedsuc_id_provee__zp_id_proveedor']
    filter_backends = (filters.SearchFilter,) 

class ItemPedSucViewSet(viewsets.ModelViewSet): 
    queryset = ItemPedidoSucursal.objects.all()
    serializer_class = ItemPedidoSucursalSerializer  
    search_fields = ['=zpedsuca_id_ped_sucur__zpedsuc_id_ped_sucur']
    filter_backends = (filters.SearchFilter,) 
    