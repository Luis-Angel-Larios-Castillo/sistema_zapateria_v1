from django.apps import AppConfig


class ModulopedsucursalConfig(AppConfig):
    name = 'moduloPedSucursal'
