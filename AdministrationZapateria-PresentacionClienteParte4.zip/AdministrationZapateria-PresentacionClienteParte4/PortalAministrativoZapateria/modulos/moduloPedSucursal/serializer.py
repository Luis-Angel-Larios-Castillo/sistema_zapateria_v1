"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloPedSucursal
"""
from rest_framework import serializers
from .models import PedidoSucursalCabecera, ItemPedidoSucursal

class PedidoSucursalCabeceraSerializer(serializers.ModelSerializer): 
    zpedsuc_sucursal = serializers.SerializerMethodField('get_sucursal') 
    zpedpro_proveedor_nombre = serializers.SerializerMethodField('get_proveedor_nombre') 
    class Meta:
        model = PedidoSucursalCabecera 
        fields = '__all__'
        #depth = 1 
    def get_sucursal(self, item):
        zpedsuc_sucursal = item.zpedsuc_id_sucursal.zdsu_nombre
        return zpedsuc_sucursal 
    def get_proveedor_nombre(self, item):
        zpedpro_proveedor_nombre = item.zpedsuc_id_provee.zp_identify_mark
        return zpedpro_proveedor_nombre 

class ItemPedidoSucursalSerializer(serializers.ModelSerializer):
    zpedsuca_model = serializers.SerializerMethodField('get_model') 
    zpedsuca_marca = serializers.SerializerMethodField('get_marca') 
    zpedsuca_status = serializers.SerializerMethodField('get_status')  
    class Meta:
        model = ItemPedidoSucursal 
        fields = '__all__'
        #depth = 1   
    def get_status(self, item):
        zpedsuca_status = item.zpedsuca_id_ped_sucur.zpedsuc_status_ped
        return zpedsuca_status 
    def get_model(self, item):
        zpedsuca_model = item.zpedsuca_id_art.zaa_id_arti_global.zaag_modelo
        return zpedsuca_model 
    def get_marca(self, item):
        zpedsuca_marca = item.zpedsuca_id_art.zaa_id_arti_global.zaag_marca
        return zpedsuca_marca 