"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zpedsu_pedido_sucur y zpedsu_caja_item_sucur
"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario 
from modulos.moduloSucursales.models import Sucursal
from modulos.moduloProveedores.models import Proveedores
from modulos.moduloPedidos.models import PedidoCabecera
from modulos.moduloArticulos.models import Articulo
from rest_framework.settings import api_settings
import uuid 

class PedidoSucursalCabecera(models.Model):
    zpedsuc_id_ped_sucur = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedsuc_nombre = models.CharField(max_length=100, null=True, blank=True)
    zpedsuc_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='SucursalOri', blank=True)
    zpedsuc_id_emple = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='EmpleadoCPS', blank=True)
    zpedsuc_id_provee = models.ForeignKey(Proveedores, on_delete=models.CASCADE, related_name='IDProveedorPS', blank=True)
    zpedsuc_fech_creat = models.DateTimeField(auto_now_add=True)
    zpedsuc_fech_mod = models.DateTimeField(auto_now=True)
    zpedsuc_puede_editar = models.BooleanField(default=True)
    zpedsuc_id_emple_mod = models.CharField(max_length=100, null=True, blank=True)
    zpedsuc_status_ped = models.CharField(max_length=50, null=False, blank=False) 
    
    def __str__(self):
        return self.zpedsuc_status_ped
    class Meta:
        permissions = [('manage_pedidos_articulos_sucursales', 'Puede Gestionar Pedidos de Artículos a Sucursales')]
        db_table = "zpedsu_pedido_sucur"  

class ItemPedidoSucursal(models.Model):
    zpedsuca_id_item_caj = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False) 
    zpedsuca_id_ped_sucur = models.ForeignKey(PedidoSucursalCabecera, on_delete=models.CASCADE, related_name='IDCabeceraPS', blank=True)
    zpedsuca_id_art  = models.ForeignKey(Articulo, on_delete=models.CASCADE, related_name='IDArticuloPS', blank=True) 
    zpedsuca_color = models.CharField(max_length=50, null=False, blank=False)
    zpedsuca_talla = models.CharField(max_length=50, null=False, blank=False)
    zpedsuca_cant_ped = models.IntegerField(default=0) 
    zpedpro_cant_ped_llego = models.IntegerField(default=0) 
    zpedsuca_notas = models.JSONField(blank=True, null=True) 
 
    def __str__(self):
        return self.zpedsuca_id_item_caj
    class Meta:
        #permissions = [('manage_pedidos_sucursales_items', 'Puede Gestionar Artículos de Pedidos de Sucursales')]
        db_table = "zpedsu_pedido_item_sucur" 