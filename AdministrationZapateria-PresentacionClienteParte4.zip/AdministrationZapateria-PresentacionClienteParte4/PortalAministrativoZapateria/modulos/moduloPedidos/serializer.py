from rest_framework import serializers
from .models import PedidoCabecera, ItemPedido, ItemIntercambio, PedidoCabeceraCatalogos, ItemPedidoCatalogo
from modulos.moduloUsuarios.serializer import GetUsuarioSerializer 

class GenerarPedidoSerializer(serializers.ModelSerializer):
    zipe_fecha = serializers.SerializerMethodField('get_fecha')
    zipe_nombre = serializers.SerializerMethodField('get_nombre')
    zipe_modelo = serializers.SerializerMethodField('get_modelo')
    zipe_marca = serializers.SerializerMethodField('get_marca')
    class Meta:
        model = ItemPedido 
        fields = '__all__'
    def get_fecha(self, item):
        zipe_fecha = item.zipe_id_pedido_cab.zped_fecha
        return zipe_fecha 
    def get_nombre(self, item):
        zipe_nombre = item.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        #zipe_nombre = item.zipe_id_arti.zaa_nombre_arti
        return zipe_nombre 
    def get_modelo(self, item):
        zipe_modelo = item.zipe_id_arti.zaa_id_arti_global.zaag_modelo
        #zipe_modelo = item.zipe_id_arti.zaa_modelo
        return zipe_modelo
    def get_marca(self, item):
        zipe_marca = item.zipe_id_arti.zaa_id_arti_global.zaag_marca
        #zipe_marca = item.zipe_id_arti.zaa_marca
        return zipe_marca 

class PedidoCabeceraSerializer(serializers.ModelSerializer):
    restante = serializers.SerializerMethodField('get_restante')    
    class Meta:
        model = PedidoCabecera 
        fields = '__all__' 
    def get_restante(self, pedidocab):
        restante = pedidocab.zipe_total - pedidocab.zped_vale - pedidocab.zped_pagado
        return restante  

class ItemPedidoSerializer(serializers.ModelSerializer):
    zipe_fecha = serializers.SerializerMethodField('get_zipe_fecha')
    zipe_art_nom = serializers.SerializerMethodField('get_name')
    nomped_nomarti = serializers.SerializerMethodField('get_nomped_nomarti') 
    zipe_temporada = serializers.SerializerMethodField('get_temporada') 
    class Meta:
        model = ItemPedido 
        fields = '__all__'
        depth = 1

    def get_temporada(self, item):
        zipe_temporada = item.zipe_id_arti.zaa_id_arti_global.zaag_id_catalogo.zca_temporada
        #zipe_temporada = item.zipe_id_arti.zaa_id_catalogo.zca_temporada
        return zipe_temporada

    def get_name(self, item):
        zipe_art_nom = item.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        #zipe_art_nom = item.zipe_id_arti.zaa_nombre_arti
        return zipe_art_nom

    def get_zipe_fecha(self, item):
        zipe_fecha = item.zipe_id_pedido_cab.zped_fecha
        return zipe_fecha
    def get_nomped_nomarti(self, item):
        nomped_nomarti = item.zipe_id_pedido_cab.zped_nombre + " " + item.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti 
        return nomped_nomarti

class ItemAddSerializer(serializers.ModelSerializer):
    zipe_id_cliente = serializers.SerializerMethodField('get_cliente')
    zipe_pedido_nombre = serializers.SerializerMethodField('get_pedido_nombre')
    zipe_sucursal = serializers.SerializerMethodField('get_sucursal')
    zipe_temporada = serializers.SerializerMethodField('get_temporada') 
    zipe_fecha = serializers.SerializerMethodField('get_fecha')
    zica_temporada = serializers.SerializerMethodField('get_temporada')
    zipe_modelo = serializers.SerializerMethodField('get_modelo')
    zipe_marca = serializers.SerializerMethodField('get_marca')
    zipe_colores = serializers.SerializerMethodField('get_colores')
    zipe_tallas = serializers.SerializerMethodField('get_tallas')
    zipe_categoria = serializers.SerializerMethodField('get_categoria')
    zipe_nombre = serializers.SerializerMethodField('get_nombre')

    class Meta:
        model = ItemPedido 
        fields = '__all__' 
    def get_pedido_nombre(self, item):
        zipe_pedido_nombre = item.zipe_id_pedido_cab.zped_nombre
        return zipe_pedido_nombre 
    def get_cliente(self, item):
        zipe_id_cliente = item.zipe_id_pedido_cab.zped_id_usuario
        return zipe_id_cliente 
    def get_sucursal(self, item):
        zipe_sucursal = item.zipe_id_pedido_cab.zped_id_sucursal.zdsu_id_sucursal
        return zipe_sucursal
    def get_temporada(self, item):
        zipe_temporada = item.zipe_id_arti.zaa_id_arti_global.zaag_id_catalogo.zca_temporada
        #zipe_temporada = item.zipe_id_arti.zaa_id_catalogo.zca_temporada
        return zipe_temporada
    def get_tallas(self, item):
        zipe_tallas = item.zipe_id_arti.zaa_talla
        #zipe_tallas = item.zipe_id_arti.zaa_talla
        return zipe_tallas 
    def get_colores(self, item):
        zipe_colores = item.zipe_id_arti.zaa_color
        return zipe_colores 
    def get_fecha(self, item):
        zipe_fecha = item.zipe_id_pedido_cab.zped_fecha
        return zipe_fecha 
    def get_modelo(self, item):
        zipe_modelo = item.zipe_id_arti.zaa_id_arti_global.zaag_modelo
        #zipe_modelo = item.zipe_id_arti.zaa_modelo
        return zipe_modelo
    def get_marca(self, item):
        zipe_marca = item.zipe_id_arti.zaa_id_arti_global.zaag_marca
        #zipe_marca = item.zipe_id_arti.zaa_marca
        return zipe_marca
    def get_temporada(self, item):
        zica_temporada = item.zipe_id_arti.zaa_id_arti_global.zaag_id_catalogo.zca_temporada
        #zica_temporada = item.zipe_id_arti.zaa_id_catalogo.zca_temporada
        return zica_temporada
    def get_categoria(self, item):
        zipe_categoria = item.zipe_id_arti.zaa_id_arti_global.zaag_categoria
        return zipe_categoria
    def get_nombre(self, item):
        zipe_nombre = item.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        return zipe_nombre 

class ItemByUserSerializer(serializers.ModelSerializer): 
    zipe_pedido_fecha = serializers.SerializerMethodField('get_pedido_fecha')
    zipe_pedido_nombre = serializers.SerializerMethodField('get_pedido_nombre')
    zipe_id_cliente = serializers.SerializerMethodField('get_cliente')
    zipe_marca = serializers.SerializerMethodField('get_marca')
    zipe_art_nombre = serializers.SerializerMethodField('get_art_nombre')
    zipe_modelo = serializers.SerializerMethodField('get_modelo')
    zipe_sucursal = serializers.SerializerMethodField('get_sucursal') 
    zipe_proveedor_id = serializers.SerializerMethodField('get_proveedor_id')
    zipe_tipo = serializers.SerializerMethodField('get_tipo')
    zipe_fecha = serializers.SerializerMethodField('get_fecha')
    class Meta:
        model = ItemPedido 
        fields = '__all__'
    def get_pedido_fecha(self, item):
        zipe_pedido_fecha = item.zipe_id_pedido_cab.zped_fecha
        return zipe_pedido_fecha  
    def get_pedido_nombre(self, item):
        zipe_pedido_nombre = item.zipe_id_pedido_cab.zped_nombre
        return zipe_pedido_nombre 
    def get_fecha(self, item):
        zipe_fecha = item.zipe_id_pedido_cab.zped_fech_creat
        return zipe_fecha 
    def get_art_nombre(self, item):
        zipe_art_nombre = item.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        return zipe_art_nombre 
    def get_cliente(self, item):
        zipe_id_cliente = item.zipe_id_pedido_cab.zped_id_usuario
        return zipe_id_cliente 
    def get_marca(self, item):
        zipe_marca = item.zipe_id_arti.zaa_id_arti_global.zaag_marca
        #zipe_marca = item.zipe_id_arti.zaa_marca
        return zipe_marca 
    def get_modelo(self, item):
        zipe_modelo = item.zipe_id_arti.zaa_id_arti_global.zaag_modelo
        #zipe_modelo = item.zipe_id_arti.zaa_modelo
        return zipe_modelo
    def get_sucursal(self, item):
        zipe_sucursal = item.zipe_id_pedido_cab.zped_id_sucursal.zdsu_id_sucursal
        return zipe_sucursal 
    def get_proveedor_id(self, item):
        zipe_proveedor_id = item.zipe_id_arti.zaa_id_arti_global.zaag_id_catalogo.zca_id_proveedores.zp_id_proveedor
        #zipe_proveedor_id = item.zipe_id_arti.zaa_id_catalogo.zca_id_proveedores.zp_id_proveedor
        return zipe_proveedor_id
    def get_tipo(self, item):
        zipe_tipo = item.zipe_id_pedido_cab.zped_is_afi
        return zipe_tipo
    
class PCAdminSerializer(serializers.ModelSerializer): 
    class Meta:
        model = PedidoCabecera 
        fields = '__all__' 

class ItemPriceSerializer(serializers.ModelSerializer):
    precio = serializers.SerializerMethodField('get_precio')
    class Meta:
        model = ItemPedido 
        fields = '__all__'
    def get_precio(self, itempedido):
        precio = itempedido.zipe_id_arti.zaa_id_arti_global.zaag_prec_cont
        #precio = itempedido.zipe_id_arti.zaa_prec_cont
        return precio

class ItemIntercambioSerializer(serializers.ModelSerializer):
    class Meta:
        model = ItemIntercambio 
        fields = '__all__'
        
class ItemInterAdminSerializer(serializers.ModelSerializer):
    articuloorig = serializers.SerializerMethodField('get_articuloorig')
    articulonew = serializers.SerializerMethodField('get_articulonew')
    precio_orig = serializers.SerializerMethodField('get_precio_orig')
    claveorig = serializers.SerializerMethodField('get_claveori')
    clavenew = serializers.SerializerMethodField('get_clavenew')
    class Meta:
        model = ItemIntercambio 
        fields = '__all__'
        depth = 2
    
    def get_articuloorig(self, item):
        articuloorig = item.zpd_id_item_ori.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        return articuloorig

    def get_articulonew(self, item):
        articulonew = item.zpd_id_item_nue.zipe_id_arti.zaa_id_arti_global.zaag_nombre_arti
        return articulonew

    def get_claveori(self, item):
        claveorig = item.zpd_id_item_ori.zipe_id_arti.zaa_id_arti_global.zaag_clave
        return claveorig
    
    def get_clavenew(self, item):
        clavenew = item.zpd_id_item_nue.zipe_id_arti.zaa_id_arti_global.zaag_clave
        return clavenew

    
    
    def get_precio_orig(self, item):
        precio_orig = item.zpd_id_item_ori.zipe_sub_tot
        return precio_orig
    
#SERIALIZER DE PEDIDOS DE CATALOGOS
class PedidoCabeceraCatalogoSerializer(serializers.ModelSerializer):
    restante = serializers.SerializerMethodField('get_restante')
    class Meta:
        model = PedidoCabeceraCatalogos 
        fields = '__all__'
        #depth = 1
    def get_restante(self, pedidocabcat):
        restante = pedidocabcat.zpdcat_total - pedidocabcat.zpdcat_pagado
        return restante

class ItemPedidoCatalogoSerializer(serializers.ModelSerializer):
    zipcat_id_sucursal = serializers.SerializerMethodField('get_sucursal')
    zipcat_id_cliente = serializers.SerializerMethodField('get_cliente')
    zipcat_marca = serializers.SerializerMethodField('get_marca')
    nombre_cat = serializers.SerializerMethodField('get_nombre_cat')
    temporada = serializers.SerializerMethodField('get_temporada')
    class Meta:
        model = ItemPedidoCatalogo 
        fields = '__all__'
        #depth = 1
    def get_cliente(self, item):
        zipcat_id_cliente = item.zipcat_id_pedcabcat.zpdcat_id_usuario
        return zipcat_id_cliente

    def get_marca(self, item):
        zipcat_marca = item.zipcat_id_catalogo.zca_id_proveedores.zp_identify_mark
        return zipcat_marca

    def get_sucursal(self, item):
        zipcat_id_sucursal = item.zipcat_id_pedcabcat.zpdcat_id_sucursal.zdsu_id_sucursal
        return zipcat_id_sucursal

    def get_nombre_cat(self, item):
        nombre_cat = item.zipcat_id_catalogo.zca_nombre_ca
        return nombre_cat
    
    def get_temporada(self, item):
        temporada = item.zipcat_id_catalogo.zca_temporada
        return temporada