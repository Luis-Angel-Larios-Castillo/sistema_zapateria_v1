"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloPedidos
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import PedidoCabeceraViewSet, ItemPedByUserViewSet, GenerarPedidoViewSet, ItemPedidoViewSet, PCByUserViewSet, ItemByPCViewSet, PCEspeByUserViewSet, PCAdminViewSet, ItemPriceViewSet, ItemIntercambioViewSet, ItemInterAdminViewSet, ItemPedidoPreferidoViewSet, ItemPedidoOpcionalViewSet, PedidoCabeceraCatalogoViewSet, ItemPedidoCatalogoViewSet

route =  routers.SimpleRouter()
route.register('pedcab' , PedidoCabeceraViewSet)
route.register('pcuactiv' , PCByUserViewSet)
route.register('pcespbyu' , PCEspeByUserViewSet)
route.register('itembpc' , ItemByPCViewSet)
route.register('itemped' , ItemPedidoViewSet) 
route.register('itempric' , ItemPriceViewSet) 
route.register('pcadmin' , PCAdminViewSet) 
route.register('Itembyuser' , ItemPedByUserViewSet) 
route.register('iteminter' , ItemIntercambioViewSet) 
route.register('intercambiadmin' , ItemInterAdminViewSet) 
route.register('generar-pedido' , GenerarPedidoViewSet)
#Urls para buscar los pedidos que tienen items de tipo preferido y opcional
route.register('itempedpre' , ItemPedidoPreferidoViewSet) 
route.register('itempedopc' , ItemPedidoOpcionalViewSet) 
#URL DEL MODULO DE PEDIDOS CATALOGOS
route.register('pedcabcat' , PedidoCabeceraCatalogoViewSet)
route.register('itempedcat' , ItemPedidoCatalogoViewSet) 
urlpatterns = route.urls