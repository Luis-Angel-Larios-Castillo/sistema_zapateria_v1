from django.contrib import admin
from .models import PedidoCabecera, ItemPedido, ItemIntercambio
# Register your models here.

class PedidoCabeceraAdmin(admin.ModelAdmin):
    list_display = ('zped_id_pedcab', 'zped_id_usuario')
    
class ItemPedidoAdmin(admin.ModelAdmin): 
    list_display = ('zipe_id_item_ped', 'zipe_cant')
    
class ItemIntercambioAdmin(admin.ModelAdmin): 
    list_display = ('zpd_id_item_ori', 'zpd_id_item_nue')


admin.site.register(PedidoCabecera, PedidoCabeceraAdmin) 
admin.site.register(ItemPedido, ItemPedidoAdmin) 
admin.site.register(ItemIntercambio, ItemIntercambioAdmin) 