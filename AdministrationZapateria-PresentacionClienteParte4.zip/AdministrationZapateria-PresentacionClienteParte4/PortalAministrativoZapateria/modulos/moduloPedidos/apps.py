from django.apps import AppConfig


class ModulopedidosConfig(AppConfig):
    name = 'moduloPedidos'
