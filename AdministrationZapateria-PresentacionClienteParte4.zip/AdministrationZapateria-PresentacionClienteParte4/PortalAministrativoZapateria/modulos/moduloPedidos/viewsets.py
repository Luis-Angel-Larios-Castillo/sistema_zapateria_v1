"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloPedidos
"""
from rest_framework import viewsets
from .models import PedidoCabecera, ItemPedido, ItemIntercambio, PedidoCabeceraCatalogos, ItemPedidoCatalogo
from .serializer import ItemByUserSerializer, PedidoCabeceraSerializer, GenerarPedidoSerializer, ItemPedidoSerializer, ItemAddSerializer, PCAdminSerializer, ItemPriceSerializer, ItemIntercambioSerializer, ItemInterAdminSerializer , PedidoCabeceraCatalogoSerializer, ItemPedidoCatalogoSerializer
from django.shortcuts import get_object_or_404
from rest_framework import filters
from django.db.models import Q 
 

class PedidoCabeceraViewSet(viewsets.ModelViewSet):
    #Busqueda por id de usuario en la cabecera de los pedidos
    search_fields = ['=zped_id_usuario' , '=zped_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    queryset = PedidoCabecera.objects.order_by('zped_fech_creat').reverse()
    serializer_class = PedidoCabeceraSerializer    

class GenerarPedidoViewSet(viewsets.ModelViewSet):
    queryset = ItemPedido.objects.all().filter(zipe_status='Espera')
    serializer_class = GenerarPedidoSerializer

class ItemPedidoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zipe_id_pedido_cab__zped_id_pedcab']
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedido.objects.all()
    serializer_class = ItemAddSerializer 

#-------------------------------------------------------------------------------
#Consulta de items de pedido solo preferidos
class ItemPedidoPreferidoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zipe_id_pedido_cab__zped_id_pedcab', '=zipe_id_arti__zaa_id_articulo']
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedido.objects.all().filter(zica_tipo_articulo='Preferido')
    serializer_class = ItemAddSerializer

#Consulta de items de pedido solo opcionales
class ItemPedidoOpcionalViewSet(viewsets.ModelViewSet):
    search_fields = ['=zipe_id_pedido_cab__zped_id_pedcab']
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedido.objects.all().filter(zica_tipo_articulo='Opcional')
    serializer_class = ItemAddSerializer
#---------------------------------------------------------------------------------
# ViewSet para observar items resibiendo el id del cliente o el id de la sucursal
class ItemPedByUserViewSet(viewsets.ModelViewSet):
    search_fields = ['=zipe_id_pedido_cab__zped_id_usuario', '=zipe_id_pedido_cab__zped_id_sucursal__zdsu_id_sucursal' ]
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedido.objects.all()
    serializer_class = ItemByUserSerializer 

class PCByUserViewSet(viewsets.ModelViewSet):    
    serializer_class = PedidoCabeceraSerializer
    search_fields = ['=zped_id_usuario__zdus_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = PedidoCabecera.objects.all().filter(zped_status='Activo')

class ItemByPCViewSet(viewsets.ModelViewSet):    
    serializer_class = ItemPedidoSerializer
    search_fields = ['=zipe_id_pedido_cab__zped_id_pedcab']
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedido.objects.all()
 
class PCEspeByUserViewSet(viewsets.ModelViewSet):    
    serializer_class = PedidoCabeceraSerializer
    search_fields = ['=zped_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = PedidoCabecera.objects.all().filter(~Q(zped_status = 'Activo'))

class PCAdminViewSet(viewsets.ModelViewSet):
    search_fields = ['=zped_id_usuario' , '=zped_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)    
    serializer_class = PCAdminSerializer
    queryset = PedidoCabecera.objects.all().filter(~Q(zped_status = 'Activo'))

class ItemPriceViewSet(viewsets.ModelViewSet):    
    serializer_class = ItemPriceSerializer
    queryset = ItemPedido.objects.all()

class ItemIntercambioViewSet(viewsets.ModelViewSet):    
    serializer_class = ItemIntercambioSerializer
    queryset = ItemIntercambio.objects.all()
    
class ItemInterAdminViewSet(viewsets.ModelViewSet):    
    serializer_class = ItemInterAdminSerializer
    queryset = ItemIntercambio.objects.all()

#VIEWSETS PARA CABEZERA DE MODULO PEDIDOS CATALOGOS

class PedidoCabeceraCatalogoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zpdcat_id_usuario']
    filter_backends = (filters.SearchFilter,)
    queryset = PedidoCabeceraCatalogos.objects.order_by('zpdcat_fech_creat').reverse()
    serializer_class = PedidoCabeceraCatalogoSerializer    

class ItemPedidoCatalogoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zipcat_id_pedcabcat__zpdcat_id_pedcabcat', '=zipcat_id_pedcabcat__zpdcat_id_usuario', '=zipcat_id_pedcabcat__zpdcat_id_sucursal__zdsu_id_sucursal']
    filter_backends = (filters.SearchFilter,)
    queryset = ItemPedidoCatalogo.objects.all()
    serializer_class = ItemPedidoCatalogoSerializer
