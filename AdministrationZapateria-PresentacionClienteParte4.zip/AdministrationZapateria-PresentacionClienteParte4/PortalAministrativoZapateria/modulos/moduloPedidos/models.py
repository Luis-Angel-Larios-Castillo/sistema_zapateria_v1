"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zped_pedido_cab y zipe_item_ped

"""
from django.db import models
from modulos.moduloUsuarios.models import Usuario
from modulos.moduloSucursales.models import Sucursal
from modulos.moduloArticulos.models import Articulo
from modulos.moduloCatalogos.models import Catalogo
from modulos.moduloSucursales.models import Sucursal
from rest_framework.settings import api_settings
import uuid 

# Create your models here.
class PedidoCabecera(models.Model):
    zped_id_pedcab = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    #zped_id_usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='Cliente')
    zped_id_usuario = models.CharField(max_length=100, default='',)
    zped_id_empleado = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='Empleado', blank=True)
    zped_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='pedidoSucursal', blank=True)
    zped_nombre = models.CharField(max_length=100, default='')
    zped_status = models.CharField(max_length=40)
    zped_pagado = models.FloatField(default=0, blank=True, null=True)
    zped_fecha = models.DateField() 
    zped_vale = models.FloatField(default=0)
    zipe_total = models.FloatField(default=0)
    zped_fech_creat = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de creación", null=False, blank=False)
    # Nuevo campo para almacenar el tipo del usuario
    zped_is_afi = models.BooleanField(default=False)
    def __str__(self):
        return self.zped_status
    class Meta:
        permissions = [('manage_pedidos_articulos', 'Puede Gestionar Pedidos de Artículos')]
        db_table = "zped_pedido_cab"  

class ItemPedido(models.Model):
    zipe_id_item_ped= models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zipe_id_pedido_cab = models.ForeignKey(PedidoCabecera, on_delete=models.CASCADE)
    zipe_id_arti = models.ForeignKey(Articulo, on_delete=models.CASCADE)
    zipe_cant = models.IntegerField()
    zipe_devo = models.IntegerField(null=True)
    zipe_sub_tot = models.FloatField()
    zipe_status = models.CharField(max_length=40)
    zipe_color = models.CharField(max_length=40)
    zipe_talla = models.CharField(max_length=40)
    zica_tipo_articulo = models.CharField(max_length=20, default='')
    zipe_entregado = models.BooleanField(default=False)
    def __str__(self):
        return self.zipe_status
    class Meta:
        #permissions = [('manage_pedidos_items', 'Puede Gestionar Artículos de Pedidos')]
        db_table = "zipe_item_ped"  

class ItemIntercambio(models.Model):
    zpd_id_pedid_devol= models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zpd_id_item_ori = models.ForeignKey(ItemPedido, on_delete=models.CASCADE, related_name='zpd_id_item_ori')
    zpd_id_item_nue = models.ForeignKey(ItemPedido, on_delete=models.CASCADE, related_name='zpd_id_item_nue')
    def __str__(self):
        return self.zpd_id_pedid_devol
    class Meta:
        permissions = [('manage_items_intercambio', 'Puede Gestionar Artículos de Intercambio')]
        db_table = "zpd_pedid_devol"  



# MODELO PARA PEDIDOCAVEZERA CATALOGOS.
class PedidoCabeceraCatalogos(models.Model):
    zpdcat_id_pedcabcat = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zpdcat_id_sucursal = models.ForeignKey(Sucursal, on_delete=models.CASCADE, related_name='pedidoCataSucursal', blank=True)
    zpdcat_id_usuario = models.CharField(max_length=100, default='',)
    zpdcat_id_empleado = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='Empleado_catalogo', blank=True)
    zpdcat_nombre = models.CharField(max_length=100, default='')
    zpdcat_status = models.CharField(max_length=40)
    zpdcat_pagado = models.FloatField(default=0, blank=True, null=True) 
    zpdcat_fecha = models.DateField() 
    zpdcat_total = models.FloatField(default=0)
    zpdcat_fech_creat = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de creación", null=False, blank=False)
    def __str__(self):
        return self.zpdcat_nombre
    class Meta:
        permissions = [('manage_pedidos_catalogos', 'Puede Gestionar Pedidos de Catálogos')]
        db_table = "zpd_ped_cab_catalogo" 

#MODELO OARA ITEMS PEDIDOCAVEZERA CATALOGOS
class ItemPedidoCatalogo(models.Model):
    zipcat_id_itemped_cat= models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zipcat_id_pedcabcat = models.ForeignKey(PedidoCabeceraCatalogos, on_delete=models.CASCADE)
    zipcat_id_catalogo = models.ForeignKey(Catalogo, on_delete=models.CASCADE)
    zipcat_tipo_precio = models.CharField(max_length=50)
    zipcat_cant = models.IntegerField()
    zipcat_sub_tot = models.FloatField()
    zipcat_estatus_cat = models.CharField(max_length=50, null=True)
    def __str__(self):
        return self.zipcat_tipo_precio
    class Meta:
        #permissions = [('manage_pedidos_catalogos_items', 'Puede Gestionar Pedidos de Catálogos')]
        db_table = "zipe_item_ped_catalogo"  