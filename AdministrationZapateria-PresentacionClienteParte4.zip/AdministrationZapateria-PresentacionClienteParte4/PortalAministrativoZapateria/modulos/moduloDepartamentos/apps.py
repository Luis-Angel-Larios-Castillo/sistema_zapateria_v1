from django.apps import AppConfig


class ModulodepartamentosConfig(AppConfig):
    name = 'moduloDepartamentos'
