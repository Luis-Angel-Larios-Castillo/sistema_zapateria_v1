"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el serializer concerniente al moduloDepartamentos
"""
from rest_framework import serializers
from .models import Departamento, SubDepartamento

class DepartamentoSerializer(serializers.ModelSerializer):
    ID = serializers.SerializerMethodField('get_id')
    class Meta:
        model = Departamento 
        fields = '__all__'
        #depth = 1
    def get_id(self, item):
        ID = item.zde_id_dep
        return ID

class SubDepartamentoSerializer(serializers.ModelSerializer):
    zsude_departamento = serializers.SerializerMethodField('get_dep')
    zsude_etiqueta = serializers.SerializerMethodField('get_etiqueta')
    ID = serializers.SerializerMethodField('get_id')
    class Meta:
        model = SubDepartamento 
        fields = '__all__'
    def get_dep(self, item):
        zsude_departamento = item.zsude_id_dep.zde_nombre 
        return zsude_departamento
    def get_etiqueta(self, item):
        zsude_etiqueta = item.zsude_id_dep.zde_nombre + ' - ' + item.zsude_nombre
        return zsude_etiqueta
    def get_id(self, item):
        ID = item.zsude_id_subdep
        return ID