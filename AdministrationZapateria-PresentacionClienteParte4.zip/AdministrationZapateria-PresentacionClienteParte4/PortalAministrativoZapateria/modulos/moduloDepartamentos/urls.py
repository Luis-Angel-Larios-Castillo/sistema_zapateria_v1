"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece las urls concerniente al moduloDepartamentos
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from .viewsets import DepartamentoViewSet, SubDepartamentoViewSet

route =  routers.SimpleRouter()
route.register('dep' , DepartamentoViewSet)
route.register('subdep' , SubDepartamentoViewSet)
urlpatterns = route.urls