"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece el viewsets concerniente al moduloDepartamentos
"""
from rest_framework import viewsets
from .models import Departamento, SubDepartamento
from .serializer import DepartamentoSerializer, SubDepartamentoSerializer
from rest_framework import filters
from django.db.models import Q  

class DepartamentoViewSet(viewsets.ModelViewSet):
    queryset = Departamento.objects.all().order_by('zde_nombre')
    serializer_class = DepartamentoSerializer  

class SubDepartamentoViewSet(viewsets.ModelViewSet):
    search_fields = ['=zsude_id_dep__zde_id_dep']
    filter_backends = (filters.SearchFilter,) 
    queryset = SubDepartamento.objects.all().order_by('zsude_nombre')
    serializer_class = SubDepartamentoSerializer  
    