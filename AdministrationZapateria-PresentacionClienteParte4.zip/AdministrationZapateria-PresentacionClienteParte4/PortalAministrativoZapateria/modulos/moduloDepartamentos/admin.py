from django.contrib import admin
from .models import Departamento, SubDepartamento

# Register your models here.

class DepartamentoAdmin(admin.ModelAdmin):
    list_display = ('zde_id_dep', 'zde_nombre')
    
class SubDepartamentoAdmin(admin.ModelAdmin): 
    list_display = ('zsude_id_subdep', 'zsude_nombre', 'zsude_id_dep')

admin.site.register(Departamento, DepartamentoAdmin) 
admin.site.register(SubDepartamento, SubDepartamentoAdmin) 
