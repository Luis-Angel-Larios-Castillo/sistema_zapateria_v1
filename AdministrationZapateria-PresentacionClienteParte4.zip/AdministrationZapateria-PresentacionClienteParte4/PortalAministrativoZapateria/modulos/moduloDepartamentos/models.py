"""
Autor: Miguel Angel Zamora Carmona 
Descripción: En este documento se establece la estructura de la tablas llamadas zde_departamentos y zsude_subdepartamento

"""
from django.db import models
import uuid 

class Departamento(models.Model):
    zde_id_dep = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zde_nombre = models.CharField(max_length=100)
    zde_is_deleted = models.BooleanField(default=False)
    zde_fech_delet = models.DateTimeField(auto_now=True, null=False, blank=False)
    zde_usua_delet = models.CharField(max_length=50, null=True)
    def __str__(self):
        return self.zde_nombre
    class Meta:
        permissions = [('manage_departamentos', 'Puede Gestionar Departamentos')]
        db_table = "zde_departamentos"  

class SubDepartamento(models.Model):
    zsude_id_subdep= models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zsude_nombre = models.CharField(max_length=100)
    zsude_categoria = models.CharField(max_length=100, default="Calzado")
    zsude_id_dep = models.ForeignKey(Departamento, on_delete=models.CASCADE)
    zsude_is_deleted = models.BooleanField(default=False)
    zsude_fech_delet = models.DateTimeField(auto_now=True, null=False, blank=False)
    zsude_usua_delet = models.CharField(max_length=50, null=True)
    def __str__(self):
        return self.zsude_nombre
    class Meta:
        permissions = [('manage_subdepartamentos', 'Puede Gestionar SubDepartamentos')]
        db_table = "zsude_subdepartamento"  